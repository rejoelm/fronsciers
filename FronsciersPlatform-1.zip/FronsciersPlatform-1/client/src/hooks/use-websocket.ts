import { useEffect, useRef, useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";

interface WebSocketMessage {
  type: string;
  data?: any;
  timestamp?: string;
}

export function useWebSocket() {
  const [isConnected, setIsConnected] = useState(false);
  const wsRef = useRef<WebSocket | null>(null);
  const queryClient = useQueryClient();
  const { toast } = useToast();

  useEffect(() => {
    const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
    const wsUrl = `${protocol}//${window.location.host}/ws`;
    
    const connect = () => {
      try {
        const ws = new WebSocket(wsUrl);
        wsRef.current = ws;

        ws.onopen = () => {
          setIsConnected(true);
          console.log("WebSocket connected");
        };

        ws.onmessage = (event) => {
          try {
            const message: WebSocketMessage = JSON.parse(event.data);
            handleMessage(message);
          } catch (error) {
            console.error("Error parsing WebSocket message:", error);
          }
        };

        ws.onclose = () => {
          setIsConnected(false);
          console.log("WebSocket disconnected");
          
          // Reconnect after 3 seconds
          setTimeout(connect, 3000);
        };

        ws.onerror = (error) => {
          console.error("WebSocket error:", error);
          setIsConnected(false);
        };
      } catch (error) {
        console.error("Failed to create WebSocket connection:", error);
        setTimeout(connect, 3000);
      }
    };

    connect();

    return () => {
      if (wsRef.current) {
        wsRef.current.close();
      }
    };
  }, []);

  const handleMessage = (message: WebSocketMessage) => {
    switch (message.type) {
      case 'DASHBOARD_UPDATE':
        handleDashboardUpdate(message.data);
        break;
      case 'UPDATE_STAGE':
        handleStageUpdate(message.data);
        break;
      default:
        console.log("Unknown WebSocket message type:", message.type);
    }
  };

  const handleDashboardUpdate = (data: any) => {
    const { updateType } = data;
    
    switch (updateType) {
      case 'MANUSCRIPT_UPLOADED':
        // Invalidate relevant queries to trigger refetch
        queryClient.invalidateQueries({ queryKey: ['/api/dashboard/stats'] });
        queryClient.invalidateQueries({ queryKey: ['/api/manuscripts'] });
        queryClient.invalidateQueries({ queryKey: ['/api/manuscripts/user'] });
        queryClient.invalidateQueries({ queryKey: ['/api/recommendations/papers'] });
        queryClient.invalidateQueries({ queryKey: ['/api/recommendations/user-interests'] });
        
        toast({
          title: "Manuscript Uploaded",
          description: `"${data.title}" has been successfully uploaded and processed.`,
        });
        break;
        
      case 'REVIEW_SUBMITTED':
        queryClient.invalidateQueries({ queryKey: ['/api/dashboard/stats'] });
        queryClient.invalidateQueries({ queryKey: ['/api/reviews'] });
        queryClient.invalidateQueries({ queryKey: ['/api/manuscripts'] });
        
        toast({
          title: "Review Submitted",
          description: "Your review has been submitted successfully.",
        });
        break;
        
      case 'MANUSCRIPT_STATUS_CHANGED':
        queryClient.invalidateQueries({ queryKey: ['/api/dashboard/stats'] });
        queryClient.invalidateQueries({ queryKey: ['/api/manuscripts'] });
        
        toast({
          title: "Manuscript Status Updated",
          description: `Manuscript status changed to: ${data.newStatus}`,
        });
        break;
        
      case 'NEW_DAO_PROPOSAL':
        queryClient.invalidateQueries({ queryKey: ['/api/dao/proposals'] });
        
        toast({
          title: "New DAO Proposal",
          description: data.title,
        });
        break;
        
      default:
        console.log("Unknown dashboard update type:", updateType);
    }
  };

  const handleStageUpdate = (data: any) => {
    const { dociId, newStage } = data;
    
    // Invalidate DOCI-related queries
    queryClient.invalidateQueries({ queryKey: ['/api/doci'] });
    queryClient.invalidateQueries({ queryKey: [`/api/doci/${dociId}`] });
    
    toast({
      title: "Research Journey Update",
      description: `DOCI ${dociId} moved to stage: ${newStage}`,
    });
  };

  const sendMessage = (message: any) => {
    if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) {
      wsRef.current.send(JSON.stringify(message));
    }
  };

  const subscribeToUpdates = (type: string, id?: string) => {
    sendMessage({
      type: 'SUBSCRIBE',
      updateType: type,
      id
    });
  };

  const unsubscribeFromUpdates = (type: string, id?: string) => {
    sendMessage({
      type: 'UNSUBSCRIBE',
      updateType: type,
      id
    });
  };

  return {
    isConnected,
    sendMessage,
    subscribeToUpdates,
    unsubscribeFromUpdates
  };
}