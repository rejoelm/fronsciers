import { useWallet as useSolanaWallet } from '@solana/wallet-adapter-react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { solanaClient } from '@/lib/solana';
import type { User } from '@shared/schema';

export function useWallet() {
  const { 
    publicKey, 
    connected, 
    connecting, 
    disconnect,
    wallet
  } = useSolanaWallet();
  
  const queryClient = useQueryClient();

  // Get user data when wallet is connected
  const { data: user, isLoading: userLoading } = useQuery({
    queryKey: ['/api/users', publicKey?.toString()],
    queryFn: async () => {
      if (!publicKey) return null;
      
      try {
        const response = await fetch(`/api/users/${publicKey.toString()}`);
        if (!response.ok) {
          if (response.status === 404) {
            // User doesn't exist, create new user
            const createResponse = await apiRequest('POST', '/api/users', {
              walletAddress: publicKey.toString(),
            });
            return await createResponse.json();
          }
          throw new Error('Failed to fetch user');
        }
        return await response.json();
      } catch (error) {
        console.error('Error fetching user:', error);
        return null;
      }
    },
    enabled: !!publicKey && connected,
  });

  // Get token balances
  const { data: balances, isLoading: balancesLoading } = useQuery({
    queryKey: ['/api/tokens/balance', publicKey?.toString()],
    queryFn: async () => {
      if (!publicKey) return null;
      
      const response = await fetch(`/api/tokens/balance/${publicKey.toString()}`);
      if (!response.ok) {
        throw new Error('Failed to fetch balances');
      }
      return await response.json();
    },
    enabled: !!publicKey && connected,
    refetchInterval: 30000, // Refresh every 30 seconds
  });

  // Create user mutation
  const createUserMutation = useMutation({
    mutationFn: async (userData: Partial<User>) => {
      const response = await apiRequest('POST', '/api/users', {
        walletAddress: publicKey?.toString(),
        ...userData,
      });
      return await response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/users', publicKey?.toString()] });
    },
  });

  // Disconnect function that clears cache
  const handleDisconnect = async () => {
    await disconnect();
    queryClient.clear();
  };

  return {
    // Wallet connection state
    publicKey,
    connected,
    connecting,
    disconnect: handleDisconnect,
    wallet,
    
    // User data
    user,
    userLoading,
    
    // Balances
    balances: balances || { fronsBalance: 0, solBalance: 0 },
    balancesLoading,
    
    // Mutations
    createUser: createUserMutation.mutate,
    isCreatingUser: createUserMutation.isPending,
    
    // Computed values
    isLoading: connecting || userLoading || balancesLoading,
    walletAddress: publicKey?.toString(),
  };
}
