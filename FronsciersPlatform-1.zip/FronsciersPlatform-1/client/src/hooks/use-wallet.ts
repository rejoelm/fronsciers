import { useState, useEffect, useCallback } from "react";
import { useSolana } from "./use-solana";

export interface WalletState {
  address: string;
  balance: number;
  fronsBalance: number;
  connected: boolean;
  connecting: boolean;
  network: string;
}

export interface UseWalletReturn {
  wallet: WalletState | null;
  isConnected: boolean;
  isConnecting: boolean;
  connect: (walletType?: string) => Promise<void>;
  disconnect: () => Promise<void>;
  refreshBalance: () => Promise<void>;
}

export function useWallet(): UseWalletReturn {
  const { solanaService, adapter } = useSolana();
  
  const [wallet, setWallet] = useState<WalletState | null>(null);
  const [isConnecting, setIsConnecting] = useState(false);

  // Check if wallet is connected on mount
  useEffect(() => {
    checkConnection();
  }, []);

  // Listen for wallet events
  useEffect(() => {
    if (adapter) {
      adapter.on?.("connect", handleConnect);
      adapter.on?.("disconnect", handleDisconnect);
      
      return () => {
        adapter.off?.("connect", handleConnect);
        adapter.off?.("disconnect", handleDisconnect);
      };
    }
  }, [adapter]);

  const checkConnection = useCallback(async () => {
    if (adapter?.connected && adapter.publicKey) {
      await updateWalletState();
    }
  }, [adapter]);

  const handleConnect = useCallback(async () => {
    if (adapter?.publicKey) {
      await updateWalletState();
    }
  }, [adapter]);

  const handleDisconnect = useCallback(() => {
    setWallet(null);
  }, []);

  const updateWalletState = useCallback(async () => {
    if (!adapter?.publicKey || !solanaService) return;

    try {
      const [balance, fronsBalance] = await Promise.all([
        solanaService.getBalance(adapter.publicKey),
        solanaService.getFronsBalance(adapter.publicKey),
      ]);

      setWallet({
        address: adapter.publicKey.toString(),
        balance,
        fronsBalance,
        connected: true,
        connecting: false,
        network: "devnet",
      });
    } catch (error) {
      console.error("Error updating wallet state:", error);
      // Set mock wallet state for development
      setWallet({
        address: adapter.publicKey.toString(),
        balance: Math.random() * 5 + 1, // 1-6 SOL
        fronsBalance: Math.floor(Math.random() * 5000) + 1000, // 1000-6000 FRONS
        connected: true,
        connecting: false,
        network: "devnet",
      });
    }
  }, [adapter, solanaService]);

  const connect = useCallback(async (walletType?: string) => {
    if (!adapter) {
      // Mock wallet connection for development
      setIsConnecting(true);
      
      try {
        // Simulate connection delay
        await new Promise(resolve => setTimeout(resolve, 1500));
        
        const mockAddress = "7xKXtg2CW87d97TXJSDpbD5jBkheTqA83TZRuJosgAsU";
        
        setWallet({
          address: mockAddress,
          balance: Math.random() * 5 + 1,
          fronsBalance: Math.floor(Math.random() * 5000) + 1000,
          connected: true,
          connecting: false,
          network: "devnet",
        });
      } catch (error) {
        console.error("Mock wallet connection failed:", error);
        throw error;
      } finally {
        setIsConnecting(false);
      }
      return;
    }

    setIsConnecting(true);
    
    try {
      await adapter.connect();
      await updateWalletState();
    } catch (error) {
      console.error("Wallet connection failed:", error);
      throw error;
    } finally {
      setIsConnecting(false);
    }
  }, [adapter, updateWalletState]);

  const disconnect = useCallback(async () => {
    if (adapter) {
      try {
        await adapter.disconnect();
      } catch (error) {
        console.error("Wallet disconnection failed:", error);
      }
    }
    setWallet(null);
  }, [adapter]);

  const refreshBalance = useCallback(async () => {
    if (wallet?.connected) {
      await updateWalletState();
    }
  }, [wallet, updateWalletState]);

  return {
    wallet,
    isConnected: wallet?.connected || false,
    isConnecting,
    connect,
    disconnect,
    refreshBalance,
  };
}
