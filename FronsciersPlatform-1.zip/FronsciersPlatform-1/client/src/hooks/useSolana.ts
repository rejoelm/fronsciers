import { useConnection, useWallet } from '@solana/wallet-adapter-react';
import { PublicKey, Transaction } from '@solana/web3.js';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { solanaClient } from '@/lib/solana';

export function useSolana() {
  const { connection } = useConnection();
  const { publicKey, sendTransaction } = useWallet();
  const queryClient = useQueryClient();

  // Send transaction mutation
  const sendTransactionMutation = useMutation({
    mutationFn: async ({ transaction }: { transaction: Transaction }) => {
      if (!publicKey || !sendTransaction) {
        throw new Error('Wallet not connected');
      }

      const { blockhash } = await connection.getLatestBlockhash();
      transaction.recentBlockhash = blockhash;
      transaction.feePayer = publicKey;

      const signature = await sendTransaction(transaction, connection);
      await connection.confirmTransaction(signature, 'confirmed');
      
      return signature;
    },
    onSuccess: () => {
      // Invalidate balance queries after successful transaction
      queryClient.invalidateQueries({ 
        queryKey: ['/api/tokens/balance', publicKey?.toString()] 
      });
    },
  });

  // Get account info
  const getAccountInfo = async (address: PublicKey) => {
    return await connection.getAccountInfo(address);
  };

  // Get token accounts
  const getTokenAccounts = async (owner: PublicKey, mint?: PublicKey) => {
    if (mint) {
      return await connection.getTokenAccountsByOwner(owner, { mint });
    }
    return await connection.getTokenAccountsByOwner(owner, { programId: new PublicKey('TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA') });
  };

  // Get balance
  const getBalance = async (address: PublicKey) => {
    return await connection.getBalance(address);
  };

  // Get token balance
  const getTokenBalance = async (tokenAccount: PublicKey) => {
    const balance = await connection.getTokenAccountBalance(tokenAccount);
    return parseFloat(balance.value.amount) / Math.pow(10, balance.value.decimals);
  };

  return {
    connection,
    sendTransaction: sendTransactionMutation.mutate,
    isSendingTransaction: sendTransactionMutation.isPending,
    getAccountInfo,
    getTokenAccounts,
    getBalance,
    getTokenBalance,
    publicKey,
  };
}
