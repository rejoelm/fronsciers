import { useState, useEffect, useMemo } from "react";
import { Connection, PublicKey } from "@solana/web3.js";
import { SolanaService } from "@/lib/solana";

// Mock wallet adapter interface for development
interface MockWalletAdapter {
  publicKey: PublicKey | null;
  connected: boolean;
  connecting: boolean;
  connect(): Promise<void>;
  disconnect(): Promise<void>;
  on?(event: string, handler: () => void): void;
  off?(event: string, handler: () => void): void;
}

export interface UseSolanaReturn {
  connection: Connection | null;
  adapter: MockWalletAdapter | null;
  solanaService: SolanaService | null;
  networkInfo: any;
  isLoading: boolean;
  error: string | null;
}

export function useSolana(): UseSolanaReturn {
  const [adapter, setAdapter] = useState<MockWalletAdapter | null>(null);
  const [networkInfo, setNetworkInfo] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const connection = useMemo(() => {
    try {
      return new Connection("https://api.devnet.solana.com", "confirmed");
    } catch (err) {
      setError("Failed to connect to Solana network");
      return null;
    }
  }, []);

  const solanaService = useMemo(() => {
    return connection ? new SolanaService() : null;
  }, [connection]);

  useEffect(() => {
    initializeSolana();
  }, []);

  const initializeSolana = async () => {
    setIsLoading(true);
    setError(null);

    try {
      // Check for available wallet adapters
      if (typeof window !== "undefined") {
        // Check for Phantom
        const phantomAdapter = (window as any).phantom?.solana;
        
        if (phantomAdapter) {
          setAdapter(phantomAdapter);
        } else {
          // Create mock adapter for development
          setAdapter(createMockAdapter());
        }
      } else {
        setAdapter(createMockAdapter());
      }

      // Get network info
      if (solanaService) {
        const info = await solanaService.getNetworkInfo();
        setNetworkInfo(info);
      }
    } catch (err) {
      console.error("Error initializing Solana:", err);
      setError("Failed to initialize Solana connection");
      // Still set mock adapter for development
      setAdapter(createMockAdapter());
    } finally {
      setIsLoading(false);
    }
  };

  const createMockAdapter = (): MockWalletAdapter => {
    let connected = false;
    let connecting = false;
    let publicKey: PublicKey | null = null;

    return {
      get publicKey() {
        return publicKey;
      },
      get connected() {
        return connected;
      },
      get connecting() {
        return connecting;
      },
      async connect() {
        connecting = true;
        
        // Simulate connection delay
        await new Promise(resolve => setTimeout(resolve, 1000));
        
        // Create mock public key
        publicKey = new PublicKey("7xKXtg2CW87d97TXJSDpbD5jBkheTqA83TZRuJosgAsU");
        connected = true;
        connecting = false;
      },
      async disconnect() {
        connected = false;
        publicKey = null;
      },
      on(event: string, handler: () => void) {
        // Mock event listener
        console.log(`Mock wallet: listening for ${event}`);
      },
      off(event: string, handler: () => void) {
        // Mock event listener removal
        console.log(`Mock wallet: removing listener for ${event}`);
      },
    };
  };

  return {
    connection,
    adapter,
    solanaService,
    networkInfo,
    isLoading,
    error,
  };
}
