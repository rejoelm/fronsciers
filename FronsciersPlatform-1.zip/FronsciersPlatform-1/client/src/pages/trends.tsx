import { useState, useEffect } from "react";
import { Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import fronsciersLogo from "@/assets/fronsciers-logo.png";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { LineChart, Line, AreaChart, Area, BarChart, Bar, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts";
import { WalletConnection } from "@/components/wallet-connection";
import { 
  TrendingUp, Globe, Activity, BarChart3, Users, FileText, 
  Quote, Eye, MapPin, Calendar, Clock, Flame, ArrowUp, 
  ArrowDown, Zap, Target, Search, Filter, RefreshCw
} from "lucide-react";

interface TrendData {
  date: string;
  publications: number;
  citations: number;
  reviews: number;
  activeUsers: number;
  fronsVolume: number;
}

interface CategoryData {
  name: string;
  publications: number;
  citations: number;
  growthRate: number;
  hotness: number;
  subcategories: string[];
  recentPapers: Array<{ title: string; citations: number }>;
}

interface GeographicData {
  country: string;
  countryCode: string;
  publications: number;
  citations: number;
  researchers: number;
  topInstitutions: string[];
  coordinates: { lat: number; lng: number };
  growthRate: number;
}

interface RealTimeActivity {
  id: number;
  type: string;
  title: string;
  author: string;
  timestamp: string;
  category: string;
  impact: string;
}

const COLORS = ['#6366f1', '#8b5cf6', '#ec4899', '#f59e0b', '#10b981', '#3b82f6', '#ef4444', '#84cc16', '#f97316', '#06b6d4'];

export default function Trends() {
  const [timeframe, setTimeframe] = useState("30d");
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [refreshing, setRefreshing] = useState(false);

  const { data: overviewData, isLoading: loadingOverview } = useQuery({
    queryKey: ["/api/trends/overview", { timeframe }],
    refetchInterval: 30000 // Refresh every 30 seconds
  });

  const { data: categoriesData, isLoading: loadingCategories } = useQuery({
    queryKey: ["/api/trends/categories"],
    refetchInterval: 60000 // Refresh every minute
  });

  const { data: geographicData, isLoading: loadingGeographic } = useQuery({
    queryKey: ["/api/trends/geographic"],
    refetchInterval: 60000
  });

  const { data: realTimeData, isLoading: loadingRealTime } = useQuery({
    queryKey: ["/api/trends/real-time"],
    refetchInterval: 10000 // Refresh every 10 seconds for real-time feel
  });

  const handleRefresh = () => {
    setRefreshing(true);
    // Manually trigger refresh of all queries
    setTimeout(() => setRefreshing(false), 1000);
  };

  const formatNumber = (num: number) => {
    if (num >= 1000000) return `${(num / 1000000).toFixed(1)}M`;
    if (num >= 1000) return `${(num / 1000).toFixed(1)}K`;
    return num.toString();
  };

  const getImpactColor = (impact: string) => {
    switch (impact) {
      case 'high': return 'text-red-600';
      case 'medium': return 'text-yellow-600';
      case 'low': return 'text-green-600';
      default: return 'text-gray-600';
    }
  };

  const getActivityIcon = (type: string) => {
    switch (type) {
      case 'publication': return <FileText className="h-4 w-4" />;
      case 'citation': return <Quote className="h-4 w-4" />;
      case 'review': return <Eye className="h-4 w-4" />;
      case 'collaboration': return <Users className="h-4 w-4" />;
      default: return <Activity className="h-4 w-4" />;
    }
  };

  const timeAgo = (timestamp: string) => {
    const now = new Date();
    const time = new Date(timestamp);
    const diff = Math.floor((now.getTime() - time.getTime()) / (1000 * 60));
    
    if (diff < 1) return 'Just now';
    if (diff < 60) return `${diff}m ago`;
    const hours = Math.floor(diff / 60);
    if (hours < 24) return `${hours}h ago`;
    const days = Math.floor(hours / 24);
    return `${days}d ago`;
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b bg-card/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 rounded-xl overflow-hidden">
                <img 
                  src={fronsciersLogo} 
                  alt="FRONSCIERS Logo" 
                  className="w-full h-full object-contain"
                />
              </div>
              <div>
                <h1 className="text-xl font-bold">FRONSCIERS</h1>
                <p className="text-sm text-muted-foreground">Research Trends</p>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <nav className="hidden md:flex space-x-6">
                <Link href="/">
                  <Button variant="ghost">Home</Button>
                </Link>
                <Link href="/dashboard">
                  <Button variant="ghost">Dashboard</Button>
                </Link>
                <Link href="/citations">
                  <Button variant="ghost">Citations</Button>
                </Link>
                <Link href="/governance">
                  <Button variant="ghost">Governance</Button>
                </Link>
              </nav>
              <Button 
                variant="outline" 
                size="sm" 
                onClick={handleRefresh}
                disabled={refreshing}
              >
                <RefreshCw className={`h-4 w-4 mr-2 ${refreshing ? 'animate-spin' : ''}`} />
                Refresh
              </Button>
              <WalletConnection />
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        {/* Hero Section */}
        <div className="text-center mb-12">
          <div className="flex items-center justify-center mb-4">
            <TrendingUp className="h-12 w-12 text-primary mr-3" />
            <h1 className="text-4xl font-bold">Research Trends</h1>
          </div>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Real-time insights into global research patterns, emerging topics, and academic collaboration networks
          </p>
        </div>

        {/* Real-time Metrics Bar */}
        {realTimeData && (
          <Card className="mb-8 bg-gradient-to-r from-blue-50 to-purple-50 border-blue-200">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-6">
                  <div className="flex items-center space-x-2">
                    <Activity className="h-5 w-5 text-green-600" />
                    <span className="text-sm text-muted-foreground">Live:</span>
                    <span className="font-semibold">{realTimeData.currentMetrics?.activeUsers} active users</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Eye className="h-5 w-5 text-blue-600" />
                    <span className="font-semibold">{realTimeData.currentMetrics?.ongoingReviews} reviews in progress</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Quote className="h-5 w-5 text-purple-600" />
                    <span className="font-semibold">{realTimeData.currentMetrics?.citationsToday} citations today</span>
                  </div>
                </div>
                <div className="flex items-center space-x-2">
                  <Flame className="h-5 w-5 text-orange-600" />
                  <span className="text-sm text-muted-foreground">Trending:</span>
                  <div className="flex space-x-2">
                    {realTimeData.currentMetrics?.trendingtopics?.slice(0, 3).map((topic: string) => (
                      <Badge key={topic} variant="secondary" className="text-xs">
                        {topic}
                      </Badge>
                    ))}
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        <Tabs defaultValue="overview" className="space-y-6">
          <TabsList className="grid w-full grid-cols-5">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="categories">Research Areas</TabsTrigger>
            <TabsTrigger value="geographic">Geographic</TabsTrigger>
            <TabsTrigger value="realtime">Live Activity</TabsTrigger>
            <TabsTrigger value="insights">AI Insights</TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview" className="space-y-6">
            <div className="flex items-center justify-between">
              <h2 className="text-2xl font-bold">Publication Trends</h2>
              <Select value={timeframe} onValueChange={setTimeframe}>
                <SelectTrigger className="w-32">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="7d">Last 7 days</SelectItem>
                  <SelectItem value="30d">Last 30 days</SelectItem>
                  <SelectItem value="90d">Last 90 days</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Summary Cards */}
            {overviewData && (
              <div className="grid md:grid-cols-5 gap-6 mb-8">
                <Card>
                  <CardContent className="pt-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm text-muted-foreground">Publications</p>
                        <p className="text-2xl font-bold">{overviewData.summary?.totalPublications || 0}</p>
                      </div>
                      <FileText className="h-8 w-8 text-blue-600" />
                    </div>
                    <div className="flex items-center mt-2">
                      {overviewData.summary?.growthRate >= 0 ? (
                        <ArrowUp className="h-4 w-4 text-green-600 mr-1" />
                      ) : (
                        <ArrowDown className="h-4 w-4 text-red-600 mr-1" />
                      )}
                      <span className={`text-sm ${overviewData.summary?.growthRate >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                        {Math.abs(overviewData.summary?.growthRate || 0).toFixed(1)}%
                      </span>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="pt-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm text-muted-foreground">Citations</p>
                        <p className="text-2xl font-bold">{formatNumber(overviewData.summary?.totalCitations || 0)}</p>
                      </div>
                      <Quote className="h-8 w-8 text-purple-600" />
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="pt-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm text-muted-foreground">Reviews</p>
                        <p className="text-2xl font-bold">{overviewData.summary?.totalReviews || 0}</p>
                      </div>
                      <Eye className="h-8 w-8 text-green-600" />
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="pt-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm text-muted-foreground">Active Users</p>
                        <p className="text-2xl font-bold">{overviewData.summary?.avgActiveUsers || 0}</p>
                      </div>
                      <Users className="h-8 w-8 text-orange-600" />
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="pt-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm text-muted-foreground">FRONS Volume</p>
                        <p className="text-2xl font-bold">{formatNumber(overviewData.data?.reduce((sum: number, day: TrendData) => sum + day.fronsVolume, 0) || 0)}</p>
                      </div>
                      <BarChart3 className="h-8 w-8 text-yellow-600" />
                    </div>
                  </CardContent>
                </Card>
              </div>
            )}

            {/* Trend Charts */}
            <div className="grid lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Publication Activity</CardTitle>
                  <CardDescription>Daily publications and citations over time</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="h-80">
                    {loadingOverview ? (
                      <div className="flex items-center justify-center h-full">
                        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
                      </div>
                    ) : (
                      <ResponsiveContainer width="100%" height="100%">
                        <LineChart data={overviewData?.data || []}>
                          <CartesianGrid strokeDasharray="3 3" />
                          <XAxis dataKey="date" />
                          <YAxis />
                          <Tooltip />
                          <Legend />
                          <Line 
                            type="monotone" 
                            dataKey="publications" 
                            stroke="#6366f1" 
                            strokeWidth={2}
                            name="Publications"
                          />
                          <Line 
                            type="monotone" 
                            dataKey="citations" 
                            stroke="#8b5cf6" 
                            strokeWidth={2}
                            name="Citations"
                          />
                        </LineChart>
                      </ResponsiveContainer>
                    )}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>User Engagement</CardTitle>
                  <CardDescription>Active users and review activity</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="h-80">
                    {loadingOverview ? (
                      <div className="flex items-center justify-center h-full">
                        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
                      </div>
                    ) : (
                      <ResponsiveContainer width="100%" height="100%">
                        <AreaChart data={overviewData?.data || []}>
                          <CartesianGrid strokeDasharray="3 3" />
                          <XAxis dataKey="date" />
                          <YAxis />
                          <Tooltip />
                          <Legend />
                          <Area 
                            type="monotone" 
                            dataKey="activeUsers" 
                            stackId="1"
                            stroke="#10b981" 
                            fill="#10b981"
                            fillOpacity={0.6}
                            name="Active Users"
                          />
                          <Area 
                            type="monotone" 
                            dataKey="reviews" 
                            stackId="1"
                            stroke="#f59e0b" 
                            fill="#f59e0b"
                            fillOpacity={0.6}
                            name="Reviews"
                          />
                        </AreaChart>
                      </ResponsiveContainer>
                    )}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Research Categories Tab */}
          <TabsContent value="categories" className="space-y-6">
            <div className="flex items-center justify-between">
              <h2 className="text-2xl font-bold">Research Categories</h2>
              <div className="flex items-center space-x-2">
                <Flame className="h-5 w-5 text-orange-600" />
                <span className="text-sm text-muted-foreground">Sorted by hotness score</span>
              </div>
            </div>

            {loadingCategories ? (
              <div className="text-center py-8">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto"></div>
                <p className="text-muted-foreground mt-2">Loading category data...</p>
              </div>
            ) : (
              <div className="grid lg:grid-cols-2 gap-6">
                {categoriesData?.categories?.map((category: CategoryData, index: number) => (
                  <Card 
                    key={category.name} 
                    className={`cursor-pointer transition-all duration-200 hover:shadow-lg ${
                      selectedCategory === category.name ? 'ring-2 ring-primary' : ''
                    }`}
                    onClick={() => setSelectedCategory(selectedCategory === category.name ? null : category.name)}
                  >
                    <CardHeader>
                      <div className="flex items-center justify-between">
                        <CardTitle className="flex items-center">
                          <div 
                            className="w-4 h-4 rounded-full mr-3"
                            style={{ backgroundColor: COLORS[index % COLORS.length] }}
                          />
                          {category.name}
                        </CardTitle>
                        <div className="flex items-center space-x-2">
                          <Badge 
                            className={`${
                              category.hotness >= 90 ? 'bg-red-100 text-red-800 border-red-200' :
                              category.hotness >= 80 ? 'bg-orange-100 text-orange-800 border-orange-200' :
                              'bg-yellow-100 text-yellow-800 border-yellow-200'
                            }`}
                          >
                            {category.hotness}% hot
                          </Badge>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <div className="grid grid-cols-3 gap-4 mb-4">
                        <div className="text-center">
                          <div className="text-lg font-bold text-blue-600">{category.publications}</div>
                          <div className="text-xs text-muted-foreground">Publications</div>
                        </div>
                        <div className="text-center">
                          <div className="text-lg font-bold text-purple-600">{formatNumber(category.citations)}</div>
                          <div className="text-xs text-muted-foreground">Citations</div>
                        </div>
                        <div className="text-center">
                          <div className={`text-lg font-bold ${category.growthRate >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                            {category.growthRate >= 0 ? '+' : ''}{category.growthRate.toFixed(1)}%
                          </div>
                          <div className="text-xs text-muted-foreground">Growth</div>
                        </div>
                      </div>

                      <div className="mb-4">
                        <div className="text-sm font-medium mb-2">Hotness Score</div>
                        <Progress value={category.hotness} className="h-2" />
                      </div>

                      <div className="mb-4">
                        <div className="text-sm font-medium mb-2">Subcategories</div>
                        <div className="flex flex-wrap gap-1">
                          {category.subcategories.slice(0, 4).map((sub) => (
                            <Badge key={sub} variant="outline" className="text-xs">
                              {sub}
                            </Badge>
                          ))}
                        </div>
                      </div>

                      {selectedCategory === category.name && (
                        <div className="border-t pt-4 animate-in slide-in-from-top-2 duration-200">
                          <div className="text-sm font-medium mb-2">Recent High-Impact Papers</div>
                          <div className="space-y-2">
                            {category.recentPapers.map((paper, idx) => (
                              <div key={idx} className="flex items-center justify-between text-sm">
                                <span className="text-muted-foreground truncate flex-1">
                                  {paper.title}
                                </span>
                                <span className="text-primary font-medium ml-2">
                                  {paper.citations} citations
                                </span>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </TabsContent>

          {/* Geographic Tab */}
          <TabsContent value="geographic" className="space-y-6">
            <div className="flex items-center justify-between">
              <h2 className="text-2xl font-bold">Global Research Activity</h2>
              <div className="flex items-center space-x-2">
                <Globe className="h-5 w-5 text-blue-600" />
                <span className="text-sm text-muted-foreground">Research output by country</span>
              </div>
            </div>

            {loadingGeographic ? (
              <div className="text-center py-8">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto"></div>
                <p className="text-muted-foreground mt-2">Loading geographic data...</p>
              </div>
            ) : (
              <div className="grid lg:grid-cols-3 gap-6">
                <div className="lg:col-span-2">
                  <Card>
                    <CardHeader>
                      <CardTitle>Publications by Country</CardTitle>
                      <CardDescription>Total research publications in the last 30 days</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="h-96">
                        <ResponsiveContainer width="100%" height="100%">
                          <BarChart data={geographicData?.geographicData || []} layout="horizontal">
                            <CartesianGrid strokeDasharray="3 3" />
                            <XAxis type="number" />
                            <YAxis dataKey="country" type="category" width={100} />
                            <Tooltip />
                            <Bar dataKey="publications" fill="#6366f1" />
                          </BarChart>
                        </ResponsiveContainer>
                      </div>
                    </CardContent>
                  </Card>
                </div>

                <div>
                  <Card>
                    <CardHeader>
                      <CardTitle>Country Rankings</CardTitle>
                      <CardDescription>Top research-producing countries</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        {geographicData?.geographicData?.slice(0, 8).map((country: GeographicData, index: number) => (
                          <div key={country.countryCode} className="flex items-center justify-between">
                            <div className="flex items-center space-x-3">
                              <div className="w-6 h-6 rounded-full bg-primary/20 flex items-center justify-center text-xs font-bold">
                                {index + 1}
                              </div>
                              <div>
                                <div className="font-medium">{country.country}</div>
                                <div className="text-xs text-muted-foreground">
                                  {formatNumber(country.researchers)} researchers
                                </div>
                              </div>
                            </div>
                            <div className="text-right">
                              <div className="font-bold">{formatNumber(country.publications)}</div>
                              <div className={`text-xs ${country.growthRate >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                                {country.growthRate >= 0 ? '+' : ''}{country.growthRate.toFixed(1)}%
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </div>
            )}
          </TabsContent>

          {/* Real-time Activity Tab */}
          <TabsContent value="realtime" className="space-y-6">
            <div className="flex items-center justify-between">
              <h2 className="text-2xl font-bold">Live Research Activity</h2>
              <div className="flex items-center space-x-2">
                <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
                <span className="text-sm text-muted-foreground">Updates every 10 seconds</span>
              </div>
            </div>

            {loadingRealTime ? (
              <div className="text-center py-8">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto"></div>
                <p className="text-muted-foreground mt-2">Loading live activity...</p>
              </div>
            ) : (
              <div className="grid lg:grid-cols-3 gap-6">
                <div className="lg:col-span-2">
                  <Card>
                    <CardHeader>
                      <CardTitle>Activity Feed</CardTitle>
                      <CardDescription>Recent research activities across the platform</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4 max-h-96 overflow-y-auto">
                        {realTimeData?.activities?.map((activity: RealTimeActivity) => (
                          <div key={activity.id} className="flex items-start space-x-3 p-3 rounded-lg bg-muted/50">
                            <div className={`p-2 rounded-full ${getImpactColor(activity.impact)} bg-current/10`}>
                              {getActivityIcon(activity.type)}
                            </div>
                            <div className="flex-1 min-w-0">
                              <div className="flex items-center justify-between">
                                <Badge variant="outline" className="text-xs mb-1">
                                  {activity.type}
                                </Badge>
                                <span className="text-xs text-muted-foreground">
                                  {timeAgo(activity.timestamp)}
                                </span>
                              </div>
                              <h4 className="font-medium text-sm truncate">{activity.title}</h4>
                              <p className="text-xs text-muted-foreground">
                                by {activity.author} • {activity.category}
                              </p>
                            </div>
                            <div className={`w-2 h-2 rounded-full ${
                              activity.impact === 'high' ? 'bg-red-500' :
                              activity.impact === 'medium' ? 'bg-yellow-500' : 'bg-green-500'
                            }`} />
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                </div>

                <div>
                  <Card>
                    <CardHeader>
                      <CardTitle>Live Metrics</CardTitle>
                      <CardDescription>Current platform activity</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-6">
                        <div className="text-center">
                          <div className="text-3xl font-bold text-green-600">
                            {realTimeData?.currentMetrics?.activeUsers}
                          </div>
                          <div className="text-sm text-muted-foreground">Active Users</div>
                          <div className="w-2 h-2 bg-green-500 rounded-full mx-auto mt-1 animate-pulse"></div>
                        </div>

                        <div className="text-center">
                          <div className="text-2xl font-bold text-blue-600">
                            {realTimeData?.currentMetrics?.ongoingReviews}
                          </div>
                          <div className="text-sm text-muted-foreground">Ongoing Reviews</div>
                        </div>

                        <div className="text-center">
                          <div className="text-2xl font-bold text-purple-600">
                            {realTimeData?.currentMetrics?.newPublications}
                          </div>
                          <div className="text-sm text-muted-foreground">New Publications Today</div>
                        </div>

                        <div>
                          <div className="text-sm font-medium mb-2">Trending Topics</div>
                          <div className="space-y-2">
                            {realTimeData?.currentMetrics?.trendingtopics?.map((topic: string, index: number) => (
                              <div key={topic} className="flex items-center justify-between">
                                <Badge variant="secondary" className="text-xs">
                                  {topic}
                                </Badge>
                                <Flame className="h-3 w-3 text-orange-500" />
                              </div>
                            ))}
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </div>
            )}
          </TabsContent>

          {/* AI Insights Tab */}
          <TabsContent value="insights" className="space-y-6">
            <div className="flex items-center justify-between">
              <h2 className="text-2xl font-bold">AI-Powered Insights</h2>
              <div className="flex items-center space-x-2">
                <Zap className="h-5 w-5 text-yellow-600" />
                <span className="text-sm text-muted-foreground">Predictive analytics and recommendations</span>
              </div>
            </div>

            <div className="grid lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Target className="h-5 w-5 mr-2 text-purple-600" />
                    Emerging Research Areas
                  </CardTitle>
                  <CardDescription>AI-predicted hot topics based on publication patterns</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {[
                      { topic: "Quantum Machine Learning", confidence: 92, growth: "+145%" },
                      { topic: "Sustainable AI Computing", confidence: 87, growth: "+89%" },
                      { topic: "Decentralized Identity Systems", confidence: 83, growth: "+76%" },
                      { topic: "Bio-inspired Computing", confidence: 79, growth: "+62%" }
                    ].map((insight) => (
                      <div key={insight.topic} className="space-y-2">
                        <div className="flex items-center justify-between">
                          <span className="font-medium">{insight.topic}</span>
                          <Badge variant="outline">{insight.growth}</Badge>
                        </div>
                        <div className="flex items-center space-x-2">
                          <Progress value={insight.confidence} className="flex-1 h-2" />
                          <span className="text-xs text-muted-foreground">{insight.confidence}% confidence</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Search className="h-5 w-5 mr-2 text-blue-600" />
                    Research Recommendations
                  </CardTitle>
                  <CardDescription>Personalized research opportunities</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="p-4 border rounded-lg">
                      <h4 className="font-medium mb-2">Cross-disciplinary Opportunities</h4>
                      <p className="text-sm text-muted-foreground mb-3">
                        AI + Climate Science shows 89% collaboration potential
                      </p>
                      <div className="flex items-center space-x-2">
                        <Badge className="bg-blue-100 text-blue-800 border-blue-200">AI</Badge>
                        <span className="text-muted-foreground">×</span>
                        <Badge className="bg-green-100 text-green-800 border-green-200">Climate</Badge>
                      </div>
                    </div>

                    <div className="p-4 border rounded-lg">
                      <h4 className="font-medium mb-2">Under-explored Niches</h4>
                      <p className="text-sm text-muted-foreground mb-3">
                        Quantum cryptography in academic publishing
                      </p>
                      <Badge variant="outline">High Impact Potential</Badge>
                    </div>

                    <div className="p-4 border rounded-lg">
                      <h4 className="font-medium mb-2">Collaboration Suggestions</h4>
                      <p className="text-sm text-muted-foreground mb-3">
                        3 researchers in your area seeking collaboration
                      </p>
                      <Button variant="outline" size="sm">
                        View Matches
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
}