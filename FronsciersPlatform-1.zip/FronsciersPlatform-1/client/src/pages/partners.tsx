import { useState } from "react";
import { Link } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import fronsciersLogo from "@/assets/fronsciers-logo.png";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { 
  ExternalLink, 
  HandHeart, 
  Zap, 
  Shield, 
  Globe, 
  FileText, 
  Wallet,
  Database,
  Network,
  BookOpen,
  Mail,
  ArrowRight,
  CheckCircle
} from "lucide-react";

const contactFormSchema = z.object({
  name: z.string().min(2, "Name must be at least 2 characters"),
  email: z.string().email("Please enter a valid email address"),
  organization: z.string().min(2, "Organization name is required"),
  message: z.string().min(10, "Message must be at least 10 characters")
});

type ContactFormData = z.infer<typeof contactFormSchema>;

export default function Partners() {
  const [selectedPartner, setSelectedPartner] = useState<any>(null);
  const [showContactForm, setShowContactForm] = useState(false);
  const { toast } = useToast();

  const { data: partners, isLoading } = useQuery({
    queryKey: ["/api/partners"],
  });

  const contactMutation = useMutation({
    mutationFn: async (data: ContactFormData) => {
      const response = await fetch("/api/partners/contact", {
        method: "POST",
        body: JSON.stringify(data),
        headers: { "Content-Type": "application/json" }
      });
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.error || "Failed to send inquiry");
      }
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Partnership inquiry sent",
        description: "We'll review your proposal and get back to you within 48 hours.",
      });
      setShowContactForm(false);
      form.reset();
    },
    onError: (error: any) => {
      toast({
        title: "Error sending inquiry",
        description: error.message || "Please try again later",
        variant: "destructive",
      });
    },
  });

  const form = useForm<ContactFormData>({
    resolver: zodResolver(contactFormSchema),
    defaultValues: {
      name: "",
      email: "",
      organization: "",
      message: ""
    }
  });

  const onSubmit = (data: ContactFormData) => {
    contactMutation.mutate(data);
  };

  const partnersArray = Array.isArray(partners) ? partners : [];
  
  const partnerCategories = [
    {
      title: "Blockchain Infrastructure",
      description: "Core technology partners powering FRONSCIERS",
      icon: Network,
      partners: partnersArray.filter((p: any) => p.category === "blockchain")
    },
    {
      title: "Academic Tools",
      description: "Reference management and research workflow integrations",
      icon: BookOpen,
      partners: partnersArray.filter((p: any) => p.category === "academic")
    },
    {
      title: "DeFi & Trading",
      description: "Financial infrastructure and token utility partners",
      icon: Zap,
      partners: partnersArray.filter((p: any) => p.category === "defi")
    }
  ];

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 py-16">
        <div className="container mx-auto px-4">
          <div className="text-center">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto"></div>
            <p className="mt-4 text-muted-foreground">Loading partners...</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <header className="border-b bg-white/95 backdrop-blur sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <Link href="/">
              <div className="flex items-center space-x-3">
                <img src={fronsciersLogo} alt="FRONSCIERS" className="h-8 w-8" />
                <span className="text-xl font-bold">FRONSCIERS</span>
              </div>
            </Link>
            <nav className="hidden md:flex items-center space-x-6">
              <Link href="/dashboard" className="text-muted-foreground hover:text-foreground">Dashboard</Link>
              <Link href="/explore" className="text-muted-foreground hover:text-foreground">Explore</Link>
              <Link href="/governance" className="text-muted-foreground hover:text-foreground">Governance</Link>
              <Link href="/trends" className="text-muted-foreground hover:text-foreground">Trends</Link>
              <span className="text-primary font-medium">Partners</span>
            </nav>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-20 bg-gradient-to-r from-blue-50 to-indigo-50">
        <div className="container mx-auto px-4 text-center">
          <div className="max-w-4xl mx-auto">
            <h1 className="text-5xl font-bold mb-6">
              Partners & <span className="text-primary">Integrations</span>
            </h1>
            <p className="text-xl text-muted-foreground mb-8 leading-relaxed">
              Building the future of academic publishing through strategic partnerships with leading technology providers, 
              academic institutions, and research organizations worldwide.
            </p>
            <div className="flex flex-wrap justify-center gap-4 mb-12">
              <Badge variant="outline" className="px-4 py-2">
                <Network className="h-4 w-4 mr-2" />
                15+ Technology Partners
              </Badge>
              <Badge variant="outline" className="px-4 py-2">
                <BookOpen className="h-4 w-4 mr-2" />
                8+ Academic Integrations
              </Badge>
              <Badge variant="outline" className="px-4 py-2">
                <Globe className="h-4 w-4 mr-2" />
                Global Network
              </Badge>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}