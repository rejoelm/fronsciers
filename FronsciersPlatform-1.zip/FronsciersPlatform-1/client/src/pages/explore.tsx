import { useState, useEffect } from "react";
import { Link } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Checkbox } from "@/components/ui/checkbox";
import { WalletConnection } from "@/components/wallet-connection";
import { ManuscriptCard } from "@/components/manuscript-card";
import { useWallet } from "@/hooks/use-wallet";
import { apiRequest } from "@/lib/queryClient";
import { 
  ArrowLeft, Search, Filter, TrendingUp, Eye, 
  Star, Calendar, Download, ExternalLink, Users, Bookmark,
  Database, Globe, BookOpen, FileText, Zap, AlertCircle
} from "lucide-react";

const RESEARCH_FIELDS = [
  "All Fields",
  "Computer Science",
  "Biology",
  "Physics", 
  "Chemistry",
  "Mathematics",
  "Medicine",
  "Engineering",
  "Economics",
  "Psychology",
  "Environmental Science"
];

const SORT_OPTIONS = [
  { value: "recent", label: "Most Recent" },
  { value: "popular", label: "Most Popular" },
  { value: "cited", label: "Most Cited" },
  { value: "title", label: "Title A-Z" },
];

const DATABASES = [
  { id: "fronsciers", name: "FRONSCIERS", icon: Database, color: "blue", enabled: true },
  { id: "pubmed", name: "PubMed", icon: FileText, color: "green", enabled: true },
  { id: "scopus", name: "Scopus", icon: Globe, color: "orange", enabled: true },
  { id: "cochrane", name: "Cochrane", icon: BookOpen, color: "purple", enabled: true },
  { id: "google_scholar", name: "Google Scholar", icon: Search, color: "red", enabled: false }
];

export default function Explore() {
  const { isConnected } = useWallet();
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedField, setSelectedField] = useState("All Fields");
  const [sortBy, setSortBy] = useState("recent");
  const [activeTab, setActiveTab] = useState("all");
  const [selectedDatabases, setSelectedDatabases] = useState(["pubmed", "scopus", "cochrane"]);
  const [isSearching, setIsSearching] = useState(false);
  const [externalResults, setExternalResults] = useState<any[]>([]);
  const [trendingResults, setTrendingResults] = useState<any[]>([]);

  const { data: manuscripts, isLoading } = useQuery({
    queryKey: ["/api/manuscripts"],
    enabled: isConnected,
  });

  // Fetch trending medical research on load
  const { data: trendingData } = useQuery({
    queryKey: ["/api/research/trending"],
    queryFn: async () => {
      const response = await fetch("/api/research/trending?year=2024");
      if (!response.ok) throw new Error("Failed to fetch trending research");
      return response.json();
    }
  });

  // Transform trending data when available
  useEffect(() => {
    if (trendingData?.results) {
      const transformedResults = trendingData.results.map((paper: any) => ({
        id: paper.id,
        title: paper.title,
        abstract: paper.abstract,
        authors: paper.authors,
        source: paper.source,
        sourceColor: paper.source === "PubMed" ? "red" : 
                    paper.source === "Scopus" ? "orange" : "green",
        doi: paper.doi,
        publishedDate: paper.publishedDate,
        citationCount: paper.citationCount,
        url: paper.url,
        researchField: "Medicine",
        keywords: paper.keywords || [],
        isOpenAccess: paper.isOpenAccess,
        isPeerReviewed: paper.isPeerReviewed
      }));
      setTrendingResults(transformedResults);
    }
  }, [trendingData]);

  // Medical database search mutation
  const searchMutation = useMutation({
    mutationFn: async ({ query, databases }: { query: string, databases: string[] }) => {
      // For medical databases, use the medical research API
      if (databases.some(db => ['pubmed', 'scopus', 'cochrane'].includes(db))) {
        const response = await fetch(`/api/research/search?query=${encodeURIComponent(query)}&year=2024`);
        if (!response.ok) throw new Error("Medical research search failed");
        return response.json();
      }
      
      // For other databases, use existing search
      const response = await fetch("/api/search/external", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ query, databases })
      });
      if (!response.ok) throw new Error("Search failed");
      return response.json();
    },
    onMutate: () => {
      setIsSearching(true);
    },
    onSuccess: (data) => {
      if (data.results) {
        // Transform medical research results to match expected format
        const transformedResults = data.results.map((paper: any) => ({
          id: paper.id,
          title: paper.title,
          abstract: paper.abstract,
          authors: paper.authors,
          source: paper.source,
          sourceColor: paper.source === "PubMed" ? "red" : 
                      paper.source === "Scopus" ? "orange" : "green",
          doi: paper.doi,
          publishedDate: paper.publishedDate,
          citationCount: paper.citationCount,
          url: paper.url,
          researchField: "Medicine",
          keywords: paper.keywords || [],
          isOpenAccess: paper.isOpenAccess,
          isPeerReviewed: paper.isPeerReviewed
        }));
        setExternalResults(transformedResults);
      } else {
        setExternalResults(data.results || []);
      }
      setIsSearching(false);
    },
    onError: (error) => {
      console.error("Search error:", error);
      setExternalResults([]);
      setIsSearching(false);
    }
  });

  const handleSearch = () => {
    if (searchQuery.trim() && selectedDatabases.length > 0) {
      searchMutation.mutate({
        query: searchQuery,
        databases: selectedDatabases,
        field: selectedField
      });
    }
  };

  const toggleDatabase = (databaseId: string) => {
    setSelectedDatabases(prev => 
      prev.includes(databaseId) 
        ? prev.filter(id => id !== databaseId)
        : [...prev, databaseId]
    );
  };

  // Filter and sort manuscripts
  const filteredManuscripts = manuscripts?.filter((manuscript) => {
    const matchesSearch = searchQuery === "" || 
      manuscript.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      manuscript.abstract.toLowerCase().includes(searchQuery.toLowerCase()) ||
      manuscript.authors.toLowerCase().includes(searchQuery.toLowerCase()) ||
      manuscript.keywords.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesField = selectedField === "All Fields" || manuscript.researchField === selectedField;
    
    const matchesStatus = activeTab === "all" || 
      (activeTab === "published" && manuscript.status === "accepted") ||
      (activeTab === "preprints" && manuscript.status === "submitted") ||
      (activeTab === "nft" && manuscript.dociMinted);
    
    return matchesSearch && matchesField && matchesStatus;
  })?.sort((a, b) => {
    switch (sortBy) {
      case "popular":
        return (b.viewCount || 0) - (a.viewCount || 0);
      case "cited":
        return (b.citationCount || 0) - (a.citationCount || 0);
      case "title":
        return a.title.localeCompare(b.title);
      case "recent":
      default:
        return new Date(b.createdAt!).getTime() - new Date(a.createdAt!).getTime();
    }
  });

  const stats = {
    totalPapers: manuscripts?.length || 0,
    publishedPapers: manuscripts?.filter(m => m.status === "accepted").length || 0,
    docisMinted: manuscripts?.filter(m => m.dociMinted).length || 0,
    totalViews: manuscripts?.reduce((acc, m) => acc + (m.viewCount || 0), 0) || 0,
  };

  // Remove wallet requirement for public research access

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b bg-card/50 backdrop-blur-sm">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <Link href="/dashboard">
                <Button variant="ghost" size="sm">
                  <ArrowLeft className="h-4 w-4 mr-2" />
                  Back to Dashboard
                </Button>
              </Link>
              <div className="hidden sm:block h-6 w-px bg-border" />
              <div>
                <h1 className="text-2xl font-bold">Academic Search Engine</h1>
                <p className="text-muted-foreground">Search across FRONSCIERS, PubMed, Scopus, Cochrane, and Google Scholar</p>
              </div>
            </div>
            <WalletConnection />
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        {/* Stats Overview */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Total Papers</p>
                  <p className="text-2xl font-bold">{stats.totalPapers}</p>
                </div>
                <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center">
                  <Search className="h-5 w-5 text-primary" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Published</p>
                  <p className="text-2xl font-bold">{stats.publishedPapers}</p>
                </div>
                <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center">
                  <Star className="h-5 w-5 text-green-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">DOCIs Minted</p>
                  <p className="text-2xl font-bold">{stats.docisMinted}</p>
                </div>
                <div className="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center">
                  <Badge className="h-5 w-5 text-purple-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Total Views</p>
                  <p className="text-2xl font-bold">{stats.totalViews.toLocaleString()}</p>
                </div>
                <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                  <Eye className="h-5 w-5 text-blue-600" />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Filters Sidebar */}
          <div className="lg:col-span-1 space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Filter className="h-5 w-5" />
                  <span>Filters</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {/* Advanced Search */}
                <div className="space-y-2">
                  <label className="text-sm font-medium">Search Query</label>
                  <div className="relative">
                    <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                    <Input
                      placeholder="Enter search terms, keywords, authors, or DOI..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="pl-10"
                      onKeyPress={(e) => e.key === 'Enter' && handleSearch()}
                    />
                  </div>
                  <Button 
                    className="w-full mt-2" 
                    onClick={handleSearch}
                    disabled={!searchQuery.trim() || selectedDatabases.length === 0 || isSearching}
                  >
                    {isSearching ? "Searching..." : "Search All Databases"}
                    <Search className="ml-2 h-4 w-4" />
                  </Button>
                </div>

                {/* Database Selection */}
                <div className="space-y-2">
                  <label className="text-sm font-medium">Search Databases</label>
                  <div className="space-y-2">
                    {DATABASES.map((database) => (
                      <div key={database.id} className="flex items-center space-x-2">
                        <Checkbox
                          id={database.id}
                          checked={selectedDatabases.includes(database.id)}
                          onCheckedChange={() => toggleDatabase(database.id)}
                          disabled={database.id !== "fronsciers" && !database.enabled}
                        />
                        <div className="flex items-center space-x-2">
                          <database.icon className={`h-4 w-4 text-${database.color}-600`} />
                          <label 
                            htmlFor={database.id} 
                            className={`text-sm ${database.id !== "fronsciers" && !database.enabled ? 'text-muted-foreground' : 'cursor-pointer'}`}
                          >
                            {database.name}
                            {database.id !== "fronsciers" && !database.enabled && (
                              <Badge variant="outline" className="ml-2 text-xs">Coming Soon</Badge>
                            )}
                          </label>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Research Field */}
                <div className="space-y-2">
                  <label className="text-sm font-medium">Research Field</label>
                  <Select value={selectedField} onValueChange={setSelectedField}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {RESEARCH_FIELDS.map((field) => (
                        <SelectItem key={field} value={field}>
                          {field}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* Sort By */}
                <div className="space-y-2">
                  <label className="text-sm font-medium">Sort By</label>
                  <Select value={sortBy} onValueChange={setSortBy}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {SORT_OPTIONS.map((option) => (
                        <SelectItem key={option.value} value={option.value}>
                          {option.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <Button
                  variant="outline" 
                  className="w-full"
                  onClick={() => {
                    setSearchQuery("");
                    setSelectedField("All Fields");
                    setSortBy("recent");
                  }}
                >
                  Clear Filters
                </Button>
              </CardContent>
            </Card>

            {/* Trending Topics */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <TrendingUp className="h-5 w-5" />
                  <span>Trending Topics</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <Badge variant="secondary" className="mr-2 mb-2">Machine Learning</Badge>
                  <Badge variant="secondary" className="mr-2 mb-2">Blockchain</Badge>
                  <Badge variant="secondary" className="mr-2 mb-2">Quantum Computing</Badge>
                  <Badge variant="secondary" className="mr-2 mb-2">Climate Science</Badge>
                  <Badge variant="secondary" className="mr-2 mb-2">Biotechnology</Badge>
                  <Badge variant="secondary" className="mr-2 mb-2">Neural Networks</Badge>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Main Content */}
          <div className="lg:col-span-3 space-y-6">
            {/* Tabs */}
            <Tabs value={activeTab} onValueChange={setActiveTab}>
              <TabsList className="grid w-full grid-cols-5">
                <TabsTrigger value="all">All Sources</TabsTrigger>
                <TabsTrigger value="fronsciers">FRONSCIERS</TabsTrigger>
                <TabsTrigger value="external">External DBs</TabsTrigger>
                <TabsTrigger value="published">Published</TabsTrigger>
                <TabsTrigger value="nft">DOCI NFTs</TabsTrigger>
              </TabsList>

              <TabsContent value={activeTab} className="space-y-6">
                {/* Results Header */}
                <div className="flex items-center justify-between">
                  <div>
                    <h2 className="text-lg font-semibold">
                      {activeTab === "external" ? externalResults.length : 
                       activeTab === "all" ? (filteredManuscripts?.length || 0) + externalResults.length :
                       filteredManuscripts?.length || 0} papers found
                    </h2>
                    {searchQuery && (
                      <p className="text-muted-foreground">
                        Results for "{searchQuery}"
                        {activeTab === "external" && externalResults.length > 0 && (
                          <span className="ml-2">
                            • {selectedDatabases.filter(db => db !== "fronsciers").length} external databases
                          </span>
                        )}
                      </p>
                    )}
                  </div>
                </div>

                {/* Papers List */}
                {isLoading ? (
                  <div className="space-y-4">
                    {[1, 2, 3, 4, 5].map((i) => (
                      <Card key={i}>
                        <CardContent className="p-6">
                          <div className="animate-pulse space-y-3">
                            <div className="h-4 bg-muted rounded w-3/4"></div>
                            <div className="h-3 bg-muted rounded w-1/2"></div>
                            <div className="h-3 bg-muted rounded w-full"></div>
                            <div className="h-3 bg-muted rounded w-2/3"></div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                ) : (activeTab === "external" ? externalResults.length === 0 : 
                     activeTab === "all" ? (filteredManuscripts?.length || 0) + externalResults.length === 0 :
                     filteredManuscripts?.length === 0) ? (
                  <Card>
                    <CardContent className="p-12 text-center">
                      <Search className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                      <h3 className="text-lg font-medium mb-2">No papers found</h3>
                      <p className="text-muted-foreground mb-4">
                        {searchQuery ? "Try different search terms or select more databases" : "Enter a search query to find papers"}
                      </p>
                      <Button 
                        variant="outline"
                        onClick={() => {
                          setSearchQuery("");
                          setSelectedField("All Fields");
                          setActiveTab("all");
                          setExternalResults([]);
                        }}
                      >
                        Clear All Filters
                      </Button>
                    </CardContent>
                  </Card>
                ) : (
                  <div className="space-y-6">
                    {/* External Database Results */}
                    {(activeTab === "external" || activeTab === "all") && externalResults.map((result) => (
                      <Card key={result.id} className="hover:shadow-md transition-shadow border-l-4 border-l-blue-500">
                        <CardContent className="p-6">
                          <div className="flex items-start justify-between">
                            <div className="flex-1">
                              <div className="flex items-center space-x-2 mb-2">
                                <h3 className="text-lg font-semibold line-clamp-2">
                                  {result.title}
                                </h3>
                                <Badge 
                                  variant="outline" 
                                  className={`text-${result.sourceColor}-600 border-${result.sourceColor}-200 bg-${result.sourceColor}-50`}
                                >
                                  {result.source}
                                </Badge>
                                {result.isOpenAccess && (
                                  <Badge variant="secondary" className="text-green-600 bg-green-50">
                                    Open Access
                                  </Badge>
                                )}
                                {result.isPeerReviewed && (
                                  <Badge variant="secondary" className="text-blue-600 bg-blue-50">
                                    Peer Reviewed
                                  </Badge>
                                )}
                              </div>
                              
                              <p className="text-sm text-muted-foreground mb-2">
                                {result.authors}
                              </p>
                              
                              <p className="text-sm mb-3 line-clamp-3">
                                {result.abstract}
                              </p>
                              
                              <div className="flex items-center space-x-4 text-sm text-muted-foreground mb-3">
                                <span className="flex items-center space-x-1">
                                  <Calendar className="h-3 w-3" />
                                  <span>{new Date(result.publishedDate).toLocaleDateString()}</span>
                                </span>
                                <span className="flex items-center space-x-1">
                                  <Star className="h-3 w-3" />
                                  <span>{result.citationCount} citations</span>
                                </span>
                                {result.doi && (
                                  <span className="flex items-center space-x-1">
                                    <FileText className="h-3 w-3" />
                                    <span>DOI: </span>
                                    <a 
                                      href={`https://doi.org/${result.doi}`}
                                      target="_blank"
                                      rel="noopener noreferrer"
                                      className="text-blue-600 hover:text-blue-800 underline font-medium"
                                    >
                                      {result.doi}
                                    </a>
                                  </span>
                                )}
                              </div>
                              
                              <div className="flex items-center space-x-2">
                                <Badge variant="outline">{result.researchField}</Badge>
                                {result.keywords.slice(0, 3).map((keyword, index) => (
                                  <Badge key={index} variant="secondary" className="text-xs">
                                    {keyword}
                                  </Badge>
                                ))}
                              </div>
                            </div>
                            
                            <div className="flex flex-col space-y-2 ml-4">
                              <Button size="sm" variant="outline" asChild>
                                <a href={result.url} target="_blank" rel="noopener noreferrer">
                                  <ExternalLink className="h-3 w-3 mr-1" />
                                  View
                                </a>
                              </Button>
                              <Button size="sm" variant="outline">
                                <Bookmark className="h-3 w-3 mr-1" />
                                Save
                              </Button>
                              {result.source === "FRONSCIERS" && (
                                <Button size="sm" variant="outline">
                                  <Download className="h-3 w-3 mr-1" />
                                  Download
                                </Button>
                              )}
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}

                    {/* FRONSCIERS Results */}
                    {(activeTab === "fronsciers" || activeTab === "all" || activeTab === "published" || activeTab === "nft") && 
                     filteredManuscripts?.map((manuscript) => (
                      <Card key={manuscript.id} className="hover:shadow-md transition-shadow">
                        <CardContent className="p-6">
                          <div className="flex items-start justify-between">
                            <div className="flex-1">
                              <div className="flex items-center space-x-2 mb-2">
                                <h3 className="text-lg font-semibold line-clamp-2">
                                  {manuscript.title}
                                </h3>
                                <Badge variant="outline" className="text-blue-600 border-blue-200 bg-blue-50">
                                  FRONSCIERS
                                </Badge>
                                {manuscript.dociMinted && (
                                  <Badge variant="secondary" className="text-purple-600">
                                    DOCI NFT
                                  </Badge>
                                )}
                              </div>
                              
                              <p className="text-sm text-muted-foreground mb-2">
                                {manuscript.authors}
                              </p>
                              
                              <p className="text-sm mb-3 line-clamp-3">
                                {manuscript.abstract}
                              </p>
                              
                              <div className="flex items-center space-x-4 text-sm text-muted-foreground mb-3">
                                <span className="flex items-center space-x-1">
                                  <Calendar className="h-3 w-3" />
                                  <span>{new Date(manuscript.createdAt!).toLocaleDateString()}</span>
                                </span>
                                <span className="flex items-center space-x-1">
                                  <Eye className="h-3 w-3" />
                                  <span>{manuscript.viewCount || 0} views</span>
                                </span>
                                <span className="flex items-center space-x-1">
                                  <Star className="h-3 w-3" />
                                  <span>{manuscript.citationCount || 0} citations</span>
                                </span>
                              </div>
                              
                              <div className="flex items-center space-x-2">
                                <Badge variant="outline">{manuscript.researchField}</Badge>
                                <Badge 
                                  variant={manuscript.status === "accepted" ? "default" : "secondary"}
                                  className={manuscript.status === "accepted" ? "bg-green-100 text-green-800" : ""}
                                >
                                  {manuscript.status === "accepted" ? "Published" : 
                                   manuscript.status === "submitted" ? "Preprint" : 
                                   manuscript.status}
                                </Badge>
                                {manuscript.keywords.split(",").slice(0, 2).map((keyword, index) => (
                                  <Badge key={index} variant="secondary" className="text-xs">
                                    {keyword.trim()}
                                  </Badge>
                                ))}
                              </div>
                            </div>
                            
                            <div className="flex flex-col space-y-2 ml-4">
                              <Button size="sm" variant="outline">
                                <Eye className="h-3 w-3 mr-1" />
                                View
                              </Button>
                              {manuscript.ipfsHash && (
                                <Button size="sm" variant="outline">
                                  <Download className="h-3 w-3 mr-1" />
                                  Download
                                </Button>
                              )}
                              <Button size="sm" variant="outline">
                                <Bookmark className="h-3 w-3 mr-1" />
                                Save
                              </Button>
                              {manuscript.dociMinted && (
                                <Button size="sm" variant="outline">
                                  <ExternalLink className="h-3 w-3 mr-1" />
                                  NFT
                                </Button>
                              )}
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                )}

                {/* Load More */}
                {filteredManuscripts && filteredManuscripts.length > 0 && (
                  <div className="text-center pt-6">
                    <Button variant="outline" size="lg">
                      Load More Papers
                    </Button>
                  </div>
                )}
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </div>
    </div>
  );
}
