import { AcademicIntegration } from '@/components/AcademicIntegration';

export default function AcademicIntegrationPage() {
  return (
    <div className="container mx-auto py-8">
      <AcademicIntegration />
    </div>
  );
}