import { useState, useEffect } from "react";
import { Link } from "wouter";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import fronsciersLogo from "@/assets/fronsciers-logo.png";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Progress } from "@/components/ui/progress";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { WalletConnection } from "@/components/wallet-connection";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useWallet } from "@/hooks/use-wallet";
import { 
  Vote, Users, Plus, Clock, CheckCircle, XCircle, 
  AlertCircle, ChevronDown, ChevronUp, BarChart3, 
  MessageSquare, ExternalLink, Coins, Crown,
  Calendar, TrendingUp, Activity
} from "lucide-react";

interface Proposal {
  id: number;
  title: string;
  description: string;
  fullDescription?: string;
  options: string[];
  proposerId: number;
  proposerName: string;
  startTime: string;
  endTime: string;
  status: string;
  minimumFronsGov: number;
  votingPower: {
    totalPower: number;
    currentVotes: Record<string, number>;
  };
  participationCount: number;
  discussionUrl?: string;
  executionDate?: string;
  outcome?: string;
}

interface VotingPower {
  fronsGovTokens: number;
  reputationScore: number;
  reputationMultiplier: number;
  totalVotingPower: number;
  canCreateProposals: boolean;
  canVote: boolean;
}

export default function Governance() {
  const [selectedTab, setSelectedTab] = useState("active");
  const [expandedProposal, setExpandedProposal] = useState<number | null>(null);
  const [selectedVote, setSelectedVote] = useState<string>("");
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [newProposal, setNewProposal] = useState({
    title: "",
    description: "",
    options: ["", ""],
    startTime: "",
    endTime: "",
    minimumFronsGov: 1000
  });

  const { isConnected } = useWallet();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // WebSocket connection for live voting updates
  useEffect(() => {
    if (!isConnected) return;

    const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
    const wsUrl = `${protocol}//${window.location.host}/ws`;
    const socket = new WebSocket(wsUrl);

    socket.onopen = () => {
      // Subscribe to proposal updates
      proposals?.proposals?.forEach((proposal: Proposal) => {
        socket.send(JSON.stringify({
          type: 'subscribe',
          channel: `proposal:${proposal.id}`
        }));
      });
    };

    socket.onmessage = (event) => {
      const data = JSON.parse(event.data);
      if (data.type === 'VOTE_UPDATE') {
        // Invalidate proposals query to refresh vote counts
        queryClient.invalidateQueries({ queryKey: ["/api/governance/proposals"] });
      }
    };

    return () => {
      socket.close();
    };
  }, [isConnected, queryClient]);

  const { data: proposals, isLoading } = useQuery({
    queryKey: ["/api/governance/proposals", { status: selectedTab === "all" ? "all" : selectedTab }]
  });

  const { data: votingPower } = useQuery<VotingPower>({
    queryKey: ["/api/governance/user-voting-power"],
    enabled: isConnected
  });

  const createProposalMutation = useMutation({
    mutationFn: (proposalData: typeof newProposal) => 
      apiRequest("/api/governance/proposals", "POST", proposalData),
    onSuccess: () => {
      toast({
        title: "Proposal Created",
        description: "Your proposal has been submitted for community review"
      });
      queryClient.invalidateQueries({ queryKey: ["/api/governance/proposals"] });
      setIsCreateModalOpen(false);
      setNewProposal({
        title: "",
        description: "",
        options: ["", ""],
        startTime: "",
        endTime: "",
        minimumFronsGov: 1000
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to create proposal",
        variant: "destructive"
      });
    }
  });

  const voteMutation = useMutation({
    mutationFn: ({ proposalId, choice }: { proposalId: number; choice: string }) => 
      apiRequest("/api/governance/vote", "POST", { proposalId, choice }),
    onSuccess: (data) => {
      toast({
        title: "Vote Recorded",
        description: `Your vote has been recorded with ${data.votingPower.toFixed(2)} voting power`
      });
      queryClient.invalidateQueries({ queryKey: ["/api/governance/proposals"] });
      setSelectedVote("");
    },
    onError: (error: any) => {
      toast({
        title: "Voting Failed",
        description: error.message || "Failed to record vote",
        variant: "destructive"
      });
    }
  });

  const handleCreateProposal = () => {
    if (!newProposal.title || !newProposal.description) {
      toast({
        title: "Validation Error",
        description: "Title and description are required",
        variant: "destructive"
      });
      return;
    }

    const validOptions = newProposal.options.filter(opt => opt.trim() !== "");
    if (validOptions.length < 2) {
      toast({
        title: "Validation Error",
        description: "At least 2 voting options are required",
        variant: "destructive"
      });
      return;
    }

    createProposalMutation.mutate({
      ...newProposal,
      options: validOptions
    });
  };

  const handleVote = (proposalId: number) => {
    if (!selectedVote) {
      toast({
        title: "Selection Required",
        description: "Please select a voting option",
        variant: "destructive"
      });
      return;
    }

    voteMutation.mutate({ proposalId, choice: selectedVote });
  };

  const addOption = () => {
    setNewProposal({
      ...newProposal,
      options: [...newProposal.options, ""]
    });
  };

  const updateOption = (index: number, value: string) => {
    const newOptions = [...newProposal.options];
    newOptions[index] = value;
    setNewProposal({ ...newProposal, options: newOptions });
  };

  const removeOption = (index: number) => {
    if (newProposal.options.length > 2) {
      const newOptions = newProposal.options.filter((_, i) => i !== index);
      setNewProposal({ ...newProposal, options: newOptions });
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'active':
        return <Badge className="bg-green-100 text-green-800 border-green-200">Active</Badge>;
      case 'pending':
        return <Badge className="bg-yellow-100 text-yellow-800 border-yellow-200">Pending</Badge>;
      case 'executed':
        return <Badge className="bg-blue-100 text-blue-800 border-blue-200">Executed</Badge>;
      case 'rejected':
        return <Badge className="bg-red-100 text-red-800 border-red-200">Rejected</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  const isVotingActive = (proposal: Proposal) => {
    const now = new Date();
    const start = new Date(proposal.startTime);
    const end = new Date(proposal.endTime);
    return now >= start && now <= end && proposal.status === 'active';
  };

  const getVotePercentage = (votes: number, total: number) => {
    return total > 0 ? (votes / total) * 100 : 0;
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b bg-card/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 rounded-xl overflow-hidden">
                <img 
                  src={fronsciersLogo} 
                  alt="FRONSCIERS Logo" 
                  className="w-full h-full object-contain"
                />
              </div>
              <div>
                <h1 className="text-xl font-bold">FRONSCIERS</h1>
                <p className="text-sm text-muted-foreground">DAO Governance</p>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <nav className="hidden md:flex space-x-6">
                <Link href="/">
                  <Button variant="ghost">Home</Button>
                </Link>
                <Link href="/dashboard">
                  <Button variant="ghost">Dashboard</Button>
                </Link>
                <Link href="/tokenomics">
                  <Button variant="ghost">Tokenomics</Button>
                </Link>
                <Link href="/citations">
                  <Button variant="ghost">Citations</Button>
                </Link>
              </nav>
              <WalletConnection />
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        {/* Hero Section */}
        <div className="text-center mb-12">
          <div className="flex items-center justify-center mb-4">
            <Vote className="h-12 w-12 text-primary mr-3" />
            <h1 className="text-4xl font-bold">DAO Governance</h1>
          </div>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Shape the future of academic publishing through decentralized governance with FRONS-GOV tokens
          </p>
        </div>

        {/* Voting Power Card */}
        {isConnected && votingPower && (
          <Card className="mb-8">
            <CardHeader>
              <CardTitle className="flex items-center">
                <Crown className="h-5 w-5 mr-2 text-yellow-600" />
                Your Voting Power
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-4 gap-6">
                <div className="text-center">
                  <div className="text-2xl font-bold text-blue-600">{votingPower.fronsGovTokens}</div>
                  <div className="text-sm text-muted-foreground">FRONS-GOV Tokens</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-purple-600">{votingPower.reputationScore}</div>
                  <div className="text-sm text-muted-foreground">Reputation Score</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-green-600">{votingPower.reputationMultiplier.toFixed(1)}x</div>
                  <div className="text-sm text-muted-foreground">Reputation Multiplier</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-orange-600">{votingPower.totalVotingPower.toFixed(0)}</div>
                  <div className="text-sm text-muted-foreground">Total Voting Power</div>
                </div>
              </div>
              
              <div className="mt-6 flex items-center justify-between">
                <div className="flex items-center space-x-4">
                  {votingPower.canVote ? (
                    <Badge className="bg-green-100 text-green-800 border-green-200">
                      <CheckCircle className="h-3 w-3 mr-1" />
                      Can Vote
                    </Badge>
                  ) : (
                    <Badge className="bg-red-100 text-red-800 border-red-200">
                      <XCircle className="h-3 w-3 mr-1" />
                      Cannot Vote (Need 100+ FRONS-GOV)
                    </Badge>
                  )}
                  
                  {votingPower.canCreateProposals ? (
                    <Badge className="bg-blue-100 text-blue-800 border-blue-200">
                      <Plus className="h-3 w-3 mr-1" />
                      Can Create Proposals
                    </Badge>
                  ) : (
                    <Badge className="bg-gray-100 text-gray-800 border-gray-200">
                      <XCircle className="h-3 w-3 mr-1" />
                      Cannot Create Proposals (Need 1000+ FRONS-GOV)
                    </Badge>
                  )}
                </div>

                <Dialog open={isCreateModalOpen} onOpenChange={setIsCreateModalOpen}>
                  <DialogTrigger asChild>
                    <Button 
                      disabled={!votingPower.canCreateProposals}
                      className="bg-primary hover:bg-primary/90"
                    >
                      <Plus className="h-4 w-4 mr-2" />
                      Create Proposal
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
                    <DialogHeader>
                      <DialogTitle>Create New Governance Proposal</DialogTitle>
                      <DialogDescription>
                        Submit a proposal for the FRONSCIERS community to vote on
                      </DialogDescription>
                    </DialogHeader>
                    <div className="space-y-6">
                      <div>
                        <Label htmlFor="title">Proposal Title *</Label>
                        <Input
                          id="title"
                          placeholder="Enter a clear, descriptive title"
                          value={newProposal.title}
                          onChange={(e) => setNewProposal({...newProposal, title: e.target.value})}
                        />
                      </div>
                      
                      <div>
                        <Label htmlFor="description">Description *</Label>
                        <Textarea
                          id="description"
                          placeholder="Provide a detailed description of your proposal..."
                          value={newProposal.description}
                          onChange={(e) => setNewProposal({...newProposal, description: e.target.value})}
                          rows={6}
                        />
                      </div>
                      
                      <div>
                        <Label>Voting Options *</Label>
                        <div className="space-y-3 mt-2">
                          {newProposal.options.map((option, index) => (
                            <div key={index} className="flex items-center space-x-2">
                              <Input
                                placeholder={`Option ${index + 1}`}
                                value={option}
                                onChange={(e) => updateOption(index, e.target.value)}
                              />
                              {newProposal.options.length > 2 && (
                                <Button 
                                  variant="outline" 
                                  size="sm"
                                  onClick={() => removeOption(index)}
                                >
                                  Remove
                                </Button>
                              )}
                            </div>
                          ))}
                          <Button variant="outline" onClick={addOption} className="w-full">
                            <Plus className="h-4 w-4 mr-2" />
                            Add Option
                          </Button>
                        </div>
                      </div>
                      
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <Label htmlFor="startTime">Voting Start Time *</Label>
                          <Input
                            id="startTime"
                            type="datetime-local"
                            value={newProposal.startTime}
                            onChange={(e) => setNewProposal({...newProposal, startTime: e.target.value})}
                          />
                        </div>
                        <div>
                          <Label htmlFor="endTime">Voting End Time *</Label>
                          <Input
                            id="endTime"
                            type="datetime-local"
                            value={newProposal.endTime}
                            onChange={(e) => setNewProposal({...newProposal, endTime: e.target.value})}
                          />
                        </div>
                      </div>
                      
                      <div>
                        <Label htmlFor="minimumFronsGov">Minimum FRONS-GOV to Vote</Label>
                        <Input
                          id="minimumFronsGov"
                          type="number"
                          value={newProposal.minimumFronsGov}
                          onChange={(e) => setNewProposal({...newProposal, minimumFronsGov: parseInt(e.target.value) || 1000})}
                        />
                      </div>
                      
                      <div className="flex justify-end space-x-2">
                        <Button variant="outline" onClick={() => setIsCreateModalOpen(false)}>
                          Cancel
                        </Button>
                        <Button 
                          onClick={handleCreateProposal}
                          disabled={createProposalMutation.isPending}
                        >
                          {createProposalMutation.isPending ? "Creating..." : "Create Proposal"}
                        </Button>
                      </div>
                    </div>
                  </DialogContent>
                </Dialog>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Governance Statistics */}
        <div className="grid md:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Active Proposals</p>
                  <p className="text-2xl font-bold">{proposals?.summary?.active || 0}</p>
                </div>
                <Activity className="h-8 w-8 text-green-600" />
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Pending Proposals</p>
                  <p className="text-2xl font-bold">{proposals?.summary?.pending || 0}</p>
                </div>
                <Clock className="h-8 w-8 text-yellow-600" />
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Executed</p>
                  <p className="text-2xl font-bold">{proposals?.summary?.executed || 0}</p>
                </div>
                <CheckCircle className="h-8 w-8 text-blue-600" />
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Total Participation</p>
                  <p className="text-2xl font-bold">
                    {proposals?.proposals?.reduce((sum: number, p: Proposal) => sum + p.participationCount, 0) || 0}
                  </p>
                </div>
                <Users className="h-8 w-8 text-purple-600" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Proposals Tabs */}
        <Tabs value={selectedTab} onValueChange={setSelectedTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="active">Active Proposals</TabsTrigger>
            <TabsTrigger value="pending">Pending</TabsTrigger>
            <TabsTrigger value="executed">Past Proposals</TabsTrigger>
            <TabsTrigger value="all">All</TabsTrigger>
          </TabsList>

          <TabsContent value={selectedTab} className="space-y-6">
            {isLoading ? (
              <div className="text-center py-8">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto"></div>
                <p className="text-muted-foreground mt-2">Loading proposals...</p>
              </div>
            ) : proposals?.proposals?.length === 0 ? (
              <Card>
                <CardContent className="text-center py-12">
                  <Vote className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                  <h3 className="text-lg font-semibold mb-2">No Proposals Found</h3>
                  <p className="text-muted-foreground mb-4">
                    Be the first to shape the platform's future by creating a proposal.
                  </p>
                  {votingPower?.canCreateProposals && (
                    <Button onClick={() => setIsCreateModalOpen(true)}>
                      <Plus className="h-4 w-4 mr-2" />
                      Create Proposal
                    </Button>
                  )}
                </CardContent>
              </Card>
            ) : (
              proposals?.proposals?.map((proposal: Proposal) => (
                <Card key={proposal.id} className="hover:shadow-md transition-shadow">
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div className="space-y-2">
                        <div className="flex items-center space-x-3">
                          {getStatusBadge(proposal.status)}
                          <span className="text-sm text-muted-foreground">
                            by {proposal.proposerName}
                          </span>
                          <span className="text-sm text-muted-foreground">
                            {proposal.participationCount} participants
                          </span>
                        </div>
                        <CardTitle className="text-xl">{proposal.title}</CardTitle>
                        <p className="text-muted-foreground">{proposal.description}</p>
                      </div>
                      <div className="text-right">
                        <div className="text-sm text-muted-foreground mb-1">
                          {isVotingActive(proposal) ? (
                            <span className="text-green-600 font-medium">Voting Active</span>
                          ) : proposal.status === 'executed' ? (
                            <span className="text-blue-600 font-medium">Executed</span>
                          ) : (
                            <span className="text-gray-600">Voting Ended</span>
                          )}
                        </div>
                        <div className="text-xs text-muted-foreground">
                          Ends: {new Date(proposal.endTime).toLocaleDateString()}
                        </div>
                      </div>
                    </div>
                  </CardHeader>
                  
                  <CardContent>
                    {/* Live Voting Results */}
                    <div className="mb-6">
                      <h4 className="font-semibold mb-3 flex items-center">
                        <BarChart3 className="h-4 w-4 mr-2" />
                        Live Results ({proposal.votingPower.totalPower.toLocaleString()} total voting power)
                      </h4>
                      <div className="space-y-3">
                        {proposal.options.map((option) => {
                          const votes = proposal.votingPower.currentVotes[option] || 0;
                          const percentage = getVotePercentage(votes, proposal.votingPower.totalPower);
                          return (
                            <div key={option}>
                              <div className="flex justify-between items-center mb-1">
                                <span className="text-sm font-medium">{option}</span>
                                <span className="text-sm text-muted-foreground">
                                  {votes.toLocaleString()} ({percentage.toFixed(1)}%)
                                </span>
                              </div>
                              <Progress value={percentage} className="h-2" />
                            </div>
                          );
                        })}
                      </div>
                    </div>

                    {/* Voting Interface */}
                    {isVotingActive(proposal) && isConnected && votingPower?.canVote && (
                      <div className="border-t pt-4">
                        <h4 className="font-semibold mb-3">Cast Your Vote</h4>
                        <RadioGroup
                          value={selectedVote}
                          onValueChange={setSelectedVote}
                          className="mb-4"
                        >
                          {proposal.options.map((option) => (
                            <div key={option} className="flex items-center space-x-2">
                              <RadioGroupItem value={option} id={`${proposal.id}-${option}`} />
                              <Label htmlFor={`${proposal.id}-${option}`}>{option}</Label>
                            </div>
                          ))}
                        </RadioGroup>
                        <Button 
                          onClick={() => handleVote(proposal.id)}
                          disabled={!selectedVote || voteMutation.isPending}
                          className="w-full"
                        >
                          {voteMutation.isPending ? "Submitting Vote..." : "Submit Vote"}
                        </Button>
                      </div>
                    )}

                    {/* Proposal Details */}
                    <Collapsible 
                      open={expandedProposal === proposal.id}
                      onOpenChange={(open) => setExpandedProposal(open ? proposal.id : null)}
                    >
                      <CollapsibleTrigger asChild>
                        <Button variant="ghost" className="w-full justify-between mt-4">
                          View Full Proposal
                          {expandedProposal === proposal.id ? 
                            <ChevronUp className="h-4 w-4" /> : 
                            <ChevronDown className="h-4 w-4" />
                          }
                        </Button>
                      </CollapsibleTrigger>
                      <CollapsibleContent className="pt-4 border-t">
                        {proposal.fullDescription && (
                          <div className="prose prose-sm max-w-none mb-4">
                            <div className="whitespace-pre-wrap">{proposal.fullDescription}</div>
                          </div>
                        )}
                        
                        <div className="flex items-center justify-between text-sm text-muted-foreground">
                          <div className="flex items-center space-x-4">
                            <div className="flex items-center space-x-1">
                              <Calendar className="h-4 w-4" />
                              <span>Start: {new Date(proposal.startTime).toLocaleString()}</span>
                            </div>
                            <div className="flex items-center space-x-1">
                              <Clock className="h-4 w-4" />
                              <span>End: {new Date(proposal.endTime).toLocaleString()}</span>
                            </div>
                          </div>
                          
                          {proposal.discussionUrl && (
                            <Button variant="outline" size="sm">
                              <MessageSquare className="h-3 w-3 mr-1" />
                              Discussion
                              <ExternalLink className="h-3 w-3 ml-1" />
                            </Button>
                          )}
                        </div>

                        {proposal.outcome && (
                          <div className="mt-4 p-3 bg-blue-50 border border-blue-200 rounded-lg">
                            <h5 className="font-semibold text-blue-800 mb-1">Final Outcome</h5>
                            <p className="text-blue-700 text-sm">{proposal.outcome}</p>
                            {proposal.executionDate && (
                              <p className="text-blue-600 text-xs mt-1">
                                Executed on {new Date(proposal.executionDate).toLocaleString()}
                              </p>
                            )}
                          </div>
                        )}
                      </CollapsibleContent>
                    </Collapsible>
                  </CardContent>
                </Card>
              ))
            )}
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
}