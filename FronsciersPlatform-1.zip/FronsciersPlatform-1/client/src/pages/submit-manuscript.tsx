import { Sidebar } from "@/components/layout/sidebar";
import { Header } from "@/components/layout/header";
import { SubmissionForm } from "@/components/manuscript/submission-form";

export default function SubmitManuscript() {
  return (
    <div className="min-h-screen flex bg-slate-50">
      <Sidebar />
      
      <main className="flex-1 overflow-auto">
        <Header />
        
        <div className="p-6">
          <div className="max-w-4xl mx-auto">
            <div className="mb-8">
              <h1 className="text-3xl font-bold text-slate-900 mb-4">Submit New Manuscript</h1>
              <p className="text-lg text-slate-600">Upload your research and metadata to begin the publication process</p>
            </div>
            
            <SubmissionForm />
          </div>
        </div>
      </main>
    </div>
  );
}
