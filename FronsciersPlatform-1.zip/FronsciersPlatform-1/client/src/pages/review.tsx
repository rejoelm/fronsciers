import { useState } from "react";
import { Link } from "wouter";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { WalletConnection } from "@/components/wallet-connection";
import { useWallet } from "@/hooks/use-wallet";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { 
  ArrowLeft, FileText, Clock, CheckCircle, Star, 
  TrendingUp, Award, Users, Eye, Download,
  Calendar, UserCheck
} from "lucide-react";
import fronsciersLogo from "@assets/Slide 16_9 - 6 (1).png";

const reviewSchema = z.object({
  noveltyScore: z.string().min(1, "Novelty score is required"),
  methodologyScore: z.string().min(1, "Methodology score is required"),
  clarityScore: z.string().min(1, "Clarity score is required"),
  comments: z.string().min(50, "Comments must be at least 50 characters"),
  recommendation: z.string().min(1, "Recommendation is required"),
});

type ReviewForm = z.infer<typeof reviewSchema>;

const SCORE_OPTIONS = [
  { value: "5", label: "Excellent (5)" },
  { value: "4", label: "Good (4)" },
  { value: "3", label: "Fair (3)" },
  { value: "2", label: "Poor (2)" },
  { value: "1", label: "Very Poor (1)" },
];

const RECOMMENDATION_OPTIONS = [
  { value: "accept", label: "Accept", color: "bg-green-100 text-green-800" },
  { value: "minor_revisions", label: "Minor Revisions", color: "bg-yellow-100 text-yellow-800" },
  { value: "major_revisions", label: "Major Revisions", color: "bg-orange-100 text-orange-800" },
  { value: "reject", label: "Reject", color: "bg-red-100 text-red-800" },
];

// Mock data for demonstration
const mockActiveReview = {
  id: 1,
  manuscriptId: 1,
  title: "Blockchain Scalability Solutions in DeFi",
  authors: "Dr. Sarah Chen, Prof. Michael Rodriguez",
  abstract: "This paper presents novel approaches to addressing scalability challenges in decentralized finance applications through innovative blockchain architecture designs.",
  researchField: "Computer Science",
  ipfsHash: "QmXYZ123...",
  daysLeft: 5,
  fronsReward: 75,
  status: "assigned"
};

const mockReviewStats = {
  completed: 28,
  avgRating: 4.8,
  tokensEarned: 2100,
  rank: 12
};

const mockTopReviewers = [
  { name: "Dr. Emily Watson", reviews: 142, rating: 4.9, tokens: 8240 },
  { name: "Prof. David Kim", reviews: 128, rating: 4.8, tokens: 7890 },
  { name: "Dr. Maria Garcia", reviews: 115, rating: 4.7, tokens: 7420 },
];

export default function Review() {
  const { isConnected } = useWallet();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [activeTab, setActiveTab] = useState("active");
  const [showReviewForm, setShowReviewForm] = useState(false);

  const form = useForm<ReviewForm>({
    resolver: zodResolver(reviewSchema),
    defaultValues: {
      noveltyScore: "",
      methodologyScore: "",
      clarityScore: "",
      comments: "",
      recommendation: "",
    },
  });

  // Mock queries - in production these would fetch real data
  const { data: manuscripts } = useQuery({
    queryKey: ["/api/manuscripts"],
    enabled: isConnected,
  });

  const { data: myReviews } = useQuery({
    queryKey: [`/api/reviews/reviewer/1`],
    enabled: isConnected,
  });

  const submitReviewMutation = useMutation({
    mutationFn: async (data: ReviewForm & { manuscriptId: number; reviewerId: number }) => {
      const response = await apiRequest("POST", "/api/reviews", data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/reviews"] });
      toast({
        title: "Review submitted!",
        description: "You have earned 75 FRONS tokens for your review.",
      });
      setShowReviewForm(false);
      form.reset();
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to submit review. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleAcceptReview = (manuscript: any) => {
    toast({
      title: "Review Accepted",
      description: `You've accepted the review for "${manuscript.title}". You have 14 days to complete your review.`,
    });
    setActiveTab("active");
  };

  const handleViewManuscript = (manuscript: any) => {
    toast({
      title: "Preview Available",
      description: `Opening preview for "${manuscript.title}"`,
    });
  };

  const onSubmitReview = (data: ReviewForm) => {
    const overallScore = (
      parseInt(data.noveltyScore) + 
      parseInt(data.methodologyScore) + 
      parseInt(data.clarityScore)
    ) / 3;

    submitReviewMutation.mutate({
      ...data,
      manuscriptId: mockActiveReview.manuscriptId,
      reviewerId: 1, // Mock reviewer ID
      noveltyScore: data.noveltyScore,
      methodologyScore: data.methodologyScore,
      clarityScore: data.clarityScore,
      fronsReward: mockActiveReview.fronsReward,
      status: "submitted",
      overallScore: overallScore.toString(),
    });

    // Simulate consensus check for automatic acceptance
    if (data.recommendation === "accept" && overallScore >= 4.0) {
      setTimeout(() => {
        toast({
          title: "Consensus Reached",
          description: "This manuscript has received approval from 3 expert reviewers and will be automatically published.",
        });
      }, 2000);
    }
  };

  // Users are automatically redirected here after wallet connection
  // No need to show connection prompt again

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b bg-card/50 backdrop-blur-sm">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <Link href="/dashboard">
                <Button variant="ghost" size="sm">
                  <ArrowLeft className="h-4 w-4 mr-2" />
                  Back to Dashboard
                </Button>
              </Link>
              <Separator orientation="vertical" className="h-6" />
              <div>
                <h1 className="text-2xl font-bold">Peer Review</h1>
                <p className="text-muted-foreground">Earn FRONS tokens by providing quality reviews</p>
              </div>
            </div>
            <WalletConnection />
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-6">
            <Tabs value={activeTab} onValueChange={setActiveTab}>
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="active">Active Review</TabsTrigger>
                <TabsTrigger value="available">Available Papers</TabsTrigger>
                <TabsTrigger value="completed">My Reviews</TabsTrigger>
              </TabsList>

              <TabsContent value="active" className="space-y-6">
                {showReviewForm ? (
                  <Card>
                    <CardHeader>
                      <div className="flex items-center justify-between">
                        <CardTitle>Submit Review</CardTitle>
                        <div className="flex items-center space-x-2">
                          <Badge className="bg-orange-100 text-orange-800 border-orange-200 hover:bg-orange-200">
                            <Clock className="h-3 w-3 mr-1" />
                            {mockActiveReview.daysLeft} days left
                          </Badge>
                          <Badge className="bg-green-100 text-green-800 border-green-200 hover:bg-green-200">
                            <img src={fronsciersLogo} alt="FRONS" className="h-3 w-3 mr-1" />
                            +{mockActiveReview.fronsReward} FRONS
                          </Badge>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <form onSubmit={form.handleSubmit(onSubmitReview)} className="space-y-6">
                        {/* Scoring */}
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                          <div className="space-y-2">
                            <Label htmlFor="novelty">Novelty</Label>
                            <Select
                              onValueChange={(value) => form.setValue("noveltyScore", value)}
                              value={form.watch("noveltyScore")}
                            >
                              <SelectTrigger>
                                <SelectValue placeholder="Select score" />
                              </SelectTrigger>
                              <SelectContent>
                                {SCORE_OPTIONS.map((option) => (
                                  <SelectItem key={option.value} value={option.value}>
                                    {option.label}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                          </div>

                          <div className="space-y-2">
                            <Label htmlFor="methodology">Methodology</Label>
                            <Select
                              onValueChange={(value) => form.setValue("methodologyScore", value)}
                              value={form.watch("methodologyScore")}
                            >
                              <SelectTrigger>
                                <SelectValue placeholder="Select score" />
                              </SelectTrigger>
                              <SelectContent>
                                {SCORE_OPTIONS.map((option) => (
                                  <SelectItem key={option.value} value={option.value}>
                                    {option.label}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                          </div>

                          <div className="space-y-2">
                            <Label htmlFor="clarity">Clarity</Label>
                            <Select
                              onValueChange={(value) => form.setValue("clarityScore", value)}
                              value={form.watch("clarityScore")}
                            >
                              <SelectTrigger>
                                <SelectValue placeholder="Select score" />
                              </SelectTrigger>
                              <SelectContent>
                                {SCORE_OPTIONS.map((option) => (
                                  <SelectItem key={option.value} value={option.value}>
                                    {option.label}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                          </div>
                        </div>

                        {/* Comments */}
                        <div className="space-y-2">
                          <Label htmlFor="comments">Detailed Comments</Label>
                          <Textarea
                            id="comments"
                            rows={6}
                            placeholder="Provide detailed feedback on the manuscript..."
                            {...form.register("comments")}
                            className={form.formState.errors.comments ? "border-destructive" : ""}
                          />
                          <div className="flex justify-between text-sm text-muted-foreground">
                            <span>{form.formState.errors.comments?.message || "Minimum 50 characters"}</span>
                            <span>{form.watch("comments")?.length || 0} characters</span>
                          </div>
                        </div>

                        {/* Recommendation */}
                        <div className="space-y-3">
                          <Label>Recommendation</Label>
                          <RadioGroup
                            value={form.watch("recommendation")}
                            onValueChange={(value) => form.setValue("recommendation", value)}
                            className="grid grid-cols-1 md:grid-cols-2 gap-3"
                          >
                            {RECOMMENDATION_OPTIONS.map((option) => (
                              <div key={option.value} className="flex items-center space-x-2">
                                <RadioGroupItem value={option.value} id={option.value} />
                                <Label
                                  htmlFor={option.value}
                                  className={`px-3 py-2 rounded-lg cursor-pointer ${option.color}`}
                                >
                                  {option.label}
                                </Label>
                              </div>
                            ))}
                          </RadioGroup>
                        </div>

                        <div className="flex justify-between pt-4">
                          <Button
                            type="button"
                            variant="outline"
                            onClick={() => setShowReviewForm(false)}
                          >
                            Cancel
                          </Button>
                          <Button
                            type="submit"
                            disabled={submitReviewMutation.isPending}
                            className="bg-gradient-to-r from-green-600 to-green-700 hover:from-green-700 hover:to-green-800 text-white shadow-lg"
                          >
                            {submitReviewMutation.isPending ? (
                              <>
                                <Clock className="h-4 w-4 mr-2 animate-spin" />
                                Submitting...
                              </>
                            ) : (
                              <>
                                <CheckCircle className="h-4 w-4 mr-2" />
                                Submit Review & Earn {mockActiveReview.fronsReward} FRONS
                              </>
                            )}
                          </Button>
                        </div>
                      </form>
                    </CardContent>
                  </Card>
                ) : (
                  <Card>
                    <CardHeader>
                      <div className="flex items-center justify-between">
                        <CardTitle>Active Review</CardTitle>
                        <div className="flex items-center space-x-2">
                          <Badge className="bg-orange-100 text-orange-800 border-orange-200 hover:bg-orange-200">
                            <Clock className="h-3 w-3 mr-1" />
                            {mockActiveReview.daysLeft} days left
                          </Badge>
                          <Badge className="bg-green-100 text-green-800 border-green-200 hover:bg-green-200">
                            <img src={fronsciersLogo} alt="FRONS" className="h-3 w-3 mr-1" />
                            +{mockActiveReview.fronsReward} FRONS
                          </Badge>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent className="space-y-6">
                      <div>
                        <h3 className="text-lg font-semibold mb-2">{mockActiveReview.title}</h3>
                        <p className="text-muted-foreground mb-2">
                          Authors: {mockActiveReview.authors}
                        </p>
                        <p className="text-sm">{mockActiveReview.abstract}</p>
                      </div>

                      {/* PDF Viewer Placeholder */}
                      <div className="border-2 border-dashed border-border rounded-lg p-8 text-center">
                        <FileText className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
                        <p className="font-medium mb-2">manuscript_blockchain_scalability.pdf</p>
                        <p className="text-sm text-muted-foreground mb-4">45 pages • 2.3 MB</p>
                        <div className="flex justify-center space-x-4">
                          <Button variant="outline">
                            <Eye className="h-4 w-4 mr-2" />
                            View PDF
                          </Button>
                          <Button variant="outline">
                            <Download className="h-4 w-4 mr-2" />
                            Download
                          </Button>
                        </div>
                      </div>

                      <Button
                        onClick={() => setShowReviewForm(true)}
                        className="w-full bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 text-white shadow-lg"
                        size="lg"
                      >
                        Start Review
                      </Button>
                    </CardContent>
                  </Card>
                )}
              </TabsContent>

              <TabsContent value="available" className="space-y-4">
                {manuscripts?.filter(m => m.status === "submitted" || m.status === "under_review").length === 0 ? (
                  <Card>
                    <CardContent className="p-12 text-center">
                      <FileText className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                      <h3 className="text-lg font-medium mb-2">No manuscripts available for review</h3>
                      <p className="text-muted-foreground">Check back later for new submissions that need expert review</p>
                    </CardContent>
                  </Card>
                ) : (
                  <div className="space-y-4">
                    {manuscripts?.filter(m => m.status === "submitted" || m.status === "under_review").map((manuscript) => (
                      <Card key={manuscript.id} className="hover:shadow-md transition-shadow">
                        <CardContent className="p-6">
                          <div className="flex items-start justify-between">
                            <div className="flex-1">
                              <div className="flex items-center space-x-2 mb-2">
                                <h3 className="font-semibold">{manuscript.title}</h3>
                                <Badge 
                                  variant={manuscript.status === "submitted" ? "secondary" : "outline"}
                                  className={manuscript.status === "submitted" ? "bg-blue-50 text-blue-600" : "bg-orange-50 text-orange-600"}
                                >
                                  {manuscript.status === "submitted" ? "New Submission" : "Under Review"}
                                </Badge>
                              </div>
                              <p className="text-sm text-muted-foreground mb-2">
                                Authors: {manuscript.authors}
                              </p>
                              <p className="text-sm mb-3 line-clamp-2">
                                {manuscript.abstract}
                              </p>
                              <div className="flex items-center space-x-4 text-sm text-muted-foreground mb-3">
                                <span className="flex items-center space-x-1">
                                  <Badge variant="outline">{manuscript.researchField}</Badge>
                                </span>
                                <span className="flex items-center space-x-1">
                                  <Calendar className="h-3 w-3" />
                                  <span>Submitted {new Date(manuscript.createdAt!).toLocaleDateString()}</span>
                                </span>
                                <span className="flex items-center space-x-1">
                                  <Clock className="h-3 w-3" />
                                  <span>Review deadline: 14 days</span>
                                </span>
                              </div>
                              <div className="flex items-center space-x-2">
                                {manuscript.keywords.split(",").slice(0, 3).map((keyword, index) => (
                                  <Badge key={index} variant="secondary" className="text-xs">
                                    {keyword.trim()}
                                  </Badge>
                                ))}
                              </div>
                            </div>
                            <div className="flex flex-col items-end space-y-2 ml-4">
                              <Badge className="bg-green-100 text-green-800 border-green-200 hover:bg-green-200">
                                <img src={fronsciersLogo} alt="FRONS" className="h-3 w-3 mr-1" />
                                +{manuscript.researchField === "Computer Science" ? "100" : 
                                   manuscript.researchField === "Medicine" ? "120" : 
                                   manuscript.researchField === "Physics" ? "90" : "85"} FRONS
                              </Badge>
                              <Button 
                                size="sm"
                                onClick={() => handleAcceptReview(manuscript)}
                                className="bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 text-white shadow-md"
                              >
                                <UserCheck className="h-3 w-3 mr-1" />
                                Accept Review
                              </Button>
                              <Button 
                                size="sm" 
                                variant="outline"
                                onClick={() => handleViewManuscript(manuscript)}
                              >
                                <Eye className="h-3 w-3 mr-1" />
                                Preview
                              </Button>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                )}
              </TabsContent>

              <TabsContent value="completed" className="space-y-4">
                {myReviews?.length === 0 ? (
                  <Card>
                    <CardContent className="p-12 text-center">
                      <CheckCircle className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                      <h3 className="text-lg font-medium mb-2">No completed reviews yet</h3>
                      <p className="text-muted-foreground">Start reviewing papers to build your reputation and earn FRONS</p>
                    </CardContent>
                  </Card>
                ) : (
                  <div className="space-y-4">
                    {/* Mock completed reviews */}
                    <Card>
                      <CardContent className="p-6">
                        <div className="flex items-start justify-between">
                          <div className="flex-1">
                            <h3 className="font-semibold mb-1">Machine Learning in Climate Modeling</h3>
                            <p className="text-sm text-muted-foreground mb-2">Reviewed on Jan 15, 2024</p>
                            <div className="flex items-center space-x-4 text-sm">
                              <span>Recommendation: Accept</span>
                              <span>•</span>
                              <span>Overall Score: 4.5/5</span>
                            </div>
                          </div>
                          <div className="flex items-center space-x-2">
                            <Badge className="bg-green-100 text-green-800 border-green-200 hover:bg-green-200">
                              +75 FRONS earned
                            </Badge>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </div>
                )}
              </TabsContent>
            </Tabs>
          </div>

          {/* Right Sidebar */}
          <div className="space-y-6">
            {/* Review Stats */}
            <Card>
              <CardHeader>
                <CardTitle>Your Review Statistics</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 gap-4">
                  <div className="text-center">
                    <div className="text-2xl font-bold">{mockReviewStats.completed}</div>
                    <div className="text-sm text-muted-foreground">Reviews Completed</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold">{mockReviewStats.avgRating}</div>
                    <div className="text-sm text-muted-foreground">Average Rating</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold">{mockReviewStats.tokensEarned.toLocaleString()}</div>
                    <div className="text-sm text-muted-foreground">FRONS Earned</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold">#{mockReviewStats.rank}</div>
                    <div className="text-sm text-muted-foreground">Global Rank</div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Top Reviewers */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <TrendingUp className="h-5 w-5" />
                  <span>Top Reviewers</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {mockTopReviewers.map((reviewer, index) => (
                  <div key={index} className="flex items-center space-x-3">
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-semibold ${
                      index === 0 ? "bg-gradient-to-br from-yellow-400 to-yellow-600 text-yellow-900" :
                      index === 1 ? "bg-gradient-to-br from-gray-300 to-gray-500 text-gray-900" :
                      "bg-gradient-to-br from-orange-400 to-orange-600 text-orange-900"
                    }`}>
                      {index + 1}
                    </div>
                    <div className="flex-1">
                      <div className="font-medium text-sm">{reviewer.name}</div>
                      <div className="text-xs text-muted-foreground">
                        {reviewer.reviews} reviews • {reviewer.rating} rating
                      </div>
                    </div>
                    <div className="text-sm font-medium token-balance">
                      {reviewer.tokens.toLocaleString()}
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>

            {/* Reviewer Guide */}
            <Card className="gradient-bg text-white">
              <CardHeader>
                <CardTitle className="text-white">Become a Top Reviewer</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="space-y-2 text-sm">
                  <div className="flex items-center space-x-2">
                    <CheckCircle className="h-4 w-4" />
                    <span>Complete reviews within deadline</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <CheckCircle className="h-4 w-4" />
                    <span>Provide detailed, constructive feedback</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <CheckCircle className="h-4 w-4" />
                    <span>Maintain high quality ratings</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <CheckCircle className="h-4 w-4" />
                    <span>Participate in reviewer discussions</span>
                  </div>
                </div>
                <Button variant="outline" className="w-full text-primary border-white hover:bg-white/10">
                  View Reviewer Guide
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
