import { Navigation } from '@/components/Navigation';
import { RegisterDociForm } from '@/components/RegisterDociForm';
import { ResearchJourneyProgressBar } from '@/components/ResearchJourneyProgressBar';
import { AuthPrompt } from '@/components/AuthPrompt';
import { useQuery } from '@tanstack/react-query';
import { useWallet } from '@/hooks/use-wallet';
import { apiRequest } from '@/lib/queryClient';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { ExternalLink, FileText, Hash, Calendar, TrendingUp, Lock } from 'lucide-react';
import { useState } from 'react';

export default function DociRegistry() {
  const [selectedDociForJourney, setSelectedDociForJourney] = useState<string | null>(null);
  const [demoStage, setDemoStage] = useState('draft');
  const [demoCompletedStages, setDemoCompletedStages] = useState<string[]>([]);
  const { isConnected } = useWallet();

  // Fetch user's DOCIs only if connected
  const { data: userDocis, isLoading } = useQuery({
    queryKey: ['/api/doci/user/1'],
    queryFn: () => apiRequest('/api/doci/user/1'),
    enabled: isConnected
  });

  const handleStageClick = (stageKey: string) => {
    console.log(`Clicked on stage: ${stageKey}`);
    // In a real application, this would navigate to stage details
  };

  const simulateStageProgress = () => {
    const stages = ['draft', 'submission', 'peer_review', 'revision', 'acceptance', 'publication', 'indexing', 'citation'];
    const currentIndex = stages.indexOf(demoStage);
    
    if (currentIndex < stages.length - 1) {
      const newCompletedStages = [...demoCompletedStages];
      if (!newCompletedStages.includes(demoStage)) {
        newCompletedStages.push(demoStage);
      }
      setDemoCompletedStages(newCompletedStages);
      setDemoStage(stages[currentIndex + 1]);
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'confirmed': return 'bg-green-100 text-green-800';
      case 'pending': return 'bg-yellow-100 text-yellow-800';
      case 'failed': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getTypeColor = (type: string) => {
    switch (type) {
      case 'article': return 'bg-blue-100 text-blue-800';
      case 'preprint': return 'bg-purple-100 text-purple-800';
      case 'dataset': return 'bg-orange-100 text-orange-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50">
      <Navigation />
      
      <div className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-slate-900 mb-4">DOCI Registry</h1>
          <p className="text-lg text-slate-600">
            Register Direct On-Chain Identifiers (DOCIs) for your publications on Solana
          </p>
        </div>

        <div className="space-y-8">
          {/* Research Journey Progress Demo */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <TrendingUp className="h-5 w-5 text-blue-600" />
                <span>Research Journey Progress</span>
              </CardTitle>
              <CardDescription>
                Eight-stage research workflow with real-time WebSocket updates (Section 3.1)
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <ResearchJourneyProgressBar
                dociId="demo-doci-123"
                currentStage={demoStage}
                completedStages={demoCompletedStages}
                onStageClick={handleStageClick}
                className="bg-white p-4 rounded-lg border"
              />
              
              <div className="flex items-center justify-between">
                <div className="text-sm text-gray-600">
                  <strong>Demo:</strong> Click "Advance Stage" to simulate research progress
                </div>
                <Button onClick={simulateStageProgress} disabled={demoStage === 'citation'}>
                  {demoStage === 'citation' ? 'Journey Complete' : 'Advance Stage'}
                </Button>
              </div>
              
              <div className="text-xs text-gray-500 bg-blue-50 p-3 rounded">
                <strong>WebSocket Integration:</strong> In production, this component listens for real-time 
                UPDATE_STAGE events from the backend as manuscripts progress through the academic workflow. 
                Each stage transition is automatically synchronized across all connected clients.
              </div>
            </CardContent>
          </Card>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Registration Form */}
            <div>
              {isConnected ? (
                <RegisterDociForm />
              ) : (
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center space-x-2">
                      <Lock className="h-5 w-5 text-orange-600" />
                      <span>DOCI Registration</span>
                    </CardTitle>
                    <CardDescription>
                      Author authentication required to register Direct On-Chain Identifiers
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <AuthPrompt action="register-doci" />
                  </CardContent>
                </Card>
              )}
            </div>

            {/* User's DOCIs */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>Your DOCIs</CardTitle>
                  <CardDescription>Previously registered Direct On-Chain Identifiers</CardDescription>
                </CardHeader>
                <CardContent>
                  {isLoading ? (
                    <div className="space-y-3">
                      {[1, 2, 3].map((i) => (
                        <div key={i} className="h-20 bg-gray-100 rounded animate-pulse" />
                      ))}
                    </div>
                  ) : userDocis?.docis?.length > 0 ? (
                    <div className="space-y-4">
                      {userDocis.docis.map((doci: any) => (
                        <div key={doci.id} className="p-4 border rounded-lg space-y-3">
                          <div className="flex items-center justify-between">
                            <div className="font-medium font-mono text-blue-600">
                              {doci.fullDoci}
                            </div>
                            <div className="flex items-center space-x-2">
                              <Badge className={getStatusColor(doci.status)}>
                                {doci.status}
                              </Badge>
                              <Badge className={getTypeColor(doci.doiType)}>
                                {doci.doiType}
                              </Badge>
                            </div>
                          </div>
                          
                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-sm text-gray-600">
                            <div className="flex items-center space-x-2">
                              <Hash className="h-4 w-4" />
                              <span>Hash: {doci.contentHash.substring(0, 16)}...</span>
                            </div>
                            <div className="flex items-center space-x-2">
                              <Calendar className="h-4 w-4" />
                              <span>{new Date(doci.createdAt).toLocaleDateString()}</span>
                            </div>
                          </div>

                          <div className="flex items-center justify-between">
                            <a
                              href={`https://explorer.solana.com/address/${doci.solanaAccount}?cluster=devnet`}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="text-sm text-blue-600 hover:underline flex items-center space-x-1"
                            >
                              <ExternalLink className="h-3 w-3" />
                              <span>View on Solana</span>
                            </a>
                            {doci.metadataUri && (
                              <a
                                href={doci.metadataUri}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="text-sm text-blue-600 hover:underline flex items-center space-x-1"
                              >
                                <FileText className="h-3 w-3" />
                                <span>Metadata</span>
                              </a>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-8 text-gray-500">
                      <FileText className="h-12 w-12 mx-auto mb-3 text-gray-300" />
                      <p>No DOCIs registered yet</p>
                      <p className="text-sm">Register your first DOCI using the form</p>
                    </div>
                  )}
                </CardContent>
              </Card>

              {/* Information Card */}
              <Card>
                <CardHeader>
                  <CardTitle>About DOCIs</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-3 text-sm text-gray-600">
                    <div className="flex items-start space-x-3">
                      <div className="w-2 h-2 bg-blue-500 rounded-full mt-2 flex-shrink-0"></div>
                      <div>
                        <strong>Permanent:</strong> Once registered on Solana, DOCIs are immutable and permanent
                      </div>
                    </div>
                    <div className="flex items-start space-x-3">
                      <div className="w-2 h-2 bg-green-500 rounded-full mt-2 flex-shrink-0"></div>
                      <div>
                        <strong>Decentralized:</strong> No central authority controls your DOCIs
                      </div>
                    </div>
                    <div className="flex items-start space-x-3">
                      <div className="w-2 h-2 bg-purple-500 rounded-full mt-2 flex-shrink-0"></div>
                      <div>
                        <strong>Verifiable:</strong> Content integrity verified through cryptographic hashes
                      </div>
                    </div>
                    <div className="flex items-start space-x-3">
                      <div className="w-2 h-2 bg-orange-500 rounded-full mt-2 flex-shrink-0"></div>
                      <div>
                        <strong>Interoperable:</strong> Compatible with existing DOI infrastructure
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}