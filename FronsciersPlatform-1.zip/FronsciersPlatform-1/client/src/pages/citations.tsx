import { useState } from "react";
import { Link } from "wouter";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import fronsciersLogo from "@/assets/fronsciers-logo.png";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { WalletConnection } from "@/components/wallet-connection";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { 
  Link2, Search, TrendingUp, FileText, Users, BarChart3, 
  ExternalLink, Clock, CheckCircle, AlertCircle, Plus,
  Hash, Copy, ArrowUpRight, Filter, SortAsc
} from "lucide-react";

interface Citation {
  id: number;
  citingDoci: string;
  citedDoci: string;
  citingTitle: string;
  citedTitle: string;
  citingAuthors: string[];
  citedAuthors: string[];
  citationType: string;
  contextSnippet: string;
  blockchainTxHash: string;
  timestamp: string;
  status: string;
  citationCount: number;
  impactScore: number;
}

interface CitationMetrics {
  totalCitations: number;
  directCitations: number;
  methodologicalCitations: number;
  comparativeCitations: number;
  hIndex: number;
  impactFactor: number;
  recentCitations: number;
  citationGrowthRate: number;
  topCitingSources: Array<{ doci: string; count: number }>;
}

export default function Citations() {
  const [searchQuery, setSearchQuery] = useState("");
  const [filterType, setFilterType] = useState("all");
  const [sortBy, setSortBy] = useState("timestamp");
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [selectedDoci, setSelectedDoci] = useState("");
  const [newCitation, setNewCitation] = useState({
    citingDoci: "",
    citedDoci: "",
    citationType: "",
    contextSnippet: ""
  });

  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: citationsData, isLoading } = useQuery({
    queryKey: ["/api/citations", { type: filterType, search: searchQuery }]
  });

  const { data: metricsData } = useQuery({
    queryKey: ["/api/citations/metrics", selectedDoci],
    enabled: !!selectedDoci
  });

  const createCitationMutation = useMutation({
    mutationFn: (citationData: typeof newCitation) => 
      apiRequest("/api/citations/create", "POST", citationData),
    onSuccess: () => {
      toast({
        title: "Citation Created",
        description: "Citation has been recorded on the blockchain"
      });
      queryClient.invalidateQueries({ queryKey: ["/api/citations"] });
      setIsCreateModalOpen(false);
      setNewCitation({ citingDoci: "", citedDoci: "", citationType: "", contextSnippet: "" });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to create citation",
        variant: "destructive"
      });
    }
  });

  const handleCreateCitation = () => {
    if (!newCitation.citingDoci || !newCitation.citedDoci || !newCitation.citationType) {
      toast({
        title: "Validation Error",
        description: "Please fill in all required fields",
        variant: "destructive"
      });
      return;
    }
    createCitationMutation.mutate(newCitation);
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast({
      title: "Copied",
      description: "Transaction hash copied to clipboard"
    });
  };

  const citations = citationsData?.citations || [];
  const metrics = citationsData?.metrics || {};

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'verified': return 'bg-green-100 text-green-800 border-green-200';
      case 'pending': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getCitationTypeColor = (type: string) => {
    switch (type) {
      case 'direct': return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'methodological': return 'bg-purple-100 text-purple-800 border-purple-200';
      case 'comparative': return 'bg-orange-100 text-orange-800 border-orange-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b bg-card/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 rounded-xl overflow-hidden">
                <img 
                  src={fronsciersLogo} 
                  alt="FRONSCIERS Logo" 
                  className="w-full h-full object-contain"
                />
              </div>
              <div>
                <h1 className="text-xl font-bold">FRONSCIERS</h1>
                <p className="text-sm text-muted-foreground">Citation Tracking</p>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <nav className="hidden md:flex space-x-6">
                <Link href="/">
                  <Button variant="ghost">Home</Button>
                </Link>
                <Link href="/dashboard">
                  <Button variant="ghost">Dashboard</Button>
                </Link>
                <Link href="/explore">
                  <Button variant="ghost">Explore</Button>
                </Link>
                <Link href="/tokenomics">
                  <Button variant="ghost">Tokenomics</Button>
                </Link>
              </nav>
              <WalletConnection />
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        {/* Hero Section */}
        <div className="text-center mb-12">
          <div className="flex items-center justify-center mb-4">
            <Link2 className="h-12 w-12 text-primary mr-3" />
            <h1 className="text-4xl font-bold">Citation Tracking</h1>
          </div>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Track and manage transparent, immutable citation records on the Solana blockchain
          </p>
        </div>

        {/* Metrics Overview */}
        <div className="grid md:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Total Citations</p>
                  <p className="text-2xl font-bold">{metrics.totalCitations || 0}</p>
                </div>
                <BarChart3 className="h-8 w-8 text-blue-600" />
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Verified Citations</p>
                  <p className="text-2xl font-bold">{metrics.verifiedCitations || 0}</p>
                </div>
                <CheckCircle className="h-8 w-8 text-green-600" />
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Average Impact</p>
                  <p className="text-2xl font-bold">{metrics.averageImpactScore?.toFixed(1) || 0}</p>
                </div>
                <TrendingUp className="h-8 w-8 text-purple-600" />
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">On-Chain Records</p>
                  <p className="text-2xl font-bold">{citations.length}</p>
                </div>
                <Hash className="h-8 w-8 text-orange-600" />
              </div>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="citations" className="space-y-6">
          <div className="flex items-center justify-between">
            <TabsList>
              <TabsTrigger value="citations">All Citations</TabsTrigger>
              <TabsTrigger value="metrics">Analytics</TabsTrigger>
              <TabsTrigger value="network">Citation Network</TabsTrigger>
            </TabsList>
            
            <Dialog open={isCreateModalOpen} onOpenChange={setIsCreateModalOpen}>
              <DialogTrigger asChild>
                <Button>
                  <Plus className="h-4 w-4 mr-2" />
                  Create Citation
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-2xl">
                <DialogHeader>
                  <DialogTitle>Create New Citation</DialogTitle>
                  <DialogDescription>
                    Record a new citation relationship on the blockchain
                  </DialogDescription>
                </DialogHeader>
                <div className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="citingDoci">Citing DOCI *</Label>
                      <Input
                        id="citingDoci"
                        placeholder="DOCI.2024.ABC123"
                        value={newCitation.citingDoci}
                        onChange={(e) => setNewCitation({...newCitation, citingDoci: e.target.value})}
                      />
                    </div>
                    <div>
                      <Label htmlFor="citedDoci">Cited DOCI *</Label>
                      <Input
                        id="citedDoci"
                        placeholder="DOCI.2023.XYZ789"
                        value={newCitation.citedDoci}
                        onChange={(e) => setNewCitation({...newCitation, citedDoci: e.target.value})}
                      />
                    </div>
                  </div>
                  
                  <div>
                    <Label htmlFor="citationType">Citation Type *</Label>
                    <Select value={newCitation.citationType} onValueChange={(value) => setNewCitation({...newCitation, citationType: value})}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select citation type" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="direct">Direct Citation</SelectItem>
                        <SelectItem value="methodological">Methodological Reference</SelectItem>
                        <SelectItem value="comparative">Comparative Analysis</SelectItem>
                        <SelectItem value="supportive">Supportive Evidence</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div>
                    <Label htmlFor="contextSnippet">Context Snippet</Label>
                    <Textarea
                      id="contextSnippet"
                      placeholder="Quote or context where the citation appears..."
                      value={newCitation.contextSnippet}
                      onChange={(e) => setNewCitation({...newCitation, contextSnippet: e.target.value})}
                      rows={3}
                    />
                  </div>
                  
                  <div className="flex justify-end space-x-2">
                    <Button variant="outline" onClick={() => setIsCreateModalOpen(false)}>
                      Cancel
                    </Button>
                    <Button 
                      onClick={handleCreateCitation}
                      disabled={createCitationMutation.isPending}
                    >
                      {createCitationMutation.isPending ? "Creating..." : "Create Citation"}
                    </Button>
                  </div>
                </div>
              </DialogContent>
            </Dialog>
          </div>

          <TabsContent value="citations" className="space-y-6">
            {/* Search and Filter Controls */}
            <div className="flex flex-col md:flex-row gap-4 items-center">
              <div className="flex-1 relative">
                <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search by DOCI, title, or author..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10"
                />
              </div>
              
              <div className="flex gap-2">
                <Select value={filterType} onValueChange={setFilterType}>
                  <SelectTrigger className="w-40">
                    <Filter className="h-4 w-4 mr-2" />
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Types</SelectItem>
                    <SelectItem value="direct">Direct</SelectItem>
                    <SelectItem value="methodological">Methodological</SelectItem>
                    <SelectItem value="comparative">Comparative</SelectItem>
                  </SelectContent>
                </Select>
                
                <Select value={sortBy} onValueChange={setSortBy}>
                  <SelectTrigger className="w-40">
                    <SortAsc className="h-4 w-4 mr-2" />
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="timestamp">Recent</SelectItem>
                    <SelectItem value="impact">Impact Score</SelectItem>
                    <SelectItem value="citations">Citation Count</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            {/* Citations List */}
            <div className="space-y-4">
              {isLoading ? (
                <div className="text-center py-8">
                  <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto"></div>
                  <p className="text-muted-foreground mt-2">Loading citations...</p>
                </div>
              ) : citations.length === 0 ? (
                <Card>
                  <CardContent className="text-center py-12">
                    <Link2 className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                    <h3 className="text-lg font-semibold mb-2">No Citations Found</h3>
                    <p className="text-muted-foreground mb-4">
                      Start building the citation network by creating your first citation record.
                    </p>
                    <Button onClick={() => setIsCreateModalOpen(true)}>
                      <Plus className="h-4 w-4 mr-2" />
                      Create Citation
                    </Button>
                  </CardContent>
                </Card>
              ) : (
                citations.map((citation: Citation) => (
                  <Card key={citation.id} className="hover:shadow-md transition-shadow">
                    <CardHeader>
                      <div className="flex items-start justify-between">
                        <div className="space-y-2">
                          <div className="flex items-center space-x-2">
                            <Badge className={getCitationTypeColor(citation.citationType)}>
                              {citation.citationType}
                            </Badge>
                            <Badge className={getStatusColor(citation.status)}>
                              {citation.status}
                            </Badge>
                            <span className="text-sm text-muted-foreground">
                              Impact: {citation.impactScore}
                            </span>
                          </div>
                          <CardTitle className="text-lg">{citation.citingTitle}</CardTitle>
                          <p className="text-sm text-muted-foreground">
                            by {citation.citingAuthors.join(", ")}
                          </p>
                        </div>
                        <div className="text-right">
                          <p className="text-sm font-medium text-primary">{citation.citingDoci}</p>
                          <p className="text-xs text-muted-foreground">
                            {new Date(citation.timestamp).toLocaleDateString()}
                          </p>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        <div className="flex items-center space-x-2 text-sm">
                          <ArrowUpRight className="h-4 w-4 text-muted-foreground" />
                          <span className="text-muted-foreground">cites</span>
                          <span className="font-medium">{citation.citedDoci}</span>
                          <span className="text-muted-foreground">-</span>
                          <span>{citation.citedTitle}</span>
                        </div>
                        
                        {citation.contextSnippet && (
                          <div className="bg-muted/50 rounded-lg p-3">
                            <p className="text-sm italic">"{citation.contextSnippet}"</p>
                          </div>
                        )}
                        
                        <div className="flex items-center justify-between pt-2 border-t">
                          <div className="flex items-center space-x-4 text-sm text-muted-foreground">
                            <div className="flex items-center space-x-1">
                              <Hash className="h-4 w-4" />
                              <span>On-chain</span>
                            </div>
                            <div className="flex items-center space-x-1">
                              <BarChart3 className="h-4 w-4" />
                              <span>{citation.citationCount} citations</span>
                            </div>
                          </div>
                          
                          <div className="flex items-center space-x-2">
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => copyToClipboard(citation.blockchainTxHash)}
                            >
                              <Copy className="h-3 w-3 mr-1" />
                              Tx Hash
                            </Button>
                            <Button variant="outline" size="sm">
                              <ExternalLink className="h-3 w-3 mr-1" />
                              View on Solscan
                            </Button>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))
              )}
            </div>
          </TabsContent>

          <TabsContent value="metrics" className="space-y-6">
            <div className="grid md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Citation Metrics</CardTitle>
                  <CardDescription>Detailed citation analysis</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex justify-between">
                      <span>Total Citations:</span>
                      <span className="font-semibold">{metricsData?.metrics?.totalCitations || 0}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>H-Index:</span>
                      <span className="font-semibold">{metricsData?.metrics?.hIndex || 0}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Impact Factor:</span>
                      <span className="font-semibold">{metricsData?.metrics?.impactFactor || 0}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Growth Rate:</span>
                      <span className="font-semibold text-green-600">
                        +{metricsData?.metrics?.citationGrowthRate || 0}%
                      </span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Citation Types</CardTitle>
                  <CardDescription>Distribution by citation type</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-2">
                        <div className="w-3 h-3 bg-blue-500 rounded-full"></div>
                        <span>Direct Citations</span>
                      </div>
                      <span className="font-semibold">{metricsData?.metrics?.directCitations || 0}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-2">
                        <div className="w-3 h-3 bg-purple-500 rounded-full"></div>
                        <span>Methodological</span>
                      </div>
                      <span className="font-semibold">{metricsData?.metrics?.methodologicalCitations || 0}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-2">
                        <div className="w-3 h-3 bg-orange-500 rounded-full"></div>
                        <span>Comparative</span>
                      </div>
                      <span className="font-semibold">{metricsData?.metrics?.comparativeCitations || 0}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="network" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Citation Network</CardTitle>
                <CardDescription>Interactive visualization of citation relationships</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="text-center py-12">
                  <Users className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
                  <h3 className="text-lg font-semibold mb-2">Citation Network Visualization</h3>
                  <p className="text-muted-foreground mb-4">
                    Interactive network graph showing citation relationships between research papers
                  </p>
                  <p className="text-sm text-muted-foreground">
                    Network visualization coming soon with D3.js integration
                  </p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
}