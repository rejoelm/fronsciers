import { useState } from "react";
import { Link } from "wouter";
// import fronsciersLogo from "@/assets/fronsciers-logo.png";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  ArrowRight, 
  FileText, 
  Users, 
  Coins, 
  Globe, 
  CheckCircle,
  IdCard,
  Vote,
  TrendingUp
} from "lucide-react";
import { SimpleWalletButton } from "@/components/wallet/simple-wallet-button";

export default function Homepage() {
  const [activeFeature, setActiveFeature] = useState(0);

  const features = [
    {
      icon: IdCard,
      title: "DOCIs (Direct On-Chain Identifiers)",
      description: "Revolutionary NFT-based manuscript identification system on Solana blockchain",
      details: "Each manuscript gets a unique DOCI NFT that tracks its entire lifecycle from submission to publication."
    },
    {
      icon: Users,
      title: "Multi-Tier Peer Review",
      description: "Automated checks, expert review, and community validation in three phases",
      details: "AI-powered initial screening followed by expert peer review and community consensus validation."
    },
    {
      icon: TrendingUp,
      title: "Real-Time Research Trends",
      description: "Track global research patterns, emerging topics, and collaboration networks",
      details: "AI-powered analytics showing publication trends, citation patterns, geographic distribution, and predictive insights for emerging research areas."
    },
    {
      icon: Coins,
      title: "FRONS Token Incentives",
      description: "Earn tokens for quality reviews, submissions, and community participation",
      details: "Reviewers earn 50-100 FRONS per review, authors get rewards for accepted papers, community votes earn 5 FRONS."
    },
    {
      icon: Vote,
      title: "DAO Governance",
      description: "Decentralized decision-making for platform policies and funding",
      details: "FRONS holders vote on platform upgrades, review standards, and research funding allocations."
    }
  ];

  const stats = [
    { label: "Research Papers", value: "2,450+", icon: FileText },
    { label: "Active Reviewers", value: "890+", icon: Users },
    { label: "FRONS Distributed", value: "125K+", icon: Coins },
    { label: "Global Institutions", value: "150+", icon: Globe }
  ];

  return (
    <div className="min-h-screen bg-background">
      {/* Main Content - now responsive */}
      <div className="container-responsive pt-4 md:pt-8">
        {/* Hero Section */}
        <section className="text-center py-8 md:py-16 lg:py-24">
          <div className="max-w-4xl mx-auto">
            <div className="flex items-center justify-center mb-6 md:mb-8">
              <div className="w-16 h-16 md:w-20 md:h-20 bg-primary rounded-xl flex items-center justify-center mr-4">
                <span className="text-white font-bold text-xl md:text-2xl">F</span>
              </div>
              <div className="text-left">
                <h1 className="text-responsive-xl font-bold font-lora text-primary">FRONSCIERS</h1>
                <p className="text-responsive-base text-muted-foreground">Blockchain Academic Publishing</p>
              </div>
            </div>
            
            <h2 className="text-3xl md:text-4xl lg:text-6xl font-bold mb-4 md:mb-6 bg-gradient-to-r from-primary to-blue-600 bg-clip-text text-transparent">
              Revolutionizing Academic Publishing
            </h2>
            <p className="text-responsive-lg text-muted-foreground mb-8 md:mb-12 max-w-3xl mx-auto">
              Decentralized peer review, blockchain verification, and community governance on Solana. 
              Earn FRONS tokens for quality research contributions.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center mb-8 md:mb-12">
              <Link href="/submit">
                <Button size="lg" className="btn-touch w-full sm:w-auto">
                  Submit Research
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </Link>
              <Link href="/explore">
                <Button variant="outline" size="lg" className="btn-touch w-full sm:w-auto">
                  Explore Papers
                </Button>
              </Link>
            </div>
            
            <div className="flex items-center justify-center space-x-2 mb-8">
              <SimpleWalletButton />
            </div>
          </div>
        </section>

        {/* Stats Section */}
        <section className="py-8 md:py-16">
          <div className="grid-responsive">
            {stats.map((stat, index) => {
              const Icon = stat.icon;
              return (
                <Card key={index} className="text-center card-responsive">
                  <CardContent className="pt-6">
                    <Icon className="h-8 w-8 md:h-10 md:w-10 mx-auto mb-3 text-primary" />
                    <div className="text-2xl md:text-3xl font-bold mb-1">{stat.value}</div>
                    <div className="text-responsive-base text-muted-foreground">{stat.label}</div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </section>

        {/* Features Section */}
        <section className="py-8 md:py-16">
          <div className="text-center mb-8 md:mb-12">
            <h3 className="text-responsive-xl font-bold mb-4">Platform Features</h3>
            <p className="text-responsive-lg text-muted-foreground max-w-2xl mx-auto">
              Comprehensive blockchain-based academic publishing ecosystem
            </p>
          </div>
          
          <div className="grid-responsive">
            {features.map((feature, index) => {
              const Icon = feature.icon;
              return (
                <Card 
                  key={index} 
                  className={`cursor-pointer transition-all duration-300 card-responsive hover:shadow-lg ${
                    activeFeature === index ? 'border-primary shadow-lg' : ''
                  }`}
                  onClick={() => setActiveFeature(index)}
                >
                  <CardHeader>
                    <div className="flex items-center space-x-3 mb-3">
                      <div className="p-2 rounded-lg bg-primary/10">
                        <Icon className="h-6 w-6 text-primary" />
                      </div>
                      <CardTitle className="text-responsive-lg">{feature.title}</CardTitle>
                    </div>
                    <CardDescription className="text-responsive-base">
                      {feature.description}
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-muted-foreground">
                      {feature.details}
                    </p>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </section>

        {/* Quick Actions */}
        <section className="py-8 md:py-16">
          <div className="text-center mb-8 md:mb-12">
            <h3 className="text-responsive-xl font-bold mb-4">Get Started</h3>
          </div>
          
          <div className="grid-responsive-2 max-w-4xl mx-auto">
            <Card className="card-responsive">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <FileText className="h-5 w-5 text-primary" />
                  <span>For Researchers</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-responsive-base text-muted-foreground">
                  Submit manuscripts, track peer review progress, and earn FRONS tokens for accepted publications.
                </p>
                <div className="flex flex-col sm:flex-row gap-2">
                  <Link href="/submit" className="flex-1">
                    <Button className="w-full btn-touch">Submit Paper</Button>
                  </Link>
                  <Link href="/dashboard" className="flex-1">
                    <Button variant="outline" className="w-full btn-touch">View Dashboard</Button>
                  </Link>
                </div>
              </CardContent>
            </Card>
            
            <Card className="card-responsive">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Users className="h-5 w-5 text-primary" />
                  <span>For Reviewers</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-responsive-base text-muted-foreground">
                  Participate in peer review, earn tokens for quality feedback, and build your reputation.
                </p>
                <div className="flex flex-col sm:flex-row gap-2">
                  <Link href="/peer-review" className="flex-1">
                    <Button className="w-full btn-touch">Start Reviewing</Button>
                  </Link>
                  <Link href="/explore" className="flex-1">
                    <Button variant="outline" className="w-full btn-touch">Browse Papers</Button>
                  </Link>
                </div>
              </CardContent>
            </Card>
          </div>
        </section>
      </div>
    </div>
  );
}