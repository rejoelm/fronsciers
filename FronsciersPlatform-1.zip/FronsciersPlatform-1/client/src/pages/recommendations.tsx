import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Link } from "wouter";
import { apiRequest } from "@/lib/queryClient";
import { useWallet } from "@/hooks/use-wallet";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Slider } from "@/components/ui/slider";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { WalletConnection } from "@/components/wallet-connection";
import { 
  Brain, Users, TrendingUp, ThumbsUp, ThumbsDown, Star, 
  BookOpen, Clock, Target, Lightbulb, ArrowLeft, Plus, Minus
} from "lucide-react";

interface UserInterest {
  id: number;
  topic: string;
  weight: number;
  source: string;
}

interface RecommendedPaper {
  id: number;
  title: string;
  authors: string;
  abstract: string;
  researchField: string;
  keywords: string;
  createdAt: string;
}

interface Collaborator {
  user: {
    id: number;
    username: string;
    institutionName?: string;
  };
  score: number;
  commonInterests: string[];
}

interface TrendingTopic {
  id: number;
  topic: string;
  category: string;
  score: number;
  manuscriptCount: number;
  growthRate: number;
  timeWindow: string;
}

export default function Recommendations() {
  const { isConnected } = useWallet();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [activeTab, setActiveTab] = useState("papers");
  const [newInterest, setNewInterest] = useState("");
  const [interestWeight, setInterestWeight] = useState([500]);

  // Mock user ID for development
  const userId = 1;

  const { data: userInterests, refetch: refetchInterests } = useQuery({
    queryKey: ["/api/recommendations/user-interests"],
    enabled: isConnected,
  });

  const { data: recommendedPapers } = useQuery({
    queryKey: [`/api/recommendations/papers/${userId}`],
    enabled: isConnected,
  });

  const { data: collaborators } = useQuery({
    queryKey: [`/api/recommendations/collaborators/${userId}`],
    enabled: isConnected,
  });

  const { data: trendingTopics } = useQuery({
    queryKey: ["/api/recommendations/trending-topics"],
  });

  const updateInterestMutation = useMutation({
    mutationFn: async (data: { topic: string; weight: number; source: string }) => {
      return await apiRequest("POST", "/api/recommendations/update-interest", data);
    },
    onSuccess: () => {
      refetchInterests();
      toast({
        title: "Interest Updated",
        description: "Your research interest has been updated successfully.",
      });
    },
  });

  const feedbackMutation = useMutation({
    mutationFn: async (data: { recommendationType: string; recommendedItemId: string; feedback: string; reason?: string }) => {
      return await apiRequest("POST", "/api/recommendations/feedback", data);
    },
    onSuccess: () => {
      toast({
        title: "Feedback Recorded",
        description: "Thank you for your feedback! This helps improve recommendations.",
      });
    },
  });

  const trackInteractionMutation = useMutation({
    mutationFn: async (data: { targetType: string; targetId: string; action: string; duration?: number }) => {
      return await apiRequest("POST", "/api/recommendations/track-interaction", data);
    },
  });

  const handleAddInterest = () => {
    if (!newInterest.trim()) return;
    
    updateInterestMutation.mutate({
      topic: newInterest,
      weight: interestWeight[0],
      source: "explicit"
    });
    
    setNewInterest("");
    setInterestWeight([500]);
  };

  const handleUpdateInterestWeight = (interest: UserInterest, newWeight: number) => {
    updateInterestMutation.mutate({
      topic: interest.topic,
      weight: newWeight,
      source: interest.source
    });
  };

  const handlePaperFeedback = (paperId: number, feedback: "like" | "dislike") => {
    feedbackMutation.mutate({
      recommendationType: "paper",
      recommendedItemId: paperId.toString(),
      feedback,
    });
    
    trackInteractionMutation.mutate({
      targetType: "manuscript",
      targetId: paperId.toString(),
      action: feedback === "like" ? "thumbs_up" : "thumbs_down"
    });
  };

  const handleCollaboratorInterest = (collaboratorId: number) => {
    feedbackMutation.mutate({
      recommendationType: "collaborator",
      recommendedItemId: collaboratorId.toString(),
      feedback: "like",
    });
    
    trackInteractionMutation.mutate({
      targetType: "author",
      targetId: collaboratorId.toString(),
      action: "view_profile"
    });
  };

  useEffect(() => {
    // Track page view interaction
    if (isConnected) {
      trackInteractionMutation.mutate({
        targetType: "page",
        targetId: "recommendations",
        action: "view"
      });
    }
  }, [isConnected]);

  // Users are automatically redirected to /review after wallet connection
  // This page is accessible without showing connection prompts

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b bg-card/50 backdrop-blur-sm">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <Link href="/dashboard">
                <Button variant="ghost" size="sm">
                  <ArrowLeft className="h-4 w-4 mr-2" />
                  Back to Dashboard
                </Button>
              </Link>
              <div>
                <h1 className="text-2xl font-bold flex items-center space-x-2">
                  <Brain className="h-6 w-6 text-primary" />
                  <span>Research Recommendations</span>
                </h1>
                <p className="text-muted-foreground">AI-powered personalized research discovery</p>
              </div>
            </div>
            <WalletConnection />
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-3">
            <Tabs value={activeTab} onValueChange={setActiveTab}>
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="papers" className="flex items-center space-x-2">
                  <BookOpen className="h-4 w-4" />
                  <span>Recommended Papers</span>
                </TabsTrigger>
                <TabsTrigger value="collaborators" className="flex items-center space-x-2">
                  <Users className="h-4 w-4" />
                  <span>Potential Collaborators</span>
                </TabsTrigger>
                <TabsTrigger value="trending" className="flex items-center space-x-2">
                  <TrendingUp className="h-4 w-4" />
                  <span>Trending Topics</span>
                </TabsTrigger>
              </TabsList>

              <TabsContent value="papers" className="space-y-6 mt-6">
                <div className="flex items-center justify-between">
                  <h2 className="text-xl font-semibold">Papers You Might Find Interesting</h2>
                  <Badge variant="outline" className="text-primary">
                    {recommendedPapers?.length || 0} recommendations
                  </Badge>
                </div>

                {!recommendedPapers || recommendedPapers.length === 0 ? (
                  <Card>
                    <CardContent className="p-12 text-center">
                      <Target className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                      <h3 className="text-lg font-medium mb-2">Building Your Recommendations</h3>
                      <p className="text-muted-foreground mb-4">
                        Add research interests to get personalized paper recommendations
                      </p>
                      <Button onClick={() => setActiveTab("interests")}>
                        Set Research Interests
                      </Button>
                    </CardContent>
                  </Card>
                ) : (
                  <div className="space-y-4">
                    {recommendedPapers.map((paper: RecommendedPaper) => (
                      <Card key={paper.id} className="hover:shadow-md transition-shadow">
                        <CardContent className="p-6">
                          <div className="flex items-start justify-between">
                            <div className="flex-1">
                              <h3 className="font-semibold mb-2">{paper.title}</h3>
                              <p className="text-sm text-muted-foreground mb-2">
                                Authors: {paper.authors}
                              </p>
                              <p className="text-sm mb-3 line-clamp-2">
                                {paper.abstract}
                              </p>
                              <div className="flex items-center space-x-4 text-sm text-muted-foreground mb-3">
                                <Badge variant="outline">{paper.researchField}</Badge>
                                <span className="flex items-center space-x-1">
                                  <Clock className="h-3 w-3" />
                                  <span>{new Date(paper.createdAt).toLocaleDateString()}</span>
                                </span>
                              </div>
                              <div className="flex items-center space-x-2">
                                {paper.keywords.split(",").slice(0, 3).map((keyword, index) => (
                                  <Badge key={index} variant="secondary" className="text-xs">
                                    {keyword.trim()}
                                  </Badge>
                                ))}
                              </div>
                            </div>
                            <div className="flex flex-col items-end space-y-2 ml-4">
                              <div className="flex items-center space-x-2">
                                <Button
                                  size="sm"
                                  variant="ghost"
                                  onClick={() => handlePaperFeedback(paper.id, "like")}
                                  className="text-green-600 hover:bg-green-50"
                                >
                                  <ThumbsUp className="h-4 w-4" />
                                </Button>
                                <Button
                                  size="sm"
                                  variant="ghost"
                                  onClick={() => handlePaperFeedback(paper.id, "dislike")}
                                  className="text-red-600 hover:bg-red-50"
                                >
                                  <ThumbsDown className="h-4 w-4" />
                                </Button>
                              </div>
                              <Link href={`/manuscript/${paper.id}`}>
                                <Button size="sm" className="bg-primary hover:bg-primary/90">
                                  View Paper
                                </Button>
                              </Link>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                )}
              </TabsContent>

              <TabsContent value="collaborators" className="space-y-6 mt-6">
                <div className="flex items-center justify-between">
                  <h2 className="text-xl font-semibold">Researchers With Similar Interests</h2>
                  <Badge variant="outline" className="text-primary">
                    {collaborators?.length || 0} suggestions
                  </Badge>
                </div>

                {!collaborators || collaborators.length === 0 ? (
                  <Card>
                    <CardContent className="p-12 text-center">
                      <Users className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                      <h3 className="text-lg font-medium mb-2">Finding Potential Collaborators</h3>
                      <p className="text-muted-foreground">
                        Set your research interests to discover researchers working on similar topics
                      </p>
                    </CardContent>
                  </Card>
                ) : (
                  <div className="space-y-4">
                    {collaborators.map((collab: Collaborator) => (
                      <Card key={collab.user.id} className="hover:shadow-md transition-shadow">
                        <CardContent className="p-6">
                          <div className="flex items-start justify-between">
                            <div className="flex-1">
                              <div className="flex items-center space-x-3 mb-3">
                                <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center">
                                  <Users className="h-5 w-5 text-primary" />
                                </div>
                                <div>
                                  <h3 className="font-semibold">{collab.user.username}</h3>
                                  {collab.user.institutionName && (
                                    <p className="text-sm text-muted-foreground">
                                      {collab.user.institutionName}
                                    </p>
                                  )}
                                </div>
                              </div>
                              <div className="mb-3">
                                <p className="text-sm font-medium mb-2">Common Research Interests:</p>
                                <div className="flex flex-wrap gap-2">
                                  {collab.commonInterests.map((interest, index) => (
                                    <Badge key={index} variant="secondary" className="text-xs">
                                      {interest}
                                    </Badge>
                                  ))}
                                </div>
                              </div>
                              <div className="flex items-center space-x-2">
                                <Star className="h-4 w-4 text-yellow-500" />
                                <span className="text-sm font-medium">
                                  {Math.round(collab.score * 100)}% similarity match
                                </span>
                              </div>
                            </div>
                            <Button
                              size="sm"
                              onClick={() => handleCollaboratorInterest(collab.user.id)}
                              className="bg-primary hover:bg-primary/90"
                            >
                              Connect
                            </Button>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                )}
              </TabsContent>

              <TabsContent value="trending" className="space-y-6 mt-6">
                <div className="flex items-center justify-between">
                  <h2 className="text-xl font-semibold">Trending Research Topics</h2>
                  <Badge variant="outline" className="text-primary">
                    Weekly trends
                  </Badge>
                </div>

                {!trendingTopics || trendingTopics.length === 0 ? (
                  <Card>
                    <CardContent className="p-12 text-center">
                      <TrendingUp className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                      <h3 className="text-lg font-medium mb-2">No Trending Topics Yet</h3>
                      <p className="text-muted-foreground">
                        Trending topics will appear as more research is published on the platform
                      </p>
                    </CardContent>
                  </Card>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {trendingTopics.map((topic: TrendingTopic) => (
                      <Card key={topic.id} className="hover:shadow-md transition-shadow">
                        <CardContent className="p-6">
                          <div className="flex items-start justify-between mb-3">
                            <div className="flex-1">
                              <h3 className="font-semibold">{topic.topic}</h3>
                              <Badge variant="outline" className="mt-1">
                                {topic.category}
                              </Badge>
                            </div>
                            <div className="text-right">
                              <div className="text-sm font-medium text-green-600">
                                +{topic.growthRate / 100}%
                              </div>
                              <div className="text-xs text-muted-foreground">growth</div>
                            </div>
                          </div>
                          <div className="flex items-center justify-between text-sm text-muted-foreground">
                            <span>{topic.manuscriptCount} papers</span>
                            <span>Score: {topic.score}</span>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                )}
              </TabsContent>
            </Tabs>
          </div>

          {/* Right Sidebar - Research Interests */}
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Lightbulb className="h-5 w-5" />
                  <span>Research Interests</span>
                </CardTitle>
                <CardDescription>
                  Manage your research interests to improve recommendations
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {/* Add New Interest */}
                <div className="space-y-3">
                  <Label htmlFor="new-interest">Add Interest</Label>
                  <Input
                    id="new-interest"
                    placeholder="e.g., Machine Learning"
                    value={newInterest}
                    onChange={(e) => setNewInterest(e.target.value)}
                    onKeyPress={(e) => e.key === "Enter" && handleAddInterest()}
                  />
                  <div className="space-y-2">
                    <Label>Interest Strength: {interestWeight[0]}</Label>
                    <Slider
                      value={interestWeight}
                      onValueChange={setInterestWeight}
                      max={1000}
                      min={100}
                      step={50}
                      className="w-full"
                    />
                  </div>
                  <Button 
                    onClick={handleAddInterest}
                    disabled={!newInterest.trim() || updateInterestMutation.isPending}
                    className="w-full"
                  >
                    <Plus className="h-4 w-4 mr-2" />
                    Add Interest
                  </Button>
                </div>

                {/* Current Interests */}
                <div className="space-y-3">
                  <Label>Current Interests</Label>
                  {userInterests && userInterests.length > 0 ? (
                    <div className="space-y-2">
                      {userInterests.map((interest: UserInterest) => (
                        <div key={interest.id} className="p-3 border rounded-lg space-y-2">
                          <div className="flex items-center justify-between">
                            <span className="font-medium text-sm">{interest.topic}</span>
                            <Badge variant="secondary" className="text-xs">
                              {interest.source}
                            </Badge>
                          </div>
                          <div className="space-y-1">
                            <div className="flex items-center justify-between text-xs text-muted-foreground">
                              <span>Weight: {interest.weight}</span>
                              <div className="flex space-x-1">
                                <Button
                                  size="sm"
                                  variant="ghost"
                                  onClick={() => handleUpdateInterestWeight(interest, Math.max(100, interest.weight - 100))}
                                  className="h-6 w-6 p-0"
                                >
                                  <Minus className="h-3 w-3" />
                                </Button>
                                <Button
                                  size="sm"
                                  variant="ghost"
                                  onClick={() => handleUpdateInterestWeight(interest, Math.min(1000, interest.weight + 100))}
                                  className="h-6 w-6 p-0"
                                >
                                  <Plus className="h-3 w-3" />
                                </Button>
                              </div>
                            </div>
                            <div className="w-full bg-gray-200 rounded-full h-1">
                              <div 
                                className="bg-primary h-1 rounded-full" 
                                style={{ width: `${(interest.weight / 1000) * 100}%` }}
                              />
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <p className="text-sm text-muted-foreground">
                      No interests set yet. Add interests to get better recommendations.
                    </p>
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Recommendation Stats */}
            <Card>
              <CardHeader>
                <CardTitle>Recommendation Stats</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex justify-between">
                    <span className="text-sm">Papers recommended</span>
                    <span className="font-medium">{recommendedPapers?.length || 0}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm">Potential collaborators</span>
                    <span className="font-medium">{collaborators?.length || 0}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm">Research interests</span>
                    <span className="font-medium">{userInterests?.length || 0}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm">Trending topics</span>
                    <span className="font-medium">{trendingTopics?.length || 0}</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}