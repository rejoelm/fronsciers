import { useState } from "react";
import { Link, useLocation } from "wouter";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { z } from "zod";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { WalletConnection } from "@/components/wallet-connection";
import { AuthPrompt } from "@/components/AuthPrompt";
import { Navigation } from "@/components/Navigation";
import { PDFUpload } from "@/components/pdf-upload";
import { useWallet } from "@/hooks/use-wallet";
import { useWebSocket } from "@/hooks/use-websocket";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { uploadToIPFS } from "@/lib/ipfs";
import { 
  ArrowLeft, Upload, FileText, Coins, IdCard, 
  AlertCircle, CheckCircle, Clock, Info, Wallet 
} from "lucide-react";

const manuscriptSchema = z.object({
  title: z.string().min(10, "Title must be at least 10 characters"),
  abstract: z.string().min(100, "Abstract must be at least 100 characters"),
  authors: z.string().min(1, "Authors are required"),
  researchField: z.string().min(1, "Research field is required"),
  keywords: z.string().min(1, "Keywords are required"),
  terms: z.boolean().refine(val => val === true, "You must accept the terms and conditions"),
});

type ManuscriptForm = z.infer<typeof manuscriptSchema>;

const RESEARCH_FIELDS = [
  "Computer Science",
  "Biology",
  "Physics", 
  "Chemistry",
  "Mathematics",
  "Medicine",
  "Engineering",
  "Economics",
  "Psychology",
  "Environmental Science"
];

export default function Submit() {
  const [, setLocation] = useLocation();
  const { isConnected } = useWallet();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { isConnected: wsConnected } = useWebSocket();
  const [showAuthPrompt, setShowAuthPrompt] = useState(false);
  const [activeTab, setActiveTab] = useState("pdf-upload");
  
  const [currentStep, setCurrentStep] = useState(1);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [isDragOver, setIsDragOver] = useState(false);
  const [mintNFT, setMintNFT] = useState(true);
  const [enableResale, setEnableResale] = useState(false);

  const form = useForm<ManuscriptForm>({
    resolver: zodResolver(manuscriptSchema),
    defaultValues: {
      title: "",
      abstract: "",
      authors: "",
      researchField: "",
      keywords: "",
      terms: false,
    },
  });

  const createManuscriptMutation = useMutation({
    mutationFn: async (data: any) => {
      const response = await apiRequest("POST", "/api/manuscripts", data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/manuscripts"] });
      toast({
        title: "Success!",
        description: "Manuscript submitted successfully and DOCI minting initiated.",
      });
      setLocation("/dashboard");
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to submit manuscript. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleFileSelect = (file: File) => {
    if (file.type !== "application/pdf") {
      toast({
        title: "Invalid file type",
        description: "Please select a PDF file.",
        variant: "destructive",
      });
      return;
    }
    
    if (file.size > 10 * 1024 * 1024) { // 10MB limit
      toast({
        title: "File too large",
        description: "Please select a file smaller than 10MB.",
        variant: "destructive",
      });
      return;
    }
    
    setSelectedFile(file);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
    
    const files = Array.from(e.dataTransfer.files);
    if (files.length > 0) {
      handleFileSelect(files[0]);
    }
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
  };

  const onSubmit = async (data: ManuscriptForm) => {
    if (!selectedFile) {
      toast({
        title: "File required",
        description: "Please upload your manuscript PDF.",
        variant: "destructive",
      });
      return;
    }

    if (currentStep === 1) {
      setCurrentStep(2);
      return;
    }

    // Check wallet connection before submitting
    if (!isConnected) {
      setShowAuthPrompt(true);
      return;
    }

    try {
      // Upload to IPFS
      const ipfsHash = await uploadToIPFS(selectedFile);
      
      // Create manuscript record
      const manuscriptData = {
        ...data,
        userId: 1, // Mock user ID
        status: "submitted",
        ipfsHash,
        dociMinted: mintNFT,
        nftAddress: mintNFT ? `nft_${Date.now()}` : null, // Mock NFT address
      };

      createManuscriptMutation.mutate(manuscriptData);
    } catch (error) {
      toast({
        title: "Upload failed",
        description: "Failed to upload manuscript to IPFS. Please try again.",
        variant: "destructive",
      });
    }
  };

  // Show auth prompt when trying to submit without connection
  if (showAuthPrompt && !isConnected) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50">
        <Navigation />
        <div className="container mx-auto px-4 py-8">
          <AuthPrompt 
            action="submit" 
            onCancel={() => setShowAuthPrompt(false)}
          />
        </div>
      </div>
    );
  }

  const progress = (currentStep / 2) * 100;

  // Show submission form regardless of connection status
  // Wallet connection will be required when actually submitting

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b bg-card/50 backdrop-blur-sm">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <Link href="/dashboard">
                <Button variant="ghost" size="sm">
                  <ArrowLeft className="h-4 w-4 mr-2" />
                  Back to Dashboard
                </Button>
              </Link>
              <Separator orientation="vertical" className="h-6" />
              <div>
                <h1 className="text-2xl font-bold">Submit Manuscript</h1>
                <p className="text-muted-foreground">Upload your research and mint a DOCI NFT</p>
              </div>
            </div>
            <WalletConnection />
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8 max-w-4xl">
        {/* Wallet Connection Status */}
        {!isConnected && (
          <div className="mb-4 p-3 bg-blue-50 border border-blue-200 rounded-md">
            <div className="flex items-center space-x-2 text-sm text-blue-700">
              <Wallet className="h-4 w-4" />
              <span>You can fill out forms and upload PDFs without connecting your wallet. Connection is only required for final submission.</span>
            </div>
          </div>
        )}

        {/* Real-time Connection Status */}
        {wsConnected && (
          <div className="mb-4 p-2 bg-green-50 border border-green-200 rounded-md">
            <div className="flex items-center space-x-2 text-sm text-green-700">
              <CheckCircle className="h-4 w-4" />
              <span>Real-time updates enabled - Dashboard will update automatically</span>
            </div>
          </div>
        )}

        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="pdf-upload" className="flex items-center space-x-2">
              <Upload className="h-4 w-4" />
              <span>Quick PDF Upload</span>
            </TabsTrigger>
            <TabsTrigger value="manual-form" className="flex items-center space-x-2">
              <FileText className="h-4 w-4" />
              <span>Manual Form</span>
            </TabsTrigger>
          </TabsList>

          <TabsContent value="pdf-upload" className="mt-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Upload className="h-5 w-5" />
                  <span>Adaptive PDF Upload</span>
                </CardTitle>
                <CardDescription>
                  Upload your PDF manuscript for automatic processing and instant dashboard updates
                </CardDescription>
              </CardHeader>
              <CardContent>
                <PDFUpload 
                  onUploadComplete={(manuscriptId) => {
                    toast({
                      title: "Upload Complete",
                      description: "Your manuscript has been processed and added to your dashboard.",
                    });
                    setLocation("/dashboard");
                  }}
                  className="w-full"
                />
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="manual-form" className="mt-6">
            {/* Progress */}
            <div className="mb-8">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium">Step {currentStep} of 2</span>
                <span className="text-sm text-muted-foreground">{Math.round(progress)}% complete</span>
              </div>
              <Progress value={progress} className="h-2" />
            </div>

            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
          {currentStep === 1 && (
            <div className="space-y-6">
              {/* Basic Information */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <FileText className="h-5 w-5" />
                    <span>Manuscript Details</span>
                  </CardTitle>
                  <CardDescription>
                    Provide basic information about your research
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="title">Title *</Label>
                      <Input
                        id="title"
                        placeholder="Enter manuscript title"
                        {...form.register("title")}
                        className={form.formState.errors.title ? "border-destructive" : ""}
                      />
                      {form.formState.errors.title && (
                        <p className="text-sm text-destructive">{form.formState.errors.title.message}</p>
                      )}
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="researchField">Research Field *</Label>
                      <Select 
                        onValueChange={(value) => form.setValue("researchField", value)}
                        value={form.watch("researchField")}
                      >
                        <SelectTrigger className={form.formState.errors.researchField ? "border-destructive" : ""}>
                          <SelectValue placeholder="Select research field" />
                        </SelectTrigger>
                        <SelectContent>
                          {RESEARCH_FIELDS.map((field) => (
                            <SelectItem key={field} value={field}>
                              {field}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      {form.formState.errors.researchField && (
                        <p className="text-sm text-destructive">{form.formState.errors.researchField.message}</p>
                      )}
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="authors">Authors *</Label>
                    <Input
                      id="authors"
                      placeholder="Comma-separated list of authors"
                      {...form.register("authors")}
                      className={form.formState.errors.authors ? "border-destructive" : ""}
                    />
                    {form.formState.errors.authors && (
                      <p className="text-sm text-destructive">{form.formState.errors.authors.message}</p>
                    )}
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="abstract">Abstract *</Label>
                    <Textarea
                      id="abstract"
                      rows={6}
                      placeholder="Enter your paper abstract..."
                      {...form.register("abstract")}
                      className={form.formState.errors.abstract ? "border-destructive" : ""}
                    />
                    <div className="flex justify-between text-sm text-muted-foreground">
                      <span>{form.formState.errors.abstract?.message || "Minimum 100 characters"}</span>
                      <span>{form.watch("abstract")?.length || 0} characters</span>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="keywords">Keywords *</Label>
                    <Input
                      id="keywords"
                      placeholder="machine learning, blockchain, optimization"
                      {...form.register("keywords")}
                      className={form.formState.errors.keywords ? "border-destructive" : ""}
                    />
                    {form.formState.errors.keywords && (
                      <p className="text-sm text-destructive">{form.formState.errors.keywords.message}</p>
                    )}
                  </div>
                </CardContent>
              </Card>

              {/* File Upload */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Upload className="h-5 w-5" />
                    <span>Manuscript File</span>
                  </CardTitle>
                  <CardDescription>
                    Upload your manuscript in PDF format (max 10MB)
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div
                    className={`file-upload-area ${isDragOver ? "dragging" : ""}`}
                    onDrop={handleDrop}
                    onDragOver={handleDragOver}
                    onDragLeave={handleDragLeave}
                    onClick={() => document.getElementById("file-input")?.click()}
                  >
                    {selectedFile ? (
                      <div className="flex items-center space-x-3">
                        <CheckCircle className="h-8 w-8 text-green-600" />
                        <div>
                          <p className="font-medium">{selectedFile.name}</p>
                          <p className="text-sm text-muted-foreground">
                            {(selectedFile.size / 1024 / 1024).toFixed(2)} MB
                          </p>
                        </div>
                      </div>
                    ) : (
                      <>
                        <Upload className="h-12 w-12 text-muted-foreground mb-4" />
                        <p className="text-lg font-medium mb-2">Drop your PDF file here</p>
                        <p className="text-muted-foreground mb-4">or click to browse</p>
                        <Button type="button" variant="outline">
                          Choose File
                        </Button>
                      </>
                    )}
                  </div>
                  <input
                    id="file-input"
                    type="file"
                    accept=".pdf"
                    className="hidden"
                    onChange={(e) => e.target.files?.[0] && handleFileSelect(e.target.files[0])}
                  />
                </CardContent>
              </Card>

              <div className="flex justify-end">
                <Button type="submit" size="lg">
                  Continue
                  <ArrowLeft className="h-4 w-4 ml-2 rotate-180" />
                </Button>
              </div>
            </div>
          )}

          {currentStep === 2 && (
            <div className="space-y-6">
              {/* Review Information */}
              <Card>
                <CardHeader>
                  <CardTitle>Review Your Submission</CardTitle>
                  <CardDescription>
                    Please review your manuscript details before final submission
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label className="text-sm font-medium text-muted-foreground">Title</Label>
                      <p className="font-medium">{form.watch("title")}</p>
                    </div>
                    <div>
                      <Label className="text-sm font-medium text-muted-foreground">Research Field</Label>
                      <p className="font-medium">{form.watch("researchField")}</p>
                    </div>
                  </div>
                  <div>
                    <Label className="text-sm font-medium text-muted-foreground">Authors</Label>
                    <p className="font-medium">{form.watch("authors")}</p>
                  </div>
                  <div>
                    <Label className="text-sm font-medium text-muted-foreground">Keywords</Label>
                    <div className="flex flex-wrap gap-2 mt-1">
                      {form.watch("keywords")?.split(",").map((keyword, index) => (
                        <Badge key={index} variant="secondary">
                          {keyword.trim()}
                        </Badge>
                      ))}
                    </div>
                  </div>
                  {selectedFile && (
                    <div>
                      <Label className="text-sm font-medium text-muted-foreground">Manuscript File</Label>
                      <div className="flex items-center space-x-2 mt-1">
                        <FileText className="h-4 w-4" />
                        <span className="font-medium">{selectedFile.name}</span>
                        <span className="text-sm text-muted-foreground">
                          ({(selectedFile.size / 1024 / 1024).toFixed(2)} MB)
                        </span>
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>

              {/* DOCI Minting Options */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <IdCard className="h-5 w-5" />
                    <span>DOCI (Direct On-Chain Identifier) Options</span>
                  </CardTitle>
                  <CardDescription>
                    Configure your publication NFT settings
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="mint-nft"
                      checked={mintNFT}
                      onCheckedChange={(checked) => setMintNFT(checked === true)}
                    />
                    <Label htmlFor="mint-nft" className="font-medium">
                      Mint as NFT
                    </Label>
                  </div>
                  
                  {mintNFT && (
                    <div className="ml-6 space-y-3">
                      <div className="flex items-center space-x-2">
                        <Checkbox
                          id="enable-resale"
                          checked={enableResale}
                          onCheckedChange={(checked) => setEnableResale(checked === true)}
                        />
                        <Label htmlFor="enable-resale">
                          Enable Resale
                        </Label>
                      </div>
                      
                      <div className="bg-primary/5 border border-primary/20 rounded-lg p-4">
                        <div className="flex items-center space-x-2 mb-2">
                          <Coins className="h-4 w-4 text-primary" />
                          <span className="font-medium">Minting Fee</span>
                        </div>
                        <div className="flex items-center space-x-2">
                          <span className="text-2xl font-bold">0.1 SOL</span>
                          <span className="text-muted-foreground">+ 50 FRONS</span>
                        </div>
                        <p className="text-sm text-muted-foreground mt-2">
                          Required for DOCI minting and initial peer review assignment
                        </p>
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>

              {/* Terms and Conditions */}
              <Card>
                <CardContent className="pt-6">
                  <div className="flex items-start space-x-2">
                    <Checkbox
                      id="terms"
                      checked={form.watch("terms")}
                      onCheckedChange={(checked) => form.setValue("terms", checked as boolean)}
                      className={form.formState.errors.terms ? "border-destructive" : ""}
                    />
                    <div className="space-y-1">
                      <Label htmlFor="terms" className="font-medium">
                        I agree to the terms and conditions
                      </Label>
                      <p className="text-sm text-muted-foreground">
                        By submitting this manuscript, you agree to our{" "}
                        <a href="#" className="text-primary underline">
                          Terms of Service
                        </a>{" "}
                        and{" "}
                        <a href="#" className="text-primary underline">
                          Publishing Guidelines
                        </a>
                        .
                      </p>
                    </div>
                  </div>
                  {form.formState.errors.terms && (
                    <p className="text-sm text-destructive mt-2">{form.formState.errors.terms.message}</p>
                  )}
                </CardContent>
              </Card>

              <div className="flex justify-between">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setCurrentStep(1)}
                >
                  <ArrowLeft className="h-4 w-4 mr-2" />
                  Back
                </Button>
                
                <Button
                  type="submit"
                  size="lg"
                  disabled={createManuscriptMutation.isPending}
                  className="gradient-bg"
                >
                  {createManuscriptMutation.isPending ? (
                    <>
                      <Clock className="h-4 w-4 mr-2 animate-spin" />
                      Submitting...
                    </>
                  ) : (
                    <>
                      <IdCard className="h-4 w-4 mr-2" />
                      Submit & Mint DOCI
                    </>
                  )}
                </Button>
              </div>
            </div>
          )}
        </form>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
