import { ReviewDashboard } from "@/components/ReviewDashboard";

export default function PeerReviewPage() {
  return <ReviewDashboard />;
}