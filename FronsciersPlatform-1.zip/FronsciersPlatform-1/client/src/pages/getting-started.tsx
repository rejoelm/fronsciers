import { useState } from "react";
import { Link } from "wouter";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { 
  Wallet, 
  FileText, 
  Users, 
  IdCard, 
  Coins, 
  Vote, 
  PlayCircle, 
  ExternalLink,
  CheckCircle,
  Clock,
  ArrowRight,
  Download
} from "lucide-react";

export default function GettingStarted() {
  const [completedSteps, setCompletedSteps] = useState<number[]>([]);

  const markStepComplete = (stepId: number) => {
    if (!completedSteps.includes(stepId)) {
      setCompletedSteps([...completedSteps, stepId]);
    }
  };

  const progressPercentage = (completedSteps.length / 6) * 100;

  const tutorialSteps = [
    {
      id: 1,
      title: "Connect Your Wallet",
      description: "Link your Solana wallet to start using FRONSCIERS",
      icon: Wallet,
      duration: "2 minutes",
      videoUrl: "https://www.youtube.com/embed/dQw4w9WgXcQ", // Demo video
      steps: [
        "Install a Solana wallet (Phantom, Solflare, or Backpack)",
        "Click 'Connect Wallet' in the top navigation",
        "Approve the connection request in your wallet",
        "Sign the authentication message to verify ownership"
      ]
    },
    {
      id: 2,
      title: "Register a DOCI",
      description: "Create your first Direct On-Chain Identifier for manuscript tracking",
      icon: IdCard,
      duration: "5 minutes",
      videoUrl: "https://www.youtube.com/embed/dQw4w9WgXcQ", // Demo video
      steps: [
        "Navigate to the DOCI Registry page",
        "Click 'Register New DOCI'",
        "Enter your manuscript metadata (title, authors, keywords)",
        "Pay the registration fee (25 FRONS tokens)",
        "Confirm the transaction to mint your DOCI NFT"
      ]
    },
    {
      id: 3,
      title: "Submit Your Research",
      description: "Upload your manuscript and begin the peer review process",
      icon: FileText,
      duration: "10 minutes",
      videoUrl: "https://www.youtube.com/embed/dQw4w9WgXcQ", // Demo video
      steps: [
        "Go to Submit Research page",
        "Upload your PDF manuscript (max 50MB)",
        "Complete the submission form with abstract and metadata",
        "Select your research category and keywords",
        "Pay submission fee (50 FRONS tokens) and submit"
      ]
    },
    {
      id: 4,
      title: "Participate in Peer Review",
      description: "Review other researchers' work and earn FRONS tokens",
      icon: Users,
      duration: "30-60 minutes",
      videoUrl: "https://www.youtube.com/embed/dQw4w9WgXcQ", // Demo video
      steps: [
        "Visit the Peer Review dashboard",
        "Browse available manuscripts in your expertise area",
        "Accept a review assignment",
        "Evaluate methodology, novelty, and clarity (1-10 scale)",
        "Submit detailed feedback and earn 50-100 FRONS tokens"
      ]
    },
    {
      id: 5,
      title: "Earn and Manage FRONS Tokens",
      description: "Understand the tokenomics and maximize your rewards",
      icon: Coins,
      duration: "5 minutes",
      videoUrl: "https://www.youtube.com/embed/dQw4w9WgXcQ", // Demo video
      steps: [
        "Check your token balance in the Tokenomics dashboard",
        "Earn tokens through quality peer reviews (50-100 FRONS)",
        "Receive publication bonuses for accepted papers (200 FRONS)",
        "Stake tokens in governance for voting power",
        "Use tokens for submission fees and platform services"
      ]
    },
    {
      id: 6,
      title: "Join DAO Governance",
      description: "Vote on platform decisions and propose improvements",
      icon: Vote,
      duration: "10 minutes",
      videoUrl: "https://www.youtube.com/embed/dQw4w9WgXcQ", // Demo video
      steps: [
        "Navigate to the Governance section",
        "Review active proposals and their details",
        "Stake FRONS tokens to gain voting power",
        "Cast your votes on proposals (Yes/No/Abstain)",
        "Create your own proposals for platform improvements"
      ]
    }
  ];

  const whitePaperSections = [
    {
      title: "Abstract",
      content: "FRONSCIERS revolutionizes academic publishing through blockchain technology, introducing Direct On-Chain Identifiers (DOCIs) as NFTs and a multi-tier peer review system powered by FRONS token incentives."
    },
    {
      title: "Problem Statement",
      content: "Traditional academic publishing faces issues with transparency, gatekeeping, slow review processes, and lack of reviewer incentives. FRONSCIERS addresses these challenges through decentralized governance and blockchain verification."
    },
    {
      title: "DOCI Technology",
      content: "Direct On-Chain Identifiers (DOCIs) are unique NFTs that track manuscripts throughout their lifecycle, providing immutable proof of authorship, submission timestamps, and review history on the Solana blockchain."
    },
    {
      title: "Tokenomics Model",
      content: "FRONS tokens incentivize quality peer review through structured rewards: 50-100 tokens per review, 200 tokens for accepted publications, and governance voting power based on token holdings."
    }
  ];

  return (
    <div className="min-h-screen bg-background">
      <div className="container-responsive py-8">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold mb-4">Getting Started with FRONSCIERS</h1>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto mb-6">
            Learn how to use the revolutionary blockchain academic publishing platform. 
            Follow our step-by-step tutorials to connect your wallet, register DOCIs, and participate in peer review.
          </p>
          
          {/* Progress Overview */}
          <Card className="max-w-md mx-auto">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium">Your Progress</span>
                <span className="text-sm text-muted-foreground">
                  {completedSteps.length}/6 steps
                </span>
              </div>
              <Progress value={progressPercentage} className="h-2" />
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="tutorials" className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="tutorials">Interactive Tutorials</TabsTrigger>
            <TabsTrigger value="whitepaper">White Paper</TabsTrigger>
            <TabsTrigger value="quickstart">Quick Start</TabsTrigger>
          </TabsList>

          {/* Interactive Tutorials */}
          <TabsContent value="tutorials" className="mt-8">
            <div className="grid gap-8">
              {tutorialSteps.map((step) => {
                const Icon = step.icon;
                const isCompleted = completedSteps.includes(step.id);

                return (
                  <Card key={step.id} className={`transition-all ${isCompleted ? 'border-green-500 bg-green-50' : 'hover:shadow-lg'}`}>
                    <CardHeader>
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-4">
                          <div className={`p-3 rounded-lg ${isCompleted ? 'bg-green-500 text-white' : 'bg-primary/10 text-primary'}`}>
                            {isCompleted ? <CheckCircle className="h-6 w-6" /> : <Icon className="h-6 w-6" />}
                          </div>
                          <div>
                            <CardTitle className="flex items-center space-x-2">
                              <span>Step {step.id}: {step.title}</span>
                              {isCompleted && <Badge variant="secondary" className="bg-green-100 text-green-800">Completed</Badge>}
                            </CardTitle>
                            <CardDescription className="flex items-center space-x-2 mt-1">
                              <Clock className="h-4 w-4" />
                              <span>{step.duration}</span>
                            </CardDescription>
                          </div>
                        </div>
                        
                        {!isCompleted && (
                          <Button 
                            onClick={() => markStepComplete(step.id)}
                            variant="outline"
                            size="sm"
                          >
                            Mark Complete
                          </Button>
                        )}
                      </div>
                    </CardHeader>
                    
                    <CardContent className="space-y-6">
                      <p className="text-muted-foreground">{step.description}</p>
                      
                      {/* Video Tutorial */}
                      <div className="relative aspect-video bg-gray-100 rounded-lg overflow-hidden">
                        <iframe
                          src={step.videoUrl}
                          title={`${step.title} Tutorial`}
                          className="w-full h-full"
                          allowFullScreen
                        />
                        <div className="absolute inset-0 flex items-center justify-center bg-black/20 opacity-0 hover:opacity-100 transition-opacity">
                          <Button size="lg" className="bg-white/90 text-gray-900 hover:bg-white">
                            <PlayCircle className="h-5 w-5 mr-2" />
                            Watch Tutorial
                          </Button>
                        </div>
                      </div>

                      {/* Step-by-step Instructions */}
                      <div>
                        <h4 className="font-semibold mb-3">Step-by-step Instructions:</h4>
                        <ol className="space-y-2">
                          {step.steps.map((instruction, index) => (
                            <li key={index} className="flex items-start space-x-3">
                              <div className="w-6 h-6 bg-primary/10 text-primary rounded-full flex items-center justify-center text-xs font-semibold mt-0.5">
                                {index + 1}
                              </div>
                              <span className="text-sm">{instruction}</span>
                            </li>
                          ))}
                        </ol>
                      </div>

                      {/* Action Buttons */}
                      <div className="flex space-x-3">
                        <Button asChild>
                          <Link href={step.id === 1 ? "/" : step.id === 2 ? "/doci-registry" : step.id === 3 ? "/submit" : step.id === 4 ? "/peer-review" : step.id === 5 ? "/tokenomics" : "/governance"}>
                            Try It Now
                            <ArrowRight className="h-4 w-4 ml-2" />
                          </Link>
                        </Button>
                        <Button variant="outline" onClick={() => markStepComplete(step.id)}>
                          Skip This Step
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </TabsContent>

          {/* White Paper */}
          <TabsContent value="whitepaper" className="mt-8">
            <div className="grid lg:grid-cols-3 gap-8">
              <div className="lg:col-span-2 space-y-8">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center space-x-2">
                      <FileText className="h-5 w-5" />
                      <span>FRONSCIERS White Paper</span>
                    </CardTitle>
                    <CardDescription>
                      Comprehensive technical documentation of the FRONSCIERS platform
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Button asChild className="mb-6">
                      <a href="/attached_assets/WHITE PAPER_FRONSCIERS.pdf" target="_blank" rel="noopener noreferrer">
                        <Download className="h-4 w-4 mr-2" />
                        Download Full White Paper (PDF)
                      </a>
                    </Button>

                    <div className="space-y-6">
                      {whitePaperSections.map((section, index) => (
                        <div key={index} className="border-l-4 border-primary/20 pl-4">
                          <h3 className="font-semibold text-lg mb-2">{section.title}</h3>
                          <p className="text-muted-foreground leading-relaxed">{section.content}</p>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </div>

              <div className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Key Statistics</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Total Pages</span>
                      <span className="font-semibold">24</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Research Citations</span>
                      <span className="font-semibold">67</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Technical Diagrams</span>
                      <span className="font-semibold">12</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Publication Date</span>
                      <span className="font-semibold">Dec 2024</span>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Related Resources</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <Button variant="outline" className="w-full justify-start" asChild>
                      <Link href="/tokenomics">
                        <Coins className="h-4 w-4 mr-2" />
                        Tokenomics Overview
                      </Link>
                    </Button>
                    <Button variant="outline" className="w-full justify-start" asChild>
                      <Link href="/governance">
                        <Vote className="h-4 w-4 mr-2" />
                        DAO Governance
                      </Link>
                    </Button>
                    <Button variant="outline" className="w-full justify-start" asChild>
                      <a href="https://docs.solana.com" target="_blank" rel="noopener noreferrer">
                        <ExternalLink className="h-4 w-4 mr-2" />
                        Solana Documentation
                      </a>
                    </Button>
                  </CardContent>
                </Card>
              </div>
            </div>
          </TabsContent>

          {/* Quick Start */}
          <TabsContent value="quickstart" className="mt-8">
            <div className="grid md:grid-cols-2 gap-8">
              <Card>
                <CardHeader>
                  <CardTitle>For Researchers</CardTitle>
                  <CardDescription>
                    Start publishing and earn FRONS tokens for your research contributions
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-3">
                    <div className="flex items-center space-x-3">
                      <div className="w-8 h-8 bg-blue-100 text-blue-600 rounded-full flex items-center justify-center text-sm font-semibold">1</div>
                      <span>Connect your Solana wallet</span>
                    </div>
                    <div className="flex items-center space-x-3">
                      <div className="w-8 h-8 bg-blue-100 text-blue-600 rounded-full flex items-center justify-center text-sm font-semibold">2</div>
                      <span>Submit your research manuscript</span>
                    </div>
                    <div className="flex items-center space-x-3">
                      <div className="w-8 h-8 bg-blue-100 text-blue-600 rounded-full flex items-center justify-center text-sm font-semibold">3</div>
                      <span>Track progress through peer review</span>
                    </div>
                    <div className="flex items-center space-x-3">
                      <div className="w-8 h-8 bg-blue-100 text-blue-600 rounded-full flex items-center justify-center text-sm font-semibold">4</div>
                      <span>Get published and earn rewards</span>
                    </div>
                  </div>
                  <Button className="w-full" asChild>
                    <Link href="/submit">
                      Start Publishing
                      <ArrowRight className="h-4 w-4 ml-2" />
                    </Link>
                  </Button>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>For Reviewers</CardTitle>
                  <CardDescription>
                    Contribute to scientific quality and earn tokens for peer review
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-3">
                    <div className="flex items-center space-x-3">
                      <div className="w-8 h-8 bg-green-100 text-green-600 rounded-full flex items-center justify-center text-sm font-semibold">1</div>
                      <span>Set up your reviewer profile</span>
                    </div>
                    <div className="flex items-center space-x-3">
                      <div className="w-8 h-8 bg-green-100 text-green-600 rounded-full flex items-center justify-center text-sm font-semibold">2</div>
                      <span>Browse manuscripts in your field</span>
                    </div>
                    <div className="flex items-center space-x-3">
                      <div className="w-8 h-8 bg-green-100 text-green-600 rounded-full flex items-center justify-center text-sm font-semibold">3</div>
                      <span>Provide quality peer review</span>
                    </div>
                    <div className="flex items-center space-x-3">
                      <div className="w-8 h-8 bg-green-100 text-green-600 rounded-full flex items-center justify-center text-sm font-semibold">4</div>
                      <span>Earn 50-100 FRONS per review</span>
                    </div>
                  </div>
                  <Button className="w-full" asChild>
                    <Link href="/peer-review">
                      Start Reviewing
                      <ArrowRight className="h-4 w-4 ml-2" />
                    </Link>
                  </Button>
                </CardContent>
              </Card>
            </div>

            {/* FAQ Section */}
            <Card className="mt-8">
              <CardHeader>
                <CardTitle>Frequently Asked Questions</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div>
                  <h4 className="font-semibold mb-2">What is a DOCI?</h4>
                  <p className="text-muted-foreground">
                    A Direct On-Chain Identifier (DOCI) is a unique NFT that serves as an immutable identifier for your research manuscript on the Solana blockchain. It tracks authorship, submission time, and review history.
                  </p>
                </div>
                <div>
                  <h4 className="font-semibold mb-2">How do I earn FRONS tokens?</h4>
                  <p className="text-muted-foreground">
                    You can earn FRONS tokens by: conducting quality peer reviews (50-100 tokens), publishing accepted research (200 tokens), and participating in community governance activities.
                  </p>
                </div>
                <div>
                  <h4 className="font-semibold mb-2">What wallets are supported?</h4>
                  <p className="text-muted-foreground">
                    FRONSCIERS supports all major Solana wallets including Phantom, Solflare, Backpack, and any wallet compatible with the Solana Web3.js standard.
                  </p>
                </div>
                <div>
                  <h4 className="font-semibold mb-2">Is my research data secure?</h4>
                  <p className="text-muted-foreground">
                    Yes, manuscripts are stored on IPFS for decentralized access while metadata and review history are secured on the Solana blockchain. Your research remains under your control.
                  </p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}