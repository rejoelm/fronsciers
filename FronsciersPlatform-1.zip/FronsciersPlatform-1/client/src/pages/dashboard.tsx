import { useState } from "react";
import { Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import fronsciersLogo from "@/assets/fronsciers-logo.png";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { WalletConnection } from "@/components/wallet-connection";
import { StatsCard } from "@/components/stats-card";
import { ManuscriptCard } from "@/components/manuscript-card";
import { ReviewCard } from "@/components/review-card";
import { ProposalCard } from "@/components/proposal-card";
import { useWallet } from "@/hooks/use-wallet";
import { 
  FileText, Upload, Users, Vote, IdCard, 
  TrendingUp, Clock, CheckCircle, AlertCircle, BarChart3, Brain 
} from "lucide-react";

export default function Dashboard() {
  const { wallet, isConnected } = useWallet();
  const [activeTab, setActiveTab] = useState("overview");

  // Mock user ID for development - in production this would come from wallet authentication
  const userId = 1;

  const { data: stats, isLoading: statsLoading } = useQuery({
    queryKey: [`/api/dashboard/stats/${userId}`],
    enabled: isConnected,
  });

  const { data: manuscripts, isLoading: manuscriptsLoading } = useQuery({
    queryKey: [`/api/manuscripts/user/${userId}`],
    enabled: isConnected,
  });

  const { data: reviews, isLoading: reviewsLoading } = useQuery({
    queryKey: [`/api/reviews/reviewer/${userId}`],
    enabled: isConnected,
  });

  const { data: activeProposals, isLoading: proposalsLoading } = useQuery({
    queryKey: ["/api/dao-proposals/active"],
    enabled: isConnected,
  });

  // Show public dashboard for all users, with login prompts only for Author/Reviewer actions
  const showPublicDashboard = true;

  if (!isConnected && !showPublicDashboard) {
    return (
      <div className="min-h-screen bg-background">
        <div className="container mx-auto px-4 py-16">
          {/* Hero Section */}
          <div className="text-center mb-16">
            <h1 className="text-6xl font-bold frons-primary-text mb-6">
              FRONSCIERS
            </h1>
            <p className="text-xl text-foreground mb-8 max-w-3xl mx-auto">
              Revolutionary blockchain-powered academic publishing ecosystem on Solana
            </p>
            <p className="text-lg text-muted-foreground mb-12 max-w-2xl mx-auto">
              Decentralized manuscript workflow • Advanced tokenomics • Direct On-Chain Identifiers (DOCIs) • 
              Peer review system • Academic integration • Governance
            </p>
          </div>

          {/* Feature Navigation Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-16">
            <Link href="/submit">
              <Card className="h-full cursor-pointer hover:shadow-lg transition-shadow border-l-4 border-l-primary">
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Upload className="h-5 w-5 frons-primary-text" />
                    <span>Submit Manuscript</span>
                  </CardTitle>
                  <CardDescription>
                    Submit your research with IPFS storage and blockchain verification
                  </CardDescription>
                </CardHeader>
              </Card>
            </Link>

            <Link href="/doci-registry">
              <Card className="h-full cursor-pointer hover:shadow-lg transition-shadow border-l-4 border-l-accent">
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <IdCard className="h-5 w-5 text-accent" />
                    <span>DOCI Registry</span>
                  </CardTitle>
                  <CardDescription>
                    Register Direct On-Chain Identifiers as NFTs on Solana blockchain
                  </CardDescription>
                </CardHeader>
              </Card>
            </Link>

            <Link href="/review">
              <Card className="h-full cursor-pointer hover:shadow-lg transition-shadow border-l-4 border-l-secondary">
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Users className="h-5 w-5 frons-secondary-text" />
                    <span>Peer Review</span>
                  </CardTitle>
                  <CardDescription>
                    Advanced peer review system with AI-powered reviewer matching
                  </CardDescription>
                </CardHeader>
              </Card>
            </Link>

            <Link href="/academic-integration">
              <Card className="h-full cursor-pointer hover:shadow-lg transition-shadow border-l-4 border-l-orange-500">
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <FileText className="h-5 w-5 text-orange-600" />
                    <span>Academic Integration</span>
                  </CardTitle>
                  <CardDescription>
                    Import from CrossRef, arXiv, PubMed, and ORCID databases
                  </CardDescription>
                </CardHeader>
              </Card>
            </Link>

            <Link href="/governance">
              <Card className="h-full cursor-pointer hover:shadow-lg transition-shadow border-l-4 border-l-red-500">
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Vote className="h-5 w-5 text-red-600" />
                    <span>DAO Governance</span>
                  </CardTitle>
                  <CardDescription>
                    FRONS token governance with DeFi capabilities and voting
                  </CardDescription>
                </CardHeader>
              </Card>
            </Link>

            <Link href="/explore">
              <Card className="h-full cursor-pointer hover:shadow-lg transition-shadow border-l-4 border-l-teal-500">
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <TrendingUp className="h-5 w-5 text-teal-600" />
                    <span>Explore Research</span>
                  </CardTitle>
                  <CardDescription>
                    Discover and explore published research on the platform
                  </CardDescription>
                </CardHeader>
              </Card>
            </Link>

            <Link href="/recommendations">
              <Card className="h-full cursor-pointer hover:shadow-lg transition-shadow border-l-4 border-l-purple-500">
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Brain className="h-5 w-5 text-purple-600" />
                    <span>AI Recommendations</span>
                  </CardTitle>
                  <CardDescription>
                    Personalized research and collaborator recommendations
                  </CardDescription>
                </CardHeader>
              </Card>
            </Link>
          </div>

          {/* Key Features */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-16">
            <Card className="text-center p-6">
              <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <img src={fronsciersLogo} alt="FRONS" className="h-6 w-6" />
              </div>
              <h3 className="font-semibold mb-2">FRONS Tokenomics</h3>
              <p className="text-sm text-gray-600">Automated staking rewards and DeFi circulation</p>
            </Card>

            <Card className="text-center p-6">
              <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <CheckCircle className="h-6 w-6 text-purple-600" />
              </div>
              <h3 className="font-semibold mb-2">Research Journey</h3>
              <p className="text-sm text-gray-600">Eight-stage workflow with real-time progress tracking</p>
            </Card>

            <Card className="text-center p-6">
              <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <AlertCircle className="h-6 w-6 text-green-600" />
              </div>
              <h3 className="font-semibold mb-2">Reputation System</h3>
              <p className="text-sm text-gray-600">Dynamic reputation scoring and quality assessment</p>
            </Card>

            <Card className="text-center p-6">
              <div className="w-12 h-12 bg-orange-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Clock className="h-6 w-6 text-orange-600" />
              </div>
              <h3 className="font-semibold mb-2">Real-time Updates</h3>
              <p className="text-sm text-gray-600">WebSocket integration for live workflow synchronization</p>
            </Card>
          </div>

          {/* Technology Showcase */}
          <div className="bg-white rounded-lg border p-8 mb-16">
            <h2 className="text-3xl font-bold text-center mb-8">Platform Technology</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="text-center">
                <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <span className="text-2xl font-bold text-blue-600">⛓️</span>
                </div>
                <h3 className="font-semibold mb-2">Solana Blockchain</h3>
                <p className="text-sm text-gray-600">Fast, secure, and low-cost transactions with NFT-based DOCIs</p>
              </div>
              <div className="text-center">
                <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <span className="text-2xl font-bold text-purple-600">🌐</span>
                </div>
                <h3 className="font-semibold mb-2">IPFS Storage</h3>
                <p className="text-sm text-gray-600">Decentralized content storage with immutable manuscript preservation</p>
              </div>
              <div className="text-center">
                <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <span className="text-2xl font-bold text-green-600">🤖</span>
                </div>
                <h3 className="font-semibold mb-2">AI Integration</h3>
                <p className="text-sm text-gray-600">Smart reviewer matching and automated quality assessment</p>
              </div>
            </div>
          </div>

          {/* Quick Access Features */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-16">
            <Card className="p-6">
              <h3 className="text-xl font-semibold mb-4 flex items-center space-x-2">
                <TrendingUp className="h-5 w-5 text-blue-600" />
                <span>Research Journey Progress</span>
              </h3>
              <p className="text-gray-600 mb-4">
                Track your manuscripts through the complete eight-stage academic workflow with real-time WebSocket updates.
              </p>
              <div className="flex space-x-2 text-xs">
                <Badge variant="outline">Draft</Badge>
                <Badge variant="outline">Submission</Badge>
                <Badge variant="outline">Peer Review</Badge>
                <Badge variant="outline">Publication</Badge>
              </div>
            </Card>

            <Card className="p-6">
              <h3 className="text-xl font-semibold mb-4 flex items-center space-x-2">
                <img src={fronsciersLogo} alt="FRONS" className="h-5 w-5" />
                <span>FRONS Tokenomics</span>
              </h3>
              <p className="text-gray-600 mb-4">
                Earn FRONS tokens through peer review, staking rewards, and quality contributions to the ecosystem.
              </p>
              <div className="flex space-x-2 text-xs">
                <Badge variant="outline">Staking</Badge>
                <Badge variant="outline">Rewards</Badge>
                <Badge variant="outline">Governance</Badge>
                <Badge variant="outline">DeFi</Badge>
              </div>
            </Card>
          </div>

          {/* Connect Wallet Section */}
          <Card className="w-full max-w-md mx-auto">
            <CardHeader className="text-center">
              <div className="w-16 h-16 bg-gradient-to-br from-blue-600 to-purple-600 rounded-xl flex items-center justify-center mx-auto mb-4">
                <IdCard className="h-8 w-8 text-white" />
              </div>
              <CardTitle className="text-2xl text-slate-900">Welcome to FRONSCIERS</CardTitle>
              <CardDescription>
                Decentralized Academic Publishing Platform
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-center text-slate-600">
                Connect your Solana wallet to access the platform and start publishing your research on-chain.
              </p>
              <WalletConnection />
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b bg-card/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 rounded-xl overflow-hidden">
                  <img 
                    src={fronsciersLogo} 
                    alt="FRONSCIERS Logo" 
                    className="w-full h-full object-contain"
                  />
                </div>
                <div>
                  <h1 className="text-xl font-bold">FRONSCIERS</h1>
                  <p className="text-sm text-muted-foreground">Research Dashboard</p>
                </div>
              </div>
              <nav className="hidden md:flex space-x-6">
                <Link href="/dashboard">
                  <Button variant="ghost" className="text-primary">Dashboard</Button>
                </Link>
                <Link href="/submit">
                  <Button variant="ghost">Submit</Button>
                </Link>
                <Link href="/review">
                  <Button variant="ghost">Review</Button>
                </Link>
                <Link href="/explore">
                  <Button variant="ghost">Explore</Button>
                </Link>
                <Link href="/governance">
                  <Button variant="ghost">Governance</Button>
                </Link>
                <Link href="/tokenomics">
                  <Button variant="ghost">Tokenomics</Button>
                </Link>
                <Link href="/citations">
                  <Button variant="ghost">Citations</Button>
                </Link>
                <Link href="/trends">
                  <Button variant="ghost">Trends</Button>
                </Link>
              </nav>
            </div>
            <div className="flex items-center space-x-4">
              <div className="hidden sm:flex items-center space-x-2 bg-muted px-3 py-2 rounded-lg">
                <img src={fronsciersLogo} alt="FRONS" className="h-4 w-4" />
                <span className="text-sm font-medium token-balance">
                  {stats?.fronsBalance?.toLocaleString() || 0} FRONS
                </span>
              </div>
              <WalletConnection />
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        {/* Stats Overview */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <StatsCard
            title="Published Papers"
            value={stats?.publishedPapers || 0}
            change="+2 this month"
            icon={FileText}
            variant="blue"
            loading={statsLoading}
          />
          <StatsCard
            title="FRONS Balance"
            value={stats?.fronsBalance || 0}
            change="+156 from reviews"
            icon={() => <img src={fronsciersLogo} alt="FRONS" className="h-6 w-6" />}
            variant="yellow"
            loading={statsLoading}
          />
          <StatsCard
            title="Pending Reviews"
            value={stats?.pendingReviews || 0}
            change="2 urgent"
            icon={Clock}
            variant="orange"
            loading={statsLoading}
          />
          <StatsCard
            title="DOCIs Minted"
            value={stats?.docisMinted || 0}
            change={`Total citations: ${manuscripts?.reduce((acc, m) => acc + (m.citationCount || 0), 0) || 0}`}
            icon={IdCard}
            variant="purple"
            loading={statsLoading}
          />
        </div>

        {/* Main Content */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Left Column - Main Actions */}
          <div className="lg:col-span-2 space-y-6">
            {/* Quick Actions */}
            <Card>
              <CardHeader>
                <CardTitle>Quick Actions</CardTitle>
                <CardDescription>Get started with common tasks</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <Link href="/submit">
                    <Button className="w-full h-auto p-6 flex-col space-y-2" variant="outline">
                      <Upload className="h-8 w-8 text-primary" />
                      <div className="text-center">
                        <div className="font-medium">Submit Manuscript</div>
                        <div className="text-sm text-muted-foreground">Upload new research paper</div>
                      </div>
                    </Button>
                  </Link>
                  <Link href="/trends">
                    <Button className="w-full h-auto p-6 flex-col space-y-2 border-orange-200 bg-gradient-to-br from-orange-50 to-yellow-50 hover:from-orange-100 hover:to-yellow-100" variant="outline">
                      <BarChart3 className="h-8 w-8 text-orange-600" />
                      <div className="text-center">
                        <div className="font-medium text-orange-700">Research Trends</div>
                        <div className="text-sm text-orange-600">Real-time analytics & insights</div>
                      </div>
                    </Button>
                  </Link>
                  <Link href="/review">
                    <Button className="w-full h-auto p-6 flex-col space-y-2" variant="outline">
                      <Users className="h-8 w-8 text-secondary" />
                      <div className="text-center">
                        <div className="font-medium">Find Reviews</div>
                        <div className="text-sm text-muted-foreground">Search expert reviewers</div>
                      </div>
                    </Button>
                  </Link>
                  <Button className="w-full h-auto p-6 flex-col space-y-2" variant="outline">
                    <IdCard className="h-8 w-8 text-accent" />
                    <div className="text-center">
                      <div className="font-medium">Mint DOCI</div>
                      <div className="text-sm text-muted-foreground">Create publication NFT</div>
                    </div>
                  </Button>
                  <Link href="/governance">
                    <Button className="w-full h-auto p-6 flex-col space-y-2" variant="outline">
                      <Vote className="h-8 w-8 text-yellow-600" />
                      <div className="text-center">
                        <div className="font-medium">DAO Proposal</div>
                        <div className="text-sm text-muted-foreground">Submit governance proposal</div>
                      </div>
                    </Button>
                  </Link>
                </div>
              </CardContent>
            </Card>

            {/* Content Tabs */}
            <Tabs value={activeTab} onValueChange={setActiveTab}>
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="overview">Overview</TabsTrigger>
                <TabsTrigger value="manuscripts">Manuscripts</TabsTrigger>
                <TabsTrigger value="reviews">Reviews</TabsTrigger>
              </TabsList>

              <TabsContent value="overview" className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Recent Activity</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="flex items-start space-x-3">
                        <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center">
                          <CheckCircle className="h-4 w-4 text-green-600" />
                        </div>
                        <div>
                          <p className="text-sm font-medium">Paper "Quantum Computing Applications" was accepted for review</p>
                          <p className="text-xs text-muted-foreground">2 hours ago</p>
                        </div>
                      </div>
                      <div className="flex items-start space-x-3">
                        <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                          <img src={fronsciersLogo} alt="FRONS" className="h-4 w-4" />
                        </div>
                        <div>
                          <p className="text-sm font-medium">Received 50 FRONS tokens for peer review completion</p>
                          <p className="text-xs text-muted-foreground">1 day ago</p>
                        </div>
                      </div>
                      <div className="flex items-start space-x-3">
                        <div className="w-8 h-8 bg-purple-100 rounded-full flex items-center justify-center">
                          <IdCard className="h-4 w-4 text-purple-600" />
                        </div>
                        <div>
                          <p className="text-sm font-medium">DOCI NFT minted for "Blockchain in Healthcare Research"</p>
                          <p className="text-xs text-muted-foreground">3 days ago</p>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="manuscripts" className="space-y-4">
                {manuscriptsLoading ? (
                  <div className="space-y-4">
                    {[1, 2, 3].map((i) => (
                      <Card key={i}>
                        <CardContent className="p-6">
                          <div className="animate-pulse space-y-3">
                            <div className="h-4 bg-muted rounded w-3/4"></div>
                            <div className="h-3 bg-muted rounded w-1/2"></div>
                            <div className="h-3 bg-muted rounded w-2/3"></div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                ) : manuscripts?.length === 0 ? (
                  <Card>
                    <CardContent className="p-12 text-center">
                      <FileText className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                      <h3 className="text-lg font-medium mb-2">No manuscripts yet</h3>
                      <p className="text-muted-foreground mb-4">Start by submitting your first research paper</p>
                      <Link href="/submit">
                        <Button>Submit Manuscript</Button>
                      </Link>
                    </CardContent>
                  </Card>
                ) : (
                  manuscripts?.map((manuscript) => (
                    <ManuscriptCard key={manuscript.id} manuscript={manuscript} />
                  ))
                )}
              </TabsContent>

              <TabsContent value="reviews" className="space-y-4">
                {reviewsLoading ? (
                  <div className="space-y-4">
                    {[1, 2].map((i) => (
                      <Card key={i}>
                        <CardContent className="p-6">
                          <div className="animate-pulse space-y-3">
                            <div className="h-4 bg-muted rounded w-3/4"></div>
                            <div className="h-3 bg-muted rounded w-1/2"></div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                ) : reviews?.length === 0 ? (
                  <Card>
                    <CardContent className="p-12 text-center">
                      <Users className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                      <h3 className="text-lg font-medium mb-2">No reviews yet</h3>
                      <p className="text-muted-foreground mb-4">Start reviewing papers to earn FRONS tokens</p>
                      <Link href="/review">
                        <Button>Find Papers to Review</Button>
                      </Link>
                    </CardContent>
                  </Card>
                ) : (
                  reviews?.map((review) => (
                    <ReviewCard key={review.id} review={review} />
                  ))
                )}
              </TabsContent>
            </Tabs>
          </div>

          {/* Right Sidebar */}
          <div className="space-y-6">
            {/* Token Summary */}
            <Card className="border-primary/20 bg-card">
              <CardHeader className="pb-3">
                <CardTitle className="text-primary">FRONS Token Summary</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex justify-between items-center">
                  <span className="text-muted-foreground font-medium">Balance</span>
                  <span className="font-bold text-xl text-foreground">{stats?.fronsBalance?.toLocaleString() || 0}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-muted-foreground font-medium">Staked</span>
                  <span className="font-mono text-foreground">{stats?.stakedFrons?.toLocaleString() || 0}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-muted-foreground font-medium">Reputation</span>
                  <span className="font-mono frons-secondary-text font-semibold">{stats?.reputationScore || 0}</span>
                </div>
                <Separator />
                <Button className="w-full bg-primary hover:bg-primary/90 text-primary-foreground">
                  Manage Tokens
                </Button>
              </CardContent>
            </Card>

            {/* Pending Reviews */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  Pending Reviews
                  <Badge variant="secondary">{stats?.pendingReviews || 0} new</Badge>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {stats?.pendingReviews === 0 ? (
                  <p className="text-sm text-muted-foreground text-center py-4">
                    No pending reviews
                  </p>
                ) : (
                  <>
                    <div className="p-3 bg-muted rounded-lg">
                      <h4 className="font-medium text-sm mb-1">AI in Medical Diagnosis</h4>
                      <div className="flex items-center justify-between">
                        <span className="text-xs text-muted-foreground">Due in 3 days</span>
                        <Badge variant="destructive" className="text-xs">Urgent</Badge>
                      </div>
                    </div>
                    <div className="p-3 bg-muted rounded-lg">
                      <h4 className="font-medium text-sm mb-1">Blockchain Scalability Solutions</h4>
                      <div className="flex items-center justify-between">
                        <span className="text-xs text-muted-foreground">Due in 7 days</span>
                        <Badge variant="secondary" className="text-xs">Normal</Badge>
                      </div>
                    </div>
                  </>
                )}
                <Link href="/review">
                  <Button variant="outline" className="w-full">View All Reviews</Button>
                </Link>
              </CardContent>
            </Card>

            {/* Active Proposals */}
            <Card>
              <CardHeader>
                <CardTitle>Active Proposals</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {proposalsLoading ? (
                  <div className="animate-pulse space-y-2">
                    <div className="h-4 bg-muted rounded w-3/4"></div>
                    <div className="h-2 bg-muted rounded w-full"></div>
                  </div>
                ) : activeProposals?.length === 0 ? (
                  <p className="text-sm text-muted-foreground text-center py-4">
                    No active proposals
                  </p>
                ) : (
                  activeProposals?.slice(0, 2).map((proposal) => (
                    <div key={proposal.id} className="space-y-2">
                      <h4 className="font-medium text-sm">{proposal.title}</h4>
                      <div className="flex items-center space-x-2 text-xs">
                        <span className="text-muted-foreground">
                          Ends {new Date(proposal.endDate!).toLocaleDateString()}
                        </span>
                        <span className="w-1 h-1 bg-muted-foreground rounded-full"></span>
                        <span className="text-green-600">
                          {Math.round(((proposal.votesFor || 0) / Math.max(proposal.totalVotes || 1, 1)) * 100)}% Yes
                        </span>
                      </div>
                      <div className="w-full bg-muted rounded-full h-2">
                        <div 
                          className="bg-green-500 h-2 rounded-full" 
                          style={{ 
                            width: `${Math.round(((proposal.votesFor || 0) / Math.max(proposal.totalVotes || 1, 1)) * 100)}%` 
                          }}
                        ></div>
                      </div>
                    </div>
                  ))
                )}
                <Link href="/governance">
                  <Button variant="outline" className="w-full">Vote on Proposals</Button>
                </Link>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
