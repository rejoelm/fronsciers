import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { type Review } from "@shared/schema";
import { 
  Clock, CheckCircle, AlertCircle, FileText, 
  Star, Calendar, Coins 
} from "lucide-react";

interface ReviewCardProps {
  review: Review;
  showActions?: boolean;
  onViewManuscript?: (manuscriptId: number) => void;
  onEditReview?: (review: Review) => void;
}

export function ReviewCard({ 
  review, 
  showActions = true,
  onViewManuscript,
  onEditReview 
}: ReviewCardProps) {
  const getStatusIcon = (status: string) => {
    switch (status) {
      case "pending":
        return <Clock className="h-4 w-4 text-yellow-600" />;
      case "submitted":
        return <CheckCircle className="h-4 w-4 text-green-600" />;
      case "completed":
        return <CheckCircle className="h-4 w-4 text-green-600" />;
      default:
        return <AlertCircle className="h-4 w-4 text-gray-600" />;
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "pending":
        return <Badge variant="secondary" className="text-yellow-800 bg-yellow-100">Pending</Badge>;
      case "submitted":
        return <Badge variant="secondary" className="text-blue-800 bg-blue-100">Submitted</Badge>;
      case "completed":
        return <Badge variant="secondary" className="text-green-800 bg-green-100">Completed</Badge>;
      default:
        return <Badge variant="secondary">{status}</Badge>;
    }
  };

  const getRecommendationBadge = (recommendation: string) => {
    switch (recommendation) {
      case "accept":
        return <Badge variant="secondary" className="text-green-800 bg-green-100">Accept</Badge>;
      case "minor_revisions":
        return <Badge variant="secondary" className="text-yellow-800 bg-yellow-100">Minor Revisions</Badge>;
      case "major_revisions":
        return <Badge variant="secondary" className="text-orange-800 bg-orange-100">Major Revisions</Badge>;
      case "reject":
        return <Badge variant="secondary" className="text-red-800 bg-red-100">Reject</Badge>;
      default:
        return null;
    }
  };

  const calculateOverallScore = () => {
    if (!review.noveltyScore || !review.methodologyScore || !review.clarityScore) {
      return null;
    }
    return ((review.noveltyScore + review.methodologyScore + review.clarityScore) / 3).toFixed(1);
  };

  const getDaysRemaining = () => {
    if (!review.deadline) return null;
    const now = new Date();
    const deadline = new Date(review.deadline);
    const diffTime = deadline.getTime() - now.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays;
  };

  const daysRemaining = getDaysRemaining();
  const overallScore = calculateOverallScore();

  return (
    <Card className="hover:shadow-md transition-shadow">
      <CardContent className="p-6">
        <div className="flex items-start justify-between mb-4">
          <div className="flex items-center space-x-2">
            {getStatusIcon(review.status || "pending")}
            <h3 className="font-semibold">Review #{review.id}</h3>
          </div>
          <div className="flex items-center space-x-2">
            {getStatusBadge(review.status || "pending")}
            {review.fronsReward && (
              <Badge variant="secondary" className="text-green-600">
                <Coins className="h-3 w-3 mr-1" />
                +{review.fronsReward} FRONS
              </Badge>
            )}
          </div>
        </div>

        <div className="space-y-3">
          {/* Manuscript Info */}
          <div className="flex items-center space-x-2 text-sm text-muted-foreground">
            <FileText className="h-3 w-3" />
            <span>Manuscript ID: {review.manuscriptId}</span>
          </div>

          {/* Timeline */}
          <div className="flex items-center space-x-4 text-sm text-muted-foreground">
            <span className="flex items-center space-x-1">
              <Calendar className="h-3 w-3" />
              <span>Assigned: {new Date(review.createdAt!).toLocaleDateString()}</span>
            </span>
            
            {review.deadline && (
              <span className="flex items-center space-x-1">
                <Clock className="h-3 w-3" />
                <span>
                  Due: {new Date(review.deadline).toLocaleDateString()}
                  {daysRemaining !== null && (
                    <span className={`ml-1 font-medium ${
                      daysRemaining < 0 ? "text-red-600" : 
                      daysRemaining <= 2 ? "text-orange-600" : 
                      "text-green-600"
                    }`}>
                      ({daysRemaining < 0 ? "overdue" : `${daysRemaining} days left`})
                    </span>
                  )}
                </span>
              </span>
            )}
          </div>

          {/* Scores */}
          {(review.noveltyScore || review.methodologyScore || review.clarityScore) && (
            <div className="grid grid-cols-3 gap-4 p-3 bg-muted rounded-lg">
              <div className="text-center">
                <div className="text-sm text-muted-foreground">Novelty</div>
                <div className="font-semibold">{review.noveltyScore || "-"}/5</div>
              </div>
              <div className="text-center">
                <div className="text-sm text-muted-foreground">Methodology</div>
                <div className="font-semibold">{review.methodologyScore || "-"}/5</div>
              </div>
              <div className="text-center">
                <div className="text-sm text-muted-foreground">Clarity</div>
                <div className="font-semibold">{review.clarityScore || "-"}/5</div>
              </div>
            </div>
          )}

          {/* Overall Score */}
          {overallScore && (
            <div className="flex items-center space-x-2">
              <Star className="h-4 w-4 text-yellow-600" />
              <span className="font-medium">Overall Score: {overallScore}/5</span>
              <Progress value={parseFloat(overallScore) * 20} className="flex-1 h-2" />
            </div>
          )}

          {/* Recommendation */}
          {review.recommendation && (
            <div className="flex items-center space-x-2">
              <span className="text-sm font-medium">Recommendation:</span>
              {getRecommendationBadge(review.recommendation)}
            </div>
          )}

          {/* Comments Preview */}
          {review.comments && (
            <div className="p-3 bg-muted rounded-lg">
              <div className="text-sm font-medium mb-1">Comments</div>
              <p className="text-sm line-clamp-2">{review.comments}</p>
            </div>
          )}
        </div>

        {/* Actions */}
        {showActions && (
          <div className="flex space-x-2 mt-4 pt-4 border-t">
            <Button 
              size="sm" 
              variant="outline"
              onClick={() => onViewManuscript?.(review.manuscriptId!)}
            >
              View Manuscript
            </Button>
            
            {review.status === "pending" && (
              <Button 
                size="sm"
                onClick={() => onEditReview?.(review)}
              >
                Continue Review
              </Button>
            )}
            
            {review.status === "submitted" && (
              <Button 
                size="sm" 
                variant="outline"
                onClick={() => onEditReview?.(review)}
              >
                Edit Review
              </Button>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
