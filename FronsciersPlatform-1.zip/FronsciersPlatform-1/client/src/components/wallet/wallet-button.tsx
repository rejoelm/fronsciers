import { Button } from "@/components/ui/button";
import { useWalletContext } from "./wallet-provider";
import { Wallet, LogOut } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export function WalletButton() {
  const { wallet, connect, disconnect } = useWalletContext();
  const { toast } = useToast();

  const handleConnect = async () => {
    try {
      await connect();
      toast({
        title: "Wallet Connected",
        description: "Successfully connected to your Solana wallet",
      });
    } catch (error) {
      toast({
        title: "Connection Failed",
        description: error instanceof Error ? error.message : "Failed to connect wallet",
        variant: "destructive",
      });
    }
  };

  const handleDisconnect = async () => {
    try {
      await disconnect();
      toast({
        title: "Wallet Disconnected",
        description: "Successfully disconnected from wallet",
      });
    } catch (error) {
      toast({
        title: "Disconnect Failed",
        description: "Failed to disconnect wallet",
        variant: "destructive",
      });
    }
  };

  if (wallet.connecting) {
    return (
      <Button disabled>
        <Wallet className="w-4 h-4 mr-2" />
        Connecting...
      </Button>
    );
  }

  if (wallet.connected && wallet.publicKey) {
    const address = wallet.publicKey.toString();
    const shortAddress = `${address.slice(0, 4)}...${address.slice(-4)}`;

    return (
      <Button variant="outline" onClick={handleDisconnect}>
        <LogOut className="w-4 h-4 mr-2" />
        {shortAddress}
      </Button>
    );
  }

  return (
    <Button onClick={handleConnect}>
      <Wallet className="w-4 h-4 mr-2" />
      Connect Wallet
    </Button>
  );
}
