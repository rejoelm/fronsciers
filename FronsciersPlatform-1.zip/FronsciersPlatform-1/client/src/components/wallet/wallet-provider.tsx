import { createContext, useContext, ReactNode } from 'react';
import { useWallet } from '@/hooks/use-wallet';
import { useSolana } from '@/hooks/use-solana';

interface WalletContextType {
  wallet: ReturnType<typeof useWallet>['wallet'];
  connect: ReturnType<typeof useWallet>['connect'];
  disconnect: ReturnType<typeof useWallet>['disconnect'];
  signTransaction: ReturnType<typeof useWallet>['signTransaction'];
  sendTransaction: ReturnType<typeof useWallet>['sendTransaction'];
  solBalance: number;
  fronsBalance: number;
  loading: boolean;
  updateBalances: () => Promise<void>;
}

const WalletContext = createContext<WalletContextType | undefined>(undefined);

export function WalletProvider({ children }: { children: ReactNode }) {
  const walletHook = useWallet();
  const solanaHook = useSolana();

  const value = {
    ...walletHook,
    ...solanaHook,
  };

  return (
    <WalletContext.Provider value={value}>
      {children}
    </WalletContext.Provider>
  );
}

export function useWalletContext() {
  const context = useContext(WalletContext);
  if (context === undefined) {
    throw new Error('useWalletContext must be used within a WalletProvider');
  }
  return context;
}
