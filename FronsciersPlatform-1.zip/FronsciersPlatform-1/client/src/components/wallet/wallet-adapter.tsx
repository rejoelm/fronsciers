import { createContext, useContext, useState, useEffect, ReactNode } from "react";
import { apiRequest } from "@/lib/queryClient";
import type { User } from "@shared/schema";

interface WalletContextType {
  user: User | null;
  isConnected: boolean;
  isConnecting: boolean;
  connectWallet: () => Promise<void>;
  disconnectWallet: () => void;
}

const WalletContext = createContext<WalletContextType | undefined>(undefined);

export function useWalletContext() {
  const context = useContext(WalletContext);
  if (context === undefined) {
    throw new Error("useWalletContext must be used within a WalletAdapter");
  }
  return context;
}

interface WalletAdapterProps {
  children: ReactNode;
}

export function WalletAdapter({ children }: WalletAdapterProps) {
  const [user, setUser] = useState<User | null>(null);
  const [isConnecting, setIsConnecting] = useState(false);

  const connectWallet = async () => {
    setIsConnecting(true);
    try {
      // In a real implementation, this would integrate with Phantom/Solflare
      // For now, simulate wallet connection
      const mockWalletAddress = "7x8KmP9qR2vL4nT6wX3yU5sE1mN8aB7cF6dH9jK2lM3oP4qR5sT6u";
      
      const response = await apiRequest("POST", "/api/user/connect", {
        walletAddress: mockWalletAddress,
        username: "dr_researcher",
        email: "researcher@university.edu",
      });

      const userData = await response.json();
      setUser(userData);
      localStorage.setItem("walletAddress", mockWalletAddress);
    } catch (error) {
      console.error("Failed to connect wallet:", error);
    } finally {
      setIsConnecting(false);
    }
  };

  const disconnectWallet = () => {
    setUser(null);
    localStorage.removeItem("walletAddress");
  };

  useEffect(() => {
    // Auto-connect if wallet address is stored
    const storedAddress = localStorage.getItem("walletAddress");
    if (storedAddress) {
      connectWallet();
    }
  }, []);

  // Set wallet address header for all API requests
  useEffect(() => {
    if (user?.walletAddress) {
      // This would be used in the API request headers
      document.documentElement.setAttribute('data-wallet-address', user.walletAddress);
    }
  }, [user]);

  const value: WalletContextType = {
    user,
    isConnected: !!user,
    isConnecting,
    connectWallet,
    disconnectWallet,
  };

  return (
    <WalletContext.Provider value={value}>
      {children}
    </WalletContext.Provider>
  );
}
