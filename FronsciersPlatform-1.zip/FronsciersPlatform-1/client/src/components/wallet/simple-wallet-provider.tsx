import { createContext, useContext, useState, ReactNode } from 'react';

interface WalletState {
  connected: boolean;
  connecting: boolean;
  publicKey: string | null;
  balance: number;
}

interface WalletContextType {
  wallet: WalletState;
  connect: () => Promise<void>;
  disconnect: () => void;
}

const WalletContext = createContext<WalletContextType | undefined>(undefined);

export function SimpleWalletProvider({ children }: { children: ReactNode }) {
  const [wallet, setWallet] = useState<WalletState>({
    connected: false,
    connecting: false,
    publicKey: null,
    balance: 0
  });

  const connect = async () => {
    setWallet(prev => ({ ...prev, connecting: true }));
    
    // Simulate wallet connection
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    setWallet({
      connected: true,
      connecting: false,
      publicKey: "7xKXtg2CW87d97TXJSDpbD5jBkheTqA83TZRuJosgAsU",
      balance: 2.5
    });
  };

  const disconnect = () => {
    setWallet({
      connected: false,
      connecting: false,
      publicKey: null,
      balance: 0
    });
  };

  return (
    <WalletContext.Provider value={{ wallet, connect, disconnect }}>
      {children}
    </WalletContext.Provider>
  );
}

export function useWalletContext() {
  const context = useContext(WalletContext);
  if (context === undefined) {
    throw new Error('useWalletContext must be used within a SimpleWalletProvider');
  }
  return context;
}