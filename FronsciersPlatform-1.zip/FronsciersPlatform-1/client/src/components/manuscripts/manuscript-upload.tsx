import { useState, useCallback } from "react";
import { useDropzone } from "react-dropzone";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { insertManuscriptSchema } from "@shared/schema";
import { z } from "zod";
import { FileText, Upload, X } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { ipfsClient } from "@/lib/ipfs";

const formSchema = insertManuscriptSchema.extend({
  keywords: z.string().transform(str => str.split(',').map(s => s.trim())),
  authors: z.string().transform(str => str.split(',').map(s => s.trim())),
});

type FormData = z.infer<typeof formSchema>;

interface ManuscriptUploadProps {
  onSubmit: (data: FormData & { file?: File }) => Promise<void>;
  loading?: boolean;
}

export function ManuscriptUpload({ onSubmit, loading = false }: ManuscriptUploadProps) {
  const [uploadedFile, setUploadedFile] = useState<File | null>(null);
  const { toast } = useToast();

  const form = useForm<FormData>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      title: "",
      abstract: "",
      authors: "",
      category: "",
      keywords: "",
      submitterId: 1, // This should come from authenticated user
    },
  });

  const onDrop = useCallback((acceptedFiles: File[]) => {
    const file = acceptedFiles[0];
    if (file && file.type === 'application/pdf') {
      setUploadedFile(file);
      toast({
        title: "File Selected",
        description: `${file.name} is ready for upload`,
      });
    } else {
      toast({
        title: "Invalid File",
        description: "Please select a PDF file",
        variant: "destructive",
      });
    }
  }, [toast]);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      'application/pdf': ['.pdf'],
    },
    maxFiles: 1,
    maxSize: 50 * 1024 * 1024, // 50MB
  });

  const removeFile = () => {
    setUploadedFile(null);
  };

  const handleSubmit = async (data: FormData) => {
    if (!uploadedFile) {
      toast({
        title: "No File Selected",
        description: "Please select a PDF file to upload",
        variant: "destructive",
      });
      return;
    }

    try {
      await onSubmit({ ...data, file: uploadedFile });
    } catch (error) {
      toast({
        title: "Submission Failed",
        description: error instanceof Error ? error.message : "Failed to submit manuscript",
        variant: "destructive",
      });
    }
  };

  return (
    <Card>
      <CardContent className="p-6">
        <Form {...form}>
          <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <FormField
                control={form.control}
                name="title"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Title</FormLabel>
                    <FormControl>
                      <Input placeholder="Enter manuscript title" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="category"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Research Field</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select research field" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="Computer Science">Computer Science</SelectItem>
                        <SelectItem value="Biology">Biology</SelectItem>
                        <SelectItem value="Physics">Physics</SelectItem>
                        <SelectItem value="Chemistry">Chemistry</SelectItem>
                        <SelectItem value="Medicine">Medicine</SelectItem>
                        <SelectItem value="Mathematics">Mathematics</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <FormField
              control={form.control}
              name="authors"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Authors</FormLabel>
                  <FormControl>
                    <Input 
                      placeholder="Enter authors separated by commas" 
                      {...field} 
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="abstract"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Abstract</FormLabel>
                  <FormControl>
                    <Textarea 
                      rows={4}
                      placeholder="Enter manuscript abstract..." 
                      {...field} 
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="keywords"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Keywords</FormLabel>
                  <FormControl>
                    <Input 
                      placeholder="Enter keywords separated by commas" 
                      {...field} 
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* File Upload Section */}
            <div>
              <Label className="text-sm font-medium">Manuscript File</Label>
              {!uploadedFile ? (
                <div
                  {...getRootProps()}
                  className={`border-2 border-dashed rounded-lg p-6 text-center cursor-pointer transition-colors ${
                    isDragActive 
                      ? 'border-primary bg-primary/5' 
                      : 'border-slate-300 hover:border-primary/50'
                  }`}
                >
                  <input {...getInputProps()} />
                  <Upload className="w-12 h-12 text-slate-400 mx-auto mb-3" />
                  <p className="text-slate-600 mb-2">
                    {isDragActive 
                      ? 'Drop your PDF file here...' 
                      : 'Drop your PDF file here or click to browse'
                    }
                  </p>
                  <p className="text-sm text-slate-500">Maximum file size: 50MB</p>
                </div>
              ) : (
                <div className="border border-slate-200 rounded-lg p-4 bg-slate-50">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <FileText className="w-8 h-8 text-red-500" />
                      <div>
                        <p className="font-medium text-slate-900">{uploadedFile.name}</p>
                        <p className="text-sm text-slate-500">
                          {(uploadedFile.size / 1024 / 1024).toFixed(2)} MB
                        </p>
                      </div>
                    </div>
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      onClick={removeFile}
                    >
                      <X className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              )}
            </div>

            {/* DOCI Minting Options */}
            <div className="bg-gradient-to-r from-secondary/5 to-primary/5 rounded-lg p-6">
              <h4 className="font-semibold text-slate-900 mb-3">
                DOCI (Direct On-Chain Identifier) Options
              </h4>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                <div className="flex items-center space-x-3">
                  <input 
                    type="checkbox" 
                    id="mintNFT"
                    className="w-5 h-5 text-primary rounded" 
                    defaultChecked 
                  />
                  <label htmlFor="mintNFT" className="text-sm text-slate-700">
                    Mint as NFT
                  </label>
                </div>
                <div className="flex items-center space-x-3">
                  <input 
                    type="checkbox" 
                    id="enableResale"
                    className="w-5 h-5 text-primary rounded" 
                  />
                  <label htmlFor="enableResale" className="text-sm text-slate-700">
                    Enable Resale
                  </label>
                </div>
              </div>
              <div>
                <Label className="block text-sm font-medium text-slate-700 mb-2">
                  Minting Fee
                </Label>
                <div className="flex items-center space-x-2">
                  <span className="text-2xl font-bold text-slate-900">0.1 SOL</span>
                  <span className="text-sm text-slate-500">+ 50 FRONS</span>
                </div>
              </div>
            </div>

            <div className="flex items-center justify-between pt-4 border-t border-slate-200">
              <div className="flex items-center space-x-2">
                <input 
                  type="checkbox" 
                  id="terms" 
                  className="rounded border-slate-300 text-primary focus:ring-primary" 
                  required
                />
                <label htmlFor="terms" className="text-sm text-slate-600">
                  I agree to the terms and conditions
                </label>
              </div>
              <div className="flex items-center space-x-3">
                <Button type="button" variant="outline">
                  Save Draft
                </Button>
                <Button type="submit" disabled={loading || !uploadedFile}>
                  {loading ? 'Submitting...' : 'Submit & Mint DOCI'}
                </Button>
              </div>
            </div>
          </form>
        </Form>
      </CardContent>
    </Card>
  );
}
