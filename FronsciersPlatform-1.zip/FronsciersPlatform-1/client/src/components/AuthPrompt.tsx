import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { WalletConnection } from '@/components/wallet-connection';
import { Lock, User, Users, FileEdit } from 'lucide-react';

interface AuthPromptProps {
  action: 'submit' | 'review' | 'vote' | 'register-doci' | 'general';
  title?: string;
  description?: string;
  onCancel?: () => void;
}

export function AuthPrompt({ action, title, description, onCancel }: AuthPromptProps) {
  const getActionConfig = () => {
    switch (action) {
      case 'submit':
        return {
          icon: <FileEdit className="h-8 w-8 text-blue-600" />,
          title: title || 'Author Authentication Required',
          description: description || 'To submit manuscripts and become an Author, you need to connect your Solana wallet.',
          role: 'Author'
        };
      case 'review':
        return {
          icon: <Users className="h-8 w-8 text-green-600" />,
          title: title || 'Reviewer Authentication Required',
          description: description || 'To participate in peer review and become a Reviewer, you need to connect your Solana wallet.',
          role: 'Reviewer'
        };
      case 'vote':
        return {
          icon: <User className="h-8 w-8 text-purple-600" />,
          title: title || 'Governance Participation Required',
          description: description || 'To vote on DAO proposals, you need to connect your Solana wallet and hold FRONS tokens.',
          role: 'Member'
        };
      case 'register-doci':
        return {
          icon: <Lock className="h-8 w-8 text-orange-600" />,
          title: title || 'DOCI Registration Authentication',
          description: description || 'To register Direct On-Chain Identifiers, you need to connect your Solana wallet.',
          role: 'Author'
        };
      default:
        return {
          icon: <Lock className="h-8 w-8 text-gray-600" />,
          title: title || 'Authentication Required',
          description: description || 'To access this feature, you need to connect your Solana wallet.',
          role: 'User'
        };
    }
  };

  const config = getActionConfig();

  return (
    <div className="flex items-center justify-center min-h-[400px]">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center">
          <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
            {config.icon}
          </div>
          <CardTitle>{config.title}</CardTitle>
          <CardDescription>{config.description}</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <Alert>
            <Lock className="h-4 w-4" />
            <AlertDescription>
              <strong>Required Role:</strong> {config.role}
              <br />
              Connect your wallet to verify your identity and access role-specific features.
            </AlertDescription>
          </Alert>
          
          <WalletConnection />
          
          {onCancel && (
            <Button variant="outline" onClick={onCancel} className="w-full">
              Browse as Guest
            </Button>
          )}
          
          <div className="text-xs text-gray-500 text-center">
            Your wallet serves as your identity on the FRONSCIERS platform. 
            No personal information is required.
          </div>
        </CardContent>
      </Card>
    </div>
  );
}