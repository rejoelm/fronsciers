import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { type Manuscript } from "@shared/schema";
import { 
  FileText, Eye, Star, Calendar, Download, 
  ExternalLink, MoreVertical, Edit, Trash2 
} from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

interface ManuscriptCardProps {
  manuscript: Manuscript;
  showActions?: boolean;
  onEdit?: (manuscript: Manuscript) => void;
  onDelete?: (manuscript: Manuscript) => void;
  onView?: (manuscript: Manuscript) => void;
}

export function ManuscriptCard({ 
  manuscript, 
  showActions = true,
  onEdit,
  onDelete,
  onView 
}: ManuscriptCardProps) {
  const getStatusBadge = (status: string) => {
    switch (status) {
      case "draft":
        return <Badge variant="secondary" className="status-draft">Draft</Badge>;
      case "submitted":
        return <Badge variant="secondary" className="status-submitted">Submitted</Badge>;
      case "under_review":
        return <Badge variant="secondary" className="status-under-review">Under Review</Badge>;
      case "accepted":
        return <Badge variant="secondary" className="status-accepted">Published</Badge>;
      case "rejected":
        return <Badge variant="secondary" className="status-rejected">Rejected</Badge>;
      default:
        return <Badge variant="secondary">{status}</Badge>;
    }
  };

  return (
    <Card className="hover:shadow-md transition-shadow">
      <CardContent className="p-6">
        <div className="flex items-start justify-between">
          <div className="flex-1">
            <div className="flex items-center space-x-2 mb-2">
              <h3 className="text-lg font-semibold line-clamp-2">
                {manuscript.title}
              </h3>
              {manuscript.dociMinted && (
                <Badge variant="outline" className="text-purple-600 border-purple-200">
                  DOCI NFT
                </Badge>
              )}
            </div>
            
            <p className="text-sm text-muted-foreground mb-2">
              {manuscript.authors}
            </p>
            
            <p className="text-sm mb-3 line-clamp-2">
              {manuscript.abstract}
            </p>
            
            <div className="flex items-center space-x-4 text-sm text-muted-foreground mb-3">
              <span className="flex items-center space-x-1">
                <Calendar className="h-3 w-3" />
                <span>{new Date(manuscript.createdAt!).toLocaleDateString()}</span>
              </span>
              <span className="flex items-center space-x-1">
                <Eye className="h-3 w-3" />
                <span>{manuscript.viewCount || 0} views</span>
              </span>
              <span className="flex items-center space-x-1">
                <Star className="h-3 w-3" />
                <span>{manuscript.citationCount || 0} citations</span>
              </span>
            </div>
            
            <div className="flex items-center space-x-2">
              {getStatusBadge(manuscript.status || "draft")}
              <Badge variant="outline">{manuscript.researchField}</Badge>
              {manuscript.keywords.split(",").slice(0, 2).map((keyword, index) => (
                <Badge key={index} variant="secondary" className="text-xs">
                  {keyword.trim()}
                </Badge>
              ))}
            </div>
          </div>
          
          <div className="flex items-center space-x-2 ml-4">
            <Button 
              size="sm" 
              variant="outline"
              onClick={() => onView?.(manuscript)}
            >
              <Eye className="h-3 w-3 mr-1" />
              View
            </Button>
            
            {manuscript.ipfsHash && (
              <Button size="sm" variant="outline">
                <Download className="h-3 w-3 mr-1" />
                PDF
              </Button>
            )}
            
            {manuscript.dociMinted && (
              <Button size="sm" variant="outline">
                <ExternalLink className="h-3 w-3 mr-1" />
                NFT
              </Button>
            )}
            
            {showActions && (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button size="sm" variant="ghost">
                    <MoreVertical className="h-3 w-3" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <DropdownMenuItem onClick={() => onView?.(manuscript)}>
                    <Eye className="h-3 w-3 mr-2" />
                    View Details
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => onEdit?.(manuscript)}>
                    <Edit className="h-3 w-3 mr-2" />
                    Edit
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem 
                    onClick={() => onDelete?.(manuscript)}
                    className="text-destructive"
                  >
                    <Trash2 className="h-3 w-3 mr-2" />
                    Delete
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
