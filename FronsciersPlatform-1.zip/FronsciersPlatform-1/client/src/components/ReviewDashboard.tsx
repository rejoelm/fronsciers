import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Clock, CheckCircle, AlertCircle, FileText, Users, Bot } from "lucide-react";
import { ReviewForm } from "./ReviewForm";
import { CommunityVoteForm } from "./CommunityVoteForm";

interface ReviewAssignment {
  id: number;
  manuscriptId: number;
  dociId: string;
  status: string;
  assignedAt: string;
  deadline: string;
  manuscript?: {
    title: string;
    authors: string[];
    abstract: string;
  };
}

interface Review {
  id: number;
  manuscriptId: number;
  dociId: string;
  phase: string;
  status: string;
  overallScore: number;
  fronsReward: number;
  submittedAt: string;
}

export function ReviewDashboard() {
  const [selectedAssignment, setSelectedAssignment] = useState<ReviewAssignment | null>(null);
  const [selectedReview, setSelectedReview] = useState<Review | null>(null);
  const [activeTab, setActiveTab] = useState("assignments");

  const { data: assignments = [], isLoading: assignmentsLoading } = useQuery({
    queryKey: ["/api/peer-review/my-assignments"],
  });

  const { data: reviews = [], isLoading: reviewsLoading } = useQuery({
    queryKey: ["/api/peer-review/my-reviews"],
  });

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "pending": return <Clock className="h-4 w-4 text-orange-500" />;
      case "in_progress": return <AlertCircle className="h-4 w-4 text-blue-500" />;
      case "completed": return <CheckCircle className="h-4 w-4 text-green-500" />;
      default: return <FileText className="h-4 w-4 text-gray-500" />;
    }
  };

  const getPhaseIcon = (phase: string) => {
    switch (phase) {
      case "automated": return <Bot className="h-4 w-4 text-purple-500" />;
      case "expert": return <FileText className="h-4 w-4 text-blue-500" />;
      case "community": return <Users className="h-4 w-4 text-green-500" />;
      default: return <FileText className="h-4 w-4 text-gray-500" />;
    }
  };

  if (selectedAssignment) {
    return (
      <ReviewForm
        assignment={selectedAssignment}
        onBack={() => setSelectedAssignment(null)}
      />
    );
  }

  if (selectedReview) {
    return (
      <CommunityVoteForm
        review={selectedReview}
        onBack={() => setSelectedReview(null)}
      />
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold text-gray-900 dark:text-white">Review Dashboard</h1>
        <Badge variant="secondary" className="bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-100">
          Multi-Tier Peer Review
        </Badge>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="assignments">Active Assignments</TabsTrigger>
          <TabsTrigger value="reviews">My Reviews</TabsTrigger>
          <TabsTrigger value="community">Community Voting</TabsTrigger>
        </TabsList>

        <TabsContent value="assignments" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="h-5 w-5" />
                Peer Review Assignments
              </CardTitle>
              <CardDescription>
                Manuscripts assigned for expert review
              </CardDescription>
            </CardHeader>
            <CardContent>
              {assignmentsLoading ? (
                <div className="text-center py-8">Loading assignments...</div>
              ) : assignments.length === 0 ? (
                <div className="text-center py-8 text-gray-500">
                  No active assignments
                </div>
              ) : (
                <div className="space-y-4">
                  {assignments.map((assignment: ReviewAssignment) => (
                    <Card key={assignment.id} className="border-l-4 border-l-blue-500">
                      <CardContent className="pt-6">
                        <div className="flex items-start justify-between">
                          <div className="space-y-2">
                            <h3 className="font-semibold text-lg">
                              {assignment.manuscript?.title || `DOCI: ${assignment.dociId}`}
                            </h3>
                            <p className="text-sm text-gray-600 dark:text-gray-400">
                              Authors: {assignment.manuscript?.authors?.join(", ") || "Not specified"}
                            </p>
                            <div className="flex items-center gap-4 text-sm">
                              <div className="flex items-center gap-1">
                                {getStatusIcon(assignment.status)}
                                <span className="capitalize">{assignment.status}</span>
                              </div>
                              <span>Due: {new Date(assignment.deadline).toLocaleDateString()}</span>
                            </div>
                          </div>
                          <Button 
                            onClick={() => setSelectedAssignment(assignment)}
                            className="bg-blue-600 hover:bg-blue-700"
                          >
                            Start Review
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="reviews" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <CheckCircle className="h-5 w-5" />
                Completed Reviews
              </CardTitle>
              <CardDescription>
                Your review history and earned FRONS rewards
              </CardDescription>
            </CardHeader>
            <CardContent>
              {reviewsLoading ? (
                <div className="text-center py-8">Loading reviews...</div>
              ) : reviews.length === 0 ? (
                <div className="text-center py-8 text-gray-500">
                  No completed reviews
                </div>
              ) : (
                <div className="space-y-4">
                  {reviews.map((review: Review) => (
                    <Card key={review.id} className="border-l-4 border-l-green-500">
                      <CardContent className="pt-6">
                        <div className="flex items-start justify-between">
                          <div className="space-y-2">
                            <div className="flex items-center gap-2">
                              {getPhaseIcon(review.phase)}
                              <h3 className="font-semibold">
                                {review.phase.charAt(0).toUpperCase() + review.phase.slice(1)} Review
                              </h3>
                              <Badge variant="outline">
                                DOCI: {review.dociId}
                              </Badge>
                            </div>
                            <div className="flex items-center gap-4 text-sm">
                              <span>Score: {review.overallScore}/100</span>
                              <span className="text-green-600 font-medium">
                                +{review.fronsReward} FRONS
                              </span>
                              <span>
                                {new Date(review.submittedAt).toLocaleDateString()}
                              </span>
                            </div>
                          </div>
                          <div className="flex items-center gap-1">
                            {getStatusIcon(review.status)}
                            <span className="text-sm capitalize">{review.status}</span>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="community" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Users className="h-5 w-5" />
                Community Validation
              </CardTitle>
              <CardDescription>
                Participate in community review validation and earn FRONS
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-center py-8 text-gray-500">
                <Users className="h-12 w-12 mx-auto mb-4 text-gray-300" />
                <p>Community voting interface will be available here</p>
                <p className="text-sm mt-2">
                  Vote on manuscript quality and earn 5 FRONS per vote
                </p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}