import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, ThumbsUp, ThumbsDown, Users, Coins } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

interface Review {
  id: number;
  manuscriptId: number;
  dociId: string;
  phase: string;
  status: string;
  overallScore: number;
  fronsReward: number;
  submittedAt: string;
}

interface CommunityVoteFormProps {
  review: Review;
  onBack: () => void;
}

export function CommunityVoteForm({ review, onBack }: CommunityVoteFormProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const [voteType, setVoteType] = useState<"approve" | "disapprove" | null>(null);
  const [reason, setReason] = useState("");

  const submitVoteMutation = useMutation({
    mutationFn: async (voteData: any) => {
      return apiRequest("/api/reviews/community-vote", {
        method: "POST",
        body: voteData
      });
    },
    onSuccess: (data) => {
      toast({
        title: "Vote Submitted Successfully",
        description: `Thank you for participating! You earned ${data.fronsReward} FRONS tokens.`,
      });
      queryClient.invalidateQueries({ queryKey: ["/api/peer-review/my-reviews"] });
      onBack();
    },
    onError: (error: any) => {
      toast({
        title: "Vote Submission Failed",
        description: error.message || "Failed to submit community vote",
        variant: "destructive",
      });
    }
  });

  const handleSubmitVote = () => {
    if (!voteType) {
      toast({
        title: "Vote Required",
        description: "Please select approve or disapprove",
        variant: "destructive",
      });
      return;
    }

    if (!reason.trim()) {
      toast({
        title: "Reason Required",
        description: "Please provide a reason for your vote",
        variant: "destructive",
      });
      return;
    }

    submitVoteMutation.mutate({
      dociId: review.dociId,
      manuscriptId: review.manuscriptId,
      voteType,
      reason
    });
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-4">
        <Button
          variant="outline"
          onClick={onBack}
          className="flex items-center gap-2"
        >
          <ArrowLeft className="h-4 w-4" />
          Back to Dashboard
        </Button>
        <div>
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white">Community Validation</h1>
          <p className="text-gray-600 dark:text-gray-400">
            Participate in community review validation
          </p>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Users className="h-5 w-5" />
            Review Information
          </CardTitle>
          <CardDescription>
            Vote on the quality and validity of this peer review
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center gap-4">
            <Badge variant="outline">DOCI: {review.dociId}</Badge>
            <Badge variant="secondary">{review.phase} Review</Badge>
            <span className="text-sm text-gray-600">
              Score: {review.overallScore}/100
            </span>
          </div>
          
          <div className="bg-gray-50 dark:bg-gray-800 p-4 rounded-lg">
            <p className="text-sm text-gray-700 dark:text-gray-300">
              This review was submitted on {new Date(review.submittedAt).toLocaleDateString()} 
              and earned the reviewer {review.fronsReward} FRONS tokens.
            </p>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Your Vote</CardTitle>
          <CardDescription>
            Do you agree with this review's assessment? Your vote helps validate peer review quality.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="grid grid-cols-2 gap-4">
            <Button
              variant={voteType === "approve" ? "default" : "outline"}
              onClick={() => setVoteType("approve")}
              className={`h-20 flex flex-col items-center gap-2 ${
                voteType === "approve" ? "bg-green-600 hover:bg-green-700" : ""
              }`}
            >
              <ThumbsUp className="h-6 w-6" />
              <span>Approve</span>
            </Button>
            
            <Button
              variant={voteType === "disapprove" ? "default" : "outline"}
              onClick={() => setVoteType("disapprove")}
              className={`h-20 flex flex-col items-center gap-2 ${
                voteType === "disapprove" ? "bg-red-600 hover:bg-red-700" : ""
              }`}
            >
              <ThumbsDown className="h-6 w-6" />
              <span>Disapprove</span>
            </Button>
          </div>

          <div>
            <Label htmlFor="reason">Reason for Vote</Label>
            <Textarea
              id="reason"
              placeholder="Please explain why you agree or disagree with this review..."
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              className="min-h-[120px] mt-2"
            />
          </div>

          <div className="bg-blue-50 dark:bg-blue-900/20 p-4 rounded-lg flex items-center gap-3">
            <Coins className="h-5 w-5 text-blue-600" />
            <div>
              <p className="text-sm font-medium text-blue-800 dark:text-blue-200">
                Community Participation Reward
              </p>
              <p className="text-sm text-blue-600 dark:text-blue-400">
                You'll earn 5 FRONS tokens for submitting your vote
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="flex justify-end gap-4">
        <Button variant="outline" onClick={onBack}>
          Cancel
        </Button>
        <Button
          onClick={handleSubmitVote}
          disabled={submitVoteMutation.isPending || !voteType}
          className="bg-blue-600 hover:bg-blue-700 flex items-center gap-2"
        >
          <Users className="h-4 w-4" />
          {submitVoteMutation.isPending ? "Submitting..." : "Submit Vote"}
        </Button>
      </div>
    </div>
  );
}