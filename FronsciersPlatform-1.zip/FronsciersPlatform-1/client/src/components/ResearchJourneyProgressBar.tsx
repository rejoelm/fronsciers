import React, { useState, useEffect, useCallback } from 'react';
import { 
  FileEdit, 
  Upload, 
  Users, 
  RefreshCw, 
  CheckCircle, 
  Globe, 
  Database, 
  Quote 
} from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Tooltip, TooltipContent, TooltipTrigger } from '@/components/ui/tooltip';

// Research journey stages as defined in white paper section 3.1
export interface ResearchStage {
  key: string;
  label: string;
  description: string;
  icon: React.ReactNode;
  color: {
    completed: string;
    current: string;
    pending: string;
  };
}

export const RESEARCH_STAGES: ResearchStage[] = [
  {
    key: 'draft',
    label: 'Draft',
    description: 'Manuscript preparation and initial formatting',
    icon: <FileEdit className="h-4 w-4" />,
    color: {
      completed: 'bg-blue-500 text-white',
      current: 'bg-blue-100 text-blue-700 ring-2 ring-blue-500',
      pending: 'bg-gray-200 text-gray-400'
    }
  },
  {
    key: 'submission',
    label: 'Submission',
    description: 'Submitted to FRONSCIERS platform for review',
    icon: <Upload className="h-4 w-4" />,
    color: {
      completed: 'bg-green-500 text-white',
      current: 'bg-green-100 text-green-700 ring-2 ring-green-500',
      pending: 'bg-gray-200 text-gray-400'
    }
  },
  {
    key: 'peer_review',
    label: 'Peer Review',
    description: 'Under review by qualified peer reviewers',
    icon: <Users className="h-4 w-4" />,
    color: {
      completed: 'bg-purple-500 text-white',
      current: 'bg-purple-100 text-purple-700 ring-2 ring-purple-500',
      pending: 'bg-gray-200 text-gray-400'
    }
  },
  {
    key: 'revision',
    label: 'Revision',
    description: 'Author revisions based on reviewer feedback',
    icon: <RefreshCw className="h-4 w-4" />,
    color: {
      completed: 'bg-orange-500 text-white',
      current: 'bg-orange-100 text-orange-700 ring-2 ring-orange-500',
      pending: 'bg-gray-200 text-gray-400'
    }
  },
  {
    key: 'acceptance',
    label: 'Acceptance',
    description: 'Manuscript accepted for publication',
    icon: <CheckCircle className="h-4 w-4" />,
    color: {
      completed: 'bg-emerald-500 text-white',
      current: 'bg-emerald-100 text-emerald-700 ring-2 ring-emerald-500',
      pending: 'bg-gray-200 text-gray-400'
    }
  },
  {
    key: 'publication',
    label: 'Publication',
    description: 'Published with DOCI minted on Solana blockchain',
    icon: <Globe className="h-4 w-4" />,
    color: {
      completed: 'bg-indigo-500 text-white',
      current: 'bg-indigo-100 text-indigo-700 ring-2 ring-indigo-500',
      pending: 'bg-gray-200 text-gray-400'
    }
  },
  {
    key: 'indexing',
    label: 'Indexing',
    description: 'Indexed in academic databases and search engines',
    icon: <Database className="h-4 w-4" />,
    color: {
      completed: 'bg-teal-500 text-white',
      current: 'bg-teal-100 text-teal-700 ring-2 ring-teal-500',
      pending: 'bg-gray-200 text-gray-400'
    }
  },
  {
    key: 'citation',
    label: 'Citation',
    description: 'Available for citation and scholarly impact tracking',
    icon: <Quote className="h-4 w-4" />,
    color: {
      completed: 'bg-pink-500 text-white',
      current: 'bg-pink-100 text-pink-700 ring-2 ring-pink-500',
      pending: 'bg-gray-200 text-gray-400'
    }
  }
];

export interface WebSocketStageUpdate {
  dociId: string;
  newStage: string;
  timestamp: string;
}

export interface ResearchJourneyProgressBarProps {
  dociId?: string;
  currentStage: string;
  completedStages?: string[];
  onStageClick?: (stageKey: string) => void;
  showLabels?: boolean;
  compact?: boolean;
  className?: string;
}

export function ResearchJourneyProgressBar({
  dociId,
  currentStage,
  completedStages = [],
  onStageClick,
  showLabels = true,
  compact = false,
  className = ''
}: ResearchJourneyProgressBarProps) {
  const [currentStageState, setCurrentStageState] = useState(currentStage);
  const [completedStagesState, setCompletedStagesState] = useState<Set<string>>(new Set(completedStages));
  const [lastUpdate, setLastUpdate] = useState<Date | null>(null);

  // WebSocket connection for real-time stage updates
  useEffect(() => {
    if (!dociId) return;

    const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
    const wsUrl = `${protocol}//${window.location.host}/ws`;
    
    const socket = new WebSocket(wsUrl);
    
    socket.onopen = () => {
      console.log('Connected to WebSocket for research journey updates');
      // Subscribe to updates for this specific DOCI
      socket.send(JSON.stringify({
        type: 'SUBSCRIBE_DOCI_UPDATES',
        dociId: dociId
      }));
    };

    socket.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data);
        
        if (data.type === 'UPDATE_STAGE' && data.dociId === dociId) {
          const update: WebSocketStageUpdate = data;
          handleStageUpdate(update);
        }
      } catch (error) {
        console.error('Error parsing WebSocket message:', error);
      }
    };

    socket.onerror = (error) => {
      console.error('WebSocket error:', error);
    };

    socket.onclose = () => {
      console.log('WebSocket connection closed');
    };

    return () => {
      socket.close();
    };
  }, [dociId]);

  const handleStageUpdate = useCallback((update: WebSocketStageUpdate) => {
    const newStageIndex = RESEARCH_STAGES.findIndex(stage => stage.key === update.newStage);
    const currentStageIndex = RESEARCH_STAGES.findIndex(stage => stage.key === currentStageState);

    if (newStageIndex > currentStageIndex) {
      // Mark all previous stages as completed
      const newCompletedStages = new Set(completedStagesState);
      for (let i = 0; i < newStageIndex; i++) {
        newCompletedStages.add(RESEARCH_STAGES[i].key);
      }
      
      setCompletedStagesState(newCompletedStages);
      setCurrentStageState(update.newStage);
      setLastUpdate(new Date(update.timestamp));
    }
  }, [currentStageState, completedStagesState]);

  const getStageStatus = (stageKey: string): 'completed' | 'current' | 'pending' => {
    if (completedStagesState.has(stageKey)) return 'completed';
    if (stageKey === currentStageState) return 'current';
    return 'pending';
  };

  const getStageStyles = (stage: ResearchStage): string => {
    const status = getStageStatus(stage.key);
    const baseStyles = 'flex items-center justify-center rounded-full transition-all duration-300 ease-in-out cursor-pointer transform hover:scale-110';
    const sizeStyles = compact ? 'w-8 h-8' : 'w-12 h-12';
    
    return `${baseStyles} ${sizeStyles} ${stage.color[status]}`;
  };

  const getConnectorStyles = (index: number): string => {
    const nextStage = RESEARCH_STAGES[index + 1];
    if (!nextStage) return '';
    
    const currentStatus = getStageStatus(RESEARCH_STAGES[index].key);
    const nextStatus = getStageStatus(nextStage.key);
    
    let color = 'bg-gray-300';
    if (currentStatus === 'completed' && (nextStatus === 'completed' || nextStatus === 'current')) {
      color = 'bg-gradient-to-r from-blue-500 to-green-500';
    } else if (currentStatus === 'completed' || currentStatus === 'current') {
      color = 'bg-gradient-to-r from-blue-500 to-gray-300';
    }
    
    return `h-1 flex-1 mx-2 rounded transition-all duration-500 ${color}`;
  };

  const handleStageClick = (stageKey: string) => {
    if (onStageClick) {
      onStageClick(stageKey);
    }
  };

  return (
    <div className={`research-journey-progress ${className}`}>
      {lastUpdate && (
        <div className="flex items-center justify-between mb-4">
          <div className="text-sm text-gray-600">
            Research Journey Progress
          </div>
          <Badge variant="outline" className="text-xs">
            Last updated: {lastUpdate.toLocaleTimeString()}
          </Badge>
        </div>
      )}
      
      <div className="flex items-center w-full">
        {RESEARCH_STAGES.map((stage, index) => (
          <React.Fragment key={stage.key}>
            <Tooltip>
              <TooltipTrigger asChild>
                <div 
                  className="flex flex-col items-center space-y-2"
                  onClick={() => handleStageClick(stage.key)}
                >
                  <div className={getStageStyles(stage)}>
                    {stage.icon}
                  </div>
                  {showLabels && (
                    <div className={`text-xs font-medium text-center ${compact ? 'max-w-16' : 'max-w-20'}`}>
                      <div className={
                        getStageStatus(stage.key) === 'completed' 
                          ? 'text-gray-700' 
                          : getStageStatus(stage.key) === 'current'
                          ? 'text-blue-700 font-semibold'
                          : 'text-gray-400'
                      }>
                        {stage.label}
                      </div>
                    </div>
                  )}
                </div>
              </TooltipTrigger>
              <TooltipContent>
                <div className="max-w-xs">
                  <div className="font-semibold">{stage.label}</div>
                  <div className="text-sm text-gray-600">{stage.description}</div>
                  {getStageStatus(stage.key) === 'current' && (
                    <div className="text-xs text-blue-600 mt-1 font-medium">Current Stage</div>
                  )}
                </div>
              </TooltipContent>
            </Tooltip>
            
            {index < RESEARCH_STAGES.length - 1 && (
              <div className={getConnectorStyles(index)} />
            )}
          </React.Fragment>
        ))}
      </div>
      
      <div className="mt-4 text-xs text-gray-500 text-center">
        {getStageStatus(currentStageState) === 'current' && (
          <div>
            Currently in <span className="font-semibold text-blue-600">{RESEARCH_STAGES.find(s => s.key === currentStageState)?.label}</span> stage
          </div>
        )}
      </div>
    </div>
  );
}

// Utility function to get stage progress percentage
export function getResearchProgress(currentStage: string, completedStages: string[] = []): number {
  const currentIndex = RESEARCH_STAGES.findIndex(stage => stage.key === currentStage);
  const completedCount = completedStages.length;
  const totalStages = RESEARCH_STAGES.length;
  
  if (currentIndex === -1) return 0;
  
  // Progress is based on completed stages plus partial progress of current stage
  const progress = (completedCount + 0.5) / totalStages * 100;
  return Math.min(100, Math.max(0, progress));
}

// Hook for WebSocket stage updates
export function useResearchJourneyUpdates(dociId?: string) {
  const [updates, setUpdates] = useState<WebSocketStageUpdate[]>([]);
  
  useEffect(() => {
    if (!dociId) return;
    
    const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
    const wsUrl = `${protocol}//${window.location.host}/ws`;
    
    const socket = new WebSocket(wsUrl);
    
    socket.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data);
        if (data.type === 'UPDATE_STAGE' && data.dociId === dociId) {
          setUpdates(prev => [...prev, data]);
        }
      } catch (error) {
        console.error('Error parsing WebSocket message:', error);
      }
    };
    
    return () => socket.close();
  }, [dociId]);
  
  return updates;
}