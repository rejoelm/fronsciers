import { useState } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { useWallet } from "@/hooks/use-wallet";
import { useToast } from "@/hooks/use-toast";
import { 
  Wallet, Copy, ExternalLink, LogOut, 
  CheckCircle, AlertCircle, Loader2 
} from "lucide-react";

const WALLET_PROVIDERS = [
  {
    name: "Phantom",
    icon: "👻",
    description: "Popular Solana wallet",
    id: "phantom"
  },
  {
    name: "Solflare",
    icon: "🔥",
    description: "Advanced Solana wallet",
    id: "solflare"
  },
  {
    name: "Glow",
    icon: "✨",
    description: "Simple and secure",
    id: "glow"
  }
];

export function WalletConnection() {
  const { wallet, isConnected, isConnecting, connect, disconnect } = useWallet();
  const { toast } = useToast();
  const [, setLocation] = useLocation();
  const [showWalletDialog, setShowWalletDialog] = useState(false);

  const handleConnect = async (walletId: string) => {
    try {
      await connect(walletId);
      setShowWalletDialog(false);
      
      toast({
        title: "Wallet Connected",
        description: "Successfully connected to FRONSCIERS platform.",
      });
    } catch (error) {
      toast({
        title: "Connection failed",
        description: "Failed to connect wallet. Please try again.",
        variant: "destructive",
      });
    }
  };

  const handleDisconnect = async () => {
    try {
      await disconnect();
      toast({
        title: "Wallet disconnected",
        description: "Your wallet has been disconnected.",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to disconnect wallet.",
        variant: "destructive",
      });
    }
  };

  const copyAddress = () => {
    if (wallet?.address) {
      navigator.clipboard.writeText(wallet.address);
      toast({
        title: "Address copied",
        description: "Wallet address copied to clipboard.",
      });
    }
  };

  const truncateAddress = (address: string) => {
    return `${address.slice(0, 4)}...${address.slice(-4)}`;
  };

  if (isConnected && wallet) {
    return (
      <Dialog>
        <DialogTrigger asChild>
          <Button variant="outline" className="wallet-connected">
            <div className="flex items-center space-x-2">
              <div className="w-2 h-2 bg-green-500 rounded-full"></div>
              <Wallet className="h-4 w-4" />
              <span className="hidden sm:inline font-mono">
                {truncateAddress(wallet.address)}
              </span>
            </div>
          </Button>
        </DialogTrigger>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center space-x-2">
              <Wallet className="h-5 w-5" />
              <span>Wallet Details</span>
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="flex items-center justify-between p-3 bg-green-50 dark:bg-green-900/20 rounded-lg">
              <div className="flex items-center space-x-2">
                <CheckCircle className="h-4 w-4 text-green-600" />
                <span className="text-sm font-medium">Connected</span>
              </div>
              <Badge variant="secondary" className="text-green-700 bg-green-100">
                Solana Devnet
              </Badge>
            </div>

            <div className="space-y-3">
              <div>
                <label className="text-sm font-medium text-muted-foreground">Wallet Address</label>
                <div className="flex items-center space-x-2 mt-1">
                  <code className="flex-1 p-2 bg-muted rounded text-sm font-mono">
                    {wallet.address}
                  </code>
                  <Button size="sm" variant="outline" onClick={copyAddress}>
                    <Copy className="h-3 w-3" />
                  </Button>
                </div>
              </div>

              <div>
                <label className="text-sm font-medium text-muted-foreground">SOL Balance</label>
                <div className="mt-1">
                  <span className="text-lg font-semibold">{wallet.balance.toFixed(4)} SOL</span>
                </div>
              </div>

              <div>
                <label className="text-sm font-medium text-muted-foreground">FRONS Balance</label>
                <div className="mt-1">
                  <span className="text-lg font-semibold token-balance">
                    {wallet.fronsBalance.toLocaleString()} FRONS
                  </span>
                </div>
              </div>
            </div>

            <div className="flex space-x-2">
              <Button variant="outline" size="sm" className="flex-1">
                <ExternalLink className="h-3 w-3 mr-2" />
                View on Explorer
              </Button>
              <Button variant="outline" size="sm" onClick={handleDisconnect}>
                <LogOut className="h-3 w-3 mr-2" />
                Disconnect
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    );
  }

  return (
    <Dialog open={showWalletDialog} onOpenChange={setShowWalletDialog}>
      <DialogTrigger asChild>
        <Button 
          variant="outline" 
          className="bg-primary hover:bg-primary/90 text-white border-primary"
          disabled={isConnecting}
        >
          {isConnecting ? (
            <>
              <Loader2 className="h-4 w-4 mr-2 animate-spin" />
              Connecting...
            </>
          ) : (
            <>
              <Wallet className="h-4 w-4 mr-2" />
              Connect Wallet
            </>
          )}
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Connect Wallet</DialogTitle>
          <DialogDescription>
            Choose a wallet to connect to FRONSCIERS. You'll need a Solana wallet to participate in the platform.
          </DialogDescription>
        </DialogHeader>
        
        <div className="space-y-3">
          {WALLET_PROVIDERS.map((provider) => (
            <Card 
              key={provider.id}
              className="cursor-pointer hover:bg-muted/50 transition-colors"
              onClick={() => handleConnect(provider.id)}
            >
              <CardContent className="p-4">
                <div className="flex items-center space-x-3">
                  <div className="text-2xl">{provider.icon}</div>
                  <div className="flex-1">
                    <h3 className="font-medium">{provider.name}</h3>
                    <p className="text-sm text-muted-foreground">{provider.description}</p>
                  </div>
                  <Button size="sm" variant="outline">
                    Connect
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="mt-6 p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
          <div className="flex items-start space-x-2">
            <AlertCircle className="h-4 w-4 text-blue-600 mt-0.5" />
            <div className="text-sm">
              <p className="font-medium text-blue-900 dark:text-blue-100 mb-1">
                First time using Solana?
              </p>
              <p className="text-blue-700 dark:text-blue-300">
                You'll need to install a Solana wallet extension in your browser and create an account.
              </p>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
