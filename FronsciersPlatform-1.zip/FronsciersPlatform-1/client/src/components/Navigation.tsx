import React from 'react';
import { Link, useLocation } from 'wouter';
import { Button } from '@/components/ui/button';
import { useWallet } from '@solana/wallet-adapter-react';
import { WalletMultiButton } from '@solana/wallet-adapter-react-ui';
import { Badge } from '@/components/ui/badge';

export function Navigation() {
  const [location] = useLocation();
  const { connected } = useWallet();

  const navItems = [
    { path: '/', label: 'Dashboard', icon: 'fas fa-chart-line' },
    { path: '/submit', label: 'Submit', icon: 'fas fa-upload' },
    { path: '/review', label: 'Review', icon: 'fas fa-users' },
    { path: '/doci-registry', label: 'DOCI Registry', icon: 'fas fa-fingerprint' },
    { path: '/academic-integration', label: 'Import', icon: 'fas fa-database' },
    { path: '/governance', label: 'Governance', icon: 'fas fa-vote-yea' },
  ];

  return (
    <header className="bg-white border-b border-slate-200 sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center space-x-8">
            <Link href="/" className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-gradient-to-br from-primary to-secondary rounded-lg flex items-center justify-center">
                <i className="fas fa-microscope text-white text-lg"></i>
              </div>
              <span className="text-xl font-bold text-slate-900">FRONSCIERS</span>
            </Link>
            <nav className="hidden md:flex space-x-8">
              {navItems.map((item) => (
                <Link key={item.path} href={item.path}>
                  <Button
                    variant={location === item.path ? "default" : "ghost"}
                    className="flex items-center space-x-2"
                  >
                    <i className={item.icon}></i>
                    <span>{item.label}</span>
                  </Button>
                </Link>
              ))}
            </nav>
          </div>
          <div className="flex items-center space-x-4">
            {connected && (
              <div className="hidden sm:flex items-center space-x-2 bg-slate-100 px-3 py-2 rounded-lg">
                <i className="fas fa-coins text-yellow-600"></i>
                <span className="text-sm font-medium">2,450 FRONS</span>
              </div>
            )}
            <Badge variant={connected ? "default" : "secondary"} className="hidden sm:flex">
              <div className="w-2 h-2 bg-green-400 rounded-full mr-2"></div>
              Solana Devnet
            </Badge>
            <WalletMultiButton className="!bg-primary hover:!bg-primary/90" />
          </div>
        </div>
      </div>
    </header>
  );
}
