import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Search, Download, ExternalLink, BookOpen, User, Building, Calendar } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';

interface ExternalPublication {
  title: string;
  authors: string[];
  abstract: string;
  doi?: string;
  arxivId?: string;
  pubmedId?: string;
  publishedDate?: string;
  journal?: string;
  citationCount?: number;
  keywords?: string[];
  pdfUrl?: string;
  externalId: string;
  source: 'arxiv' | 'pubmed' | 'crossref' | 'google_scholar' | 'research_gate';
}

interface AcademicProfile {
  orcid?: string;
  googleScholarId?: string;
  researchGateId?: string;
  arxivAuthorId?: string;
  pubmedAuthorId?: string;
}

export function AcademicIntegration() {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedDatabases, setSelectedDatabases] = useState(['crossref', 'arxiv', 'pubmed']);
  const [selectedPublications, setSelectedPublications] = useState<Set<string>>(new Set());
  const [academicProfiles, setAcademicProfiles] = useState<AcademicProfile>({});
  const [activeTab, setActiveTab] = useState('search');
  
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Search publications across multiple databases
  const { data: searchResults, isLoading: isSearching, refetch: performSearch } = useQuery({
    queryKey: ['academic-search', searchQuery, selectedDatabases],
    queryFn: async () => {
      if (!searchQuery.trim()) return null;
      
      const params = new URLSearchParams({
        query: searchQuery,
        databases: selectedDatabases.join(','),
        limit: '20'
      });
      
      const response = await apiRequest('GET', `/api/academic/search?${params}`);
      return response.json();
    },
    enabled: false
  });

  // Import selected publications
  const importMutation = useMutation({
    mutationFn: async (publications: ExternalPublication[]) => {
      const response = await apiRequest('POST', '/api/academic/import', { publications });
      return response.json();
    },
    onSuccess: (data) => {
      toast({
        title: "Publications Imported",
        description: `Successfully imported ${data.imported} out of ${data.total} publications`,
      });
      setSelectedPublications(new Set());
      queryClient.invalidateQueries({ queryKey: ['manuscripts'] });
    },
    onError: () => {
      toast({
        title: "Import Failed",
        description: "Failed to import publications. Please try again.",
        variant: "destructive",
      });
    }
  });

  // Sync academic profiles
  const syncProfileMutation = useMutation({
    mutationFn: async (profiles: AcademicProfile) => {
      const response = await apiRequest('POST', '/api/academic/sync-profile', { profiles });
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Profile Synchronized",
        description: "Your academic profile has been updated successfully",
      });
      queryClient.invalidateQueries({ queryKey: ['user'] });
    },
    onError: () => {
      toast({
        title: "Sync Failed",
        description: "Failed to sync academic profile. Please try again.",
        variant: "destructive",
      });
    }
  });

  const handleSearch = () => {
    if (searchQuery.trim()) {
      performSearch();
    }
  };

  const handleDatabaseToggle = (database: string) => {
    setSelectedDatabases(prev => 
      prev.includes(database) 
        ? prev.filter(db => db !== database)
        : [...prev, database]
    );
  };

  const handlePublicationToggle = (publicationId: string) => {
    setSelectedPublications(prev => {
      const newSet = new Set(prev);
      if (newSet.has(publicationId)) {
        newSet.delete(publicationId);
      } else {
        newSet.add(publicationId);
      }
      return newSet;
    });
  };

  const handleImportSelected = () => {
    if (selectedPublications.size === 0) {
      toast({
        title: "No Publications Selected",
        description: "Please select at least one publication to import",
        variant: "destructive",
      });
      return;
    }

    const publicationsToImport = searchResults?.publications?.filter((pub: ExternalPublication) => 
      selectedPublications.has(pub.externalId)
    ) || [];

    importMutation.mutate(publicationsToImport);
  };

  const handleProfileSync = () => {
    syncProfileMutation.mutate(academicProfiles);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center space-x-2">
        <BookOpen className="h-6 w-6" />
        <h2 className="text-2xl font-bold">Academic Database Integration</h2>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="search">Search & Import</TabsTrigger>
          <TabsTrigger value="profile">Profile Sync</TabsTrigger>
          <TabsTrigger value="history">Import History</TabsTrigger>
        </TabsList>

        <TabsContent value="search" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Search Academic Publications</CardTitle>
              <CardDescription>
                Search across multiple academic databases to find and import your existing publications
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex space-x-2">
                <Input
                  placeholder="Search by title, author, keywords, or DOI..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  onKeyPress={(e) => e.key === 'Enter' && handleSearch()}
                  className="flex-1"
                />
                <Button onClick={handleSearch} disabled={isSearching || !searchQuery.trim()}>
                  <Search className="h-4 w-4 mr-2" />
                  {isSearching ? 'Searching...' : 'Search'}
                </Button>
              </div>

              <div className="space-y-2">
                <Label>Search Databases:</Label>
                <div className="flex flex-wrap gap-4">
                  {[
                    { id: 'crossref', label: 'CrossRef', description: 'DOI-based academic publications' },
                    { id: 'arxiv', label: 'arXiv', description: 'Preprints and papers' },
                    { id: 'pubmed', label: 'PubMed', description: 'Biomedical literature' }
                  ].map((db) => (
                    <div key={db.id} className="flex items-center space-x-2">
                      <Checkbox
                        id={db.id}
                        checked={selectedDatabases.includes(db.id)}
                        onCheckedChange={() => handleDatabaseToggle(db.id)}
                      />
                      <Label htmlFor={db.id} className="text-sm font-medium">
                        {db.label}
                      </Label>
                    </div>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>

          {searchResults && (
            <Card>
              <CardHeader className="flex flex-row items-center justify-between">
                <div>
                  <CardTitle>Search Results</CardTitle>
                  <CardDescription>
                    Found {searchResults.total} publications for "{searchResults.query}"
                  </CardDescription>
                </div>
                {selectedPublications.size > 0 && (
                  <Button 
                    onClick={handleImportSelected}
                    disabled={importMutation.isPending}
                  >
                    <Download className="h-4 w-4 mr-2" />
                    Import Selected ({selectedPublications.size})
                  </Button>
                )}
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {searchResults.publications?.map((pub: ExternalPublication) => (
                    <div key={pub.externalId} className="border rounded-lg p-4 space-y-3">
                      <div className="flex items-start justify-between">
                        <div className="flex items-center space-x-2">
                          <Checkbox
                            checked={selectedPublications.has(pub.externalId)}
                            onCheckedChange={() => handlePublicationToggle(pub.externalId)}
                          />
                          <div className="flex-1">
                            <h3 className="font-semibold text-lg">{pub.title}</h3>
                            <p className="text-sm text-gray-600 mt-1">
                              {pub.authors.slice(0, 3).join(', ')}
                              {pub.authors.length > 3 && ` + ${pub.authors.length - 3} more`}
                            </p>
                          </div>
                        </div>
                        <div className="flex items-center space-x-2">
                          <Badge variant="secondary">{pub.source}</Badge>
                          {pub.pdfUrl && (
                            <Button variant="ghost" size="sm" asChild>
                              <a href={pub.pdfUrl} target="_blank" rel="noopener noreferrer">
                                <ExternalLink className="h-4 w-4" />
                              </a>
                            </Button>
                          )}
                        </div>
                      </div>

                      {pub.abstract && (
                        <p className="text-sm text-gray-700 line-clamp-3">{pub.abstract}</p>
                      )}

                      <div className="flex flex-wrap gap-2 text-xs text-gray-500">
                        {pub.journal && (
                          <div className="flex items-center">
                            <Building className="h-3 w-3 mr-1" />
                            {pub.journal}
                          </div>
                        )}
                        {pub.publishedDate && (
                          <div className="flex items-center">
                            <Calendar className="h-3 w-3 mr-1" />
                            {new Date(pub.publishedDate).getFullYear()}
                          </div>
                        )}
                        {pub.citationCount !== undefined && (
                          <div>Citations: {pub.citationCount}</div>
                        )}
                        {pub.doi && (
                          <div>DOI: {pub.doi}</div>
                        )}
                      </div>

                      {pub.keywords && pub.keywords.length > 0 && (
                        <div className="flex flex-wrap gap-1">
                          {pub.keywords.slice(0, 5).map((keyword, index) => (
                            <Badge key={index} variant="outline" className="text-xs">
                              {keyword}
                            </Badge>
                          ))}
                          {pub.keywords.length > 5 && (
                            <Badge variant="outline" className="text-xs">
                              +{pub.keywords.length - 5} more
                            </Badge>
                          )}
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="profile" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Sync Academic Profiles</CardTitle>
              <CardDescription>
                Connect your academic profiles to automatically sync your information and publications
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="orcid">ORCID ID</Label>
                  <Input
                    id="orcid"
                    placeholder="0000-0000-0000-0000"
                    value={academicProfiles.orcid || ''}
                    onChange={(e) => setAcademicProfiles(prev => ({ ...prev, orcid: e.target.value }))}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="googleScholar">Google Scholar ID</Label>
                  <Input
                    id="googleScholar"
                    placeholder="Your Google Scholar ID"
                    value={academicProfiles.googleScholarId || ''}
                    onChange={(e) => setAcademicProfiles(prev => ({ ...prev, googleScholarId: e.target.value }))}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="researchGate">ResearchGate ID</Label>
                  <Input
                    id="researchGate"
                    placeholder="Your ResearchGate ID"
                    value={academicProfiles.researchGateId || ''}
                    onChange={(e) => setAcademicProfiles(prev => ({ ...prev, researchGateId: e.target.value }))}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="arxiv">arXiv Author ID</Label>
                  <Input
                    id="arxiv"
                    placeholder="Your arXiv Author ID"
                    value={academicProfiles.arxivAuthorId || ''}
                    onChange={(e) => setAcademicProfiles(prev => ({ ...prev, arxivAuthorId: e.target.value }))}
                  />
                </div>
              </div>

              <Button 
                onClick={handleProfileSync}
                disabled={syncProfileMutation.isPending}
                className="w-full"
              >
                <User className="h-4 w-4 mr-2" />
                {syncProfileMutation.isPending ? 'Syncing...' : 'Sync Academic Profiles'}
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="history" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Import History</CardTitle>
              <CardDescription>
                View your previously imported publications and their sources
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-center py-8 text-gray-500">
                <BookOpen className="h-12 w-12 mx-auto mb-4 opacity-50" />
                <p>Import history will be displayed here</p>
                <p className="text-sm">Import some publications to see your history</p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}