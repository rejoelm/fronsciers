import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Coins, TrendingUp, ArrowUpRight, ArrowDownRight } from "lucide-react";
import { useWalletContext } from "@/components/wallet/wallet-provider";

interface TokenBalanceProps {
  stakedAmount?: number;
  pendingRewards?: number;
}

export function TokenBalance({ stakedAmount = 0, pendingRewards = 0 }: TokenBalanceProps) {
  const { fronsBalance, solBalance, loading } = useWalletContext();

  const totalValue = fronsBalance + stakedAmount;
  const usdValue = totalValue * 0.50; // Mock exchange rate

  return (
    <div className="space-y-6">
      {/* Main Balance Card */}
      <Card className="bg-gradient-to-br from-primary to-purple-600 text-white">
        <CardHeader>
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-white/20 rounded-lg flex items-center justify-center">
              <Coins className="w-6 h-6" />
            </div>
            <CardTitle className="text-lg">FRONS Token Balance</CardTitle>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div>
              <div className="text-3xl font-bold">
                {loading ? '...' : fronsBalance.toLocaleString()}
              </div>
              <div className="text-primary-100">
                ≈ ${usdValue.toFixed(2)} USD
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <div className="text-primary-100 text-sm">Available</div>
                <div className="font-semibold">
                  {(fronsBalance - stakedAmount).toLocaleString()}
                </div>
              </div>
              <div>
                <div className="text-primary-100 text-sm">Staked</div>
                <div className="font-semibold">
                  {stakedAmount.toLocaleString()}
                </div>
              </div>
            </div>

            {pendingRewards > 0 && (
              <div className="flex items-center justify-between p-3 bg-white/10 rounded-lg">
                <div>
                  <div className="text-sm text-primary-100">Pending Rewards</div>
                  <div className="font-semibold text-green-200">
                    +{pendingRewards.toLocaleString()}
                  </div>
                </div>
                <Button size="sm" variant="secondary">
                  Claim
                </Button>
              </div>
            )}

            <div className="grid grid-cols-2 gap-3">
              <Button variant="secondary" className="text-primary">
                <ArrowUpRight className="w-4 h-4 mr-2" />
                Stake
              </Button>
              <Button variant="secondary" className="text-primary">
                <ArrowDownRight className="w-4 h-4 mr-2" />
                Trade
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* SOL Balance */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg flex items-center space-x-2">
            <span>SOL Balance</span>
            <Badge variant="outline">Native</Badge>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-between">
            <div>
              <div className="text-2xl font-bold">
                {loading ? '...' : solBalance.toFixed(4)}
              </div>
              <div className="text-sm text-slate-500">Solana</div>
            </div>
            <TrendingUp className="w-8 h-8 text-green-500" />
          </div>
        </CardContent>
      </Card>

      {/* Token Stats */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Token Statistics</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex justify-between">
              <span className="text-slate-600">24h Change</span>
              <span className="text-green-600 font-medium">+5.2%</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-600">Market Cap</span>
              <span className="font-medium">$12.5M</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-600">Total Supply</span>
              <span className="font-medium">100M FRONS</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-600">Your Share</span>
              <span className="font-medium">
                {((totalValue / 100000000) * 100).toFixed(4)}%
              </span>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
