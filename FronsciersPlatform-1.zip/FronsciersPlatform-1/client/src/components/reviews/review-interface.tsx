import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { z } from "zod";
import { FileText, Eye, CheckCircle } from "lucide-react";
import type { Manuscript } from "@shared/schema";

const reviewSchema = z.object({
  noveltyScore: z.string().transform(str => parseInt(str)),
  methodologyScore: z.string().transform(str => parseInt(str)),
  clarityScore: z.string().transform(str => parseInt(str)),
  comments: z.string().min(50, "Comments must be at least 50 characters"),
  recommendation: z.enum(["accept", "minor_revisions", "major_revisions", "reject"]),
});

type ReviewFormData = z.infer<typeof reviewSchema>;

interface ReviewInterfaceProps {
  manuscript: Manuscript;
  onSubmit: (data: ReviewFormData) => Promise<void>;
  loading?: boolean;
}

export function ReviewInterface({ manuscript, onSubmit, loading = false }: ReviewInterfaceProps) {
  const [showPDF, setShowPDF] = useState(false);

  const form = useForm<ReviewFormData>({
    resolver: zodResolver(reviewSchema),
    defaultValues: {
      noveltyScore: "3",
      methodologyScore: "3",
      clarityScore: "3",
      comments: "",
      recommendation: "accept",
    },
  });

  const handleSubmit = async (data: ReviewFormData) => {
    try {
      await onSubmit(data);
    } catch (error) {
      console.error('Review submission error:', error);
    }
  };

  const getRecommendationColor = (recommendation: string) => {
    switch (recommendation) {
      case "accept":
        return "bg-green-100 text-green-800";
      case "minor_revisions":
        return "bg-yellow-100 text-yellow-800";
      case "major_revisions":
        return "bg-orange-100 text-orange-800";
      case "reject":
        return "bg-red-100 text-red-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  return (
    <div className="space-y-6">
      {/* Manuscript Info */}
      <Card>
        <CardHeader>
          <div className="flex items-start justify-between">
            <div className="flex-1">
              <CardTitle className="text-xl mb-2">{manuscript.title}</CardTitle>
              <p className="text-sm text-slate-600 mb-2">
                Authors: {manuscript.authors.join(", ")}
              </p>
              <div className="flex items-center space-x-4 text-sm text-slate-500">
                <span>Category: {manuscript.category}</span>
                <span>•</span>
                <span>Status: {manuscript.status}</span>
              </div>
            </div>
            <div className="flex items-center space-x-2">
              <Badge variant="outline">5 days left</Badge>
              <Badge className="bg-emerald-100 text-emerald-800">+75 FRONS</Badge>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div>
              <Label className="font-medium">Abstract</Label>
              <p className="text-sm text-slate-600 mt-1">{manuscript.abstract}</p>
            </div>

            {manuscript.keywords && (
              <div>
                <Label className="font-medium">Keywords</Label>
                <div className="flex flex-wrap gap-2 mt-1">
                  {manuscript.keywords.map((keyword, index) => (
                    <Badge key={index} variant="secondary" className="text-xs">
                      {keyword}
                    </Badge>
                  ))}
                </div>
              </div>
            )}

            {/* PDF Viewer */}
            {manuscript.ipfsHash && (
              <div className="border-2 border-slate-200 rounded-lg p-6 text-center">
                <FileText className="w-16 h-16 text-slate-400 mx-auto mb-4" />
                <p className="text-slate-600 mb-2">
                  {manuscript.filePath || 'manuscript.pdf'}
                </p>
                <p className="text-sm text-slate-500 mb-4">
                  Stored on IPFS: {manuscript.ipfsHash.slice(0, 20)}...
                </p>
                <Button onClick={() => setShowPDF(!showPDF)}>
                  <Eye className="w-4 h-4 mr-2" />
                  {showPDF ? 'Hide PDF' : 'View PDF'}
                </Button>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Review Form */}
      <Card>
        <CardHeader>
          <CardTitle>Submit Review</CardTitle>
        </CardHeader>
        <CardContent>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-6">
              {/* Scoring */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <FormField
                  control={form.control}
                  name="noveltyScore"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Novelty</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="5">Excellent (5)</SelectItem>
                          <SelectItem value="4">Good (4)</SelectItem>
                          <SelectItem value="3">Fair (3)</SelectItem>
                          <SelectItem value="2">Poor (2)</SelectItem>
                          <SelectItem value="1">Very Poor (1)</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="methodologyScore"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Methodology</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="5">Excellent (5)</SelectItem>
                          <SelectItem value="4">Good (4)</SelectItem>
                          <SelectItem value="3">Fair (3)</SelectItem>
                          <SelectItem value="2">Poor (2)</SelectItem>
                          <SelectItem value="1">Very Poor (1)</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="clarityScore"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Clarity</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="5">Excellent (5)</SelectItem>
                          <SelectItem value="4">Good (4)</SelectItem>
                          <SelectItem value="3">Fair (3)</SelectItem>
                          <SelectItem value="2">Poor (2)</SelectItem>
                          <SelectItem value="1">Very Poor (1)</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              {/* Comments */}
              <FormField
                control={form.control}
                name="comments"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Detailed Comments</FormLabel>
                    <FormControl>
                      <Textarea
                        rows={6}
                        placeholder="Provide detailed feedback on the manuscript..."
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {/* Recommendation */}
              <FormField
                control={form.control}
                name="recommendation"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Recommendation</FormLabel>
                    <FormControl>
                      <RadioGroup
                        onValueChange={field.onChange}
                        defaultValue={field.value}
                        className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4"
                      >
                        <div className="flex items-center space-x-2">
                          <RadioGroupItem value="accept" id="accept" />
                          <Label
                            htmlFor="accept"
                            className={`px-3 py-2 rounded-lg cursor-pointer ${getRecommendationColor("accept")}`}
                          >
                            Accept
                          </Label>
                        </div>
                        <div className="flex items-center space-x-2">
                          <RadioGroupItem value="minor_revisions" id="minor" />
                          <Label
                            htmlFor="minor"
                            className={`px-3 py-2 rounded-lg cursor-pointer ${getRecommendationColor("minor_revisions")}`}
                          >
                            Minor Revisions
                          </Label>
                        </div>
                        <div className="flex items-center space-x-2">
                          <RadioGroupItem value="major_revisions" id="major" />
                          <Label
                            htmlFor="major"
                            className={`px-3 py-2 rounded-lg cursor-pointer ${getRecommendationColor("major_revisions")}`}
                          >
                            Major Revisions
                          </Label>
                        </div>
                        <div className="flex items-center space-x-2">
                          <RadioGroupItem value="reject" id="reject" />
                          <Label
                            htmlFor="reject"
                            className={`px-3 py-2 rounded-lg cursor-pointer ${getRecommendationColor("reject")}`}
                          >
                            Reject
                          </Label>
                        </div>
                      </RadioGroup>
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <Button type="submit" disabled={loading} className="w-full">
                <CheckCircle className="w-4 h-4 mr-2" />
                {loading ? 'Submitting Review...' : 'Submit Review & Earn 75 FRONS'}
              </Button>
            </form>
          </Form>
        </CardContent>
      </Card>
    </div>
  );
}
