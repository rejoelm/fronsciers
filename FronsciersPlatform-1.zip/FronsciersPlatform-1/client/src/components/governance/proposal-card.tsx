import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { ThumbsUp, ThumbsDown, Eye } from "lucide-react";
import type { Proposal } from "@shared/schema";

interface ProposalCardProps {
  proposal: Proposal;
  onVote: (proposalId: number, voteType: 'for' | 'against') => Promise<void>;
  userHasVoted?: boolean;
  loading?: boolean;
}

export function ProposalCard({ proposal, onVote, userHasVoted = false, loading = false }: ProposalCardProps) {
  const totalVotes = (proposal.votesFor || 0) + (proposal.votesAgainst || 0);
  const forPercentage = totalVotes > 0 ? ((proposal.votesFor || 0) / totalVotes) * 100 : 0;
  const againstPercentage = totalVotes > 0 ? ((proposal.votesAgainst || 0) / totalVotes) * 100 : 0;

  const getStatusColor = (status: string) => {
    switch (status) {
      case "active":
        return "bg-green-100 text-green-800";
      case "passed":
        return "bg-blue-100 text-blue-800";
      case "rejected":
        return "bg-red-100 text-red-800";
      case "executed":
        return "bg-purple-100 text-purple-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const getDaysLeft = () => {
    const now = new Date();
    const endDate = new Date(proposal.endDate);
    const diffTime = endDate.getTime() - now.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return Math.max(0, diffDays);
  };

  const handleVote = async (voteType: 'for' | 'against') => {
    if (userHasVoted || loading) return;
    await onVote(proposal.id, voteType);
  };

  return (
    <Card className="w-full">
      <CardHeader>
        <div className="flex items-start justify-between">
          <div className="flex-1">
            <CardTitle className="text-lg mb-2">{proposal.title}</CardTitle>
            <p className="text-sm text-slate-600 mb-3 line-clamp-2">
              {proposal.description}
            </p>
            <div className="flex items-center space-x-4 text-sm text-slate-500">
              <span>Proposed by User #{proposal.proposerId}</span>
              <span>•</span>
              <span>{getDaysLeft()} days left</span>
              <span>•</span>
              <span>{totalVotes} votes</span>
            </div>
          </div>
          <div className="flex items-center space-x-2">
            <Badge className={getStatusColor(proposal.status)}>
              {proposal.status}
            </Badge>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {/* Voting Progress */}
          <div>
            <div className="flex justify-between text-sm mb-2">
              <span className="text-slate-600">Progress</span>
              <span className="text-slate-900 font-medium">
                {forPercentage.toFixed(1)}% in favor
              </span>
            </div>
            <div className="w-full bg-slate-200 rounded-full h-3 mb-2">
              <div
                className="bg-gradient-to-r from-green-500 to-green-600 h-3 rounded-full transition-all duration-300"
                style={{ width: `${forPercentage}%` }}
              />
            </div>
            <div className="flex justify-between text-xs text-slate-500">
              <span>{proposal.votesFor || 0} For</span>
              <span>{proposal.votesAgainst || 0} Against</span>
            </div>
          </div>

          {/* Voting Power Display */}
          {proposal.totalVotingPower && parseFloat(proposal.totalVotingPower) > 0 && (
            <div className="text-sm text-slate-600">
              Total Voting Power: {parseFloat(proposal.totalVotingPower).toLocaleString()} FRONS
            </div>
          )}

          {/* Action Buttons */}
          {proposal.status === "active" && (
            <div className="flex items-center space-x-3">
              <Button
                onClick={() => handleVote('for')}
                disabled={userHasVoted || loading}
                className="bg-green-600 hover:bg-green-700"
              >
                <ThumbsUp className="w-4 h-4 mr-2" />
                Vote For
              </Button>
              <Button
                onClick={() => handleVote('against')}
                disabled={userHasVoted || loading}
                variant="destructive"
              >
                <ThumbsDown className="w-4 h-4 mr-2" />
                Vote Against
              </Button>
              <Button variant="outline">
                <Eye className="w-4 h-4 mr-2" />
                View Details
              </Button>
            </div>
          )}

          {userHasVoted && (
            <div className="text-sm text-green-600 font-medium">
              ✓ You have already voted on this proposal
            </div>
          )}

          {/* Proposal Type Info */}
          {proposal.proposalType && (
            <div className="text-xs text-slate-500">
              Type: {proposal.proposalType.replace('_', ' ').toUpperCase()}
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
