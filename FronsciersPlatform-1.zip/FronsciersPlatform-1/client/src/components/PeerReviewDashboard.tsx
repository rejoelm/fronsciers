import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Progress } from '@/components/ui/progress';
import { Star, Clock, CheckCircle, XCircle, TrendingUp, Award } from 'lucide-react';
import { apiRequest } from '@/lib/queryClient';

interface ReviewerMatch {
  reviewer: {
    id: number;
    username: string;
    reputationScore: number;
    reviewerLevel: string;
    avgReviewQuality: number;
    reviewsCompleted: number;
  };
  matchScore: number;
  expertiseMatch: number;
  availabilityScore: number;
  reputationScore: number;
  workloadScore: number;
  reasons: string[];
}

interface PeerReviewAssignment {
  id: number;
  manuscriptId: number;
  reviewerId: number;
  status: string;
  responseDeadline: string;
  reviewDeadline: string;
  assignedAt: string;
}

interface ReputationHistory {
  id: number;
  action: string;
  points: number;
  description: string;
  createdAt: string;
}

export function PeerReviewDashboard() {
  const [selectedManuscript, setSelectedManuscript] = useState<number | null>(null);
  const [selectedReviewers, setSelectedReviewers] = useState<number[]>([]);
  const queryClient = useQueryClient();

  // Fetch user's review assignments
  const { data: assignments, isLoading: assignmentsLoading } = useQuery({
    queryKey: ['/api/peer-review/my-assignments'],
    queryFn: () => apiRequest('/api/peer-review/my-assignments')
  });

  // Fetch user's completed reviews
  const { data: reviews, isLoading: reviewsLoading } = useQuery({
    queryKey: ['/api/peer-review/my-reviews'],
    queryFn: () => apiRequest('/api/peer-review/my-reviews')
  });

  // Fetch reputation history
  const { data: reputationData, isLoading: reputationLoading } = useQuery({
    queryKey: ['/api/reputation/history'],
    queryFn: () => apiRequest('/api/reputation/history')
  });

  // Find optimal reviewers mutation
  const findReviewersMutation = useMutation({
    mutationFn: (manuscriptId: number) => 
      apiRequest(`/api/peer-review/find-reviewers/${manuscriptId}?count=6`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/peer-review/find-reviewers'] });
    }
  });

  // Assign reviewers mutation
  const assignReviewersMutation = useMutation({
    mutationFn: ({ manuscriptId, reviewerIds }: { manuscriptId: number; reviewerIds: number[] }) =>
      apiRequest('/api/peer-review/assign-reviewers', {
        method: 'POST',
        body: { manuscriptId, reviewerIds }
      }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/peer-review/my-assignments'] });
      setSelectedReviewers([]);
      setSelectedManuscript(null);
    }
  });

  // Respond to assignment mutation
  const respondToAssignmentMutation = useMutation({
    mutationFn: ({ assignmentId, response, declineReason }: { 
      assignmentId: number; 
      response: 'accepted' | 'declined'; 
      declineReason?: string 
    }) =>
      apiRequest(`/api/peer-review/respond-assignment/${assignmentId}`, {
        method: 'POST',
        body: { response, declineReason }
      }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/peer-review/my-assignments'] });
    }
  });

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'assigned': return 'bg-yellow-100 text-yellow-800';
      case 'accepted': return 'bg-blue-100 text-blue-800';
      case 'completed': return 'bg-green-100 text-green-800';
      case 'declined': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getReviewerLevelColor = (level: string) => {
    switch (level) {
      case 'distinguished': return 'bg-purple-100 text-purple-800';
      case 'expert': return 'bg-blue-100 text-blue-800';
      case 'intermediate': return 'bg-green-100 text-green-800';
      case 'novice': return 'bg-gray-100 text-gray-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="container mx-auto p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Peer Review Dashboard</h1>
          <p className="text-muted-foreground">Manage reviews and track your reputation</p>
        </div>
        <div className="flex items-center space-x-4">
          <Badge variant="outline" className="flex items-center space-x-2">
            <TrendingUp className="h-4 w-4" />
            <span>Reputation: {reputationData?.user?.reputationScore || 0}</span>
          </Badge>
          <Badge variant="outline" className="flex items-center space-x-2">
            <Award className="h-4 w-4" />
            <span>Level: {reputationData?.user?.reviewerLevel || 'Novice'}</span>
          </Badge>
        </div>
      </div>

      <Tabs defaultValue="assignments" className="space-y-6">
        <TabsList>
          <TabsTrigger value="assignments">My Assignments</TabsTrigger>
          <TabsTrigger value="reviews">My Reviews</TabsTrigger>
          <TabsTrigger value="reputation">Reputation History</TabsTrigger>
          <TabsTrigger value="find-reviewers">Find Reviewers</TabsTrigger>
        </TabsList>

        <TabsContent value="assignments" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Review Assignments</CardTitle>
              <CardDescription>Papers assigned to you for peer review</CardDescription>
            </CardHeader>
            <CardContent>
              {assignmentsLoading ? (
                <div className="space-y-3">
                  {[1, 2, 3].map((i) => (
                    <div key={i} className="h-16 bg-gray-100 rounded animate-pulse" />
                  ))}
                </div>
              ) : assignments?.assignments?.length > 0 ? (
                <div className="space-y-4">
                  {assignments.assignments.map((assignment: PeerReviewAssignment) => (
                    <div key={assignment.id} className="flex items-center justify-between p-4 border rounded-lg">
                      <div className="space-y-1">
                        <div className="flex items-center space-x-2">
                          <h3 className="font-medium">Manuscript #{assignment.manuscriptId}</h3>
                          <Badge className={getStatusColor(assignment.status)}>
                            {assignment.status}
                          </Badge>
                        </div>
                        <p className="text-sm text-muted-foreground">
                          Review deadline: {new Date(assignment.reviewDeadline).toLocaleDateString()}
                        </p>
                      </div>
                      <div className="flex items-center space-x-2">
                        {assignment.status === 'assigned' && (
                          <>
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => respondToAssignmentMutation.mutate({
                                assignmentId: assignment.id,
                                response: 'accepted'
                              })}
                              disabled={respondToAssignmentMutation.isPending}
                            >
                              <CheckCircle className="h-4 w-4 mr-1" />
                              Accept
                            </Button>
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => respondToAssignmentMutation.mutate({
                                assignmentId: assignment.id,
                                response: 'declined',
                                declineReason: 'Time constraints'
                              })}
                              disabled={respondToAssignmentMutation.isPending}
                            >
                              <XCircle className="h-4 w-4 mr-1" />
                              Decline
                            </Button>
                          </>
                        )}
                        {assignment.status === 'accepted' && (
                          <Button size="sm">
                            Start Review
                          </Button>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8 text-muted-foreground">
                  No review assignments found
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="reviews" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Completed Reviews</CardTitle>
              <CardDescription>Your peer review history and performance</CardDescription>
            </CardHeader>
            <CardContent>
              {reviewsLoading ? (
                <div className="space-y-3">
                  {[1, 2, 3].map((i) => (
                    <div key={i} className="h-20 bg-gray-100 rounded animate-pulse" />
                  ))}
                </div>
              ) : reviews?.reviews?.length > 0 ? (
                <div className="space-y-4">
                  {reviews.reviews.map((review: any) => (
                    <div key={review.id} className="p-4 border rounded-lg space-y-2">
                      <div className="flex items-center justify-between">
                        <h3 className="font-medium">Manuscript #{review.manuscriptId}</h3>
                        <div className="flex items-center space-x-2">
                          <Badge className={getStatusColor(review.status)}>
                            {review.status}
                          </Badge>
                          {review.qualityRating && (
                            <Badge variant="outline">
                              Quality: {review.qualityRating}/100
                            </Badge>
                          )}
                        </div>
                      </div>
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                        <div>
                          <span className="font-medium">Overall Score:</span>
                          <div className="text-lg font-bold">{review.overallScore || 'N/A'}</div>
                        </div>
                        <div>
                          <span className="font-medium">Recommendation:</span>
                          <div className="capitalize">{review.recommendation || 'N/A'}</div>
                        </div>
                        <div>
                          <span className="font-medium">FRONS Reward:</span>
                          <div className="text-green-600">{review.fronsReward || 0}</div>
                        </div>
                        <div>
                          <span className="font-medium">Reputation Impact:</span>
                          <div className={review.reputationImpact > 0 ? 'text-green-600' : 'text-red-600'}>
                            {review.reputationImpact > 0 ? '+' : ''}{review.reputationImpact || 0}
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8 text-muted-foreground">
                  No completed reviews found
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="reputation" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Reputation History</CardTitle>
              <CardDescription>Track your reputation changes and achievements</CardDescription>
            </CardHeader>
            <CardContent>
              {reputationLoading ? (
                <div className="space-y-3">
                  {[1, 2, 3].map((i) => (
                    <div key={i} className="h-12 bg-gray-100 rounded animate-pulse" />
                  ))}
                </div>
              ) : reputationData?.history?.length > 0 ? (
                <div className="space-y-3">
                  {reputationData.history.map((entry: ReputationHistory) => (
                    <div key={entry.id} className="flex items-center justify-between p-3 border rounded">
                      <div className="space-y-1">
                        <div className="font-medium capitalize">{entry.action.replace('_', ' ')}</div>
                        <div className="text-sm text-muted-foreground">{entry.description}</div>
                        <div className="text-xs text-muted-foreground">
                          {new Date(entry.createdAt).toLocaleDateString()}
                        </div>
                      </div>
                      <div className={`font-bold ${entry.points > 0 ? 'text-green-600' : 'text-red-600'}`}>
                        {entry.points > 0 ? '+' : ''}{entry.points}
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8 text-muted-foreground">
                  No reputation history found
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="find-reviewers" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Find Optimal Reviewers</CardTitle>
              <CardDescription>Use AI-powered matching to find the best reviewers for manuscripts</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center space-x-4">
                <input
                  type="number"
                  placeholder="Enter manuscript ID"
                  className="flex-1 px-3 py-2 border rounded-md"
                  value={selectedManuscript || ''}
                  onChange={(e) => setSelectedManuscript(parseInt(e.target.value) || null)}
                />
                <Button
                  onClick={() => selectedManuscript && findReviewersMutation.mutate(selectedManuscript)}
                  disabled={!selectedManuscript || findReviewersMutation.isPending}
                >
                  {findReviewersMutation.isPending ? 'Finding...' : 'Find Reviewers'}
                </Button>
              </div>

              {findReviewersMutation.data?.reviewers && (
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <h3 className="font-medium">Recommended Reviewers</h3>
                    {selectedReviewers.length > 0 && (
                      <Button
                        onClick={() => assignReviewersMutation.mutate({
                          manuscriptId: selectedManuscript!,
                          reviewerIds: selectedReviewers
                        })}
                        disabled={assignReviewersMutation.isPending}
                      >
                        Assign Selected ({selectedReviewers.length})
                      </Button>
                    )}
                  </div>
                  
                  <div className="grid gap-4">
                    {findReviewersMutation.data.reviewers.map((match: ReviewerMatch) => (
                      <div key={match.reviewer.id} className="p-4 border rounded-lg space-y-3">
                        <div className="flex items-center justify-between">
                          <div className="space-y-1">
                            <div className="flex items-center space-x-2">
                              <h4 className="font-medium">{match.reviewer.username}</h4>
                              <Badge className={getReviewerLevelColor(match.reviewer.reviewerLevel)}>
                                {match.reviewer.reviewerLevel}
                              </Badge>
                            </div>
                            <div className="text-sm text-muted-foreground">
                              {match.reviewer.reviewsCompleted} reviews • Reputation: {match.reviewer.reputationScore}
                            </div>
                          </div>
                          <div className="text-right space-y-1">
                            <div className="text-lg font-bold">{match.matchScore}%</div>
                            <div className="text-sm text-muted-foreground">Match Score</div>
                          </div>
                        </div>

                        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                          <div>
                            <div className="font-medium">Expertise</div>
                            <Progress value={match.expertiseMatch} className="mt-1" />
                            <div className="text-xs text-muted-foreground">{match.expertiseMatch}%</div>
                          </div>
                          <div>
                            <div className="font-medium">Availability</div>
                            <Progress value={match.availabilityScore} className="mt-1" />
                            <div className="text-xs text-muted-foreground">{match.availabilityScore}%</div>
                          </div>
                          <div>
                            <div className="font-medium">Reputation</div>
                            <Progress value={match.reputationScore} className="mt-1" />
                            <div className="text-xs text-muted-foreground">{match.reputationScore}%</div>
                          </div>
                          <div>
                            <div className="font-medium">Workload</div>
                            <Progress value={match.workloadScore} className="mt-1" />
                            <div className="text-xs text-muted-foreground">{match.workloadScore}%</div>
                          </div>
                        </div>

                        <div className="space-y-2">
                          <div className="font-medium text-sm">Matching Reasons:</div>
                          <div className="flex flex-wrap gap-1">
                            {match.reasons.map((reason, index) => (
                              <Badge key={index} variant="secondary" className="text-xs">
                                {reason}
                              </Badge>
                            ))}
                          </div>
                        </div>

                        <div className="flex items-center space-x-2">
                          <input
                            type="checkbox"
                            id={`reviewer-${match.reviewer.id}`}
                            checked={selectedReviewers.includes(match.reviewer.id)}
                            onChange={(e) => {
                              if (e.target.checked) {
                                setSelectedReviewers(prev => [...prev, match.reviewer.id]);
                              } else {
                                setSelectedReviewers(prev => prev.filter(id => id !== match.reviewer.id));
                              }
                            }}
                            className="rounded"
                          />
                          <label htmlFor={`reviewer-${match.reviewer.id}`} className="text-sm font-medium">
                            Select for assignment
                          </label>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}