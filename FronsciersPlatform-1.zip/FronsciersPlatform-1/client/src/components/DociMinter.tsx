import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Separator } from '@/components/ui/separator';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Progress } from '@/components/ui/progress';
import { uploadToIPFS } from '@/lib/ipfs';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { useSolana } from '@/hooks/use-solana';
import { Upload, FileText, Coins, CheckCircle } from 'lucide-react';

const DociMinter: React.FC = () => {
  const { adapter, isLoading: walletLoading } = useSolana();
  const { toast } = useToast();
  const [isLoading, setIsLoading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [mintingStep, setMintingStep] = useState<'upload' | 'metadata' | 'mint' | 'complete'>('upload');
  const [formData, setFormData] = useState({
    title: '',
    authors: '',
    abstract: '',
    keywords: '',
    researchField: '',
    doiType: 'article',
    fileToUpload: null as File | null,
  });
  
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      setFormData({
        ...formData,
        fileToUpload: e.target.files[0],
      });
    }
  };
  
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });
  };
  
  const handleSelectChange = (field: string, value: string) => {
    setFormData({
      ...formData,
      [field]: value,
    });
  };
  
  const validateForm = () => {
    if (!formData.title.trim()) {
      toast({
        title: 'Missing Title',
        description: 'Please provide a title for your publication.',
        variant: 'destructive',
      });
      return false;
    }
    
    if (!formData.authors.trim()) {
      toast({
        title: 'Missing Authors',
        description: 'Please list the authors of this publication.',
        variant: 'destructive',
      });
      return false;
    }
    
    if (!formData.abstract.trim()) {
      toast({
        title: 'Missing Abstract',
        description: 'Please provide an abstract for your publication.',
        variant: 'destructive',
      });
      return false;
    }
    
    if (!formData.fileToUpload) {
      toast({
        title: 'File Required',
        description: 'Please upload your manuscript file.',
        variant: 'destructive',
      });
      return false;
    }
    
    return true;
  };
  
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!adapter?.publicKey || !adapter.connected) {
      toast({
        title: 'Wallet Required',
        description: 'Please connect your Solana wallet to mint a DOCI.',
        variant: 'destructive',
      });
      return;
    }
    
    if (!validateForm()) {
      return;
    }
    
    try {
      setIsLoading(true);
      setMintingStep('upload');
      setUploadProgress(10);
      
      // Step 1: Upload file to IPFS
      const ipfsHash = await uploadToIPFS(formData.fileToUpload!, {
        name: formData.title,
        description: formData.abstract,
        keyvalues: {
          authors: formData.authors,
          researchField: formData.researchField,
          doiType: formData.doiType,
        }
      });
      
      setUploadProgress(50);
      setMintingStep('metadata');
      
      // Step 2: Create manuscript record
      const manuscriptData = {
        title: formData.title,
        authors: formData.authors,
        abstract: formData.abstract,
        keywords: formData.keywords,
        researchField: formData.researchField,
        ipfsHash: ipfsHash,
        status: 'draft',
      };
      
      const manuscriptResponse = await apiRequest('POST', '/api/manuscripts', manuscriptData);
      if (!manuscriptResponse.ok) {
        throw new Error('Failed to create manuscript record');
      }
      
      const manuscript = await manuscriptResponse.json();
      setUploadProgress(75);
      setMintingStep('mint');
      
      // Step 3: Mint DOCI NFT (mock implementation)
      const dociMetadata = {
        title: formData.title,
        authors: formData.authors.split(',').map(a => a.trim()),
        abstract: formData.abstract,
        keywords: formData.keywords.split(',').map(k => k.trim()),
        researchField: formData.researchField,
        ipfsHash: ipfsHash,
        manuscriptId: manuscript.id,
      };
      
      // Simulate DOCI minting process
      await new Promise(resolve => setTimeout(resolve, 2000));
      const mockNftAddress = `DOCI${Date.now()}_${Math.random().toString(36).substring(7)}`;
      
      // Update manuscript with NFT address
      const updateResponse = await apiRequest('PATCH', `/api/manuscripts/${manuscript.id}`, {
        dociMinted: true,
        nftAddress: mockNftAddress,
        status: 'submitted',
      });
      
      if (!updateResponse.ok) {
        throw new Error('Failed to update manuscript with DOCI information');
      }
      
      setUploadProgress(100);
      setMintingStep('complete');
      
      toast({
        title: 'DOCI Minted Successfully',
        description: `Your Digital Object Citation Identifier has been created: ${mockNftAddress}`,
      });
      
      // Reset form
      setFormData({
        title: '',
        authors: '',
        abstract: '',
        keywords: '',
        researchField: '',
        doiType: 'article',
        fileToUpload: null,
      });
      
    } catch (error: any) {
      toast({
        title: 'Minting Failed',
        description: error.message || 'Failed to mint DOCI. Please try again.',
        variant: 'destructive',
      });
      setMintingStep('upload');
      setUploadProgress(0);
    } finally {
      setIsLoading(false);
    }
  };
  
  const getMintingStepIcon = (step: string) => {
    switch (step) {
      case 'upload': return <Upload className="w-5 h-5" />;
      case 'metadata': return <FileText className="w-5 h-5" />;
      case 'mint': return <Coins className="w-5 h-5" />;
      case 'complete': return <CheckCircle className="w-5 h-5" />;
      default: return <Upload className="w-5 h-5" />;
    }
  };
  
  const getMintingStepDescription = (step: string) => {
    switch (step) {
      case 'upload': return 'Uploading manuscript to IPFS...';
      case 'metadata': return 'Creating manuscript metadata...';
      case 'mint': return 'Minting DOCI NFT on Solana...';
      case 'complete': return 'DOCI successfully minted!';
      default: return 'Preparing to mint DOCI...';
    }
  };
  
  if (isLoading) {
    return (
      <Card className="w-full max-w-2xl mx-auto">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            {getMintingStepIcon(mintingStep)}
            Minting DOCI
          </CardTitle>
          <CardDescription>
            {getMintingStepDescription(mintingStep)}
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <Progress value={uploadProgress} className="w-full" />
            <p className="text-sm text-muted-foreground text-center">
              {uploadProgress}% Complete
            </p>
          </div>
        </CardContent>
      </Card>
    );
  }
  
  return (
    <Card className="w-full max-w-4xl mx-auto">
      <CardHeader>
        <CardTitle>Mint Digital Object Citation Identifier (DOCI)</CardTitle>
        <CardDescription>
          Create a blockchain-based citation identifier for your research publication.
          DOCIs provide permanent, verifiable links to your work on the Solana blockchain.
        </CardDescription>
      </CardHeader>
      
      <form onSubmit={handleSubmit}>
        <CardContent className="space-y-6">
          <Tabs defaultValue="manuscript" className="w-full">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="manuscript">Manuscript Details</TabsTrigger>
              <TabsTrigger value="metadata">Metadata</TabsTrigger>
              <TabsTrigger value="upload">File Upload</TabsTrigger>
            </TabsList>
            
            <TabsContent value="manuscript" className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="title">Title *</Label>
                  <Input
                    id="title"
                    name="title"
                    value={formData.title}
                    onChange={handleInputChange}
                    placeholder="Enter manuscript title"
                    required
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="authors">Authors *</Label>
                  <Input
                    id="authors"
                    name="authors"
                    value={formData.authors}
                    onChange={handleInputChange}
                    placeholder="John Doe, Jane Smith, ..."
                    required
                  />
                </div>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="abstract">Abstract *</Label>
                <Textarea
                  id="abstract"
                  name="abstract"
                  value={formData.abstract}
                  onChange={handleInputChange}
                  placeholder="Enter your manuscript abstract"
                  rows={6}
                  required
                />
              </div>
            </TabsContent>
            
            <TabsContent value="metadata" className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="researchField">Research Field</Label>
                  <Select onValueChange={(value) => handleSelectChange('researchField', value)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select research field" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="computer-science">Computer Science</SelectItem>
                      <SelectItem value="biology">Biology</SelectItem>
                      <SelectItem value="chemistry">Chemistry</SelectItem>
                      <SelectItem value="physics">Physics</SelectItem>
                      <SelectItem value="mathematics">Mathematics</SelectItem>
                      <SelectItem value="medicine">Medicine</SelectItem>
                      <SelectItem value="engineering">Engineering</SelectItem>
                      <SelectItem value="social-sciences">Social Sciences</SelectItem>
                      <SelectItem value="humanities">Humanities</SelectItem>
                      <SelectItem value="other">Other</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="doiType">Publication Type</Label>
                  <Select onValueChange={(value) => handleSelectChange('doiType', value)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select publication type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="article">Research Article</SelectItem>
                      <SelectItem value="preprint">Preprint</SelectItem>
                      <SelectItem value="review">Review Paper</SelectItem>
                      <SelectItem value="conference">Conference Paper</SelectItem>
                      <SelectItem value="thesis">Thesis/Dissertation</SelectItem>
                      <SelectItem value="dataset">Dataset</SelectItem>
                      <SelectItem value="software">Software</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="keywords">Keywords</Label>
                <Input
                  id="keywords"
                  name="keywords"
                  value={formData.keywords}
                  onChange={handleInputChange}
                  placeholder="machine learning, neural networks, AI, ..."
                />
                <p className="text-xs text-muted-foreground">
                  Separate keywords with commas to improve discoverability
                </p>
              </div>
            </TabsContent>
            
            <TabsContent value="upload" className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="file">Manuscript File *</Label>
                <Input
                  id="file"
                  type="file"
                  onChange={handleFileChange}
                  accept=".pdf,.doc,.docx,.tex,.md"
                  required
                />
                <p className="text-xs text-muted-foreground">
                  Supported formats: PDF, DOC, DOCX, TEX, MD (max 50MB)
                </p>
              </div>
              
              {formData.fileToUpload && (
                <div className="p-4 bg-muted rounded-lg">
                  <div className="flex items-center gap-2">
                    <FileText className="w-4 h-4" />
                    <span className="text-sm font-medium">{formData.fileToUpload.name}</span>
                  </div>
                  <p className="text-xs text-muted-foreground mt-1">
                    Size: {(formData.fileToUpload.size / 1024 / 1024).toFixed(2)} MB
                  </p>
                </div>
              )}
            </TabsContent>
          </Tabs>
          
          <Separator />
          
          <div className="bg-blue-50 dark:bg-blue-900/20 p-4 rounded-lg">
            <h4 className="font-medium text-blue-900 dark:text-blue-100 mb-2">What is a DOCI?</h4>
            <p className="text-sm text-blue-700 dark:text-blue-300">
              A Digital Object Citation Identifier (DOCI) is a blockchain-based NFT that provides 
              permanent, verifiable citation for your research. It includes immutable metadata 
              stored on IPFS and creates a unique identifier on the Solana blockchain that can 
              never be lost or changed.
            </p>
          </div>
        </CardContent>
        
        <CardFooter className="flex justify-between">
          <p className="text-sm text-muted-foreground">
            Minting fee: 0.1 SOL + network fees
          </p>
          <Button
            type="submit"
            disabled={isLoading || walletLoading || !adapter?.connected}
            className="min-w-[120px]"
          >
            {!adapter?.connected ? 'Connect Wallet' : 'Mint DOCI'}
          </Button>
        </CardFooter>
      </form>
    </Card>
  );
};

export default DociMinter;