import { useState } from "react";
import { useForm } from "react-hook-form";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { FileText, CheckCircle, Clock } from "lucide-react";

interface ReviewInterfaceProps {
  review: any;
}

export function ReviewInterface({ review }: ReviewInterfaceProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const form = useForm({
    defaultValues: {
      noveltyScore: "",
      methodologyScore: "",
      clarityScore: "",
      comments: "",
      recommendation: "",
    },
  });

  const submitMutation = useMutation({
    mutationFn: async (data: any) => {
      return apiRequest("PATCH", `/api/reviews/${review.id}/submit`, {
        ...data,
        reward: "75.00", // Standard review reward
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/reviews/pending"] });
      toast({
        title: "Review Submitted",
        description: "Your review has been submitted successfully. You earned 75 FRONS tokens!",
      });
    },
    onError: () => {
      toast({
        title: "Submission Failed",
        description: "Failed to submit review. Please try again.",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: any) => {
    submitMutation.mutate(data);
  };

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle>Active Review</CardTitle>
        <div className="flex items-center space-x-2">
          <Badge variant="outline" className="bg-yellow-50 text-yellow-700 border-yellow-300">
            <Clock className="w-3 h-3 mr-1" />
            5 days left
          </Badge>
          <Badge variant="outline" className="bg-green-50 text-green-700 border-green-300">
            +75 FRONS
          </Badge>
        </div>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Manuscript Info */}
        <div>
          <h4 className="font-semibold text-slate-900 mb-2">Blockchain Scalability Solutions in DeFi</h4>
          <p className="text-sm text-slate-600 mb-4">Authors: Dr. Sarah Chen, Prof. Michael Rodriguez</p>
          
          {/* PDF Viewer Placeholder */}
          <Card className="bg-white border-2 border-slate-200">
            <CardContent className="p-8 text-center">
              <div className="w-16 h-16 bg-slate-100 rounded-lg flex items-center justify-center mx-auto mb-4">
                <FileText className="text-slate-400 text-2xl" />
              </div>
              <p className="text-slate-600 mb-2">manuscript_blockchain_scalability.pdf</p>
              <p className="text-sm text-slate-500">45 pages • 2.3 MB</p>
              <Button className="mt-4 bg-primary-500 hover:bg-primary-600">
                Open in Viewer
              </Button>
            </CardContent>
          </Card>
        </div>

        {/* Review Form */}
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            {/* Scoring */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <FormField
                control={form.control}
                name="noveltyScore"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Novelty</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Score" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="5">Excellent (5)</SelectItem>
                        <SelectItem value="4">Good (4)</SelectItem>
                        <SelectItem value="3">Fair (3)</SelectItem>
                        <SelectItem value="2">Poor (2)</SelectItem>
                        <SelectItem value="1">Very Poor (1)</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="methodologyScore"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Methodology</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Score" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="5">Excellent (5)</SelectItem>
                        <SelectItem value="4">Good (4)</SelectItem>
                        <SelectItem value="3">Fair (3)</SelectItem>
                        <SelectItem value="2">Poor (2)</SelectItem>
                        <SelectItem value="1">Very Poor (1)</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="clarityScore"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Clarity</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Score" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="5">Excellent (5)</SelectItem>
                        <SelectItem value="4">Good (4)</SelectItem>
                        <SelectItem value="3">Fair (3)</SelectItem>
                        <SelectItem value="2">Poor (2)</SelectItem>
                        <SelectItem value="1">Very Poor (1)</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            {/* Detailed Comments */}
            <FormField
              control={form.control}
              name="comments"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Detailed Comments</FormLabel>
                  <FormControl>
                    <Textarea 
                      rows={6} 
                      placeholder="Provide detailed feedback on the manuscript..." 
                      {...field} 
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* Recommendation */}
            <FormField
              control={form.control}
              name="recommendation"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Recommendation</FormLabel>
                  <FormControl>
                    <RadioGroup
                      onValueChange={field.onChange}
                      defaultValue={field.value}
                      className="grid grid-cols-1 md:grid-cols-3 gap-3"
                    >
                      <div className="flex items-center space-x-2 p-3 border border-slate-300 rounded-lg cursor-pointer hover:bg-slate-50">
                        <RadioGroupItem value="accept" id="accept" />
                        <Label htmlFor="accept" className="cursor-pointer">Accept</Label>
                      </div>
                      <div className="flex items-center space-x-2 p-3 border border-slate-300 rounded-lg cursor-pointer hover:bg-slate-50">
                        <RadioGroupItem value="minor" id="minor" />
                        <Label htmlFor="minor" className="cursor-pointer">Minor Revisions</Label>
                      </div>
                      <div className="flex items-center space-x-2 p-3 border border-slate-300 rounded-lg cursor-pointer hover:bg-slate-50">
                        <RadioGroupItem value="reject" id="reject" />
                        <Label htmlFor="reject" className="cursor-pointer">Reject</Label>
                      </div>
                    </RadioGroup>
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <Button 
              type="submit" 
              className="w-full bg-green-600 hover:bg-green-700"
              disabled={submitMutation.isPending}
            >
              <CheckCircle className="w-4 h-4 mr-2" />
              {submitMutation.isPending ? "Submitting..." : "Submit Review & Earn 75 FRONS"}
            </Button>
          </form>
        </Form>
      </CardContent>
    </Card>
  );
}
