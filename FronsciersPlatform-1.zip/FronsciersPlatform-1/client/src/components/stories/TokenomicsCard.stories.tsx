import type { Meta, StoryObj } from '@storybook/react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Coins, TrendingUp, Users, Zap } from 'lucide-react';

// TokenomicsCard component for displaying FRONS token information
const TokenomicsCard = ({ 
  title, 
  value, 
  description, 
  icon: Icon, 
  trend,
  action,
  variant = 'default' 
}: {
  title: string;
  value: string | number;
  description: string;
  icon: React.ElementType;
  trend?: { direction: 'up' | 'down'; percentage: number };
  action?: { label: string; onClick: () => void };
  variant?: 'default' | 'primary' | 'success' | 'warning';
}) => {
  const variantStyles = {
    default: 'border-gray-200',
    primary: 'border-blue-200 bg-blue-50',
    success: 'border-green-200 bg-green-50',
    warning: 'border-orange-200 bg-orange-50'
  };

  return (
    <Card className={`transition-all hover:shadow-lg ${variantStyles[variant]}`}>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-sm font-medium text-muted-foreground">
          {title}
        </CardTitle>
        <Icon className="h-4 w-4 text-muted-foreground" />
      </CardHeader>
      <CardContent>
        <div className="flex items-center justify-between">
          <div>
            <div className="text-2xl font-bold">{value}</div>
            {trend && (
              <div className={`flex items-center text-xs ${trend.direction === 'up' ? 'text-green-600' : 'text-red-600'}`}>
                <TrendingUp className={`h-3 w-3 mr-1 ${trend.direction === 'down' ? 'rotate-180' : ''}`} />
                {trend.percentage}% this month
              </div>
            )}
          </div>
        </div>
        <CardDescription className="mt-2">
          {description}
        </CardDescription>
        {action && (
          <Button 
            size="sm" 
            className="mt-3 w-full"
            onClick={action.onClick}
            variant={variant === 'primary' ? 'default' : 'outline'}
          >
            {action.label}
          </Button>
        )}
      </CardContent>
    </Card>
  );
};

const meta: Meta<typeof TokenomicsCard> = {
  title: 'FRONSCIERS/TokenomicsCard',
  component: TokenomicsCard,
  parameters: {
    layout: 'centered',
    docs: {
      description: {
        component: 'A card component for displaying FRONS token-related information and metrics.'
      }
    }
  },
  tags: ['autodocs'],
  argTypes: {
    variant: {
      control: 'select',
      options: ['default', 'primary', 'success', 'warning'],
      description: 'Visual variant of the card'
    },
    icon: {
      control: false,
      description: 'Lucide React icon component'
    },
    trend: {
      control: 'object',
      description: 'Trend information with direction and percentage'
    },
    action: {
      control: 'object',
      description: 'Action button configuration'
    }
  }
};

export default meta;
type Story = StoryObj<typeof meta>;

export const Default: Story = {
  args: {
    title: 'FRONS Balance',
    value: '1,250',
    description: 'Your current FRONS token balance',
    icon: Coins,
    variant: 'default'
  }
};

export const WithTrend: Story = {
  args: {
    title: 'Total Rewards Earned',
    value: '3,847',
    description: 'FRONS tokens earned from peer reviews and publications',
    icon: TrendingUp,
    trend: { direction: 'up', percentage: 12.5 },
    variant: 'success'
  }
};

export const WithAction: Story = {
  args: {
    title: 'Staking Pool',
    value: '25,000',
    description: 'FRONS tokens currently staked in governance',
    icon: Zap,
    action: { label: 'Stake More', onClick: () => alert('Stake More clicked') },
    variant: 'primary'
  }
};

export const CommunityMetrics: Story = {
  args: {
    title: 'Active Reviewers',
    value: '2,341',
    description: 'Researchers actively participating in peer review',
    icon: Users,
    trend: { direction: 'up', percentage: 8.2 },
    variant: 'default'
  }
};

export const WarningState: Story = {
  args: {
    title: 'Low Balance Warning',
    value: '45',
    description: 'Insufficient FRONS for submission fees',
    icon: Coins,
    trend: { direction: 'down', percentage: 23.1 },
    action: { label: 'Earn More', onClick: () => alert('Earn More clicked') },
    variant: 'warning'
  }
};