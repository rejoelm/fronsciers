import type { Meta, StoryObj } from '@storybook/react';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { CheckCircle, Clock, AlertCircle, FileText, Users, Vote } from 'lucide-react';

// ResearchJourneyProgressBar component for tracking manuscript progress
const ResearchJourneyProgressBar = ({ 
  currentStage, 
  stages, 
  manuscriptTitle,
  submissionDate,
  estimatedCompletion 
}: {
  currentStage: number;
  stages: Array<{
    id: number;
    name: string;
    description: string;
    icon: React.ElementType;
    status: 'completed' | 'current' | 'pending' | 'failed';
    duration?: string;
  }>;
  manuscriptTitle: string;
  submissionDate: string;
  estimatedCompletion?: string;
}) => {
  const progress = ((currentStage - 1) / (stages.length - 1)) * 100;

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed': return 'text-green-600 bg-green-100';
      case 'current': return 'text-blue-600 bg-blue-100';
      case 'failed': return 'text-red-600 bg-red-100';
      default: return 'text-gray-400 bg-gray-100';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'completed': return CheckCircle;
      case 'current': return Clock;
      case 'failed': return AlertCircle;
      default: return Clock;
    }
  };

  return (
    <Card className="w-full max-w-4xl">
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="text-lg font-semibold">{manuscriptTitle}</CardTitle>
            <p className="text-sm text-muted-foreground mt-1">
              Submitted: {submissionDate}
              {estimatedCompletion && ` • Est. completion: ${estimatedCompletion}`}
            </p>
          </div>
          <Badge variant="outline" className="text-sm">
            Stage {currentStage} of {stages.length}
          </Badge>
        </div>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Progress Bar */}
        <div className="space-y-2">
          <div className="flex justify-between text-sm text-muted-foreground">
            <span>Progress</span>
            <span>{Math.round(progress)}% Complete</span>
          </div>
          <Progress value={progress} className="h-2" />
        </div>

        {/* Stage Timeline */}
        <div className="relative">
          {stages.map((stage, index) => {
            const Icon = stage.icon;
            const StatusIcon = getStatusIcon(stage.status);
            const isLast = index === stages.length - 1;

            return (
              <div key={stage.id} className="flex items-start space-x-4 pb-8 relative">
                {/* Timeline Line */}
                {!isLast && (
                  <div className="absolute left-6 top-12 w-0.5 h-16 bg-gray-200" />
                )}
                
                {/* Stage Icon */}
                <div className={`relative z-10 flex items-center justify-center w-12 h-12 rounded-full border-2 ${
                  stage.status === 'completed' ? 'border-green-500 bg-green-50' :
                  stage.status === 'current' ? 'border-blue-500 bg-blue-50' :
                  stage.status === 'failed' ? 'border-red-500 bg-red-50' :
                  'border-gray-300 bg-gray-50'
                }`}>
                  <Icon className={`h-5 w-5 ${
                    stage.status === 'completed' ? 'text-green-600' :
                    stage.status === 'current' ? 'text-blue-600' :
                    stage.status === 'failed' ? 'text-red-600' :
                    'text-gray-400'
                  }`} />
                </div>

                {/* Stage Content */}
                <div className="flex-1 min-w-0">
                  <div className="flex items-center space-x-2">
                    <h3 className={`text-sm font-medium ${
                      stage.status === 'completed' ? 'text-green-900' :
                      stage.status === 'current' ? 'text-blue-900' :
                      stage.status === 'failed' ? 'text-red-900' :
                      'text-gray-500'
                    }`}>
                      {stage.name}
                    </h3>
                    <StatusIcon className={`h-4 w-4 ${
                      stage.status === 'completed' ? 'text-green-600' :
                      stage.status === 'current' ? 'text-blue-600' :
                      stage.status === 'failed' ? 'text-red-600' :
                      'text-gray-400'
                    }`} />
                    {stage.duration && (
                      <Badge variant="secondary" className="text-xs">
                        {stage.duration}
                      </Badge>
                    )}
                  </div>
                  <p className="text-sm text-muted-foreground mt-1">
                    {stage.description}
                  </p>
                </div>
              </div>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
};

const meta: Meta<typeof ResearchJourneyProgressBar> = {
  title: 'FRONSCIERS/ResearchJourneyProgressBar',
  component: ResearchJourneyProgressBar,
  parameters: {
    layout: 'centered',
    docs: {
      description: {
        component: 'A progress tracking component that shows the journey of a research manuscript through the FRONSCIERS platform stages.'
      }
    }
  },
  tags: ['autodocs'],
  argTypes: {
    currentStage: {
      control: { type: 'number', min: 1, max: 6 },
      description: 'Current stage number in the research journey'
    },
    manuscriptTitle: {
      control: 'text',
      description: 'Title of the research manuscript'
    },
    submissionDate: {
      control: 'text',
      description: 'Date when the manuscript was submitted'
    },
    estimatedCompletion: {
      control: 'text',
      description: 'Optional estimated completion date'
    }
  }
};

export default meta;
type Story = StoryObj<typeof meta>;

const defaultStages = [
  {
    id: 1,
    name: 'Submission',
    description: 'Manuscript uploaded and DOCI NFT minted on Solana blockchain',
    icon: FileText,
    status: 'completed' as const,
    duration: '1 day'
  },
  {
    id: 2,
    name: 'Automated Review',
    description: 'AI-powered preliminary checks for plagiarism and formatting',
    icon: CheckCircle,
    status: 'completed' as const,
    duration: '2 days'
  },
  {
    id: 3,
    name: 'Peer Review',
    description: 'Expert reviewers evaluate methodology, novelty, and clarity',
    icon: Users,
    status: 'current' as const,
    duration: '14-21 days'
  },
  {
    id: 4,
    name: 'Community Review',
    description: 'Community members vote on acceptance and provide feedback',
    icon: Vote,
    status: 'pending' as const,
    duration: '7 days'
  },
  {
    id: 5,
    name: 'Editorial Decision',
    description: 'Final decision based on all review phases',
    icon: CheckCircle,
    status: 'pending' as const,
    duration: '3 days'
  },
  {
    id: 6,
    name: 'Publication',
    description: 'Manuscript published and indexed on IPFS network',
    icon: FileText,
    status: 'pending' as const,
    duration: '1 day'
  }
];

export const InProgress: Story = {
  args: {
    currentStage: 3,
    stages: defaultStages,
    manuscriptTitle: 'Novel Approaches to Quantum Error Correction in Distributed Systems',
    submissionDate: 'Dec 15, 2024',
    estimatedCompletion: 'Jan 20, 2025'
  }
};

export const JustSubmitted: Story = {
  args: {
    currentStage: 1,
    stages: defaultStages.map(stage => ({
      ...stage,
      status: stage.id === 1 ? 'current' as const : 'pending' as const
    })),
    manuscriptTitle: 'Machine Learning Applications in Climate Change Prediction',
    submissionDate: 'Dec 20, 2024',
    estimatedCompletion: 'Feb 1, 2025'
  }
};

export const NearCompletion: Story = {
  args: {
    currentStage: 5,
    stages: defaultStages.map(stage => ({
      ...stage,
      status: stage.id < 5 ? 'completed' as const : 
             stage.id === 5 ? 'current' as const : 'pending' as const
    })),
    manuscriptTitle: 'Blockchain-Based Academic Publishing: A Comprehensive Analysis',
    submissionDate: 'Nov 28, 2024',
    estimatedCompletion: 'Dec 25, 2024'
  }
};

export const WithRejection: Story = {
  args: {
    currentStage: 3,
    stages: defaultStages.map(stage => ({
      ...stage,
      status: stage.id === 1 ? 'completed' as const :
             stage.id === 2 ? 'completed' as const :
             stage.id === 3 ? 'failed' as const : 'pending' as const,
      description: stage.id === 3 ? 'Review identified significant methodological concerns requiring revision' : stage.description
    })),
    manuscriptTitle: 'Experimental Study on Neural Network Optimization',
    submissionDate: 'Dec 1, 2024'
  }
};

export const Published: Story = {
  args: {
    currentStage: 6,
    stages: defaultStages.map(stage => ({
      ...stage,
      status: 'completed' as const
    })),
    manuscriptTitle: 'Advances in Decentralized Academic Peer Review Systems',
    submissionDate: 'Oct 15, 2024',
    estimatedCompletion: 'Nov 30, 2024'
  }
};