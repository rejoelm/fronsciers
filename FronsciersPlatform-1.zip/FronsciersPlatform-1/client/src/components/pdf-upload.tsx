import { useState, useCallback } from "react";
import { useDropzone } from "react-dropzone";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useWallet } from "@/hooks/use-wallet";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Upload, FileText, X, CheckCircle, AlertTriangle, Wallet } from "lucide-react";

interface UploadedFile {
  file: File;
  preview?: string;
  status: 'pending' | 'uploading' | 'processing' | 'completed' | 'error';
  progress: number;
  extractedData?: {
    title?: string;
    abstract?: string;
    authors?: string;
    keywords?: string;
  };
}

interface PDFUploadProps {
  onUploadComplete?: (manuscriptId: number) => void;
  className?: string;
}

export function PDFUpload({ onUploadComplete, className }: PDFUploadProps) {
  const [uploadedFiles, setUploadedFiles] = useState<UploadedFile[]>([]);
  const [isProcessing, setIsProcessing] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { isConnected, connect } = useWallet();

  const uploadMutation = useMutation({
    mutationFn: async (formData: FormData) => {
      const response = await fetch('/api/manuscripts/upload-pdf', {
        method: 'POST',
        credentials: 'include',
        body: formData,
      });
      
      if (!response.ok) {
        throw new Error('Upload failed');
      }
      
      return response.json();
    },
    onSuccess: (data) => {
      toast({
        title: "Upload Successful",
        description: "Your manuscript has been uploaded and processed successfully.",
      });
      
      // Invalidate dashboard queries to trigger real-time updates
      queryClient.invalidateQueries({ queryKey: ['/api/dashboard/stats'] });
      queryClient.invalidateQueries({ queryKey: ['/api/manuscripts'] });
      queryClient.invalidateQueries({ queryKey: ['/api/manuscripts/user'] });
      
      if (onUploadComplete && data.manuscriptId) {
        onUploadComplete(data.manuscriptId);
      }
    },
    onError: (error) => {
      toast({
        title: "Upload Failed",
        description: error.message || "Failed to upload manuscript",
        variant: "destructive",
      });
    },
  });

  const onDrop = useCallback((acceptedFiles: File[]) => {
    const newFiles = acceptedFiles.map(file => ({
      file,
      status: 'pending' as const,
      progress: 0,
      preview: URL.createObjectURL(file),
    }));
    
    setUploadedFiles(prev => [...prev, ...newFiles]);
    
    // Auto-process PDF files
    newFiles.forEach(fileObj => {
      if (fileObj.file.type === 'application/pdf') {
        processPDF(fileObj);
      }
    });
  }, []);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      'application/pdf': ['.pdf']
    },
    maxFiles: 5,
    maxSize: 50 * 1024 * 1024, // 50MB
  });

  const processPDF = async (fileObj: UploadedFile) => {
    setIsProcessing(true);
    
    // Update file status to processing
    setUploadedFiles(prev => prev.map(f => 
      f.file === fileObj.file 
        ? { ...f, status: 'processing', progress: 25 }
        : f
    ));

    try {
      // Simulate PDF text extraction and metadata processing
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      // Mock extracted data - in production this would use PDF parsing
      const extractedData = {
        title: fileObj.file.name.replace('.pdf', '').replace(/[-_]/g, ' '),
        abstract: "Extracted abstract from PDF content...",
        authors: "Extracted author names from PDF metadata...",
        keywords: "machine learning, artificial intelligence, research"
      };

      setUploadedFiles(prev => prev.map(f => 
        f.file === fileObj.file 
          ? { 
              ...f, 
              status: 'completed',
              progress: 100,
              extractedData 
            }
          : f
      ));

    } catch (error) {
      setUploadedFiles(prev => prev.map(f => 
        f.file === fileObj.file 
          ? { ...f, status: 'error', progress: 0 }
          : f
      ));
    } finally {
      setIsProcessing(false);
    }
  };

  const handleSubmitManuscript = async (fileObj: UploadedFile) => {
    if (!fileObj.extractedData) return;

    // Check wallet connection before submitting
    if (!isConnected) {
      toast({
        title: "Wallet Connection Required",
        description: "Please connect your wallet to submit manuscripts.",
        variant: "destructive",
      });
      await connect();
      return;
    }

    const formData = new FormData();
    formData.append('pdf', fileObj.file);
    formData.append('title', fileObj.extractedData.title || '');
    formData.append('abstract', fileObj.extractedData.abstract || '');
    formData.append('authors', fileObj.extractedData.authors || '');
    formData.append('keywords', fileObj.extractedData.keywords || '');
    formData.append('researchField', 'Computer Science'); // Default field

    setUploadedFiles(prev => prev.map(f => 
      f.file === fileObj.file 
        ? { ...f, status: 'uploading', progress: 50 }
        : f
    ));

    uploadMutation.mutate(formData);
  };

  const removeFile = (fileToRemove: File) => {
    setUploadedFiles(prev => {
      const filtered = prev.filter(f => f.file !== fileToRemove);
      // Clean up preview URLs
      prev.forEach(f => {
        if (f.file === fileToRemove && f.preview) {
          URL.revokeObjectURL(f.preview);
        }
      });
      return filtered;
    });
  };

  const updateExtractedData = (file: File, field: string, value: string) => {
    setUploadedFiles(prev => prev.map(f => 
      f.file === file 
        ? { 
            ...f, 
            extractedData: { 
              ...f.extractedData, 
              [field]: value 
            }
          }
        : f
    ));
  };

  return (
    <div className={className}>
      {/* Drop Zone */}
      <Card className="mb-6">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Upload className="h-5 w-5" />
            <span>Upload PDF Manuscript</span>
          </CardTitle>
          <CardDescription>
            Drag and drop your PDF files or click to browse. Files will be automatically processed.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div
            {...getRootProps()}
            className={`border-2 border-dashed rounded-lg p-8 text-center cursor-pointer transition-colors ${
              isDragActive 
                ? 'border-primary bg-primary/5' 
                : 'border-gray-300 hover:border-primary'
            }`}
          >
            <input {...getInputProps()} />
            <Upload className="h-12 w-12 mx-auto mb-4 text-gray-400" />
            {isDragActive ? (
              <p className="text-lg">Drop the PDF files here...</p>
            ) : (
              <div>
                <p className="text-lg mb-2">Drag & drop PDF files here</p>
                <p className="text-sm text-gray-500 mb-4">or click to select files</p>
                <Button variant="outline">
                  Choose Files
                </Button>
              </div>
            )}
            <p className="text-xs text-gray-400 mt-4">
              Supports PDF files up to 50MB each
            </p>
          </div>
        </CardContent>
      </Card>

      {/* Uploaded Files */}
      {uploadedFiles.length > 0 && (
        <div className="space-y-4">
          {uploadedFiles.map((fileObj, index) => (
            <Card key={index} className="overflow-hidden">
              <CardHeader className="pb-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <FileText className="h-8 w-8 text-red-500" />
                    <div>
                      <h3 className="font-medium">{fileObj.file.name}</h3>
                      <p className="text-sm text-gray-500">
                        {(fileObj.file.size / 1024 / 1024).toFixed(2)} MB
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Badge 
                      variant={
                        fileObj.status === 'completed' ? 'default' : 
                        fileObj.status === 'error' ? 'destructive' : 
                        'secondary'
                      }
                    >
                      {fileObj.status === 'processing' ? 'Processing...' :
                       fileObj.status === 'uploading' ? 'Uploading...' :
                       fileObj.status === 'completed' ? 'Ready' :
                       fileObj.status === 'error' ? 'Error' : 'Pending'}
                    </Badge>
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => removeFile(fileObj.file)}
                    >
                      <X className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
                
                {fileObj.progress > 0 && fileObj.status !== 'completed' && (
                  <Progress value={fileObj.progress} className="mt-2" />
                )}
              </CardHeader>

              {fileObj.extractedData && (
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor={`title-${index}`}>Title</Label>
                      <Input
                        id={`title-${index}`}
                        value={fileObj.extractedData.title || ''}
                        onChange={(e) => updateExtractedData(fileObj.file, 'title', e.target.value)}
                        placeholder="Manuscript title"
                      />
                    </div>
                    <div>
                      <Label htmlFor={`authors-${index}`}>Authors</Label>
                      <Input
                        id={`authors-${index}`}
                        value={fileObj.extractedData.authors || ''}
                        onChange={(e) => updateExtractedData(fileObj.file, 'authors', e.target.value)}
                        placeholder="Author names"
                      />
                    </div>
                  </div>
                  
                  <div>
                    <Label htmlFor={`abstract-${index}`}>Abstract</Label>
                    <Textarea
                      id={`abstract-${index}`}
                      value={fileObj.extractedData.abstract || ''}
                      onChange={(e) => updateExtractedData(fileObj.file, 'abstract', e.target.value)}
                      placeholder="Research abstract"
                      rows={4}
                    />
                  </div>
                  
                  <div>
                    <Label htmlFor={`keywords-${index}`}>Keywords</Label>
                    <Input
                      id={`keywords-${index}`}
                      value={fileObj.extractedData.keywords || ''}
                      onChange={(e) => updateExtractedData(fileObj.file, 'keywords', e.target.value)}
                      placeholder="Comma-separated keywords"
                    />
                  </div>

                  <div className="flex items-center justify-between pt-4 border-t">
                    <div className="flex items-center space-x-2 text-sm text-gray-500">
                      {fileObj.status === 'completed' ? (
                        <>
                          <CheckCircle className="h-4 w-4 text-green-500" />
                          <span>Ready to submit</span>
                        </>
                      ) : fileObj.status === 'error' ? (
                        <>
                          <AlertTriangle className="h-4 w-4 text-red-500" />
                          <span>Processing failed</span>
                        </>
                      ) : (
                        <span>Processing PDF content...</span>
                      )}
                    </div>
                    
                    {fileObj.status === 'completed' && (
                      <Button
                        onClick={() => handleSubmitManuscript(fileObj)}
                        disabled={uploadMutation.isPending}
                        className="bg-primary hover:bg-primary/90"
                      >
                        Submit Manuscript
                      </Button>
                    )}
                  </div>
                </CardContent>
              )}
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}