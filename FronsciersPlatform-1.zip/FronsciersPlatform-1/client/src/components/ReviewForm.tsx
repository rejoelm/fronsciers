import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, FileText, Star, Send } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

interface ReviewAssignment {
  id: number;
  manuscriptId: number;
  dociId: string;
  status: string;
  assignedAt: string;
  deadline: string;
  manuscript?: {
    title: string;
    authors: string[];
    abstract: string;
  };
}

interface ReviewFormProps {
  assignment: ReviewAssignment;
  onBack: () => void;
}

interface ReviewScores {
  novelty: number;
  methodology: number;
  clarity: number;
  significance: number;
  presentation: number;
  overall: number;
}

export function ReviewForm({ assignment, onBack }: ReviewFormProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const [scores, setScores] = useState<ReviewScores>({
    novelty: 50,
    methodology: 50,
    clarity: 50,
    significance: 50,
    presentation: 50,
    overall: 50
  });

  const [comments, setComments] = useState("");
  const [recommendation, setRecommendation] = useState("");

  const submitReviewMutation = useMutation({
    mutationFn: async (reviewData: any) => {
      return apiRequest("/api/reviews/submit", {
        method: "POST",
        body: reviewData
      });
    },
    onSuccess: (data) => {
      toast({
        title: "Review Submitted Successfully",
        description: `Review submitted. You earned ${data.fronsReward} FRONS tokens!`,
      });
      queryClient.invalidateQueries({ queryKey: ["/api/peer-review/my-assignments"] });
      queryClient.invalidateQueries({ queryKey: ["/api/peer-review/my-reviews"] });
      onBack();
    },
    onError: (error: any) => {
      toast({
        title: "Submission Failed",
        description: error.message || "Failed to submit review",
        variant: "destructive",
      });
    }
  });

  const handleScoreChange = (field: keyof ReviewScores, value: number[]) => {
    setScores(prev => ({ ...prev, [field]: value[0] }));
  };

  const handleSubmit = () => {
    if (!comments.trim()) {
      toast({
        title: "Missing Comments",
        description: "Please provide detailed review comments",
        variant: "destructive",
      });
      return;
    }

    if (!recommendation) {
      toast({
        title: "Missing Recommendation",
        description: "Please select a recommendation",
        variant: "destructive",
      });
      return;
    }

    submitReviewMutation.mutate({
      dociId: assignment.dociId,
      manuscriptId: assignment.manuscriptId,
      scores,
      comments,
      recommendation,
      phase: "expert"
    });
  };

  const getScoreColor = (score: number) => {
    if (score >= 80) return "text-green-600";
    if (score >= 60) return "text-yellow-600";
    return "text-red-600";
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-4">
        <Button
          variant="outline"
          onClick={onBack}
          className="flex items-center gap-2"
        >
          <ArrowLeft className="h-4 w-4" />
          Back to Dashboard
        </Button>
        <div>
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white">Expert Review</h1>
          <p className="text-gray-600 dark:text-gray-400">
            Manuscript peer review submission
          </p>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <FileText className="h-5 w-5" />
            Manuscript Information
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label className="text-sm font-medium">Title</Label>
            <p className="text-lg font-semibold mt-1">
              {assignment.manuscript?.title || `DOCI: ${assignment.dociId}`}
            </p>
          </div>
          
          <div>
            <Label className="text-sm font-medium">Authors</Label>
            <p className="mt-1">
              {assignment.manuscript?.authors?.join(", ") || "Not specified"}
            </p>
          </div>

          <div>
            <Label className="text-sm font-medium">Abstract</Label>
            <p className="mt-1 text-sm text-gray-700 dark:text-gray-300">
              {assignment.manuscript?.abstract || "Abstract not available"}
            </p>
          </div>

          <div className="flex items-center gap-4 text-sm">
            <Badge variant="outline">DOCI: {assignment.dociId}</Badge>
            <span>Due: {new Date(assignment.deadline).toLocaleDateString()}</span>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Star className="h-5 w-5" />
            Review Scores
          </CardTitle>
          <CardDescription>
            Rate each aspect of the manuscript (0-100 scale)
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {Object.entries(scores).map(([field, value]) => (
            <div key={field} className="space-y-2">
              <div className="flex items-center justify-between">
                <Label className="text-sm font-medium capitalize">
                  {field === "overall" ? "Overall Quality" : field}
                </Label>
                <span className={`font-bold ${getScoreColor(value)}`}>
                  {value}/100
                </span>
              </div>
              <Slider
                value={[value]}
                onValueChange={(val) => handleScoreChange(field as keyof ReviewScores, val)}
                max={100}
                step={1}
                className="w-full"
              />
            </div>
          ))}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Review Comments</CardTitle>
          <CardDescription>
            Provide detailed feedback on the manuscript
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label htmlFor="comments">Detailed Comments</Label>
            <Textarea
              id="comments"
              placeholder="Please provide comprehensive feedback on the manuscript's methodology, findings, presentation, and overall contribution to the field..."
              value={comments}
              onChange={(e) => setComments(e.target.value)}
              className="min-h-[200px] mt-2"
            />
          </div>

          <div>
            <Label htmlFor="recommendation">Recommendation</Label>
            <Select value={recommendation} onValueChange={setRecommendation}>
              <SelectTrigger className="mt-2">
                <SelectValue placeholder="Select your recommendation" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="accept">Accept</SelectItem>
                <SelectItem value="minor_revision">Minor Revision</SelectItem>
                <SelectItem value="major_revision">Major Revision</SelectItem>
                <SelectItem value="reject">Reject</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      <div className="flex justify-end gap-4">
        <Button variant="outline" onClick={onBack}>
          Cancel
        </Button>
        <Button
          onClick={handleSubmit}
          disabled={submitReviewMutation.isPending}
          className="bg-blue-600 hover:bg-blue-700 flex items-center gap-2"
        >
          <Send className="h-4 w-4" />
          {submitReviewMutation.isPending ? "Submitting..." : "Submit Review"}
        </Button>
      </div>
    </div>
  );
}