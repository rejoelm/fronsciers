import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { insertManuscriptSchema } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";
import { useWallet } from "@/hooks/use-wallet";
import { useToast } from "@/hooks/use-toast";
import { CloudUpload, FileText, Layers } from "lucide-react";
import { z } from "zod";

const formSchema = insertManuscriptSchema.extend({
  file: z.any().optional(),
  mintNFT: z.boolean().default(true),
  enableResale: z.boolean().default(false),
});

type FormData = z.infer<typeof formSchema>;

export function SubmissionForm() {
  const { user } = useWallet();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [uploadProgress, setUploadProgress] = useState(0);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);

  const form = useForm<FormData>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      title: "",
      abstract: "",
      authors: "",
      category: "",
      keywords: "",
      submissionFee: "10.00",
      mintNFT: true,
      enableResale: false,
    },
  });

  const uploadMutation = useMutation({
    mutationFn: async (file: File) => {
      // Simulate IPFS upload
      setUploadProgress(0);
      const interval = setInterval(() => {
        setUploadProgress(prev => {
          if (prev >= 100) {
            clearInterval(interval);
            return 100;
          }
          return prev + 10;
        });
      }, 200);

      return new Promise<string>((resolve) => {
        setTimeout(() => {
          clearInterval(interval);
          resolve(`QmYwAPJzv5CZsnA625s3Xf2nemtYgPpHdWEz79ojWnPbdG${Date.now()}`);
        }, 2000);
      });
    },
  });

  const submitMutation = useMutation({
    mutationFn: async (data: FormData) => {
      let ipfsHash = "";
      
      if (selectedFile) {
        ipfsHash = await uploadMutation.mutateAsync(selectedFile);
      }

      return apiRequest("POST", "/api/manuscripts", {
        ...data,
        ipfsHash,
        submitterId: user?.id,
      });
    },
    onSuccess: async (response) => {
      const manuscript = await response.json();
      queryClient.invalidateQueries({ queryKey: ["/api/manuscripts/user"] });
      
      toast({
        title: "Manuscript Submitted",
        description: "Your manuscript has been successfully submitted for review.",
      });

      // If minting NFT, trigger DOCI minting
      if (form.getValues("mintNFT")) {
        try {
          await apiRequest("POST", "/api/solana/mint-doci", {
            manuscriptId: manuscript.id,
          });
          
          toast({
            title: "DOCI NFT Minted",
            description: "Your manuscript's DOCI NFT has been successfully minted on Solana.",
          });
        } catch (error) {
          toast({
            title: "NFT Minting Failed",
            description: "Manuscript submitted but NFT minting failed. You can try again later.",
            variant: "destructive",
          });
        }
      }

      form.reset();
      setSelectedFile(null);
      setUploadProgress(0);
    },
    onError: () => {
      toast({
        title: "Submission Failed",
        description: "Failed to submit manuscript. Please try again.",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: FormData) => {
    if (!user) {
      toast({
        title: "Wallet Not Connected",
        description: "Please connect your wallet to submit a manuscript.",
        variant: "destructive",
      });
      return;
    }

    submitMutation.mutate(data);
  };

  const handleFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      if (file.type !== "application/pdf") {
        toast({
          title: "Invalid File Type",
          description: "Please select a PDF file.",
          variant: "destructive",
        });
        return;
      }
      
      if (file.size > 50 * 1024 * 1024) { // 50MB limit
        toast({
          title: "File Too Large",
          description: "File size must be less than 50MB.",
          variant: "destructive",
        });
        return;
      }

      setSelectedFile(file);
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center space-x-3">
          <div className="w-10 h-10 bg-primary-100 rounded-lg flex items-center justify-center">
            <CloudUpload className="text-primary-600" />
          </div>
          <span>Submit New Manuscript</span>
        </CardTitle>
      </CardHeader>
      <CardContent>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            {/* Basic Information */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <FormField
                control={form.control}
                name="title"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Title</FormLabel>
                    <FormControl>
                      <Input placeholder="Enter manuscript title" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="category"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Research Category</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select category" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="Computer Science">Computer Science</SelectItem>
                        <SelectItem value="Mathematics">Mathematics</SelectItem>
                        <SelectItem value="Physics">Physics</SelectItem>
                        <SelectItem value="Biology">Biology</SelectItem>
                        <SelectItem value="Chemistry">Chemistry</SelectItem>
                        <SelectItem value="Medicine">Medicine</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            {/* Authors */}
            <FormField
              control={form.control}
              name="authors"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Authors</FormLabel>
                  <FormControl>
                    <Input placeholder="Comma-separated list of authors" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* Abstract */}
            <FormField
              control={form.control}
              name="abstract"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Abstract</FormLabel>
                  <FormControl>
                    <Textarea rows={4} placeholder="Enter your paper abstract" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* Keywords */}
            <FormField
              control={form.control}
              name="keywords"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Keywords</FormLabel>
                  <FormControl>
                    <Input placeholder="machine learning, blockchain, optimization" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* File Upload */}
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">Manuscript PDF</label>
              <div className="border-2 border-dashed border-slate-300 rounded-lg p-8 text-center hover:border-primary-400 transition-colors">
                {selectedFile ? (
                  <div className="space-y-4">
                    <div className="flex items-center justify-center space-x-2">
                      <FileText className="w-8 h-8 text-primary-600" />
                      <span className="font-medium">{selectedFile.name}</span>
                    </div>
                    {uploadProgress > 0 && uploadProgress < 100 && (
                      <div className="max-w-xs mx-auto">
                        <Progress value={uploadProgress} className="h-2" />
                        <p className="text-sm text-slate-600 mt-2">Uploading to IPFS... {uploadProgress}%</p>
                      </div>
                    )}
                    <Button
                      type="button"
                      variant="outline"
                      onClick={() => document.getElementById("file-input")?.click()}
                    >
                      Choose Different File
                    </Button>
                  </div>
                ) : (
                  <div>
                    <CloudUpload className="w-16 h-16 text-slate-400 mx-auto mb-4" />
                    <p className="text-slate-600 mb-2">Drop your PDF file here or click to browse</p>
                    <p className="text-sm text-slate-500">Maximum file size: 50MB</p>
                    <Button
                      type="button"
                      variant="outline"
                      className="mt-4"
                      onClick={() => document.getElementById("file-input")?.click()}
                    >
                      Choose File
                    </Button>
                  </div>
                )}
                <input
                  id="file-input"
                  type="file"
                  accept=".pdf"
                  className="hidden"
                  onChange={handleFileSelect}
                />
              </div>
            </div>

            {/* DOCI Minting Options */}
            <Card className="bg-gradient-to-r from-secondary-50 to-primary-50">
              <CardHeader>
                <CardTitle className="text-lg">DOCI (Direct On-Chain Identifier) Options</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="mintNFT"
                    render={({ field }) => (
                      <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                        <FormControl>
                          <Checkbox
                            checked={field.value}
                            onCheckedChange={field.onChange}
                          />
                        </FormControl>
                        <div className="space-y-1 leading-none">
                          <FormLabel>Mint as NFT</FormLabel>
                          <p className="text-sm text-slate-500">Create a unique NFT for this manuscript</p>
                        </div>
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="enableResale"
                    render={({ field }) => (
                      <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                        <FormControl>
                          <Checkbox
                            checked={field.value}
                            onCheckedChange={field.onChange}
                          />
                        </FormControl>
                        <div className="space-y-1 leading-none">
                          <FormLabel>Enable Resale</FormLabel>
                          <p className="text-sm text-slate-500">Allow trading of your DOCI NFT</p>
                        </div>
                      </FormItem>
                    )}
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">Minting Fee</label>
                  <div className="flex items-center space-x-2">
                    <span className="text-2xl font-bold text-slate-900">0.1 SOL</span>
                    <span className="text-sm text-slate-500">+ 50 FRONS</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Submission Fee */}
            <Card className="bg-primary-50 border-primary-200">
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="font-medium text-primary-900">Submission Fee</h4>
                    <p className="text-sm text-primary-700">Required for DOCI minting and peer review assignment</p>
                  </div>
                  <div className="text-right">
                    <div className="text-lg font-semibold text-primary-900">10 FRONS</div>
                    <div className="text-sm text-primary-600">≈ $2.50 USD</div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Submit Button */}
            <div className="flex justify-end space-x-4">
              <Button type="button" variant="outline">
                Save Draft
              </Button>
              <Button 
                type="submit" 
                disabled={submitMutation.isPending || uploadMutation.isPending}
                className="bg-primary-500 hover:bg-primary-600"
              >
                <Layers className="w-4 h-4 mr-2" />
                {submitMutation.isPending ? "Submitting..." : "Submit for Review"}
              </Button>
            </div>
          </form>
        </Form>
      </CardContent>
    </Card>
  );
}
