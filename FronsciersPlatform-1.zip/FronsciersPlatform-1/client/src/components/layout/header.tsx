import { useWalletContext } from "@/components/wallet/wallet-provider";
import { WalletButton } from "@/components/wallet/wallet-button";
import { Bell } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";

interface HeaderProps {
  title: string;
  description: string;
}

export function Header({ title, description }: HeaderProps) {
  const { wallet, fronsBalance } = useWalletContext();

  return (
    <header className="bg-white shadow-sm border-b border-slate-200 px-6 py-4">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-slate-900">{title}</h2>
          <p className="text-slate-600">{description}</p>
        </div>
        
        <div className="flex items-center space-x-4">
          {wallet.connected && (
            <div className="flex items-center space-x-3 bg-slate-100 rounded-lg px-4 py-2">
              <div className="w-8 h-8 bg-gradient-to-r from-purple-400 to-pink-400 rounded-full flex items-center justify-center">
                <span className="text-white text-sm font-bold">₣</span>
              </div>
              <div className="text-sm">
                <div className="font-mono text-slate-700">
                  {fronsBalance.toFixed(2)} FRONS
                </div>
                <div className="text-xs text-slate-500">Balance</div>
              </div>
            </div>
          )}
          
          <Button variant="ghost" size="icon">
            <Bell className="h-5 w-5" />
          </Button>
          
          <WalletButton />
          
          {wallet.connected && (
            <Avatar>
              <AvatarFallback>DR</AvatarFallback>
            </Avatar>
          )}
        </div>
      </div>
    </header>
  );
}
