import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Separator } from "@/components/ui/separator";
import { type DaoProposal } from "@shared/schema";
import { 
  Calendar, Users, TrendingUp, CheckCircle, 
  XCircle, Clock, Info, ExternalLink 
} from "lucide-react";

interface ProposalCardProps {
  proposal: DaoProposal;
  onVote?: (proposalId: number, voteType: string) => void;
  userVotingPower?: number;
  hasVoted?: boolean;
  userVote?: string;
  isVoting?: boolean;
  showActions?: boolean;
}

export function ProposalCard({ 
  proposal, 
  onVote,
  userVotingPower = 0,
  hasVoted = false,
  userVote,
  isVoting = false,
  showActions = true 
}: ProposalCardProps) {
  const getStatusBadge = (status: string) => {
    switch (status) {
      case "active":
        return <Badge variant="secondary" className="text-green-800 bg-green-100">Active</Badge>;
      case "passed":
        return <Badge variant="secondary" className="text-blue-800 bg-blue-100">Passed</Badge>;
      case "rejected":
        return <Badge variant="secondary" className="text-red-800 bg-red-100">Rejected</Badge>;
      case "executed":
        return <Badge variant="secondary" className="text-purple-800 bg-purple-100">Executed</Badge>;
      default:
        return <Badge variant="secondary">{status}</Badge>;
    }
  };

  const getCategoryBadge = (category: string) => {
    switch (category) {
      case "governance":
        return <Badge variant="outline" className="text-blue-600 border-blue-200">Governance</Badge>;
      case "tokenomics":
        return <Badge variant="outline" className="text-yellow-600 border-yellow-200">Tokenomics</Badge>;
      case "platform":
        return <Badge variant="outline" className="text-purple-600 border-purple-200">Platform</Badge>;
      default:
        return <Badge variant="outline">{category}</Badge>;
    }
  };

  const getDaysRemaining = () => {
    if (!proposal.endDate) return null;
    const now = new Date();
    const endDate = new Date(proposal.endDate);
    const diffTime = endDate.getTime() - now.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays;
  };

  const getVotePercentage = (votes: number, totalVotes: number) => {
    if (totalVotes === 0) return 0;
    return Math.round((votes / totalVotes) * 100);
  };

  const daysRemaining = getDaysRemaining();
  const forPercentage = getVotePercentage(proposal.votesFor || 0, proposal.totalVotes || 0);
  const againstPercentage = getVotePercentage(proposal.votesAgainst || 0, proposal.totalVotes || 0);

  return (
    <Card className="hover:shadow-md transition-shadow">
      <CardHeader>
        <div className="flex items-start justify-between">
          <div className="flex-1">
            <div className="flex items-center space-x-2 mb-2">
              <CardTitle className="text-lg">{proposal.title}</CardTitle>
            </div>
            <p className="text-muted-foreground text-sm line-clamp-2">
              {proposal.description}
            </p>
          </div>
          <div className="flex items-center space-x-2 ml-4">
            {getStatusBadge(proposal.status || "active")}
            {getCategoryBadge(proposal.category)}
          </div>
        </div>
      </CardHeader>
      
      <CardContent className="space-y-4">
        {/* Proposal Meta */}
        <div className="flex items-center space-x-4 text-sm text-muted-foreground">
          <span className="flex items-center space-x-1">
            <Calendar className="h-3 w-3" />
            <span>Created: {new Date(proposal.createdAt!).toLocaleDateString()}</span>
          </span>
          
          {proposal.endDate && (
            <span className="flex items-center space-x-1">
              <Clock className="h-3 w-3" />
              <span>
                Ends: {new Date(proposal.endDate).toLocaleDateString()}
                {daysRemaining !== null && (
                  <span className={`ml-1 font-medium ${
                    daysRemaining < 0 ? "text-red-600" : 
                    daysRemaining <= 2 ? "text-orange-600" : 
                    "text-green-600"
                  }`}>
                    ({daysRemaining < 0 ? "ended" : `${daysRemaining} days left`})
                  </span>
                )}
              </span>
            </span>
          )}
          
          <span className="flex items-center space-x-1">
            <Users className="h-3 w-3" />
            <span>{proposal.totalVotes?.toLocaleString() || 0} votes</span>
          </span>
        </div>

        {/* Voting Progress */}
        <div className="space-y-3">
          <div className="flex justify-between text-sm">
            <span className="text-muted-foreground">Voting Progress</span>
            <span className="font-medium">
              {forPercentage}% in favor
            </span>
          </div>
          
          <div className="space-y-2">
            <Progress value={forPercentage} className="h-3" />
            <div className="flex justify-between text-xs text-muted-foreground">
              <span className="flex items-center space-x-1">
                <CheckCircle className="h-3 w-3 text-green-600" />
                <span>{(proposal.votesFor || 0).toLocaleString()} For ({forPercentage}%)</span>
              </span>
              <span className="flex items-center space-x-1">
                <XCircle className="h-3 w-3 text-red-600" />
                <span>{(proposal.votesAgainst || 0).toLocaleString()} Against ({againstPercentage}%)</span>
              </span>
            </div>
          </div>
        </div>

        {/* User Vote Status */}
        {hasVoted && userVote && (
          <div className="p-3 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
            <div className="flex items-center space-x-2">
              <Info className="h-4 w-4 text-blue-600" />
              <span className="text-sm font-medium text-blue-900 dark:text-blue-100">
                You voted {userVote === "for" ? "For" : "Against"} with {userVotingPower.toLocaleString()} voting power
              </span>
            </div>
          </div>
        )}

        {/* Voting Actions */}
        {showActions && proposal.status === "active" && !hasVoted && daysRemaining && daysRemaining > 0 && (
          <>
            <Separator />
            <div className="flex items-center justify-between">
              <div className="text-sm text-muted-foreground">
                Your voting power: <span className="font-medium">{userVotingPower.toLocaleString()}</span>
              </div>
              <div className="flex space-x-2">
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => onVote?.(proposal.id, "for")}
                  disabled={isVoting || userVotingPower === 0}
                  className="text-green-700 border-green-200 hover:bg-green-50"
                >
                  {isVoting ? (
                    <Clock className="h-3 w-3 mr-1 animate-spin" />
                  ) : (
                    <CheckCircle className="h-3 w-3 mr-1" />
                  )}
                  Vote For
                </Button>
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => onVote?.(proposal.id, "against")}
                  disabled={isVoting || userVotingPower === 0}
                  className="text-red-700 border-red-200 hover:bg-red-50"
                >
                  {isVoting ? (
                    <Clock className="h-3 w-3 mr-1 animate-spin" />
                  ) : (
                    <XCircle className="h-3 w-3 mr-1" />
                  )}
                  Vote Against
                </Button>
              </div>
            </div>
          </>
        )}

        {/* Proposal Details Link */}
        <div className="flex justify-end">
          <Button size="sm" variant="ghost">
            <ExternalLink className="h-3 w-3 mr-1" />
            View Details
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
