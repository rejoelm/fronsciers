import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";
import { 
  LayoutDashboard, 
  Upload, 
  Users, 
  Coins, 
  IdCard, 
  Vote,
  Search,
  Microscope
} from "lucide-react";

const navigation = [
  { name: "Dashboard", href: "/", icon: LayoutDashboard },
  { name: "Submit Manuscript", href: "/submit", icon: Upload },
  { name: "Peer Review", href: "/review", icon: Users },
  { name: "Explore", href: "/explore", icon: Search },
  { name: "FRONS Tokens", href: "/tokens", icon: Coins },
  { name: "My DOCIs", href: "/docis", icon: IdCard },
  { name: "DAO Governance", href: "/governance", icon: Vote },
];

export function Sidebar() {
  const [location] = useLocation();

  return (
    <aside className="w-64 bg-white shadow-lg flex-shrink-0 border-r border-slate-200">
      <div className="p-6 border-b border-slate-200">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center">
            <Microscope className="text-white" size={20} />
          </div>
          <div>
            <h1 className="text-xl font-bold text-slate-900">FRONSCIERS</h1>
            <p className="text-xs text-slate-500 font-mono">v1.0.0-beta</p>
          </div>
        </div>
      </div>
      
      <nav className="p-4 space-y-2">
        {navigation.map((item) => {
          const isActive = location === item.href;
          return (
            <Link key={item.name} href={item.href}>
              <div className={cn(
                "flex items-center space-x-3 px-3 py-2 rounded-lg text-sm font-medium transition-colors",
                isActive
                  ? "bg-primary/10 text-primary"
                  : "text-slate-600 hover:bg-slate-100 hover:text-slate-900"
              )}>
                <item.icon className="w-5 h-5" />
                <span>{item.name}</span>
              </div>
            </Link>
          );
        })}
      </nav>
      
      <div className="absolute bottom-4 left-4 right-4">
        <div className="bg-slate-100 rounded-lg p-3">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-medium text-slate-700">Network</span>
            <span className="text-xs bg-yellow-100 text-yellow-800 px-2 py-1 rounded">Devnet</span>
          </div>
          <div className="flex items-center space-x-2 text-xs text-slate-600">
            <div className="w-2 h-2 bg-green-400 rounded-full"></div>
            <span>Solana Connected</span>
          </div>
        </div>
      </div>
    </aside>
  );
}
