import React, { useState, useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useMutation, useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { useToast } from '@/hooks/use-toast';
import { Loader2, ExternalLink, Copy, CheckCircle, AlertCircle } from 'lucide-react';
import { apiRequest } from '@/lib/queryClient';

// DOCI registration schema with validation
const dociRegistrationSchema = z.object({
  prefix: z.string().min(1, 'Prefix is required').regex(/^10\.[A-Za-z0-9]+$/, 'Invalid prefix format. Must start with "10." followed by alphanumeric characters'),
  suffix: z.string().min(1, 'Suffix is required'),
  metadataUri: z.string().url('Must be a valid URL'),
  contentHash: z.string().regex(/^[a-fA-F0-9]{64}$/, 'Content hash must be a 64-character hex string'),
  doiType: z.enum(['article', 'preprint', 'dataset', 'book', 'chapter', 'conference', 'thesis', 'other']),
  manuscriptId: z.number().optional(),
});

type DociRegistrationForm = z.infer<typeof dociRegistrationSchema>;

interface RegisterDociFormProps {
  manuscriptId?: number;
  onSuccess?: (doci: any) => void;
}

export function RegisterDociForm({ manuscriptId, onSuccess }: RegisterDociFormProps) {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [registrationResult, setRegistrationResult] = useState<any>(null);
  const { toast } = useToast();

  const form = useForm<DociRegistrationForm>({
    resolver: zodResolver(dociRegistrationSchema),
    defaultValues: {
      prefix: '10.FRONS',
      suffix: '',
      metadataUri: '',
      contentHash: '',
      doiType: 'article',
      manuscriptId: manuscriptId,
    },
  });

  // Generate suffix mutation
  const generateSuffixMutation = useMutation({
    mutationFn: () => apiRequest('/api/doci/generate-suffix', { method: 'POST' }),
    onSuccess: (data) => {
      form.setValue('suffix', data.suffix);
    },
    onError: () => {
      toast({
        title: 'Error',
        description: 'Failed to generate suffix',
        variant: 'destructive',
      });
    }
  });

  // Register DOCI mutation
  const registerDociMutation = useMutation({
    mutationFn: (data: DociRegistrationForm) => 
      apiRequest('/api/doci/register', {
        method: 'POST',
        body: data,
      }),
    onSuccess: (result) => {
      setRegistrationResult(result);
      toast({
        title: 'Success',
        description: `DOCI ${result.fullDoci} registered successfully on Solana`,
      });
      if (onSuccess) {
        onSuccess(result.doci);
      }
    },
    onError: (error: any) => {
      toast({
        title: 'Registration Failed',
        description: error.message || 'Failed to register DOCI',
        variant: 'destructive',
      });
    },
    onSettled: () => {
      setIsSubmitting(false);
    }
  });

  const onSubmit = async (data: DociRegistrationForm) => {
    setIsSubmitting(true);
    registerDociMutation.mutate(data);
  };

  const handleGenerateSuffix = () => {
    generateSuffixMutation.mutate();
  };

  const handleCopyDoci = () => {
    if (registrationResult?.fullDoci) {
      navigator.clipboard.writeText(registrationResult.fullDoci);
      toast({
        title: 'Copied',
        description: 'DOCI copied to clipboard',
      });
    }
  };

  const handleCopyTransactionHash = () => {
    if (registrationResult?.transactionSignature) {
      navigator.clipboard.writeText(registrationResult.transactionSignature);
      toast({
        title: 'Copied',
        description: 'Transaction hash copied to clipboard',
      });
    }
  };

  // Auto-generate suffix on component mount if empty
  useEffect(() => {
    if (!form.getValues('suffix')) {
      handleGenerateSuffix();
    }
  }, []);

  if (registrationResult) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <CheckCircle className="h-5 w-5 text-green-600" />
            <span>DOCI Registration Successful</span>
          </CardTitle>
          <CardDescription>
            Your Direct On-Chain Identifier has been minted on Solana
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="space-y-4">
            <div className="flex items-center justify-between p-4 border rounded-lg bg-green-50">
              <div>
                <Label className="text-sm font-medium">Registered DOCI</Label>
                <div className="text-lg font-mono font-bold text-green-700">
                  {registrationResult.fullDoci}
                </div>
              </div>
              <Button variant="outline" size="sm" onClick={handleCopyDoci}>
                <Copy className="h-4 w-4 mr-1" />
                Copy
              </Button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label className="text-sm font-medium">Solana Account</Label>
                <div className="p-2 bg-gray-50 rounded text-sm font-mono break-all">
                  {registrationResult.solanaAccount}
                </div>
              </div>
              <div className="space-y-2">
                <Label className="text-sm font-medium">Transaction Hash</Label>
                <div className="flex items-center space-x-2">
                  <div className="flex-1 p-2 bg-gray-50 rounded text-sm font-mono break-all">
                    {registrationResult.transactionSignature.substring(0, 20)}...
                  </div>
                  <Button variant="outline" size="sm" onClick={handleCopyTransactionHash}>
                    <Copy className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </div>

            <div className="flex items-center space-x-4">
              <Button asChild>
                <a 
                  href={registrationResult.explorerUrl} 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="flex items-center space-x-2"
                >
                  <ExternalLink className="h-4 w-4" />
                  <span>View on Solana Explorer</span>
                </a>
              </Button>
              <Button variant="outline" onClick={() => setRegistrationResult(null)}>
                Register Another DOCI
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Register DOCI</CardTitle>
        <CardDescription>
          Create a Direct On-Chain Identifier (DOCI) for your publication on Solana
        </CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="prefix">Prefix *</Label>
              <Input
                id="prefix"
                {...form.register('prefix')}
                placeholder="10.FRONS"
                disabled={isSubmitting}
              />
              {form.formState.errors.prefix && (
                <p className="text-sm text-red-600">{form.formState.errors.prefix.message}</p>
              )}
              <p className="text-xs text-gray-500">
                Standard format: 10.FRONS (FRONSCIERS identifier)
              </p>
            </div>

            <div className="space-y-2">
              <Label htmlFor="suffix">Suffix *</Label>
              <div className="flex space-x-2">
                <Input
                  id="suffix"
                  {...form.register('suffix')}
                  placeholder="Auto-generated unique suffix"
                  disabled={isSubmitting}
                />
                <Button
                  type="button"
                  variant="outline"
                  onClick={handleGenerateSuffix}
                  disabled={isSubmitting || generateSuffixMutation.isPending}
                >
                  {generateSuffixMutation.isPending ? (
                    <Loader2 className="h-4 w-4 animate-spin" />
                  ) : (
                    'Generate'
                  )}
                </Button>
              </div>
              {form.formState.errors.suffix && (
                <p className="text-sm text-red-600">{form.formState.errors.suffix.message}</p>
              )}
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="metadataUri">Metadata URI *</Label>
            <Input
              id="metadataUri"
              {...form.register('metadataUri')}
              placeholder="https://ipfs.io/ipfs/Qm... or https://arweave.net/..."
              disabled={isSubmitting}
            />
            {form.formState.errors.metadataUri && (
              <p className="text-sm text-red-600">{form.formState.errors.metadataUri.message}</p>
            )}
            <p className="text-xs text-gray-500">
              URL pointing to IPFS or Arweave metadata containing publication details
            </p>
          </div>

          <div className="space-y-2">
            <Label htmlFor="contentHash">Content Hash (SHA-256) *</Label>
            <Input
              id="contentHash"
              {...form.register('contentHash')}
              placeholder="64-character hex string (SHA-256 hash)"
              disabled={isSubmitting}
              className="font-mono"
            />
            {form.formState.errors.contentHash && (
              <p className="text-sm text-red-600">{form.formState.errors.contentHash.message}</p>
            )}
            <p className="text-xs text-gray-500">
              SHA-256 hash of the publication content (32 bytes as hex string)
            </p>
          </div>

          <div className="space-y-2">
            <Label htmlFor="doiType">Publication Type *</Label>
            <Select
              value={form.watch('doiType')}
              onValueChange={(value) => form.setValue('doiType', value as any)}
              disabled={isSubmitting}
            >
              <SelectTrigger>
                <SelectValue placeholder="Select publication type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="article">Research Article</SelectItem>
                <SelectItem value="preprint">Preprint</SelectItem>
                <SelectItem value="dataset">Dataset</SelectItem>
                <SelectItem value="book">Book</SelectItem>
                <SelectItem value="chapter">Book Chapter</SelectItem>
                <SelectItem value="conference">Conference Paper</SelectItem>
                <SelectItem value="thesis">Thesis/Dissertation</SelectItem>
                <SelectItem value="other">Other</SelectItem>
              </SelectContent>
            </Select>
            {form.formState.errors.doiType && (
              <p className="text-sm text-red-600">{form.formState.errors.doiType.message}</p>
            )}
          </div>

          <Alert>
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>
              <strong>Important:</strong> DOCI registration is permanent and immutable on the Solana blockchain. 
              Ensure all information is accurate before submitting.
            </AlertDescription>
          </Alert>

          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <div className="font-medium">Preview DOCI</div>
                <div className="text-sm text-gray-600">
                  {form.watch('prefix')}/{form.watch('suffix') || '[suffix]'}
                </div>
              </div>
              <Badge variant="outline" className="text-xs">
                Solana Devnet
              </Badge>
            </div>

            <Button 
              type="submit" 
              className="w-full" 
              disabled={isSubmitting}
            >
              {isSubmitting ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  Registering on Solana...
                </>
              ) : (
                'Register DOCI'
              )}
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
}