// Research Journey Types
export enum JourneyStage {
  DRAFT = 'draft',
  SUBMISSION = 'submission',
  PEER_REVIEW = 'peer_review',
  REVISION = 'revision',
  ACCEPTANCE = 'acceptance',
  PUBLICATION = 'publication',
  INDEXING = 'indexing',
  CITATION = 'citation'
}

// Publication Status Types
export enum PublicationStatus {
  DRAFT = 'draft',
  SUBMITTED = 'submitted',
  UNDER_REVIEW = 'under_review',
  REVISION_REQUIRED = 'revision_required',
  ACCEPTED = 'accepted',
  PUBLISHED = 'published',
  REJECTED = 'rejected'
}

// Review Status Types
export enum ReviewStatus {
  PENDING = 'pending',
  IN_PROGRESS = 'in_progress',
  COMPLETED = 'completed',
  OVERDUE = 'overdue'
}

// DAO Proposal Types
export enum ProposalCategory {
  GOVERNANCE = 'governance',
  TOKENOMICS = 'tokenomics',
  PLATFORM = 'platform',
  RESEARCH = 'research'
}

export enum ProposalStatus {
  ACTIVE = 'active',
  PASSED = 'passed',
  REJECTED = 'rejected',
  EXECUTED = 'executed'
}

// DOCI Types
export interface DOCIMetadata {
  title: string;
  authors: string[];
  abstract: string;
  keywords: string[];
  researchField: string;
  publicationDate: string;
  doi?: string;
  ipfsHash: string;
  version: string;
}

// User Profile Types
export interface UserProfile {
  id: number;
  walletAddress: string;
  username?: string;
  email?: string;
  institutionName?: string;
  researchField?: string;
  orcidId?: string;
  bio?: string;
  avatar?: string;
  reputationScore: number;
  fronsBalance: number;
  stakedFrons: number;
  publicationsCount: number;
  reviewsCount: number;
  citationsCount: number;
  hIndex: number;
  createdAt: Date;
}

// Research Analytics Types
export interface ResearchMetrics {
  totalPublications: number;
  totalCitations: number;
  hIndex: number;
  recentPublications: number;
  averageReviewTime: number;
  collaborationNetwork: number;
  impactScore: number;
}

// Collaboration Types
export interface CollaborationRequest {
  id: number;
  fromUserId: number;
  toUserId: number;
  manuscriptId?: number;
  message: string;
  status: 'pending' | 'accepted' | 'declined';
  createdAt: Date;
}

// Notification Types
export enum NotificationType {
  REVIEW_ASSIGNED = 'review_assigned',
  REVIEW_COMPLETED = 'review_completed',
  MANUSCRIPT_ACCEPTED = 'manuscript_accepted',
  MANUSCRIPT_REJECTED = 'manuscript_rejected',
  CITATION_RECEIVED = 'citation_received',
  COLLABORATION_REQUEST = 'collaboration_request',
  DAO_PROPOSAL = 'dao_proposal',
  TOKEN_REWARD = 'token_reward'
}

export interface Notification {
  id: number;
  userId: number;
  type: NotificationType;
  title: string;
  message: string;
  data?: any;
  read: boolean;
  createdAt: Date;
}

// File Upload Types
export interface FileUploadProgress {
  fileName: string;
  progress: number;
  status: 'uploading' | 'completed' | 'error';
  ipfsHash?: string;
  error?: string;
}

// Search and Filter Types
export interface SearchFilters {
  query?: string;
  researchField?: string;
  dateRange?: {
    start: Date;
    end: Date;
  };
  authors?: string[];
  keywords?: string[];
  sortBy?: 'relevance' | 'date' | 'citations' | 'impact';
  sortOrder?: 'asc' | 'desc';
}

// Blockchain Transaction Types
export interface TransactionResult {
  signature: string;
  status: 'pending' | 'confirmed' | 'failed';
  blockTime?: number;
  fee?: number;
  error?: string;
}

// IPFS Upload Result
export interface IPFSUploadResult {
  ipfsHash: string;
  size: number;
  timestamp: string;
  pinataUrl: string;
}