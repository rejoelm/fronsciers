// IPFS configuration and utilities
const IPFS_GATEWAY = "https://gateway.pinata.cloud/ipfs/";
const PINATA_API_URL = "https://api.pinata.cloud";

// Get API keys from environment variables
const PINATA_API_KEY = import.meta.env.VITE_PINATA_API_KEY;
const PINATA_SECRET_KEY = import.meta.env.VITE_PINATA_SECRET_KEY;

export interface IPFSUploadResult {
  ipfsHash: string;
  size: number;
  timestamp: string;
  pinataUrl: string;
}

export interface IPFSMetadata {
  name: string;
  description?: string;
  keyvalues?: Record<string, string>;
}

export class IPFSService {
  private apiKey: string;
  private secretKey: string;

  constructor() {
    this.apiKey = PINATA_API_KEY || "";
    this.secretKey = PINATA_SECRET_KEY || "";
  }

  // Upload file to IPFS via Pinata
  async uploadFile(
    file: File,
    metadata?: IPFSMetadata
  ): Promise<IPFSUploadResult> {
    if (!this.apiKey || !this.secretKey) {
      // Fallback to mock implementation for development
      return this.mockUpload(file);
    }

    try {
      const formData = new FormData();
      formData.append("file", file);

      if (metadata) {
        const pinataMetadata = {
          name: metadata.name,
          keyvalues: metadata.keyvalues || {},
        };
        formData.append("pinataMetadata", JSON.stringify(pinataMetadata));
      }

      const pinataOptions = {
        cidVersion: 0,
        customPinPolicy: {
          regions: [
            {
              id: "FRA1",
              desiredReplicationCount: 1,
            },
            {
              id: "NYC1", 
              desiredReplicationCount: 1,
            },
          ],
        },
      };
      formData.append("pinataOptions", JSON.stringify(pinataOptions));

      const response = await fetch(`${PINATA_API_URL}/pinning/pinFileToIPFS`, {
        method: "POST",
        headers: {
          pinata_api_key: this.apiKey,
          pinata_secret_api_key: this.secretKey,
        },
        body: formData,
      });

      if (!response.ok) {
        throw new Error(`IPFS upload failed: ${response.statusText}`);
      }

      const result = await response.json();

      return {
        ipfsHash: result.IpfsHash,
        size: result.PinSize,
        timestamp: result.Timestamp,
        pinataUrl: `${IPFS_GATEWAY}${result.IpfsHash}`,
      };
    } catch (error) {
      console.error("IPFS upload error:", error);
      // Fallback to mock for development
      return this.mockUpload(file);
    }
  }

  // Upload JSON metadata to IPFS
  async uploadMetadata(
    metadata: object,
    name: string
  ): Promise<IPFSUploadResult> {
    if (!this.apiKey || !this.secretKey) {
      return this.mockUploadMetadata(metadata, name);
    }

    try {
      const response = await fetch(`${PINATA_API_URL}/pinning/pinJSONToIPFS`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          pinata_api_key: this.apiKey,
          pinata_secret_api_key: this.secretKey,
        },
        body: JSON.stringify({
          pinataContent: metadata,
          pinataMetadata: {
            name: name,
          },
        }),
      });

      if (!response.ok) {
        throw new Error(`IPFS metadata upload failed: ${response.statusText}`);
      }

      const result = await response.json();

      return {
        ipfsHash: result.IpfsHash,
        size: result.PinSize,
        timestamp: result.Timestamp,
        pinataUrl: `${IPFS_GATEWAY}${result.IpfsHash}`,
      };
    } catch (error) {
      console.error("IPFS metadata upload error:", error);
      return this.mockUploadMetadata(metadata, name);
    }
  }

  // Get file from IPFS
  async getFile(ipfsHash: string): Promise<Response> {
    const url = `${IPFS_GATEWAY}${ipfsHash}`;
    
    try {
      const response = await fetch(url);
      if (!response.ok) {
        throw new Error(`Failed to fetch from IPFS: ${response.statusText}`);
      }
      return response;
    } catch (error) {
      console.error("IPFS fetch error:", error);
      throw error;
    }
  }

  // Get IPFS URL for a hash
  getIPFSUrl(ipfsHash: string): string {
    return `${IPFS_GATEWAY}${ipfsHash}`;
  }

  // Validate IPFS hash
  isValidIPFSHash(hash: string): boolean {
    // Basic validation for IPFS hash (CIDv0 and CIDv1)
    const cidv0Regex = /^Qm[1-9A-HJ-NP-Za-km-z]{44}$/;
    const cidv1Regex = /^b[a-z2-7]{58}$/;
    
    return cidv0Regex.test(hash) || cidv1Regex.test(hash);
  }

  // Get file info from Pinata
  async getFileInfo(ipfsHash: string) {
    if (!this.apiKey || !this.secretKey) {
      return null;
    }

    try {
      const response = await fetch(
        `${PINATA_API_URL}/data/pinList?hashContains=${ipfsHash}`,
        {
          headers: {
            pinata_api_key: this.apiKey,
            pinata_secret_api_key: this.secretKey,
          },
        }
      );

      if (!response.ok) {
        throw new Error(`Failed to get file info: ${response.statusText}`);
      }

      const result = await response.json();
      return result.rows[0] || null;
    } catch (error) {
      console.error("Error getting file info:", error);
      return null;
    }
  }

  // Mock upload for development
  private async mockUpload(file: File): Promise<IPFSUploadResult> {
    // Simulate upload delay
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    const mockHash = "Qm" + Math.random().toString(36).substring(2, 15) + 
                     Math.random().toString(36).substring(2, 15) + 
                     Math.random().toString(36).substring(2, 15);

    return {
      ipfsHash: mockHash,
      size: file.size,
      timestamp: new Date().toISOString(),
      pinataUrl: `${IPFS_GATEWAY}${mockHash}`,
    };
  }

  // Mock metadata upload for development
  private async mockUploadMetadata(metadata: object, name: string): Promise<IPFSUploadResult> {
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    const mockHash = "Qm" + Math.random().toString(36).substring(2, 15) + 
                     Math.random().toString(36).substring(2, 15) + 
                     Math.random().toString(36).substring(2, 15);

    return {
      ipfsHash: mockHash,
      size: JSON.stringify(metadata).length,
      timestamp: new Date().toISOString(),
      pinataUrl: `${IPFS_GATEWAY}${mockHash}`,
    };
  }
}

export const ipfsService = new IPFSService();

// Convenience function for uploading files
export async function uploadToIPFS(
  file: File,
  metadata?: IPFSMetadata
): Promise<string> {
  const result = await ipfsService.uploadFile(file, metadata);
  return result.ipfsHash;
}

// Convenience function for uploading metadata
export async function uploadMetadataToIPFS(
  metadata: object,
  name: string
): Promise<string> {
  const result = await ipfsService.uploadMetadata(metadata, name);
  return result.ipfsHash;
}

// Convenience function for getting IPFS URLs
export function getIPFSUrl(ipfsHash: string): string {
  return ipfsService.getIPFSUrl(ipfsHash);
}
