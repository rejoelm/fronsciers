import { Connection, PublicKey, clusterApiUrl, LAMPORTS_PER_SOL } from "@solana/web3.js";
import { getAssociatedTokenAddress, TOKEN_PROGRAM_ID } from "@solana/spl-token";

// Solana configuration
export const SOLANA_NETWORK = "devnet";
export const RPC_ENDPOINT = clusterApiUrl(SOLANA_NETWORK);

// Create connection
export const connection = new Connection(RPC_ENDPOINT, "confirmed");

// FRONS token configuration (mock for development)
export const FRONS_TOKEN_MINT = new PublicKey("11111111111111111111111111111112"); // Mock mint address

export interface WalletAdapter {
  publicKey: PublicKey | null;
  connected: boolean;
  connect(): Promise<void>;
  disconnect(): Promise<void>;
  signTransaction(transaction: any): Promise<any>;
  signAllTransactions(transactions: any[]): Promise<any[]>;
}

export class SolanaService {
  private connection: Connection;

  constructor() {
    this.connection = new Connection(RPC_ENDPOINT, "confirmed");
  }

  // Get SOL balance
  async getBalance(publicKey: PublicKey): Promise<number> {
    try {
      const balance = await this.connection.getBalance(publicKey);
      return balance / LAMPORTS_PER_SOL;
    } catch (error) {
      console.error("Error getting SOL balance:", error);
      return 0;
    }
  }

  // Get FRONS token balance
  async getFronsBalance(publicKey: PublicKey): Promise<number> {
    try {
      // In development mode, return a consistent mock balance based on wallet address
      const addressString = publicKey.toString();
      const hash = addressString.split('').reduce((acc, char) => acc + char.charCodeAt(0), 0);
      return 1500 + (hash % 3000); // Consistent balance between 1500-4500 FRONS
    } catch (error) {
      console.error("Error getting FRONS balance:", error);
      return 2500; // Default development balance
    }
  }

  // Validate Solana address
  isValidAddress(address: string): boolean {
    try {
      new PublicKey(address);
      return true;
    } catch {
      return false;
    }
  }

  // Get transaction history (simplified)
  async getTransactionHistory(publicKey: PublicKey, limit: number = 10) {
    try {
      const signatures = await this.connection.getSignaturesForAddress(
        publicKey,
        { limit }
      );
      
      return signatures.map(sig => ({
        signature: sig.signature,
        slot: sig.slot,
        blockTime: sig.blockTime,
        confirmationStatus: sig.confirmationStatus,
      }));
    } catch (error) {
      console.error("Error getting transaction history:", error);
      return [];
    }
  }

  // Create FRONS token transfer (mock implementation)
  async transferFrons(
    wallet: WalletAdapter,
    recipientAddress: string,
    amount: number
  ): Promise<string> {
    if (!wallet.publicKey || !wallet.connected) {
      throw new Error("Wallet not connected");
    }

    // Mock transaction for development
    console.log(`Transferring ${amount} FRONS to ${recipientAddress}`);
    
    // In production, this would create and send a real transaction
    return "mock_transaction_signature_" + Date.now();
  }

  // Mint DOCI NFT (mock implementation)
  async mintDociNft(
    wallet: WalletAdapter,
    metadata: {
      title: string;
      authors: string;
      ipfsHash: string;
      doi?: string;
    }
  ): Promise<string> {
    if (!wallet.publicKey || !wallet.connected) {
      throw new Error("Wallet not connected");
    }

    console.log("Minting DOCI NFT with metadata:", metadata);
    
    // Mock NFT mint address
    return "DOCI" + Date.now() + "_" + Math.random().toString(36).substring(7);
  }

  // Stake FRONS tokens (mock implementation)
  async stakeFrons(
    wallet: WalletAdapter,
    amount: number
  ): Promise<string> {
    if (!wallet.publicKey || !wallet.connected) {
      throw new Error("Wallet not connected");
    }

    console.log(`Staking ${amount} FRONS tokens`);
    
    // Mock staking transaction
    return "stake_transaction_" + Date.now();
  }

  // Create DAO vote transaction (mock implementation)
  async submitVote(
    wallet: WalletAdapter,
    proposalId: number,
    voteType: "for" | "against",
    votingPower: number
  ): Promise<string> {
    if (!wallet.publicKey || !wallet.connected) {
      throw new Error("Wallet not connected");
    }

    console.log(`Voting ${voteType} on proposal ${proposalId} with ${votingPower} voting power`);
    
    // Mock vote transaction
    return "vote_transaction_" + Date.now();
  }

  // Get network info
  async getNetworkInfo() {
    try {
      const epochInfo = await this.connection.getEpochInfo();
      const blockHeight = await this.connection.getBlockHeight();
      
      return {
        network: SOLANA_NETWORK,
        epochInfo,
        blockHeight,
        rpcEndpoint: RPC_ENDPOINT,
      };
    } catch (error) {
      console.error("Error getting network info:", error);
      return null;
    }
  }
}

export const solanaService = new SolanaService();
