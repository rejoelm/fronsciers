import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { SimpleWalletProvider } from "@/components/wallet/simple-wallet-provider";
import { MobileNavigation, OfflineIndicator } from "@/components/mobile-navigation";
import { FeedbackForm } from "@/components/feedback-form";
import Homepage from "@/pages/homepage";
import Dashboard from "@/pages/dashboard";
import Submit from "@/pages/submit";
import Review from "@/pages/review";
import PeerReview from "@/pages/peer-review";
import Governance from "@/pages/governance";
import Explore from "@/pages/explore";
import AcademicIntegration from "@/pages/academic-integration";
import DociRegistry from "@/pages/doci-registry";
import Tokenomics from "@/pages/tokenomics";
import Citations from "@/pages/citations";
import Trends from "@/pages/trends";
import Partners from "@/pages/partners";
import Recommendations from "@/pages/recommendations";
import GettingStarted from "@/pages/getting-started";

import NotFound from "@/pages/not-found";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Homepage} />
      <Route path="/dashboard" component={Dashboard} />
      <Route path="/submit" component={Submit} />
      <Route path="/review" component={Review} />
      <Route path="/peer-review" component={PeerReview} />
      <Route path="/doci-registry" component={DociRegistry} />
      <Route path="/academic-integration" component={AcademicIntegration} />
      <Route path="/governance" component={Governance} />
      <Route path="/tokenomics" component={Tokenomics} />
      <Route path="/citations" component={Citations} />
      <Route path="/trends" component={Trends} />
      <Route path="/partners" component={Partners} />
      <Route path="/explore" component={Explore} />
      <Route path="/recommendations" component={Recommendations} />
      <Route path="/getting-started" component={GettingStarted} />

      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <SimpleWalletProvider>
        <TooltipProvider>
          <div className="min-h-screen bg-background">
            <OfflineIndicator />
            <MobileNavigation />
            <main className="pb-20 md:pb-0">
              <Router />
            </main>
            <FeedbackForm />
            <Toaster />
          </div>
        </TooltipProvider>
      </SimpleWalletProvider>
    </QueryClientProvider>
  );
}

export default App;
