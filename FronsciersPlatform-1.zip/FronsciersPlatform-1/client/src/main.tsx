import { createRoot } from "react-dom/client";
import { StrictMode } from "react";
import App from "./App";
import { ErrorBoundary } from "./components/error-boundary";
import "./index.css";

// Register service worker for PWA functionality
if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('/sw.js')
      .then((registration) => {
        console.log('SW registered: ', registration);
      })
      .catch((registrationError) => {
        console.log('SW registration failed: ', registrationError);
      });
  });
}

// Add to Home Screen prompt for PWA
let deferredPrompt: any;
window.addEventListener('beforeinstallprompt', (e) => {
  e.preventDefault();
  deferredPrompt = e;
  
  // Show install banner after user interaction
  setTimeout(() => {
    if (deferredPrompt) {
      const installBanner = document.createElement('div');
      installBanner.innerHTML = `
        <div style="position: fixed; top: 0; left: 0; right: 0; background: #00D1B2; color: white; padding: 12px; text-align: center; z-index: 1000; font-family: Arial, sans-serif;">
          <span style="margin-right: 16px;">Install Fronsciers app for the best experience!</span>
          <button id="install-btn" style="background: white; color: #00D1B2; border: none; padding: 8px 16px; border-radius: 4px; font-weight: bold; margin-right: 8px; cursor: pointer;">Install</button>
          <button id="dismiss-btn" style="background: transparent; color: white; border: 1px solid white; padding: 8px 16px; border-radius: 4px; cursor: pointer;">Later</button>
        </div>
      `;
      document.body.appendChild(installBanner);
      
      document.getElementById('install-btn')?.addEventListener('click', () => {
        deferredPrompt.prompt();
        deferredPrompt.userChoice.then((choiceResult: any) => {
          if (choiceResult.outcome === 'accepted') {
            console.log('User accepted the A2HS prompt');
          }
          deferredPrompt = null;
          installBanner.remove();
        });
      });
      
      document.getElementById('dismiss-btn')?.addEventListener('click', () => {
        installBanner.remove();
      });
    }
  }, 5000);
});

createRoot(document.getElementById("root")!).render(
  <ErrorBoundary>
    <App />
  </ErrorBoundary>
);
