// Fronsciers Service Worker for PWA functionality
const CACHE_NAME = 'fronsciers-v1';
const STATIC_CACHE = 'fronsciers-static-v1';
const API_CACHE = 'fronsciers-api-v1';
const PDF_CACHE = 'fronsciers-pdf-v1';

const STATIC_ASSETS = [
  '/',
  '/manifest.json',
  '/icons/icon.svg',
  '/icons/icon-192x192.png',
  '/icons/icon-512x512.png'
];

const API_ENDPOINTS = [
  '/api/partners',
  '/api/governance/proposals',
  '/api/tokenomics/utilities'
];

const ONCHAIN_ENDPOINTS = [
  '/api/analytics/impact',
  '/api/doci/',
  '/api/manuscripts/'
];

// Install event - cache static assets
self.addEventListener('install', (event) => {
  console.log('Fronsciers Service Worker installing...');
  event.waitUntil(
    caches.open(STATIC_CACHE)
      .then((cache) => {
        return cache.addAll(STATIC_ASSETS);
      })
      .then(() => {
        self.skipWaiting();
      })
  );
});

// Activate event - cleanup old caches
self.addEventListener('activate', (event) => {
  console.log('Fronsciers Service Worker activated');
  event.waitUntil(
    caches.keys().then((cacheNames) => {
      return Promise.all(
        cacheNames.map((cacheName) => {
          if (cacheName !== STATIC_CACHE && 
              cacheName !== API_CACHE && 
              cacheName !== PDF_CACHE &&
              cacheName !== CACHE_NAME) {
            console.log('Deleting old cache:', cacheName);
            return caches.delete(cacheName);
          }
        })
      );
    }).then(() => {
      return self.clients.claim();
    })
  );
});

// Fetch event - handle requests with appropriate caching strategies
self.addEventListener('fetch', (event) => {
  const url = new URL(event.request.url);
  
  // Skip non-GET requests
  if (event.request.method !== 'GET') {
    return;
  }

  // Handle static assets with Cache First strategy
  if (STATIC_ASSETS.some(asset => url.pathname === asset || 
      url.pathname.startsWith('/icons/') ||
      url.pathname.startsWith('/assets/') ||
      url.pathname.endsWith('.css') ||
      url.pathname.endsWith('.js') ||
      url.pathname.endsWith('.png') ||
      url.pathname.endsWith('.svg'))) {
    
    event.respondWith(
      caches.open(STATIC_CACHE).then((cache) => {
        return cache.match(event.request).then((response) => {
          if (response) {
            return response;
          }
          return fetch(event.request).then((networkResponse) => {
            if (networkResponse.ok) {
              cache.put(event.request, networkResponse.clone());
            }
            return networkResponse;
          });
        });
      })
    );
    return;
  }

  // Handle infrequent API updates with Stale While Revalidate
  if (API_ENDPOINTS.some(endpoint => url.pathname.startsWith(endpoint))) {
    event.respondWith(
      caches.open(API_CACHE).then((cache) => {
        return cache.match(event.request).then((response) => {
          const fetchPromise = fetch(event.request).then((networkResponse) => {
            if (networkResponse.ok) {
              cache.put(event.request, networkResponse.clone());
            }
            return networkResponse;
          });
          
          return response || fetchPromise;
        });
      })
    );
    return;
  }

  // Handle on-chain data with Network First fallback
  if (ONCHAIN_ENDPOINTS.some(endpoint => url.pathname.startsWith(endpoint)) ||
      url.pathname.startsWith('/api/research/') ||
      url.pathname.startsWith('/api/explore/')) {
    
    event.respondWith(
      fetch(event.request, { timeout: 3000 }).then((response) => {
        if (response.ok) {
          caches.open(API_CACHE).then((cache) => {
            cache.put(event.request, response.clone());
          });
        }
        return response;
      }).catch(() => {
        return caches.open(API_CACHE).then((cache) => {
          return cache.match(event.request);
        });
      })
    );
    return;
  }

  // Handle IPFS-hosted PDFs and downloads with Cache First
  if (url.hostname.includes('ipfs') || 
      url.pathname.includes('.pdf') ||
      url.pathname.startsWith('/api/manuscripts/download')) {
    
    event.respondWith(
      caches.open(PDF_CACHE).then((cache) => {
        return cache.match(event.request).then((response) => {
          if (response) {
            return response;
          }
          return fetch(event.request).then((networkResponse) => {
            if (networkResponse.ok) {
              cache.put(event.request, networkResponse.clone());
            }
            return networkResponse;
          });
        });
      })
    );
    return;
  }

  // Handle navigation requests with Network First
  if (event.request.mode === 'navigate') {
    event.respondWith(
      fetch(event.request).then((response) => {
        if (response.ok) {
          caches.open(CACHE_NAME).then((cache) => {
            cache.put(event.request, response.clone());
          });
        }
        return response;
      }).catch(() => {
        return caches.open(CACHE_NAME).then((cache) => {
          return cache.match(event.request);
        }).then((response) => {
          return response || caches.open(STATIC_CACHE).then((cache) => {
            return cache.match('/');
          });
        });
      })
    );
    return;
  }

  // Default: try network first, then cache
  event.respondWith(
    fetch(event.request).catch(() => {
      return caches.match(event.request);
    })
  );
});

// Background sync for offline manuscript submissions
self.addEventListener('sync', (event) => {
  if (event.tag === 'manuscript-submission') {
    event.waitUntil(syncManuscriptSubmissions());
  }
});

async function syncManuscriptSubmissions() {
  try {
    const cache = await caches.open('pending-submissions');
    const requests = await cache.keys();
    
    for (const request of requests) {
      try {
        const response = await fetch(request);
        if (response.ok) {
          await cache.delete(request);
          console.log('Synced manuscript submission:', request.url);
        }
      } catch (error) {
        console.log('Sync failed for:', request.url, error);
      }
    }
  } catch (error) {
    console.error('Background sync failed:', error);
  }
}

// Push notification handler
self.addEventListener('push', (event) => {
  if (event.data) {
    const data = event.data.json();
    const options = {
      body: data.body || 'New update from Fronsciers',
      icon: '/icons/icon-192x192.png',
      badge: '/icons/icon-72x72.png',
      tag: data.tag || 'fronsciers-notification',
      data: data.data || {},
      actions: [
        {
          action: 'view',
          title: 'View',
          icon: '/icons/icon-72x72.png'
        },
        {
          action: 'dismiss',
          title: 'Dismiss'
        }
      ]
    };

    event.waitUntil(
      self.registration.showNotification(data.title || 'Fronsciers', options)
    );
  }
});

// Notification click handler
self.addEventListener('notificationclick', (event) => {
  event.notification.close();

  if (event.action === 'view') {
    event.waitUntil(
      self.clients.openWindow(event.notification.data?.url || '/')
    );
  }
});

// Message handler for cache management
self.addEventListener('message', (event) => {
  if (event.data && event.data.type === 'SKIP_WAITING') {
    self.skipWaiting();
  }
  
  if (event.data && event.data.type === 'CACHE_PDF') {
    const { url } = event.data;
    caches.open(PDF_CACHE).then((cache) => {
      cache.add(url);
    });
  }
});