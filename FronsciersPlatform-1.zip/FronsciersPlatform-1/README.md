# FRONSCIERS - Blockchain Academic Publishing Platform

A revolutionary decentralized academic publishing platform built on Solana blockchain, featuring Direct On-Chain Identifiers (DOCIs) as NFTs, multi-tier peer review, and FRONS token incentives.

## 🚀 Features

- **DOCIs (Direct On-Chain Identifiers)**: NFT-based manuscript identification system
- **Multi-Tier Peer Review**: Automated checks, expert review, and community validation
- **FRONS Token Economy**: Earn tokens for quality reviews and publications
- **DAO Governance**: Community-driven platform decisions
- **IPFS Storage**: Decentralized manuscript storage and retrieval
- **Real-Time Analytics**: Research trends and collaboration insights
- **Medical Research Integration**: Connect to PubMed, Scopus, and Cochrane databases
- **Progressive Web App**: Offline functionality and mobile-first design

## 📋 Prerequisites

- **Node.js** 20.x or higher
- **PostgreSQL** 15.x or higher
- **Docker** (optional, for containerized deployment)
- **Solana CLI** (for blockchain operations)

## 🛠️ Local Development Setup

### 1. Clone and Install Dependencies

```bash
git clone https://github.com/fronsciers/platform.git
cd platform
npm install
```

### 2. Environment Configuration

Create a `.env` file in the root directory:

```env
# Database
DATABASE_URL=postgresql://username:password@localhost:5432/fronsciers

# Solana Configuration
SOLANA_PRIVATE_KEY=your_solana_private_key
SOLANA_RPC_URL=https://api.devnet.solana.com

# IPFS Configuration
IPFS_API_KEY=your_ipfs_api_key

# AI Services
ANTHROPIC_API_KEY=your_anthropic_api_key

# Medical Research APIs
PUBMED_API_KEY=your_pubmed_api_key
SCOPUS_API_KEY=your_scopus_api_key
COCHRANE_API_KEY=your_cochrane_api_key

# Application
NODE_ENV=development
PORT=5000
```

### 3. Database Setup

```bash
# Create PostgreSQL database
createdb fronsciers

# Run database migrations
npm run db:migrate

# (Optional) Seed with sample data
npm run db:seed
```

### 4. Start Development Server

```bash
# Start both backend and frontend
npm run dev
```

The application will be available at:
- **Frontend**: http://localhost:5000
- **Backend API**: http://localhost:5000/api
- **API Documentation**: http://localhost:5000/api/docs

## 🧪 Testing

### Run All Tests
```bash
npm test
```

### Run Specific Test Suites
```bash
# Backend tests
npm run test:server

# Frontend tests  
npm run test:client

# Integration tests
npm run test:integration
```

### Test Coverage
```bash
npm run test:coverage
```

## 📚 API Documentation

Interactive API documentation is available at `/api/docs` when running the development server. The documentation includes:

- **Authentication**: Wallet-based authentication endpoints
- **Manuscripts**: Research paper submission and management
- **Reviews**: Multi-tier peer review system
- **DOCIs**: NFT-based identifier registry
- **Tokenomics**: FRONS token operations
- **Governance**: DAO proposals and voting

### Example API Usage

```javascript
// Authenticate with Solana wallet
const response = await fetch('/api/auth/wallet', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    walletAddress: 'your_wallet_address',
    signature: 'signed_message'
  })
});

// Submit a manuscript
const manuscript = await fetch('/api/manuscripts', {
  method: 'POST',
  headers: { 
    'Content-Type': 'application/json',
    'Authorization': `Bearer ${token}`
  },
  body: JSON.stringify({
    title: 'Research Title',
    abstract: 'Research abstract...',
    authors: ['Author 1', 'Author 2'],
    keywords: ['keyword1', 'keyword2'],
    category: 'Computer Science'
  })
});
```

## 🏗️ Architecture

### Frontend (React + TypeScript)
- **UI Components**: Shadcn/ui component library
- **State Management**: TanStack Query for server state
- **Routing**: Wouter for client-side routing
- **Styling**: Tailwind CSS with custom themes
- **PWA**: Service worker with offline support

### Backend (Express + TypeScript)
- **Database**: PostgreSQL with Drizzle ORM
- **Authentication**: JWT with Solana wallet verification
- **Real-time**: WebSocket for live updates
- **File Storage**: IPFS for decentralized storage
- **Blockchain**: Solana Web3.js for NFT operations

### Infrastructure
- **CI/CD**: GitHub Actions with automated testing
- **Deployment**: Kubernetes with Helm charts
- **Monitoring**: Prometheus + Grafana
- **Security**: Rate limiting, CORS, helmet

## 🚀 Deployment

### Production Deployment

1. **Build the application**:
```bash
npm run build
```

2. **Deploy with Docker**:
```bash
# Build Docker image
npm run docker:build

# Deploy to production
docker-compose up -d
```

3. **Deploy to Kubernetes**:
```bash
# Apply Kubernetes manifests
kubectl apply -f k8s/

# Or use Helm
helm install fronsciers ./helm-chart
```

### Infrastructure as Code

The platform supports both Terraform and Pulumi for infrastructure management:

```bash
# Terraform deployment
cd infrastructure/terraform
terraform init
terraform plan
terraform apply

# Pulumi deployment  
cd infrastructure/pulumi
pulumi up
```

## 🔧 Configuration

### Environment Variables

| Variable | Description | Required |
|----------|-------------|----------|
| `DATABASE_URL` | PostgreSQL connection string | Yes |
| `SOLANA_PRIVATE_KEY` | Solana wallet private key | Yes |
| `IPFS_API_KEY` | IPFS service API key | Yes |
| `ANTHROPIC_API_KEY` | AI service for automated reviews | No |
| `PUBMED_API_KEY` | Medical research database access | No |
| `SCOPUS_API_KEY` | Academic database access | No |

### Feature Flags

```env
# Enable experimental features
ENABLE_COMMUNITY_VOTING=true
ENABLE_AI_REVIEWS=true
ENABLE_MEDICAL_INTEGRATION=true
```

## 📖 Component Documentation

Frontend components are documented with Storybook:

```bash
# Start Storybook development server
npm run storybook

# Build static Storybook
npm run build-storybook
```

Key component stories include:
- **TokenomicsCard**: FRONS token display components
- **ResearchJourneyProgressBar**: Manuscript status tracking
- **WalletConnection**: Solana wallet integration
- **ReviewPanel**: Peer review interface

## 🤝 Contributing

1. **Fork the repository**
2. **Create a feature branch**: `git checkout -b feature/your-feature`
3. **Commit changes**: `git commit -am 'Add new feature'`
4. **Push to branch**: `git push origin feature/your-feature`
5. **Submit a Pull Request**

### Development Guidelines

- Follow TypeScript strict mode
- Use ESLint and Prettier for code formatting
- Write comprehensive tests for new features
- Update documentation for API changes
- Follow conventional commit messages

## 📊 Monitoring and Analytics

### Health Checks
- **Application Health**: `/health`
- **Readiness Check**: `/ready`
- **Metrics**: `/metrics` (Prometheus format)

### Performance Monitoring
- **Lighthouse**: PWA performance audits
- **Grafana**: Real-time dashboards
- **AlertManager**: Incident notifications

## 🔒 Security

- **Wallet Authentication**: Cryptographic signature verification
- **Rate Limiting**: API endpoint protection
- **CORS**: Cross-origin request filtering
- **Content Security Policy**: XSS protection
- **Input Validation**: Zod schema validation

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 🆘 Support

- **Documentation**: [docs.fronsciers.com](https://docs.fronsciers.com)
- **GitHub Issues**: [Report bugs and request features](https://github.com/fronsciers/platform/issues)
- **Discord**: [Join our community](https://discord.gg/fronsciers)
- **Email**: support@fronsciers.com

## 🌟 Acknowledgments

- **Solana Foundation** for blockchain infrastructure
- **IPFS Protocol Labs** for decentralized storage
- **Academic Community** for feedback and validation
- **Open Source Contributors** for platform improvements