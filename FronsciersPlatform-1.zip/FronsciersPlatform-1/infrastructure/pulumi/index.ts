import * as aws from "@pulumi/aws";
import * as awsx from "@pulumi/awsx";
import * as eks from "@pulumi/eks";
import * as k8s from "@pulumi/kubernetes";

// Configuration
const config = new aws.Config();
const environment = config.get("environment") || "production";
const region = config.get("region") || "us-west-2";

// VPC
const vpc = new awsx.ec2.Vpc("fronsciers-vpc", {
  cidrBlock: "10.0.0.0/16",
  numberOfAvailabilityZones: 2,
  enableDnsHostnames: true,
  enableDnsSupport: true,
  tags: {
    Name: "fronsciers-vpc",
    Environment: environment,
  },
});

// RDS Subnet Group
const dbSubnetGroup = new aws.rds.SubnetGroup("fronsciers-db-subnet-group", {
  subnetIds: vpc.privateSubnetIds,
  tags: {
    Name: "fronsciers-db-subnet-group",
    Environment: environment,
  },
});

// Security Group for RDS
const dbSecurityGroup = new aws.ec2.SecurityGroup("fronsciers-db-sg", {
  vpcId: vpc.vpcId,
  description: "Security group for FRONSCIERS PostgreSQL database",
  ingress: [
    {
      protocol: "tcp",
      fromPort: 5432,
      toPort: 5432,
      cidrBlocks: [vpc.vpc.cidrBlock],
    },
  ],
  egress: [
    {
      protocol: "-1",
      fromPort: 0,
      toPort: 0,
      cidrBlocks: ["0.0.0.0/0"],
    },
  ],
  tags: {
    Name: "fronsciers-db-sg",
    Environment: environment,
  },
});

// RDS PostgreSQL Instance
const database = new aws.rds.Instance("fronsciers-postgres", {
  identifier: "fronsciers-postgres",
  engine: "postgres",
  engineVersion: "15.4",
  instanceClass: "db.t3.micro",
  allocatedStorage: 100,
  maxAllocatedStorage: 1000,
  storageType: "gp3",
  storageEncrypted: true,
  
  dbName: "fronsciers",
  username: "fronsciers_admin",
  password: config.requireSecret("dbPassword"),
  
  vpcSecurityGroupIds: [dbSecurityGroup.id],
  dbSubnetGroupName: dbSubnetGroup.name,
  
  backupRetentionPeriod: 7,
  backupWindow: "03:00-04:00",
  maintenanceWindow: "sun:04:00-sun:05:00",
  
  skipFinalSnapshot: environment === "development",
  deletionProtection: environment === "production",
  
  performanceInsightsEnabled: true,
  monitoringInterval: 60,
  
  tags: {
    Name: "fronsciers-postgres",
    Environment: environment,
  },
});

// EKS Cluster
const cluster = new eks.Cluster("fronsciers-cluster", {
  vpcId: vpc.vpcId,
  subnetIds: [...vpc.publicSubnetIds, ...vpc.privateSubnetIds],
  instanceType: "t3.medium",
  desiredCapacity: 3,
  minSize: 1,
  maxSize: 10,
  storageClass: "gp3",
  deployDashboard: false,
  version: "1.28",
  tags: {
    Name: "fronsciers-cluster",
    Environment: environment,
  },
});

// Kubernetes provider
const k8sProvider = new k8s.Provider("k8s-provider", {
  kubeconfig: cluster.kubeconfig,
});

// Secrets Manager for application secrets
const appSecrets = new aws.secretsmanager.Secret("fronsciers-app-secrets", {
  name: `fronsciers/app-secrets-${environment}`,
  description: "Application secrets for FRONSCIERS platform",
  tags: {
    Name: "fronsciers-app-secrets",
    Environment: environment,
  },
});

const secretVersion = new aws.secretsmanager.SecretVersion("app-secrets-version", {
  secretId: appSecrets.id,
  secretString: aws.jsonencode({
    database_url: database.endpoint.apply(endpoint => 
      `postgresql://fronsciers_admin:${config.requireSecret("dbPassword")}@${endpoint}/fronsciers`
    ),
    solana_private_key: config.requireSecret("solanaPrivateKey"),
    solana_rpc_url: config.get("solanaRpcUrl") || "https://api.mainnet-beta.solana.com",
    ipfs_api_key: config.requireSecret("ipfsApiKey"),
    anthropic_api_key: config.requireSecret("anthropicApiKey"),
    pubmed_api_key: config.requireSecret("pubmedApiKey"),
    scopus_api_key: config.requireSecret("scopusApiKey"),
    cochrane_api_key: config.requireSecret("cochraneApiKey"),
  }),
});

// Kubernetes namespace
const namespace = new k8s.core.v1.Namespace("fronsciers-namespace", {
  metadata: {
    name: "fronsciers-production",
  },
}, { provider: k8sProvider });

// Kubernetes secret for application configuration
const k8sSecret = new k8s.core.v1.Secret("app-secrets", {
  metadata: {
    name: "app-secrets",
    namespace: namespace.metadata.name,
  },
  type: "Opaque",
  stringData: {
    "database-url": database.endpoint.apply(endpoint => 
      `postgresql://fronsciers_admin:${config.requireSecret("dbPassword")}@${endpoint}/fronsciers`
    ),
    "solana-private-key": config.requireSecret("solanaPrivateKey"),
    "solana-rpc-url": config.get("solanaRpcUrl") || "https://api.mainnet-beta.solana.com",
    "ipfs-api-key": config.requireSecret("ipfsApiKey"),
    "anthropic-api-key": config.requireSecret("anthropicApiKey"),
    "pubmed-api-key": config.requireSecret("pubmedApiKey"),
    "scopus-api-key": config.requireSecret("scopusApiKey"),
    "cochrane-api-key": config.requireSecret("cochraneApiKey"),
  },
}, { provider: k8sProvider });

// CloudWatch Log Groups
const appLogGroup = new aws.cloudwatch.LogGroup("fronsciers-app-logs", {
  name: "/aws/eks/fronsciers/application",
  retentionInDays: 30,
  tags: {
    Name: "fronsciers-app-logs",
    Environment: environment,
  },
});

const clusterLogGroup = new aws.cloudwatch.LogGroup("fronsciers-cluster-logs", {
  name: "/aws/eks/fronsciers/cluster",
  retentionInDays: 30,
  tags: {
    Name: "fronsciers-cluster-logs",
    Environment: environment,
  },
});

// NGINX Ingress Controller
const nginxIngress = new k8s.helm.v3.Chart("nginx-ingress", {
  chart: "ingress-nginx",
  repository: "https://kubernetes.github.io/ingress-nginx",
  namespace: "ingress-nginx",
  createNamespace: true,
  values: {
    controller: {
      service: {
        type: "LoadBalancer",
        annotations: {
          "service.beta.kubernetes.io/aws-load-balancer-type": "nlb",
          "service.beta.kubernetes.io/aws-load-balancer-cross-zone-load-balancing-enabled": "true",
        },
      },
      metrics: {
        enabled: true,
      },
    },
  },
}, { provider: k8sProvider });

// Cert-manager for SSL certificates
const certManager = new k8s.helm.v3.Chart("cert-manager", {
  chart: "cert-manager",
  repository: "https://charts.jetstack.io",
  namespace: "cert-manager",
  createNamespace: true,
  values: {
    installCRDs: true,
    global: {
      leaderElection: {
        namespace: "cert-manager",
      },
    },
  },
}, { provider: k8sProvider });

// ClusterIssuer for Let's Encrypt
const clusterIssuer = new k8s.apiextensions.CustomResource("letsencrypt-prod", {
  apiVersion: "cert-manager.io/v1",
  kind: "ClusterIssuer",
  metadata: {
    name: "letsencrypt-prod",
  },
  spec: {
    acme: {
      server: "https://acme-v02.api.letsencrypt.org/directory",
      email: config.get("acmeEmail") || "admin@fronsciers.com",
      privateKeySecretRef: {
        name: "letsencrypt-prod",
      },
      solvers: [
        {
          http01: {
            ingress: {
              class: "nginx",
            },
          },
        },
      ],
    },
  },
}, { 
  provider: k8sProvider,
  dependsOn: [certManager],
});

// Exports
export const vpcId = vpc.vpcId;
export const databaseEndpoint = database.endpoint;
export const clusterName = cluster.eksCluster.name;
export const kubeconfig = cluster.kubeconfig;
export const secretsArn = appSecrets.arn;