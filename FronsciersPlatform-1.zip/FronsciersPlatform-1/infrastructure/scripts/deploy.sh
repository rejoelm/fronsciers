#!/bin/bash

# FRONSCIERS Production Deployment Script
set -e

# Configuration
ENVIRONMENT=${ENVIRONMENT:-production}
NAMESPACE=fronsciers-${ENVIRONMENT}
DOCKER_IMAGE=fronsciers/backend:latest
KUBECONFIG_PATH=${KUBECONFIG_PATH:-~/.kube/config}

echo "🚀 Starting FRONSCIERS deployment to ${ENVIRONMENT}..."

# Check prerequisites
command -v kubectl >/dev/null 2>&1 || { echo "kubectl is required but not installed. Aborting." >&2; exit 1; }
command -v docker >/dev/null 2>&1 || { echo "docker is required but not installed. Aborting." >&2; exit 1; }

# Verify cluster connection
echo "📡 Verifying Kubernetes cluster connection..."
kubectl cluster-info

# Create namespace if it doesn't exist
echo "🏗️  Setting up namespace: ${NAMESPACE}"
kubectl create namespace ${NAMESPACE} --dry-run=client -o yaml | kubectl apply -f -

# Apply secrets (assuming they're created via CI/CD pipeline)
echo "🔐 Applying application secrets..."
kubectl apply -f - <<EOF
apiVersion: v1
kind: Secret
metadata:
  name: app-secrets
  namespace: ${NAMESPACE}
type: Opaque
data:
  database-url: $(echo -n "${DATABASE_URL}" | base64)
  solana-private-key: $(echo -n "${SOLANA_PRIVATE_KEY}" | base64)
  solana-rpc-url: $(echo -n "${SOLANA_RPC_URL}" | base64)
  ipfs-api-key: $(echo -n "${IPFS_API_KEY}" | base64)
  anthropic-api-key: $(echo -n "${ANTHROPIC_API_KEY}" | base64)
  pubmed-api-key: $(echo -n "${PUBMED_API_KEY}" | base64)
  scopus-api-key: $(echo -n "${SCOPUS_API_KEY}" | base64)
  cochrane-api-key: $(echo -n "${COCHRANE_API_KEY}" | base64)
EOF

# Run database migrations
echo "🗄️  Running database migrations..."
kubectl apply -f - <<EOF
apiVersion: batch/v1
kind: Job
metadata:
  name: db-migration-$(date +%s)
  namespace: ${NAMESPACE}
spec:
  template:
    spec:
      containers:
      - name: migration
        image: ${DOCKER_IMAGE}
        command: ["npm", "run", "db:migrate"]
        env:
        - name: DATABASE_URL
          valueFrom:
            secretKeyRef:
              name: app-secrets
              key: database-url
      restartPolicy: OnFailure
  backoffLimit: 3
EOF

# Wait for migration to complete
echo "⏳ Waiting for database migration to complete..."
sleep 30

# Deploy backend application
echo "🎯 Deploying backend application..."
kubectl apply -f - <<EOF
apiVersion: apps/v1
kind: Deployment
metadata:
  name: fronsciers-backend
  namespace: ${NAMESPACE}
  labels:
    app: fronsciers-backend
spec:
  replicas: 3
  selector:
    matchLabels:
      app: fronsciers-backend
  template:
    metadata:
      labels:
        app: fronsciers-backend
      annotations:
        prometheus.io/scrape: "true"
        prometheus.io/port: "5000"
        prometheus.io/path: "/metrics"
    spec:
      containers:
      - name: backend
        image: ${DOCKER_IMAGE}
        ports:
        - containerPort: 5000
        env:
        - name: NODE_ENV
          value: "production"
        - name: DATABASE_URL
          valueFrom:
            secretKeyRef:
              name: app-secrets
              key: database-url
        - name: SOLANA_PRIVATE_KEY
          valueFrom:
            secretKeyRef:
              name: app-secrets
              key: solana-private-key
        - name: SOLANA_RPC_URL
          valueFrom:
            secretKeyRef:
              name: app-secrets
              key: solana-rpc-url
        - name: IPFS_API_KEY
          valueFrom:
            secretKeyRef:
              name: app-secrets
              key: ipfs-api-key
        - name: ANTHROPIC_API_KEY
          valueFrom:
            secretKeyRef:
              name: app-secrets
              key: anthropic-api-key
        - name: PUBMED_API_KEY
          valueFrom:
            secretKeyRef:
              name: app-secrets
              key: pubmed-api-key
        - name: SCOPUS_API_KEY
          valueFrom:
            secretKeyRef:
              name: app-secrets
              key: scopus-api-key
        - name: COCHRANE_API_KEY
          valueFrom:
            secretKeyRef:
              name: app-secrets
              key: cochrane-api-key
        resources:
          requests:
            memory: "512Mi"
            cpu: "250m"
          limits:
            memory: "1Gi"
            cpu: "500m"
        livenessProbe:
          httpGet:
            path: /health
            port: 5000
          initialDelaySeconds: 30
          periodSeconds: 10
        readinessProbe:
          httpGet:
            path: /ready
            port: 5000
          initialDelaySeconds: 5
          periodSeconds: 5
---
apiVersion: v1
kind: Service
metadata:
  name: fronsciers-backend-service
  namespace: ${NAMESPACE}
spec:
  selector:
    app: fronsciers-backend
  ports:
  - protocol: TCP
    port: 80
    targetPort: 5000
  type: ClusterIP
---
apiVersion: networking.k8s.io/v1
kind: Ingress
metadata:
  name: fronsciers-backend-ingress
  namespace: ${NAMESPACE}
  annotations:
    kubernetes.io/ingress.class: "nginx"
    cert-manager.io/cluster-issuer: "letsencrypt-prod"
    nginx.ingress.kubernetes.io/rate-limit: "100"
    nginx.ingress.kubernetes.io/cors-allow-origin: "https://fronsciers.com"
    nginx.ingress.kubernetes.io/cors-allow-methods: "GET, POST, PUT, DELETE, OPTIONS"
    nginx.ingress.kubernetes.io/cors-allow-headers: "DNT,User-Agent,X-Requested-With,If-Modified-Since,Cache-Control,Content-Type,Range,Authorization"
spec:
  tls:
  - hosts:
    - api.fronsciers.com
    secretName: api-fronsciers-tls
  rules:
  - host: api.fronsciers.com
    http:
      paths:
      - path: /
        pathType: Prefix
        backend:
          service:
            name: fronsciers-backend-service
            port:
              number: 80
EOF

# Wait for deployment to be ready
echo "⏳ Waiting for deployment to be ready..."
kubectl rollout status deployment/fronsciers-backend -n ${NAMESPACE} --timeout=300s

# Deploy monitoring stack
echo "📊 Setting up monitoring..."
kubectl create namespace monitoring --dry-run=client -o yaml | kubectl apply -f -
kubectl apply -f infrastructure/monitoring/kubernetes-monitoring.yaml

# Verify deployment
echo "✅ Verifying deployment..."
kubectl get pods -n ${NAMESPACE}
kubectl get services -n ${NAMESPACE}
kubectl get ingress -n ${NAMESPACE}

# Run smoke tests
echo "🧪 Running smoke tests..."
BACKEND_URL="https://api.fronsciers.com"
curl -f "${BACKEND_URL}/health" || echo "⚠️  Health check failed"
curl -f "${BACKEND_URL}/ready" || echo "⚠️  Ready check failed"

echo "🎉 FRONSCIERS deployment completed successfully!"
echo "📊 Monitor your application at:"
echo "   - API: ${BACKEND_URL}"
echo "   - Health: ${BACKEND_URL}/health"
echo "   - Metrics: ${BACKEND_URL}/metrics"
echo "   - Frontend: https://fronsciers.com"