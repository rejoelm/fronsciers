import swaggerJsdoc from 'swagger-jsdoc';
import swaggerUi from 'swagger-ui-express';
import { Express } from 'express';

const options = {
  definition: {
    openapi: '3.0.0',
    info: {
      title: 'FRONSCIERS API',
      version: '1.0.0',
      description: 'Blockchain-powered academic publishing platform API documentation',
      contact: {
        name: 'FRONSCIERS Team',
        url: 'https://fronsciers.com',
        email: 'api@fronsciers.com'
      },
      license: {
        name: 'MIT',
        url: 'https://opensource.org/licenses/MIT'
      }
    },
    servers: [
      {
        url: 'http://localhost:5000',
        description: 'Development server'
      },
      {
        url: 'https://api.fronsciers.com',
        description: 'Production server'
      }
    ],
    components: {
      securitySchemes: {
        bearerAuth: {
          type: 'http',
          scheme: 'bearer',
          bearerFormat: 'JWT'
        }
      },
      schemas: {
        User: {
          type: 'object',
          properties: {
            id: { type: 'integer', description: 'User ID' },
            walletAddress: { type: 'string', description: 'Solana wallet address' },
            username: { type: 'string', description: 'User display name' },
            email: { type: 'string', format: 'email', description: 'User email address' }
          }
        },
        Manuscript: {
          type: 'object',
          properties: {
            id: { type: 'integer', description: 'Manuscript ID' },
            title: { type: 'string', description: 'Manuscript title' },
            abstract: { type: 'string', description: 'Manuscript abstract' },
            authors: { type: 'array', items: { type: 'string' }, description: 'List of authors' },
            keywords: { type: 'array', items: { type: 'string' }, description: 'Research keywords' },
            category: { type: 'string', description: 'Research category' },
            status: { 
              type: 'string', 
              enum: ['draft', 'submitted', 'under_review', 'accepted', 'published', 'rejected'],
              description: 'Manuscript status'
            },
            submittedAt: { type: 'string', format: 'date-time', description: 'Submission timestamp' },
            publishedAt: { type: 'string', format: 'date-time', description: 'Publication timestamp' }
          }
        },
        Review: {
          type: 'object',
          properties: {
            id: { type: 'integer', description: 'Review ID' },
            manuscriptId: { type: 'integer', description: 'Manuscript being reviewed' },
            reviewerId: { type: 'integer', description: 'Reviewer user ID' },
            phase: { 
              type: 'string',
              enum: ['automated', 'peer_review', 'community'],
              description: 'Review phase'
            },
            status: {
              type: 'string',
              enum: ['pending', 'in_progress', 'completed'],
              description: 'Review status'
            },
            noveltyScore: { type: 'number', minimum: 0, maximum: 10, description: 'Novelty rating' },
            methodologyScore: { type: 'number', minimum: 0, maximum: 10, description: 'Methodology rating' },
            clarityScore: { type: 'number', minimum: 0, maximum: 10, description: 'Clarity rating' },
            overallScore: { type: 'number', minimum: 0, maximum: 10, description: 'Overall rating' },
            feedback: { type: 'string', description: 'Review feedback text' }
          }
        },
        DOCI: {
          type: 'object',
          properties: {
            id: { type: 'integer', description: 'DOCI registry ID' },
            dociId: { type: 'string', description: 'Unique DOCI identifier' },
            fullDoci: { type: 'string', description: 'Complete DOCI string' },
            manuscriptId: { type: 'integer', description: 'Associated manuscript ID' },
            userId: { type: 'integer', description: 'Owner user ID' },
            solanaAccount: { type: 'string', description: 'Solana NFT account address' },
            ipfsHash: { type: 'string', description: 'IPFS content hash' },
            status: {
              type: 'string',
              enum: ['minted', 'published', 'cited'],
              description: 'DOCI status'
            }
          }
        },
        DaoProposal: {
          type: 'object',
          properties: {
            id: { type: 'integer', description: 'Proposal ID' },
            title: { type: 'string', description: 'Proposal title' },
            description: { type: 'string', description: 'Proposal description' },
            proposerId: { type: 'integer', description: 'Proposer user ID' },
            status: {
              type: 'string',
              enum: ['active', 'passed', 'rejected', 'expired'],
              description: 'Proposal status'
            },
            votingStartsAt: { type: 'string', format: 'date-time', description: 'Voting start time' },
            votingEndsAt: { type: 'string', format: 'date-time', description: 'Voting end time' },
            yesVotes: { type: 'integer', description: 'Yes votes count' },
            noVotes: { type: 'integer', description: 'No votes count' }
          }
        },
        Transaction: {
          type: 'object',
          properties: {
            id: { type: 'integer', description: 'Transaction ID' },
            userId: { type: 'integer', description: 'User ID' },
            type: {
              type: 'string',
              enum: ['reward', 'fee', 'stake', 'unstake'],
              description: 'Transaction type'
            },
            amount: { type: 'number', description: 'FRONS token amount' },
            status: {
              type: 'string',
              enum: ['pending', 'completed', 'failed'],
              description: 'Transaction status'
            },
            transactionHash: { type: 'string', description: 'Solana transaction hash' }
          }
        },
        Error: {
          type: 'object',
          properties: {
            message: { type: 'string', description: 'Error message' },
            code: { type: 'string', description: 'Error code' }
          }
        }
      }
    },
    tags: [
      {
        name: 'Authentication',
        description: 'Wallet-based authentication endpoints'
      },
      {
        name: 'Manuscripts',
        description: 'Research manuscript management'
      },
      {
        name: 'Reviews',
        description: 'Peer review system'
      },
      {
        name: 'DOCI Registry',
        description: 'Direct On-Chain Identifier management'
      },
      {
        name: 'Governance',
        description: 'DAO proposals and voting'
      },
      {
        name: 'Tokenomics',
        description: 'FRONS token operations'
      },
      {
        name: 'Research Trends',
        description: 'Analytics and trending topics'
      },
      {
        name: 'Academic Integration',
        description: 'External database integration'
      }
    ]
  },
  apis: ['./server/routes.ts'], // Path to the API docs
};

const specs = swaggerJsdoc(options);

export function setupSwagger(app: Express) {
  app.use('/api/docs', swaggerUi.serve, swaggerUi.setup(specs, {
    customCss: '.swagger-ui .topbar { display: none }',
    customSiteTitle: 'FRONSCIERS API Documentation',
    swaggerOptions: {
      persistAuthorization: true,
      docExpansion: 'none',
      filter: true,
      showRequestDuration: true
    }
  }));

  // Serve OpenAPI spec as JSON
  app.get('/api/docs.json', (req, res) => {
    res.setHeader('Content-Type', 'application/json');
    res.send(specs);
  });
}