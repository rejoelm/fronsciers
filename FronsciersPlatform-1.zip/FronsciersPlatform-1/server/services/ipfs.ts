import { create } from 'ipfs-http-client';

class IPFSService {
  private client: any;

  constructor() {
    // Use public IPFS gateway or configure with environment variables
    const ipfsUrl = process.env.IPFS_URL || 'https://ipfs.infura.io:5001';
    const projectId = process.env.IPFS_PROJECT_ID;
    const projectSecret = process.env.IPFS_PROJECT_SECRET;

    if (projectId && projectSecret) {
      const auth = 'Basic ' + Buffer.from(projectId + ':' + projectSecret).toString('base64');
      this.client = create({
        url: ipfsUrl,
        headers: {
          authorization: auth,
        },
      });
    } else {
      // Fallback to public gateway
      this.client = create({ url: 'https://ipfs.io/api/v0' });
    }
  }

  async uploadFile(buffer: Buffer, filename: string): Promise<string> {
    try {
      const result = await this.client.add({
        path: filename,
        content: buffer,
      });
      return result.cid.toString();
    } catch (error) {
      console.error('IPFS upload error:', error);
      throw new Error('Failed to upload file to IPFS');
    }
  }

  async uploadJSON(data: object): Promise<string> {
    try {
      const buffer = Buffer.from(JSON.stringify(data));
      const result = await this.client.add(buffer);
      return result.cid.toString();
    } catch (error) {
      console.error('IPFS JSON upload error:', error);
      throw new Error('Failed to upload JSON to IPFS');
    }
  }

  getFileUrl(hash: string): string {
    return `https://ipfs.io/ipfs/${hash}`;
  }

  async getFile(hash: string): Promise<Buffer> {
    try {
      const chunks = [];
      for await (const chunk of this.client.cat(hash)) {
        chunks.push(chunk);
      }
      return Buffer.concat(chunks);
    } catch (error) {
      console.error('IPFS get file error:', error);
      throw new Error('Failed to retrieve file from IPFS');
    }
  }
}

export const ipfsService = new IPFSService();
