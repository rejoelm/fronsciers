import { PublicKey } from '@solana/web3.js';
import { solanaService } from './solana';
import { storage } from '../storage';

export interface TokenReward {
  amount: number;
  description: string;
  txSignature?: string;
}

class TokenService {
  // Standard reward amounts
  private readonly REVIEW_REWARD = 75;
  private readonly SUBMISSION_FEE = 10;
  private readonly PUBLICATION_REWARD = 100;
  private readonly CITATION_REWARD = 5;

  async rewardReviewer(userId: number, manuscriptId: number): Promise<TokenReward> {
    try {
      const user = await storage.getUser(userId);
      if (!user || !user.walletAddress) {
        throw new Error('User not found or no wallet address');
      }

      const userPublicKey = new PublicKey(user.walletAddress);
      
      // Mint reward tokens
      const txSignature = await solanaService.mintFronsTokens(userPublicKey, this.REVIEW_REWARD);
      
      // Update user balance in database
      await storage.updateUserBalance(userId, this.REVIEW_REWARD, 'earn');
      
      // Record transaction
      await storage.recordTokenTransaction(
        userId,
        'earn',
        this.REVIEW_REWARD,
        `Review reward for manuscript ${manuscriptId}`,
        txSignature
      );

      return {
        amount: this.REVIEW_REWARD,
        description: 'Peer review completion reward',
        txSignature,
      };
    } catch (error) {
      console.error('Error rewarding reviewer:', error);
      throw new Error('Failed to process reviewer reward');
    }
  }

  async processSubmissionFee(userId: number, manuscriptId: number): Promise<TokenReward> {
    try {
      const user = await storage.getUser(userId);
      if (!user || !user.walletAddress) {
        throw new Error('User not found or no wallet address');
      }

      // Check if user has sufficient balance
      const userPublicKey = new PublicKey(user.walletAddress);
      const balance = await solanaService.getTokenBalance(userPublicKey);
      
      if (balance < this.SUBMISSION_FEE) {
        throw new Error('Insufficient FRONS balance for submission fee');
      }

      // Deduct submission fee (in a real scenario, this would transfer to treasury)
      await storage.updateUserBalance(userId, -this.SUBMISSION_FEE, 'spend');
      
      // Record transaction
      await storage.recordTokenTransaction(
        userId,
        'spend',
        this.SUBMISSION_FEE,
        `Submission fee for manuscript ${manuscriptId}`,
        'fee_deduction'
      );

      return {
        amount: this.SUBMISSION_FEE,
        description: 'Manuscript submission fee',
      };
    } catch (error) {
      console.error('Error processing submission fee:', error);
      throw new Error('Failed to process submission fee');
    }
  }

  async rewardPublication(userId: number, manuscriptId: number): Promise<TokenReward> {
    try {
      const user = await storage.getUser(userId);
      if (!user || !user.walletAddress) {
        throw new Error('User not found or no wallet address');
      }

      const userPublicKey = new PublicKey(user.walletAddress);
      
      // Mint publication reward tokens
      const txSignature = await solanaService.mintFronsTokens(userPublicKey, this.PUBLICATION_REWARD);
      
      // Update user balance
      await storage.updateUserBalance(userId, this.PUBLICATION_REWARD, 'earn');
      
      // Record transaction
      await storage.recordTokenTransaction(
        userId,
        'earn',
        this.PUBLICATION_REWARD,
        `Publication reward for manuscript ${manuscriptId}`,
        txSignature
      );

      return {
        amount: this.PUBLICATION_REWARD,
        description: 'Manuscript publication reward',
        txSignature,
      };
    } catch (error) {
      console.error('Error rewarding publication:', error);
      throw new Error('Failed to process publication reward');
    }
  }

  async getRewardAmounts() {
    return {
      review: this.REVIEW_REWARD,
      submissionFee: this.SUBMISSION_FEE,
      publication: this.PUBLICATION_REWARD,
      citation: this.CITATION_REWARD,
    };
  }

  async getUserTokenBalance(userId: number): Promise<number> {
    try {
      const user = await storage.getUser(userId);
      if (!user || !user.walletAddress) {
        return 0;
      }

      const userPublicKey = new PublicKey(user.walletAddress);
      return await solanaService.getTokenBalance(userPublicKey);
    } catch (error) {
      console.error('Error getting user token balance:', error);
      return 0;
    }
  }

  async stakeTokens(userId: number, amount: number): Promise<TokenReward> {
    try {
      const user = await storage.getUser(userId);
      if (!user || !user.walletAddress) {
        throw new Error('User not found or no wallet address');
      }

      // Check balance
      const balance = await this.getUserTokenBalance(userId);
      if (balance < amount) {
        throw new Error('Insufficient balance for staking');
      }

      // Update staked amount in database
      await storage.updateUserStake(userId, amount);
      
      // Record transaction
      await storage.recordTokenTransaction(
        userId,
        'stake',
        amount,
        `Staked ${amount} FRONS for governance`,
        'stake_transaction'
      );

      return {
        amount,
        description: 'Tokens staked for governance',
      };
    } catch (error) {
      console.error('Error staking tokens:', error);
      throw new Error('Failed to stake tokens');
    }
  }
}

export const tokenService = new TokenService();
