import {
  Connection,
  PublicKey,
  Keypair,
  Transaction,
  SystemProgram,
  LAMPORTS_PER_SOL,
} from '@solana/web3.js';
import {
  createMint,
  createAssociatedTokenAccount,
  mintTo,
  transfer,
  getOrCreateAssociatedTokenAccount,
  TOKEN_PROGRAM_ID,
} from '@solana/spl-token';

class SolanaService {
  private connection: Connection;
  private payer: Keypair;
  private fronsTokenMint: PublicKey | null = null;

  constructor() {
    const rpcUrl = process.env.SOLANA_RPC_URL || 'https://api.devnet.solana.com';
    this.connection = new Connection(rpcUrl, 'confirmed');
    
    // Initialize payer from environment variable
    const payerSecretKey = process.env.SOLANA_PAYER_SECRET_KEY;
    if (payerSecretKey) {
      const secretKey = Uint8Array.from(JSON.parse(payerSecretKey));
      this.payer = Keypair.fromSecretKey(secretKey);
    } else {
      // Generate a new keypair for development
      this.payer = Keypair.generate();
      console.warn('No SOLANA_PAYER_SECRET_KEY provided, using generated keypair');
    }

    // Set FRONS token mint address if provided
    const tokenMintAddress = process.env.FRONS_TOKEN_MINT;
    if (tokenMintAddress) {
      this.fronsTokenMint = new PublicKey(tokenMintAddress);
    }
  }

  async initializeFronsToken(): Promise<PublicKey> {
    if (this.fronsTokenMint) {
      return this.fronsTokenMint;
    }

    try {
      // Create FRONS token mint
      const mint = await createMint(
        this.connection,
        this.payer,
        this.payer.publicKey, // mint authority
        this.payer.publicKey, // freeze authority
        9, // decimals
        undefined,
        undefined,
        TOKEN_PROGRAM_ID
      );

      this.fronsTokenMint = mint;
      console.log('FRONS token mint created:', mint.toString());
      return mint;
    } catch (error) {
      console.error('Error creating FRONS token:', error);
      throw new Error('Failed to initialize FRONS token');
    }
  }

  async createUserTokenAccount(userPublicKey: PublicKey): Promise<PublicKey> {
    if (!this.fronsTokenMint) {
      await this.initializeFronsToken();
    }

    try {
      const tokenAccount = await getOrCreateAssociatedTokenAccount(
        this.connection,
        this.payer,
        this.fronsTokenMint!,
        userPublicKey
      );

      return tokenAccount.address;
    } catch (error) {
      console.error('Error creating user token account:', error);
      throw new Error('Failed to create user token account');
    }
  }

  async mintFronsTokens(userPublicKey: PublicKey, amount: number): Promise<string> {
    if (!this.fronsTokenMint) {
      await this.initializeFronsToken();
    }

    try {
      const userTokenAccount = await this.createUserTokenAccount(userPublicKey);
      
      const signature = await mintTo(
        this.connection,
        this.payer,
        this.fronsTokenMint!,
        userTokenAccount,
        this.payer,
        amount * Math.pow(10, 9) // Convert to lamports (9 decimals)
      );

      await this.connection.confirmTransaction(signature, 'confirmed');
      return signature;
    } catch (error) {
      console.error('Error minting FRONS tokens:', error);
      throw new Error('Failed to mint FRONS tokens');
    }
  }

  async transferFronsTokens(
    fromPublicKey: PublicKey,
    toPublicKey: PublicKey,
    amount: number
  ): Promise<string> {
    if (!this.fronsTokenMint) {
      await this.initializeFronsToken();
    }

    try {
      const fromTokenAccount = await this.createUserTokenAccount(fromPublicKey);
      const toTokenAccount = await this.createUserTokenAccount(toPublicKey);

      const signature = await transfer(
        this.connection,
        this.payer,
        fromTokenAccount,
        toTokenAccount,
        fromPublicKey,
        amount * Math.pow(10, 9), // Convert to lamports
        []
      );

      await this.connection.confirmTransaction(signature, 'confirmed');
      return signature;
    } catch (error) {
      console.error('Error transferring FRONS tokens:', error);
      throw new Error('Failed to transfer FRONS tokens');
    }
  }

  async getTokenBalance(userPublicKey: PublicKey): Promise<number> {
    if (!this.fronsTokenMint) {
      return 0;
    }

    try {
      const tokenAccount = await this.createUserTokenAccount(userPublicKey);
      const balance = await this.connection.getTokenAccountBalance(tokenAccount);
      return parseFloat(balance.value.amount) / Math.pow(10, 9); // Convert from lamports
    } catch (error) {
      console.error('Error getting token balance:', error);
      return 0;
    }
  }

  async getSolBalance(publicKey: PublicKey): Promise<number> {
    try {
      const balance = await this.connection.getBalance(publicKey);
      return balance / LAMPORTS_PER_SOL;
    } catch (error) {
      console.error('Error getting SOL balance:', error);
      return 0;
    }
  }

  getConnection(): Connection {
    return this.connection;
  }

  getFronsTokenMint(): PublicKey | null {
    return this.fronsTokenMint;
  }
}

export const solanaService = new SolanaService();
