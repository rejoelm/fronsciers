import { db } from "../db";
import { users, manuscripts } from "@shared/schema";
import { eq } from "drizzle-orm";

export async function seedDatabase() {
  try {
    // Check if sample data already exists
    const existingManuscripts = await db.select().from(manuscripts).limit(1);
    if (existingManuscripts.length > 0) return;

    console.log("Seeding database with research papers...");

    // Create sample users
    const sampleUsers = [
      {
        walletAddress: "8K7S2vP3mN5qR9tY6fH4jL1wE3xC8zV2pQ9mN7sK4fH6",
        username: "dr_researcher",
        email: "researcher@university.edu"
      },
      {
        walletAddress: "5M2nP8kL9rS3vT7yF1qH6jW4eR2xN9mQ5pL8sK3fG7h",
        username: "prof_science",
        email: "professor@institute.org"
      },
      {
        walletAddress: "3Q9mK5hF2nL7sP4tY8rW1vE6jH3xC9zN2pQ7mK5fG4h",
        username: "lab_director",
        email: "director@research.lab"
      }
    ];

    const createdUsers = await Promise.all(
      sampleUsers.map(async (user) => {
        const [createdUser] = await db.insert(users).values(user).returning();
        return createdUser;
      })
    );

    // Create comprehensive research manuscripts
    const sampleManuscripts = [
      {
        title: "Blockchain-Based Academic Publishing: A Decentralized Approach to Scholarly Communication",
        abstract: "This paper introduces a novel blockchain-based system for academic publishing that addresses the current challenges in scholarly communication. Our approach leverages distributed ledger technology to ensure transparency, immutability, and democratic governance in the peer review process. We present FRONSCIERS, a platform that combines NFT-based document certification with decentralized autonomous organization (DAO) governance, enabling researchers to maintain ownership of their work while facilitating open collaboration.",
        authors: "Dr. Sarah Chen, Prof. Michael Rodriguez, Dr. Anna Thompson",
        keywords: "blockchain, academic publishing, peer review, NFT, DAO, scholarly communication",
        researchField: "Computer Science",
        userId: createdUsers[0].id,
        status: "accepted" as const,
        dociMinted: true,
        ipfsHash: "QmYjtig7VJQ6XsnUjqqJvj7QaMcCAwtrgNdahSiFofrE7o",
        citationCount: 15,
        viewCount: 342
      },
      {
        title: "Machine Learning Applications in Climate Change Prediction: A Comprehensive Review",
        abstract: "Climate change represents one of the most pressing challenges of our time. This comprehensive review examines the application of machine learning techniques in climate modeling and prediction. We analyze various ML algorithms including neural networks, support vector machines, and ensemble methods, evaluating their effectiveness in processing large-scale climate datasets. Our findings suggest that deep learning approaches show particular promise for long-term climate forecasting.",
        authors: "Dr. Elena Volkov, Prof. James Patterson, Dr. Liu Wei",
        keywords: "machine learning, climate change, neural networks, prediction models, environmental science",
        researchField: "Environmental Science",
        userId: createdUsers[1].id,
        status: "accepted" as const,
        dociMinted: true,
        ipfsHash: "QmPK4VJQ6XsnUjqqJvj7QaMcCAwtrgNdahSiFofrE7o9m",
        citationCount: 28,
        viewCount: 567
      },
      {
        title: "CRISPR-Cas9 Gene Editing: Ethical Considerations and Regulatory Frameworks",
        abstract: "The advent of CRISPR-Cas9 technology has revolutionized genetic engineering, offering unprecedented precision in gene editing. However, its application raises significant ethical and regulatory questions. This paper examines the current ethical frameworks surrounding CRISPR usage, analyzes international regulatory approaches, and proposes guidelines for responsible implementation. We discuss the balance between scientific advancement and ethical responsibility, particularly in human embryo editing and germline modifications.",
        authors: "Dr. Maria Gonzalez, Prof. Robert Kim, Dr. Ahmed Hassan",
        keywords: "CRISPR, gene editing, bioethics, regulation, genetic engineering, biotechnology",
        researchField: "Biology",
        userId: createdUsers[2].id,
        status: "accepted" as const,
        dociMinted: false,
        ipfsHash: "QmR8VJQ6XsnUjqqJvj7QaMcCAwtrgNdahSiFofrE7o3k",
        citationCount: 42,
        viewCount: 789
      },
      {
        title: "Quantum Computing and Cryptography: Implications for Cybersecurity",
        abstract: "As quantum computing technology advances, it poses both opportunities and threats to current cryptographic systems. This research investigates the impact of quantum algorithms on classical encryption methods and explores quantum-resistant cryptographic protocols. We analyze the timeline for quantum supremacy in cryptanalysis and present recommendations for transitioning to post-quantum cryptography. Our work contributes to the ongoing effort to secure digital communications in the quantum era.",
        authors: "Dr. Alex Turner, Prof. Yuki Tanaka, Dr. Sophie Martin",
        keywords: "quantum computing, cryptography, cybersecurity, post-quantum, encryption",
        researchField: "Computer Science",
        userId: createdUsers[0].id,
        status: "submitted" as const,
        dociMinted: false,
        ipfsHash: "QmT7VJQ6XsnUjqqJvj7QaMcCAwtrgNdahSiFofrE7o5n",
        citationCount: 8,
        viewCount: 234
      },
      {
        title: "Renewable Energy Storage: Advances in Battery Technology and Grid Integration",
        abstract: "The transition to renewable energy requires efficient storage solutions to address intermittency challenges. This study examines recent advances in battery technology, including lithium-ion improvements, solid-state batteries, and alternative chemistries. We analyze grid integration strategies and economic implications of large-scale energy storage deployment. Our research provides insights into the technological and policy pathways necessary for achieving a sustainable energy future.",
        authors: "Dr. Patricia Williams, Prof. Hans Mueller, Dr. Raj Patel",
        keywords: "renewable energy, battery technology, grid integration, energy storage, sustainability",
        researchField: "Engineering",
        userId: createdUsers[1].id,
        status: "accepted" as const,
        dociMinted: true,
        ipfsHash: "QmU9VJQ6XsnUjqqJvj7QaMcCAwtrgNdahSiFofrE7o6p",
        citationCount: 35,
        viewCount: 456
      },
      {
        title: "Neuroplasticity in Aging: Cognitive Training and Brain Health",
        abstract: "Understanding neuroplasticity in aging populations is crucial for developing interventions to maintain cognitive health. This longitudinal study examines the effects of structured cognitive training on brain plasticity in adults over 65. Using neuroimaging and cognitive assessments, we demonstrate that targeted training can enhance neural connectivity and improve cognitive performance. Our findings support the potential for non-pharmacological interventions in age-related cognitive decline.",
        authors: "Dr. Rebecca Stone, Prof. Carlos Mendez, Dr. Ingrid Larsson",
        keywords: "neuroplasticity, aging, cognitive training, brain health, neuroscience",
        researchField: "Medicine",
        userId: createdUsers[2].id,
        status: "under_review" as const,
        dociMinted: false,
        ipfsHash: "QmV1VJQ6XsnUjqqJvj7QaMcCAwtrgNdahSiFofrE7o7q",
        citationCount: 0,
        viewCount: 123
      },
      {
        title: "Artificial Intelligence in Drug Discovery: Accelerating Pharmaceutical Research",
        abstract: "The pharmaceutical industry faces significant challenges in drug discovery, including high costs, lengthy timelines, and low success rates. This research explores the application of artificial intelligence and machine learning in accelerating drug discovery processes. We examine AI-driven approaches for target identification, compound screening, and clinical trial optimization. Our analysis demonstrates that AI integration can reduce discovery timelines by up to 40% while improving success rates in early-stage development.",
        authors: "Dr. Jennifer Walsh, Prof. David Chen, Dr. Mikhail Petrov",
        keywords: "artificial intelligence, drug discovery, pharmaceutical research, machine learning, healthcare",
        researchField: "Medicine",
        userId: createdUsers[0].id,
        status: "accepted" as const,
        dociMinted: true,
        ipfsHash: "QmW2VJQ6XsnUjqqJvj7QaMcCAwtrgNdahSiFofrE7o8r",
        citationCount: 23,
        viewCount: 445
      },
      {
        title: "Sustainable Agriculture Through Precision Farming: IoT and Data Analytics",
        abstract: "Modern agriculture faces the challenge of feeding a growing global population while minimizing environmental impact. This study investigates the implementation of precision farming techniques using Internet of Things (IoT) sensors and advanced data analytics. We present a comprehensive framework for optimizing crop yields, reducing resource consumption, and enhancing soil health through real-time monitoring and predictive modeling. Field trials demonstrate significant improvements in efficiency and sustainability metrics.",
        authors: "Dr. Amanda Foster, Prof. Giovanni Rossi, Dr. Kenji Nakamura",
        keywords: "precision farming, IoT, sustainable agriculture, data analytics, environmental conservation",
        researchField: "Agriculture",
        userId: createdUsers[1].id,
        status: "accepted" as const,
        dociMinted: false,
        ipfsHash: "QmX3VJQ6XsnUjqqJvj7QaMcCAwtrgNdahSiFofrE7o9s",
        citationCount: 19,
        viewCount: 298
      },
      {
        title: "Space Debris Mitigation: Advanced Tracking and Removal Technologies",
        abstract: "The proliferation of space debris poses a growing threat to operational satellites and space missions. This research presents novel approaches for space debris tracking, characterization, and active removal. We develop advanced radar algorithms for improved debris detection and propose cost-effective removal strategies using autonomous spacecraft. Our simulations demonstrate the feasibility of reducing debris populations in critical orbital regions, contributing to long-term space sustainability.",
        authors: "Dr. Lisa Park, Prof. Andreas Weber, Dr. Priya Sharma",
        keywords: "space debris, orbital mechanics, satellite safety, space sustainability, autonomous systems",
        researchField: "Physics",
        userId: createdUsers[2].id,
        status: "submitted" as const,
        dociMinted: false,
        ipfsHash: "QmY4VJQ6XsnUjqqJvj7QaMcCAwtrgNdahSiFofrE7o1t",
        citationCount: 7,
        viewCount: 156
      },
      {
        title: "Social Media Analytics for Public Health Monitoring: Early Disease Detection",
        abstract: "Social media platforms generate vast amounts of health-related data that can be leveraged for public health surveillance. This study develops natural language processing techniques to analyze social media posts for early detection of disease outbreaks and health trends. We present a real-time monitoring system that complements traditional epidemiological surveillance methods. Validation during recent health events demonstrates the system's effectiveness in providing early warning signals for public health authorities.",
        authors: "Dr. Thomas Anderson, Prof. Maria Santos, Dr. Omar Ibrahim",
        keywords: "social media analytics, public health, disease surveillance, natural language processing, epidemiology",
        researchField: "Medicine",
        userId: createdUsers[0].id,
        status: "under_review" as const,
        dociMinted: false,
        ipfsHash: "QmZ5VJQ6XsnUjqqJvj7QaMcCAwtrgNdahSiFofrE7o2u",
        citationCount: 3,
        viewCount: 187
      }
    ];

    await Promise.all(
      sampleManuscripts.map(async (manuscript) => {
        await db.insert(manuscripts).values(manuscript);
      })
    );

    console.log(`Successfully seeded database with ${sampleManuscripts.length} research papers`);
  } catch (error) {
    console.error("Error seeding database:", error);
  }
}