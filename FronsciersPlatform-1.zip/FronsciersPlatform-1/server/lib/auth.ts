import jwt from 'jsonwebtoken';
import bcrypt from 'bcrypt';
import { Request, Response, NextFunction } from 'express';
import { storage } from '../storage';

const JWT_SECRET = process.env.JWT_SECRET || 'fronsciers-dev-secret-2025';
const JWT_EXPIRES_IN = '7d';
const SALT_ROUNDS = 12;

export interface AuthenticatedRequest extends Request {
  user?: {
    id: number;
    walletAddress: string;
    username?: string;
    email?: string;
  };
}

export class AuthService {
  static generateToken(userId: number, walletAddress: string): string {
    return jwt.sign(
      { userId, walletAddress },
      JWT_SECRET,
      { expiresIn: JWT_EXPIRES_IN }
    );
  }

  static verifyToken(token: string): { userId: number; walletAddress: string } | null {
    try {
      const decoded = jwt.verify(token, JWT_SECRET) as any;
      return { userId: decoded.userId, walletAddress: decoded.walletAddress };
    } catch (error) {
      return null;
    }
  }

  static async hashPassword(password: string): Promise<string> {
    return bcrypt.hash(password, SALT_ROUNDS);
  }

  static async verifyPassword(password: string, hashedPassword: string): Promise<boolean> {
    return bcrypt.compare(password, hashedPassword);
  }

  static async authenticateWallet(walletAddress: string, signature?: string): Promise<{ user: any; token: string } | null> {
    try {
      // Check if user exists with this wallet address
      let user = await storage.getUserByWalletAddress(walletAddress);
      
      if (!user) {
        // Create new user if doesn't exist
        user = await storage.createUser({
          walletAddress,
          reputationScore: 0,
          fronsBalance: 0,
          stakedFrons: 0,
        });
      }

      const token = AuthService.generateToken(user.id, user.walletAddress);
      
      return {
        user: {
          id: user.id,
          walletAddress: user.walletAddress,
          username: user.username,
          email: user.email,
          institutionName: user.institutionName,
          researchField: user.researchField,
          reputationScore: user.reputationScore,
          fronsBalance: user.fronsBalance,
          stakedFrons: user.stakedFrons,
        },
        token
      };
    } catch (error) {
      console.error('Authentication error:', error);
      return null;
    }
  }

  static authenticateToken(req: AuthenticatedRequest, res: Response, next: NextFunction) {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1]; // Bearer TOKEN

    if (!token) {
      return res.status(401).json({ message: 'Access token required' });
    }

    const decoded = AuthService.verifyToken(token);
    if (!decoded) {
      return res.status(403).json({ message: 'Invalid or expired token' });
    }

    req.user = { id: decoded.userId, walletAddress: decoded.walletAddress };
    next();
  }

  static optionalAuth(req: AuthenticatedRequest, res: Response, next: NextFunction) {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];

    if (token) {
      const decoded = AuthService.verifyToken(token);
      if (decoded) {
        req.user = { id: decoded.userId, walletAddress: decoded.walletAddress };
      }
    }

    next();
  }
}

export const requireAuth = AuthService.authenticateToken;
export const optionalAuth = AuthService.optionalAuth;