import { storage } from '../storage';
import {
  User,
  Manuscript,
  Review,
  InsertReview,
  PeerReviewAssignment,
  InsertPeerReviewAssignment,
  ReputationHistory,
  InsertReputationHistory,
  ReviewerExpertise,
  InsertReviewerExpertise
} from '@shared/schema';

export interface ReviewerMatch {
  reviewer: User;
  matchScore: number;
  expertiseMatch: number;
  availabilityScore: number;
  reputationScore: number;
  workloadScore: number;
  reasons: string[];
}

export interface ReviewQualityMetrics {
  thoroughness: number;
  timeliness: number;
  constructiveness: number;
  accuracy: number;
  overall: number;
}

export class PeerReviewService {
  private static readonly REVIEWER_WORKLOAD_LIMIT = 5; // max active reviews
  private static readonly REVIEW_DEADLINE_DAYS = 21;
  private static readonly RESPONSE_DEADLINE_DAYS = 7;

  // Reputation scoring constants
  private static readonly REPUTATION_REWARDS = {
    REVIEW_COMPLETED: 50,
    HIGH_QUALITY_REVIEW: 25,
    DEADLINE_MET: 15,
    QUICK_RESPONSE: 10,
    EXPERTISE_MATCH_BONUS: 20,
  };

  private static readonly REPUTATION_PENALTIES = {
    DEADLINE_MISSED: -30,
    LOW_QUALITY_REVIEW: -20,
    DECLINED_ASSIGNMENT: -5,
    NO_RESPONSE: -15,
  };

  // Find optimal reviewers for a manuscript using advanced matching algorithms
  static async findOptimalReviewers(
    manuscriptId: number,
    requiredReviewers: number = 3
  ): Promise<ReviewerMatch[]> {
    const manuscript = await storage.getManuscript(manuscriptId);
    if (!manuscript) throw new Error('Manuscript not found');

    const allUsers = await storage.getAllUsers();
    const potentialReviewers = allUsers.filter(user => 
      user.id !== manuscript.userId && // exclude author
      user.isVerifiedReviewer // only verified reviewers
    );

    const reviewerMatches: ReviewerMatch[] = [];

    for (const reviewer of potentialReviewers) {
      const match = await this.calculateReviewerMatch(reviewer, manuscript);
      if (match.matchScore > 30) { // minimum threshold
        reviewerMatches.push(match);
      }
    }

    // Sort by match score and return top candidates
    return reviewerMatches
      .sort((a, b) => b.matchScore - a.matchScore)
      .slice(0, requiredReviewers * 2); // return double to allow selection
  }

  // Calculate comprehensive reviewer-manuscript matching score
  private static async calculateReviewerMatch(
    reviewer: User,
    manuscript: Manuscript
  ): Promise<ReviewerMatch> {
    const expertiseMatch = await this.calculateExpertiseMatch(reviewer, manuscript);
    const availabilityScore = await this.calculateAvailabilityScore(reviewer);
    const reputationScore = this.calculateReputationScore(reviewer);
    const workloadScore = await this.calculateWorkloadScore(reviewer);

    // Weighted scoring algorithm
    const matchScore = Math.round(
      expertiseMatch * 0.4 +
      reputationScore * 0.25 +
      availabilityScore * 0.2 +
      workloadScore * 0.15
    );

    const reasons = this.generateMatchReasons(
      expertiseMatch,
      reputationScore,
      availabilityScore,
      workloadScore
    );

    return {
      reviewer,
      matchScore,
      expertiseMatch,
      availabilityScore,
      reputationScore,
      workloadScore,
      reasons
    };
  }

  // Calculate expertise match between reviewer and manuscript
  private static async calculateExpertiseMatch(
    reviewer: User,
    manuscript: Manuscript
  ): Promise<number> {
    const reviewerExpertise = await storage.getReviewerExpertiseByUser(reviewer.id);
    
    // Primary field match
    let expertiseScore = 0;
    const manuscriptField = manuscript.researchField.toLowerCase();
    
    for (const expertise of reviewerExpertise) {
      if (expertise.researchField.toLowerCase() === manuscriptField) {
        expertiseScore += (expertise.expertiseLevel || 1) * 20;
      }
      
      // Check subfield matches
      if (expertise.subfields) {
        const manuscriptKeywords = manuscript.keywords.toLowerCase().split(',');
        for (const subfield of expertise.subfields) {
          if (manuscriptKeywords.some(keyword => 
            keyword.trim().includes(subfield.toLowerCase())
          )) {
            expertiseScore += (expertise.expertiseLevel || 1) * 10;
          }
        }
      }
    }

    // General field compatibility
    if (reviewer.researchField && 
        reviewer.researchField.toLowerCase() === manuscriptField) {
      expertiseScore += 30;
    }

    return Math.min(expertiseScore, 100);
  }

  // Calculate reviewer availability based on recent activity and workload
  private static async calculateAvailabilityScore(reviewer: User): Promise<number> {
    const now = new Date();
    const lastActive = reviewer.lastActiveAt ? new Date(reviewer.lastActiveAt) : new Date(0);
    const daysSinceActive = Math.floor((now.getTime() - lastActive.getTime()) / (1000 * 3600 * 24));

    // Recent activity score
    let availabilityScore = 100;
    if (daysSinceActive > 30) availabilityScore -= 30;
    else if (daysSinceActive > 14) availabilityScore -= 15;
    else if (daysSinceActive > 7) availabilityScore -= 5;

    // Response time factor
    if (reviewer.reviewResponseTime) {
      if (reviewer.reviewResponseTime > 72) availabilityScore -= 20;
      else if (reviewer.reviewResponseTime > 48) availabilityScore -= 10;
      else if (reviewer.reviewResponseTime <= 24) availabilityScore += 10;
    }

    return Math.max(availabilityScore, 0);
  }

  // Calculate reputation-based scoring
  private static calculateReputationScore(reviewer: User): number {
    let score = reviewer.reputationScore || 0;
    
    // Normalize to 0-100 scale
    score = Math.min(score / 10, 100);
    
    // Quality factor
    if (reviewer.avgReviewQuality) {
      score = (score + reviewer.avgReviewQuality) / 2;
    }

    // Experience factor
    const reviewCount = reviewer.reviewsCompleted || 0;
    if (reviewCount > 50) score += 15;
    else if (reviewCount > 20) score += 10;
    else if (reviewCount > 10) score += 5;

    // Reviewer level bonus
    const levelBonus = {
      'distinguished': 20,
      'expert': 15,
      'intermediate': 10,
      'novice': 0
    };
    score += levelBonus[reviewer.reviewerLevel as keyof typeof levelBonus] || 0;

    return Math.min(score, 100);
  }

  // Calculate current workload impact on availability
  private static async calculateWorkloadScore(reviewer: User): Promise<number> {
    const activeAssignments = await storage.getPeerReviewAssignmentsByReviewer(reviewer.id);
    const activeCount = activeAssignments.filter(assignment => 
      assignment.status === 'assigned' || assignment.status === 'accepted'
    ).length;

    if (activeCount >= this.REVIEWER_WORKLOAD_LIMIT) return 0;
    if (activeCount >= this.REVIEWER_WORKLOAD_LIMIT - 1) return 25;
    if (activeCount >= this.REVIEWER_WORKLOAD_LIMIT - 2) return 50;
    return 100;
  }

  // Generate human-readable reasons for the match
  private static generateMatchReasons(
    expertiseMatch: number,
    reputationScore: number,
    availabilityScore: number,
    workloadScore: number
  ): string[] {
    const reasons = [];

    if (expertiseMatch > 80) reasons.push('Excellent expertise match');
    else if (expertiseMatch > 60) reasons.push('Good expertise match');
    else if (expertiseMatch > 40) reasons.push('Moderate expertise match');

    if (reputationScore > 80) reasons.push('High reputation reviewer');
    else if (reputationScore > 60) reasons.push('Experienced reviewer');

    if (availabilityScore > 80) reasons.push('Recently active');
    else if (availabilityScore < 40) reasons.push('Limited recent activity');

    if (workloadScore > 80) reasons.push('Low current workload');
    else if (workloadScore < 40) reasons.push('High current workload');

    return reasons;
  }

  // Assign reviewers to manuscript with intelligent assignment
  static async assignReviewers(
    manuscriptId: number,
    reviewerIds: number[],
    assignedBy: number
  ): Promise<PeerReviewAssignment[]> {
    const assignments: PeerReviewAssignment[] = [];
    const now = new Date();
    const responseDeadline = new Date(now.getTime() + this.RESPONSE_DEADLINE_DAYS * 24 * 60 * 60 * 1000);
    const reviewDeadline = new Date(now.getTime() + this.REVIEW_DEADLINE_DAYS * 24 * 60 * 60 * 1000);

    for (const reviewerId of reviewerIds) {
      const assignmentData: InsertPeerReviewAssignment = {
        manuscriptId,
        reviewerId,
        assignedBy,
        responseDeadline,
        reviewDeadline,
        invitationSent: false,
        status: 'assigned'
      };

      const assignment = await storage.createPeerReviewAssignment(assignmentData);
      assignments.push(assignment);
    }

    return assignments;
  }

  // Process review submission with quality assessment
  static async submitReview(
    reviewId: number,
    reviewData: Partial<InsertReview>
  ): Promise<{ review: Review; reputationImpact: number }> {
    const review = await storage.updateReview(reviewId, {
      ...reviewData,
      status: 'submitted',
      submittedAt: new Date()
    });

    if (!review) throw new Error('Review not found');

    // Calculate quality metrics and reputation impact
    const qualityMetrics = this.assessReviewQuality(review);
    const reputationImpact = await this.calculateReputationImpact(review, qualityMetrics);

    // Update review with quality assessment
    await storage.updateReview(reviewId, {
      qualityRating: qualityMetrics.overall,
      reputationImpact
    });

    // Update reviewer reputation
    await this.updateReviewerReputation(review.reviewerId!, reputationImpact, review);

    return { review, reputationImpact };
  }

  // Assess review quality using multiple criteria
  private static assessReviewQuality(review: Review): ReviewQualityMetrics {
    const scores = {
      noveltyScore: review.noveltyScore || 0,
      methodologyScore: review.methodologyScore || 0,
      clarityScore: review.clarityScore || 0,
      significanceScore: review.significanceScore || 0,
      presentationScore: review.presentationScore || 0
    };

    const avgScore = Object.values(scores).reduce((sum, score) => sum + score, 0) / Object.keys(scores).length;

    // Thoroughness based on completeness of scores and comments
    const thoroughness = Math.min(
      (Object.values(scores).filter(score => score > 0).length / Object.keys(scores).length) * 100,
      review.comments ? Math.min(review.comments.length / 200, 1) * 100 : 50
    );

    // Timeliness based on submission vs deadline
    let timeliness = 100;
    if (review.submittedAt && review.deadline && review.createdAt) {
      const submittedDate = new Date(review.submittedAt);
      const deadlineDate = new Date(review.deadline);
      const createdDate = new Date(review.createdAt);
      const timeToComplete = submittedDate.getTime() - createdDate.getTime();
      const timeAllowed = deadlineDate.getTime() - createdDate.getTime();
      const timeRatio = timeToComplete / timeAllowed;
      
      if (timeRatio > 1) timeliness = 0; // late submission
      else timeliness = Math.max(0, 100 - (timeRatio * 50));
    }

    // Constructiveness based on detailed comments and recommendations
    const constructiveness = review.comments 
      ? Math.min(review.comments.length / 300, 1) * 100 
      : 30;

    // Accuracy estimated based on score consistency and confidence
    const scoreVariance = Object.values(scores).reduce((variance, score) => {
      return variance + Math.pow(score - avgScore, 2);
    }, 0) / Object.keys(scores).length;
    
    const accuracy = Math.max(0, 100 - (scoreVariance * 5));

    const overall = Math.round(
      thoroughness * 0.3 +
      timeliness * 0.25 +
      constructiveness * 0.25 +
      accuracy * 0.2
    );

    return {
      thoroughness: Math.round(thoroughness),
      timeliness: Math.round(timeliness),
      constructiveness: Math.round(constructiveness),
      accuracy: Math.round(accuracy),
      overall
    };
  }

  // Calculate reputation impact based on review quality and performance
  private static async calculateReputationImpact(
    review: Review,
    qualityMetrics: ReviewQualityMetrics
  ): Promise<number> {
    let impact = this.REPUTATION_REWARDS.REVIEW_COMPLETED;

    // Quality bonus/penalty
    if (qualityMetrics.overall >= 80) {
      impact += this.REPUTATION_REWARDS.HIGH_QUALITY_REVIEW;
    } else if (qualityMetrics.overall < 50) {
      impact += this.REPUTATION_PENALTIES.LOW_QUALITY_REVIEW;
    }

    // Timeliness bonus/penalty
    if (qualityMetrics.timeliness >= 90) {
      impact += this.REPUTATION_REWARDS.DEADLINE_MET;
    } else if (qualityMetrics.timeliness === 0) {
      impact += this.REPUTATION_PENALTIES.DEADLINE_MISSED;
    }

    // Expertise match bonus
    if (review.expertiseMatch && review.expertiseMatch >= 80) {
      impact += this.REPUTATION_REWARDS.EXPERTISE_MATCH_BONUS;
    }

    return impact;
  }

  // Update reviewer's reputation and related metrics
  private static async updateReviewerReputation(
    reviewerId: number,
    reputationImpact: number,
    review: Review
  ): Promise<void> {
    const reviewer = await storage.getUser(reviewerId);
    if (!reviewer) return;

    // Update reputation score
    const newReputationScore = (reviewer.reputationScore || 0) + reputationImpact;
    const newReviewsCompleted = (reviewer.reviewsCompleted || 0) + 1;

    // Update average review quality
    const currentAvgQuality = reviewer.avgReviewQuality || 0;
    const newAvgQuality = Math.round(
      (currentAvgQuality * (newReviewsCompleted - 1) + (review.qualityRating || 0)) / newReviewsCompleted
    );

    // Update reviewer level based on reputation and experience
    const newReviewerLevel = this.calculateReviewerLevel(newReputationScore, newReviewsCompleted);

    await storage.updateUser(reviewerId, {
      reputationScore: newReputationScore,
      reviewsCompleted: newReviewsCompleted,
      avgReviewQuality: newAvgQuality,
      reviewerLevel: newReviewerLevel,
      lastActiveAt: new Date()
    });

    // Record reputation history
    const historyData: InsertReputationHistory = {
      userId: reviewerId,
      action: 'review_completed',
      points: reputationImpact,
      reviewId: review.id,
      description: `Review completed with quality score ${review.qualityRating}`
    };

    await storage.createReputationHistory(historyData);
  }

  // Calculate reviewer level based on reputation and experience
  private static calculateReviewerLevel(
    reputationScore: number,
    reviewsCompleted: number
  ): string {
    if (reputationScore >= 2000 && reviewsCompleted >= 100) return 'distinguished';
    if (reputationScore >= 1000 && reviewsCompleted >= 50) return 'expert';
    if (reputationScore >= 500 && reviewsCompleted >= 20) return 'intermediate';
    return 'novice';
  }

  // Get comprehensive reviewer statistics
  static async getReviewerStats(reviewerId: number) {
    const reviewer = await storage.getUser(reviewerId);
    if (!reviewer) throw new Error('Reviewer not found');

    const reputationHistory = await storage.getReputationHistoryByUser(reviewerId);
    const reviews = await storage.getReviewsByReviewer(reviewerId);
    const assignments = await storage.getPeerReviewAssignmentsByReviewer(reviewerId);

    // Calculate various metrics
    const completedReviews = reviews.filter(r => r.status === 'completed').length;
    const avgTimeToComplete = reviews
      .filter(r => r.timeToComplete)
      .reduce((sum, r) => sum + (r.timeToComplete || 0), 0) / completedReviews || 0;

    const onTimeReviews = reviews.filter(r => 
      r.submittedAt && r.deadline && 
      new Date(r.submittedAt) <= new Date(r.deadline)
    ).length;

    const onTimeRate = completedReviews > 0 ? (onTimeReviews / completedReviews) * 100 : 0;

    return {
      reviewer,
      stats: {
        totalReviews: completedReviews,
        avgQuality: reviewer.avgReviewQuality || 0,
        avgTimeToComplete: Math.round(avgTimeToComplete),
        onTimeRate: Math.round(onTimeRate),
        reputationScore: reviewer.reputationScore || 0,
        level: reviewer.reviewerLevel,
        recentActivity: reputationHistory.slice(-10)
      }
    };
  }

  // Handle reviewer response to assignment
  static async respondToAssignment(
    assignmentId: number,
    response: 'accepted' | 'declined',
    declineReason?: string
  ): Promise<PeerReviewAssignment> {
    const assignment = await storage.updatePeerReviewAssignment(assignmentId, {
      status: response,
      respondedAt: new Date(),
      declineReason: response === 'declined' ? declineReason : undefined
    });

    if (!assignment) throw new Error('Assignment not found');

    // Update reviewer reputation based on response
    if (response === 'declined') {
      const reviewer = await storage.getUser(assignment.reviewerId);
      if (reviewer) {
        const newReputationScore = (reviewer.reputationScore || 0) + this.REPUTATION_PENALTIES.DECLINED_ASSIGNMENT;
        await storage.updateUser(assignment.reviewerId, {
          reputationScore: newReputationScore,
          lastActiveAt: new Date()
        });

        // Record reputation history
        const historyData: InsertReputationHistory = {
          userId: assignment.reviewerId,
          action: 'declined_assignment',
          points: this.REPUTATION_PENALTIES.DECLINED_ASSIGNMENT,
          description: `Declined review assignment: ${declineReason || 'No reason provided'}`
        };
        await storage.createReputationHistory(historyData);
      }
    }

    return assignment;
  }
}