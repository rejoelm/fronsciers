import { storage } from '../storage';
import { solanaService } from './solana';
import { PublicKey } from '@solana/web3.js';
import cron from 'node-cron';

export interface TokenReward {
  userId: number;
  amount: number;
  type: 'review' | 'submission_fee' | 'publication' | 'citation' | 'staking' | 'governance';
  description: string;
  transactionHash?: string;
  manuscriptId?: number;
  proposalId?: number;
}

export class TokenomicsService {
  // FRONS token reward amounts
  private static readonly REWARDS = {
    MANUSCRIPT_SUBMISSION: 10,
    PEER_REVIEW_COMPLETION: 75,
    SUCCESSFUL_PUBLICATION: 100,
    CITATION_RECEIVED: 5,
    DAO_PROPOSAL_CREATION: 25,
    DAO_VOTING_PARTICIPATION: 2,
    QUALITY_REVIEW_BONUS: 50,
    STAKING_DAILY_RATE: 0.01, // 1% daily
  };

  private static readonly FEES = {
    MANUSCRIPT_SUBMISSION: 10,
    DOCI_MINTING: 5,
    PRIORITY_REVIEW: 25,
  };

  static async rewardPeerReview(reviewerId: number, manuscriptId: number, qualityScore?: number): Promise<TokenReward> {
    const baseReward = this.REWARDS.PEER_REVIEW_COMPLETION;
    const qualityBonus = qualityScore && qualityScore >= 8 ? this.REWARDS.QUALITY_REVIEW_BONUS : 0;
    const totalReward = baseReward + qualityBonus;

    // Get reviewer's wallet address
    const reviewer = await storage.getUser(reviewerId);
    if (!reviewer?.walletAddress) {
      throw new Error('Reviewer wallet address not found');
    }

    // Mint FRONS tokens to reviewer
    const txSignature = await solanaService.mintFronsTokens(
      new PublicKey(reviewer.walletAddress),
      totalReward
    );

    // Update user's FRONS balance
    await storage.updateUser(reviewerId, {
      fronsBalance: (reviewer.fronsBalance || 0) + totalReward,
      reputationScore: (reviewer.reputationScore || 0) + 10
    });

    // Record transaction
    await storage.createTransaction({
      userId: reviewerId,
      type: 'reward',
      amount: totalReward,
      status: 'completed',
      transactionHash: txSignature
    });

    return {
      userId: reviewerId,
      amount: totalReward,
      type: 'review',
      description: `Peer review reward${qualityBonus > 0 ? ' with quality bonus' : ''}`,
      transactionHash: txSignature,
      manuscriptId
    };
  }

  static async processSubmissionFee(userId: number, manuscriptId: number): Promise<TokenReward> {
    const fee = this.FEES.MANUSCRIPT_SUBMISSION;
    
    const user = await storage.getUser(userId);
    if (!user?.walletAddress) {
      throw new Error('User wallet address not found');
    }

    if ((user.fronsBalance || 0) < fee) {
      throw new Error('Insufficient FRONS balance for submission fee');
    }

    // Deduct fee from user's balance
    await storage.updateUser(userId, {
      fronsBalance: (user.fronsBalance || 0) - fee
    });

    // Record transaction
    await storage.createTransaction({
      userId,
      type: 'fee',
      amount: -fee,
      status: 'completed'
    });

    return {
      userId,
      amount: -fee,
      type: 'submission_fee',
      description: 'Manuscript submission fee',
      manuscriptId
    };
  }

  static async rewardPublication(authorId: number, manuscriptId: number): Promise<TokenReward> {
    const reward = this.REWARDS.SUCCESSFUL_PUBLICATION;
    
    const author = await storage.getUser(authorId);
    if (!author?.walletAddress) {
      throw new Error('Author wallet address not found');
    }

    // Mint FRONS tokens to author
    const txSignature = await solanaService.mintFronsTokens(
      new PublicKey(author.walletAddress),
      reward
    );

    // Update user's balance and reputation
    await storage.updateUser(authorId, {
      fronsBalance: (author.fronsBalance || 0) + reward,
      reputationScore: (author.reputationScore || 0) + 25
    });

    // Record transaction
    await storage.createTransaction({
      userId: authorId,
      type: 'reward',
      amount: reward,
      status: 'completed',
      transactionHash: txSignature
    });

    return {
      userId: authorId,
      amount: reward,
      type: 'publication',
      description: 'Successful publication reward',
      transactionHash: txSignature,
      manuscriptId
    };
  }

  static async rewardCitation(authorId: number, manuscriptId: number): Promise<TokenReward> {
    const reward = this.REWARDS.CITATION_RECEIVED;
    
    const author = await storage.getUser(authorId);
    if (!author?.walletAddress) {
      throw new Error('Author wallet address not found');
    }

    // Mint FRONS tokens to author
    const txSignature = await solanaService.mintFronsTokens(
      new PublicKey(author.walletAddress),
      reward
    );

    // Update user's balance and reputation
    await storage.updateUser(authorId, {
      fronsBalance: (author.fronsBalance || 0) + reward,
      reputationScore: (author.reputationScore || 0) + 2
    });

    // Record transaction
    await storage.createTransaction({
      userId: authorId,
      type: 'reward',
      amount: reward,
      status: 'completed',
      transactionHash: txSignature
    });

    return {
      userId: authorId,
      amount: reward,
      type: 'citation',
      description: 'Citation reward',
      transactionHash: txSignature,
      manuscriptId
    };
  }

  static async stakeTokens(userId: number, amount: number): Promise<TokenReward> {
    const user = await storage.getUser(userId);
    if (!user) {
      throw new Error('User not found');
    }

    if ((user.fronsBalance || 0) < amount) {
      throw new Error('Insufficient FRONS balance for staking');
    }

    // Move tokens from balance to staked
    await storage.updateUser(userId, {
      fronsBalance: (user.fronsBalance || 0) - amount,
      stakedFrons: (user.stakedFrons || 0) + amount
    });

    // Record transaction
    await storage.createTransaction({
      userId,
      type: 'stake',
      amount,
      status: 'completed'
    });

    return {
      userId,
      amount,
      type: 'staking',
      description: `Staked ${amount} FRONS tokens`
    };
  }

  static async unstakeTokens(userId: number, amount: number): Promise<TokenReward> {
    const user = await storage.getUser(userId);
    if (!user) {
      throw new Error('User not found');
    }

    if ((user.stakedFrons || 0) < amount) {
      throw new Error('Insufficient staked FRONS for unstaking');
    }

    // Move tokens from staked back to balance
    await storage.updateUser(userId, {
      fronsBalance: (user.fronsBalance || 0) + amount,
      stakedFrons: (user.stakedFrons || 0) - amount
    });

    // Record transaction
    await storage.createTransaction({
      userId,
      type: 'unstake',
      amount,
      status: 'completed'
    });

    return {
      userId,
      amount,
      type: 'staking',
      description: `Unstaked ${amount} FRONS tokens`
    };
  }

  static async distributeStakingRewards(): Promise<TokenReward[]> {
    const allUsers = await storage.getAllUsers();
    const rewards: TokenReward[] = [];

    for (const user of allUsers) {
      if ((user.stakedFrons || 0) > 0) {
        const dailyReward = Math.floor((user.stakedFrons || 0) * this.REWARDS.STAKING_DAILY_RATE);
        
        if (dailyReward > 0 && user.walletAddress) {
          try {
            // Mint staking rewards
            const txSignature = await solanaService.mintFronsTokens(
              new PublicKey(user.walletAddress),
              dailyReward
            );

            // Update user's balance
            await storage.updateUser(user.id, {
              fronsBalance: (user.fronsBalance || 0) + dailyReward
            });

            // Record transaction
            await storage.createTransaction({
              userId: user.id,
              type: 'reward',
              amount: dailyReward,
              status: 'completed',
              transactionHash: txSignature
            });

            rewards.push({
              userId: user.id,
              amount: dailyReward,
              type: 'staking',
              description: 'Daily staking reward',
              transactionHash: txSignature
            });
          } catch (error) {
            console.error(`Failed to distribute staking rewards to user ${user.id}:`, error);
          }
        }
      }
    }

    return rewards;
  }

  static async getTokenomicsStats() {
    const transactions = await storage.getAllTransactions();
    const users = await storage.getAllUsers();

    const totalSupply = users.reduce((sum: number, user: any) => 
      sum + (user.fronsBalance || 0) + (user.stakedFrons || 0), 0
    );

    const totalStaked = users.reduce((sum: number, user: any) => 
      sum + (user.stakedFrons || 0), 0
    );

    const recentRewards = transactions
      .filter((tx: any) => tx.type === 'reward' && tx.createdAt > new Date(Date.now() - 30 * 24 * 60 * 60 * 1000))
      .reduce((sum: number, tx: any) => sum + tx.amount, 0);

    return {
      totalSupply,
      totalStaked,
      stakingRate: totalStaked / totalSupply,
      recentRewards,
      activeUsers: users.filter((u: any) => (u.fronsBalance || 0) > 0 || (u.stakedFrons || 0) > 0).length
    };
  }

  // Initialize automated staking rewards distribution (daily at midnight)
  static initializeAutomatedRewards() {
    // Run daily at midnight UTC
    cron.schedule('0 0 * * *', async () => {
      try {
        console.log('Distributing daily staking rewards...');
        const rewards = await this.distributeStakingRewards();
        console.log(`Distributed rewards to ${rewards.length} users`);
      } catch (error) {
        console.error('Failed to distribute staking rewards:', error);
      }
    });

    console.log('Automated staking rewards scheduler initialized');
  }
}

