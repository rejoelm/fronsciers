import {
  Connection,
  PublicKey,
  Keypair,
  Transaction,
  SystemProgram,
  LAMPORTS_PER_SOL,
} from '@solana/web3.js';
import {
  Token,
  TOKEN_PROGRAM_ID,
  createMint,
  createAccount,
  mintTo,
  transfer,
  getOrCreateAssociatedTokenAccount,
} from '@solana/spl-token';

export class SolanaService {
  private connection: Connection;
  private payer: Keypair;
  private fronsTokenMint?: PublicKey;

  constructor() {
    const rpcUrl = process.env.SOLANA_RPC_URL || 'https://api.devnet.solana.com';
    this.connection = new Connection(rpcUrl, 'confirmed');
    
    // Initialize payer from private key or create new one for devnet
    const privateKey = process.env.SOLANA_PRIVATE_KEY;
    if (privateKey) {
      this.payer = Keypair.fromSecretKey(
        Uint8Array.from(JSON.parse(privateKey))
      );
    } else {
      // For development - generate new keypair
      this.payer = Keypair.generate();
      console.warn('No SOLANA_PRIVATE_KEY provided, using generated keypair for development');
    }
  }

  async initializeFronsToken(): Promise<PublicKey> {
    if (this.fronsTokenMint) {
      return this.fronsTokenMint;
    }

    try {
      // Check if token mint already exists in environment
      const existingMint = process.env.FRONS_TOKEN_MINT;
      if (existingMint) {
        this.fronsTokenMint = new PublicKey(existingMint);
        return this.fronsTokenMint;
      }

      // Create new token mint
      this.fronsTokenMint = await createMint(
        this.connection,
        this.payer,
        this.payer.publicKey, // mint authority
        this.payer.publicKey, // freeze authority
        6 // decimals
      );

      console.log(`FRONS token mint created: ${this.fronsTokenMint.toString()}`);
      return this.fronsTokenMint;
    } catch (error) {
      console.error('Error initializing FRONS token:', error);
      throw new Error('Failed to initialize FRONS token');
    }
  }

  async getOrCreateUserTokenAccount(userWallet: PublicKey): Promise<PublicKey> {
    if (!this.fronsTokenMint) {
      await this.initializeFronsToken();
    }

    try {
      const tokenAccount = await getOrCreateAssociatedTokenAccount(
        this.connection,
        this.payer,
        this.fronsTokenMint!,
        userWallet
      );

      return tokenAccount.address;
    } catch (error) {
      console.error('Error creating user token account:', error);
      throw new Error('Failed to create user token account');
    }
  }

  async mintFronsTokens(userWallet: PublicKey, amount: number): Promise<string> {
    if (!this.fronsTokenMint) {
      await this.initializeFronsToken();
    }

    try {
      const userTokenAccount = await this.getOrCreateUserTokenAccount(userWallet);
      
      const signature = await mintTo(
        this.connection,
        this.payer,
        this.fronsTokenMint!,
        userTokenAccount,
        this.payer,
        amount * Math.pow(10, 6) // Convert to token units (6 decimals)
      );

      await this.connection.confirmTransaction(signature);
      return signature;
    } catch (error) {
      console.error('Error minting FRONS tokens:', error);
      throw new Error('Failed to mint FRONS tokens');
    }
  }

  async transferFronsTokens(
    fromWallet: PublicKey,
    toWallet: PublicKey,
    amount: number
  ): Promise<string> {
    if (!this.fronsTokenMint) {
      await this.initializeFronsToken();
    }

    try {
      const fromTokenAccount = await this.getOrCreateUserTokenAccount(fromWallet);
      const toTokenAccount = await this.getOrCreateUserTokenAccount(toWallet);

      const signature = await transfer(
        this.connection,
        this.payer,
        fromTokenAccount,
        toTokenAccount,
        fromWallet,
        amount * Math.pow(10, 6) // Convert to token units
      );

      await this.connection.confirmTransaction(signature);
      return signature;
    } catch (error) {
      console.error('Error transferring FRONS tokens:', error);
      throw new Error('Failed to transfer FRONS tokens');
    }
  }

  async getUserFronsBalance(userWallet: PublicKey): Promise<number> {
    if (!this.fronsTokenMint) {
      await this.initializeFronsToken();
    }

    try {
      const userTokenAccount = await this.getOrCreateUserTokenAccount(userWallet);
      const balance = await this.connection.getTokenAccountBalance(userTokenAccount);
      return parseFloat(balance.value.amount) / Math.pow(10, 6);
    } catch (error) {
      console.error('Error getting FRONS balance:', error);
      return 0;
    }
  }

  async createDOCINFT(
    manuscriptData: {
      title: string;
      authors: string[];
      ipfsHash: string;
      doi?: string;
    },
    ownerWallet: PublicKey
  ): Promise<{ mintAddress: string; transactionId: string }> {
    try {
      // For simplicity, we'll create a token mint for each DOCI NFT
      // In production, you'd use Metaplex for proper NFT creation
      const nftMint = await createMint(
        this.connection,
        this.payer,
        this.payer.publicKey,
        this.payer.publicKey,
        0 // 0 decimals for NFT
      );

      // Create token account for owner
      const ownerTokenAccount = await getOrCreateAssociatedTokenAccount(
        this.connection,
        this.payer,
        nftMint,
        ownerWallet
      );

      // Mint 1 NFT to owner
      const signature = await mintTo(
        this.connection,
        this.payer,
        nftMint,
        ownerTokenAccount.address,
        this.payer,
        1 // Mint 1 NFT
      );

      await this.connection.confirmTransaction(signature);

      return {
        mintAddress: nftMint.toString(),
        transactionId: signature,
      };
    } catch (error) {
      console.error('Error creating DOCI NFT:', error);
      throw new Error('Failed to create DOCI NFT');
    }
  }

  async getConnection(): Promise<Connection> {
    return this.connection;
  }

  async getPayerPublicKey(): Promise<PublicKey> {
    return this.payer.publicKey;
  }
}

export const solanaService = new SolanaService();
