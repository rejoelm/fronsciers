import axios from 'axios';
import { storage } from '../storage';
import { InsertManuscript, InsertUser } from '@shared/schema';

export interface AcademicProfile {
  orcid?: string;
  googleScholarId?: string;
  researchGateId?: string;
  arxivAuthorId?: string;
  pubmedAuthorId?: string;
}

export interface ExternalPublication {
  title: string;
  authors: string[];
  abstract: string;
  doi?: string;
  arxivId?: string;
  pubmedId?: string;
  publishedDate?: Date;
  journal?: string;
  citationCount?: number;
  keywords?: string[];
  pdfUrl?: string;
  externalId: string;
  source: 'arxiv' | 'pubmed' | 'crossref' | 'google_scholar' | 'research_gate';
}

export class AcademicIntegrationService {
  private static readonly CROSSREF_API = 'https://api.crossref.org/works';
  private static readonly ARXIV_API = 'http://export.arxiv.org/api/query';
  private static readonly PUBMED_API = 'https://eutils.ncbi.nlm.nih.gov/entrez/eutils';
  private static readonly ORCID_API = 'https://pub.orcid.org/v3.0';
  
  // CrossRef integration for DOI-based publication lookup
  static async searchCrossRef(query: string, limit: number = 10): Promise<ExternalPublication[]> {
    try {
      const response = await axios.get(this.CROSSREF_API, {
        params: {
          query: query,
          rows: limit,
          select: 'DOI,title,author,abstract,published-print,container-title,is-referenced-by-count,subject'
        },
        headers: {
          'User-Agent': 'FRONSCIERS/1.0 (https://fronsciers.com; mailto:contact@fronsciers.com)'
        }
      });

      return response.data.message.items.map((item: any) => ({
        title: Array.isArray(item.title) ? item.title[0] : item.title || 'Unknown Title',
        authors: item.author?.map((a: any) => `${a.given || ''} ${a.family || ''}`.trim()) || [],
        abstract: item.abstract || '',
        doi: item.DOI,
        publishedDate: item['published-print']?.['date-parts']?.[0] ? 
          new Date(item['published-print']['date-parts'][0][0], 
                  (item['published-print']['date-parts'][0][1] || 1) - 1,
                  item['published-print']['date-parts'][0][2] || 1) : undefined,
        journal: Array.isArray(item['container-title']) ? item['container-title'][0] : item['container-title'],
        citationCount: item['is-referenced-by-count'] || 0,
        keywords: item.subject || [],
        externalId: item.DOI,
        source: 'crossref' as const
      }));
    } catch (error) {
      console.error('CrossRef search error:', error);
      return [];
    }
  }

  // arXiv integration for preprint search
  static async searchArXiv(query: string, limit: number = 10): Promise<ExternalPublication[]> {
    try {
      const response = await axios.get(this.ARXIV_API, {
        params: {
          search_query: `all:${query}`,
          start: 0,
          max_results: limit,
          sortBy: 'relevance',
          sortOrder: 'descending'
        }
      });

      // Parse XML response
      const xmlData = response.data;
      const entries = this.parseArXivXML(xmlData);
      
      return entries.map((entry: any) => ({
        title: entry.title,
        authors: entry.authors,
        abstract: entry.summary,
        arxivId: entry.id.split('/').pop(),
        publishedDate: new Date(entry.published),
        keywords: entry.categories,
        pdfUrl: entry.links?.find((l: any) => l.type === 'application/pdf')?.href,
        externalId: entry.id,
        source: 'arxiv' as const
      }));
    } catch (error) {
      console.error('arXiv search error:', error);
      return [];
    }
  }

  // PubMed integration for biomedical literature
  static async searchPubMed(query: string, limit: number = 10): Promise<ExternalPublication[]> {
    try {
      // First, search for PMIDs
      const searchResponse = await axios.get(`${this.PUBMED_API}/esearch.fcgi`, {
        params: {
          db: 'pubmed',
          term: query,
          retmax: limit,
          retmode: 'json',
          tool: 'fronsciers',
          email: 'contact@fronsciers.com'
        }
      });

      const pmids = searchResponse.data.esearchresult?.idlist || [];
      if (pmids.length === 0) return [];

      // Fetch detailed information
      const detailResponse = await axios.get(`${this.PUBMED_API}/esummary.fcgi`, {
        params: {
          db: 'pubmed',
          id: pmids.join(','),
          retmode: 'json',
          tool: 'fronsciers',
          email: 'contact@fronsciers.com'
        }
      });

      const results = detailResponse.data.result;
      return pmids.map((pmid: string) => {
        const article = results[pmid];
        return {
          title: article.title || 'Unknown Title',
          authors: article.authors?.map((a: any) => a.name) || [],
          abstract: '', // PubMed summaries don't include abstracts
          pubmedId: pmid,
          publishedDate: article.pubdate ? new Date(article.pubdate) : undefined,
          journal: article.fulljournalname,
          externalId: pmid,
          source: 'pubmed' as const
        };
      });
    } catch (error) {
      console.error('PubMed search error:', error);
      return [];
    }
  }

  // ORCID integration for author profiles
  static async getORCIDProfile(orcidId: string): Promise<any> {
    try {
      const response = await axios.get(`${this.ORCID_API}/${orcidId}/record`, {
        headers: {
          'Accept': 'application/json'
        }
      });

      const profile = response.data;
      return {
        orcidId,
        name: profile['person']?.['name']?.['given-names']?.value + ' ' + 
              profile['person']?.['name']?.['family-name']?.value,
        email: profile['person']?.['emails']?.['email']?.[0]?.email,
        affiliation: profile['activities-summary']?.['employments']?.['employment-summary']?.[0]?.['organization']?.name,
        researchField: profile['person']?.['researcher-urls']?.['researcher-url']?.[0]?.['url-name']
      };
    } catch (error) {
      console.error('ORCID profile error:', error);
      return null;
    }
  }

  // Import publications from external sources
  static async importPublications(userId: number, publications: ExternalPublication[]): Promise<any[]> {
    const imported = [];
    
    for (const pub of publications) {
      try {
        // Check if publication already exists
        const existing = await storage.getManuscriptByExternalId?.(pub.externalId);
        if (existing) continue;

        const manuscriptData: InsertManuscript = {
          userId,
          title: pub.title,
          abstract: pub.abstract,
          authors: pub.authors.join(', '),
          keywords: (pub.keywords || []).join(', '),
          researchField: this.inferResearchField(pub.keywords || []),
          status: 'published',
          submissionDate: pub.publishedDate,
          citationCount: pub.citationCount || 0,
          externalId: pub.externalId,
          externalSource: pub.source,
          doi: pub.doi,
          arxivId: pub.arxivId,
          pubmedId: pub.pubmedId
        };

        const manuscript = await storage.createManuscript(manuscriptData);
        imported.push(manuscript);
      } catch (error) {
        console.error(`Failed to import publication ${pub.title}:`, error);
      }
    }

    return imported;
  }

  // Sync user profile with external academic profiles
  static async syncUserProfile(userId: number, profiles: AcademicProfile): Promise<void> {
    const updates: any = {};

    if (profiles.orcid) {
      const orcidData = await this.getORCIDProfile(profiles.orcid);
      if (orcidData) {
        updates.email = orcidData.email;
        updates.institutionName = orcidData.affiliation;
        updates.researchField = orcidData.researchField;
      }
    }

    if (Object.keys(updates).length > 0) {
      await storage.updateUser(userId, updates);
    }
  }

  // Search across multiple databases
  static async universalSearch(query: string, databases: string[] = ['crossref', 'arxiv', 'pubmed']): Promise<ExternalPublication[]> {
    const searchPromises = [];

    if (databases.includes('crossref')) {
      searchPromises.push(this.searchCrossRef(query, 5));
    }
    if (databases.includes('arxiv')) {
      searchPromises.push(this.searchArXiv(query, 5));
    }
    if (databases.includes('pubmed')) {
      searchPromises.push(this.searchPubMed(query, 5));
    }

    const results = await Promise.allSettled(searchPromises);
    const allPublications = results
      .filter(result => result.status === 'fulfilled')
      .flatMap(result => (result as PromiseFulfilledResult<ExternalPublication[]>).value);

    // Remove duplicates based on DOI or title
    const unique = allPublications.filter((pub, index, arr) => 
      arr.findIndex(p => 
        (pub.doi && p.doi === pub.doi) || 
        (pub.title.toLowerCase() === p.title.toLowerCase())
      ) === index
    );

    return unique.sort((a, b) => (b.citationCount || 0) - (a.citationCount || 0));
  }

  private static parseArXivXML(xmlData: string): any[] {
    // Simple XML parsing for arXiv response
    // In production, consider using a proper XML parser
    const entries = [];
    const entryRegex = /<entry>([\s\S]*?)<\/entry>/g;
    let match;

    while ((match = entryRegex.exec(xmlData)) !== null) {
      const entryXml = match[1];
      
      const title = this.extractXMLValue(entryXml, 'title');
      const summary = this.extractXMLValue(entryXml, 'summary');
      const id = this.extractXMLValue(entryXml, 'id');
      const published = this.extractXMLValue(entryXml, 'published');
      
      // Extract authors
      const authorRegex = /<author><name>(.*?)<\/name><\/author>/g;
      const authors = [];
      let authorMatch;
      while ((authorMatch = authorRegex.exec(entryXml)) !== null) {
        authors.push(authorMatch[1]);
      }

      // Extract categories
      const categoryRegex = /<category term="([^"]+)"/g;
      const categories = [];
      let categoryMatch;
      while ((categoryMatch = categoryRegex.exec(entryXml)) !== null) {
        categories.push(categoryMatch[1]);
      }

      entries.push({
        title: title?.replace(/\s+/g, ' ').trim(),
        summary: summary?.replace(/\s+/g, ' ').trim(),
        id,
        published,
        authors,
        categories
      });
    }

    return entries;
  }

  private static extractXMLValue(xml: string, tag: string): string | undefined {
    const regex = new RegExp(`<${tag}[^>]*>(.*?)<\/${tag}>`, 's');
    const match = xml.match(regex);
    return match ? match[1] : undefined;
  }

  private static inferResearchField(keywords: string[]): string {
    const fieldMapping: { [key: string]: string[] } = {
      'Computer Science': ['computer', 'algorithm', 'software', 'ai', 'machine learning', 'programming'],
      'Physics': ['physics', 'quantum', 'particle', 'energy', 'mechanics'],
      'Biology': ['biology', 'cell', 'gene', 'protein', 'organism', 'evolution'],
      'Medicine': ['medical', 'clinical', 'patient', 'disease', 'treatment', 'therapy'],
      'Chemistry': ['chemical', 'molecule', 'reaction', 'synthesis', 'compound'],
      'Mathematics': ['mathematics', 'theorem', 'proof', 'equation', 'analysis']
    };

    for (const [field, terms] of Object.entries(fieldMapping)) {
      if (keywords.some(keyword => 
        terms.some(term => keyword.toLowerCase().includes(term))
      )) {
        return field;
      }
    }

    return 'Interdisciplinary';
  }
}

// Extend storage interface for external publication tracking
declare module '../storage' {
  interface IStorage {
    getManuscriptByExternalId?(externalId: string): Promise<any>;
  }
}