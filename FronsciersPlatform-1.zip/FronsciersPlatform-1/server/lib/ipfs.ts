import { create, IPFSHTTPClient } from 'ipfs-http-client';

class IPFSService {
  private client: IPFSHTTPClient;

  constructor() {
    // Use Infura IPFS gateway or local node
    const projectId = process.env.IPFS_PROJECT_ID || process.env.INFURA_IPFS_PROJECT_ID;
    const projectSecret = process.env.IPFS_PROJECT_SECRET || process.env.INFURA_IPFS_PROJECT_SECRET;
    
    if (projectId && projectSecret) {
      const auth = Buffer.from(`${projectId}:${projectSecret}`).toString('base64');
      this.client = create({
        host: 'ipfs.infura.io',
        port: 5001,
        protocol: 'https',
        headers: {
          authorization: `Basic ${auth}`,
        },
      });
    } else {
      // Fallback to local IPFS node
      this.client = create({
        host: 'localhost',
        port: 5001,
        protocol: 'http',
      });
    }
  }

  async uploadFile(fileBuffer: Buffer, fileName: string): Promise<string> {
    try {
      const result = await this.client.add({
        path: fileName,
        content: fileBuffer,
      });
      return result.cid.toString();
    } catch (error) {
      console.error('IPFS upload error:', error);
      throw new Error('Failed to upload file to IPFS');
    }
  }

  async uploadJSON(data: any): Promise<string> {
    try {
      const result = await this.client.add(JSON.stringify(data));
      return result.cid.toString();
    } catch (error) {
      console.error('IPFS JSON upload error:', error);
      throw new Error('Failed to upload JSON to IPFS');
    }
  }

  async getFile(hash: string): Promise<Uint8Array> {
    try {
      const stream = this.client.cat(hash);
      const chunks = [];
      for await (const chunk of stream) {
        chunks.push(chunk);
      }
      return new Uint8Array(Buffer.concat(chunks));
    } catch (error) {
      console.error('IPFS retrieval error:', error);
      throw new Error('Failed to retrieve file from IPFS');
    }
  }

  getGatewayUrl(hash: string): string {
    return `https://ipfs.io/ipfs/${hash}`;
  }
}

export const ipfsService = new IPFSService();
