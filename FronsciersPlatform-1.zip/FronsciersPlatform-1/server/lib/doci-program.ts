import * as anchor from '@project-serum/anchor';
import { Connection, PublicKey, Keypair, SystemProgram } from '@solana/web3.js';
import { AnchorProvider, BN } from '@project-serum/anchor';

// DOCI Program IDL (Interface Definition Language)
export const DOCI_PROGRAM_IDL = {
  "version": "0.1.0",
  "name": "doci_registry",
  "instructions": [
    {
      "name": "registerPublicationDoci",
      "accounts": [
        {
          "name": "doci",
          "isMut": true,
          "isSigner": false
        },
        {
          "name": "authority",
          "isMut": true,
          "isSigner": true
        },
        {
          "name": "systemProgram",
          "isMut": false,
          "isSigner": false
        }
      ],
      "args": [
        {
          "name": "prefix",
          "type": "string"
        },
        {
          "name": "suffix",
          "type": "string"
        },
        {
          "name": "metadataUri",
          "type": "string"
        },
        {
          "name": "contentHash",
          "type": "string"
        },
        {
          "name": "doiType",
          "type": "string"
        }
      ]
    }
  ],
  "accounts": [
    {
      "name": "DociAccount",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "authority",
            "type": "publicKey"
          },
          {
            "name": "prefix",
            "type": "string"
          },
          {
            "name": "suffix",
            "type": "string"
          },
          {
            "name": "fullDoci",
            "type": "string"
          },
          {
            "name": "metadataUri",
            "type": "string"
          },
          {
            "name": "contentHash",
            "type": "string"
          },
          {
            "name": "doiType",
            "type": "string"
          },
          {
            "name": "createdAt",
            "type": "i64"
          },
          {
            "name": "bump",
            "type": "u8"
          }
        ]
      }
    }
  ],
  "errors": [
    {
      "code": 6000,
      "name": "InvalidContentHash",
      "msg": "Content hash must be a valid 32-byte hex string"
    },
    {
      "code": 6001,
      "name": "InvalidPrefix",
      "msg": "Invalid DOCI prefix format"
    },
    {
      "code": 6002,
      "name": "DuplicateDoci",
      "msg": "DOCI already exists"
    }
  ]
};

export interface DociRegistrationData {
  prefix: string;
  suffix: string;
  metadataUri: string;
  contentHash: string;
  doiType: string;
}

export interface DociRegistrationResult {
  dociAccount: PublicKey;
  transactionSignature: string;
  fullDoci: string;
}

export class DociProgramService {
  private connection: Connection;
  private provider: AnchorProvider;
  private program: anchor.Program;
  private programId: PublicKey;

  constructor() {
    // Use environment variable or default to devnet
    const rpcUrl = process.env.SOLANA_RPC_URL || 'https://api.devnet.solana.com';
    this.connection = new Connection(rpcUrl, 'confirmed');

    // Generate or load program keypair
    const programKeypair = this.loadProgramKeypair();
    this.programId = programKeypair.publicKey;

    // Setup provider and program
    const wallet = this.loadWallet();
    this.provider = new AnchorProvider(this.connection, wallet, {
      commitment: 'confirmed',
      preflightCommitment: 'confirmed'
    });

    this.program = new anchor.Program(
      DOCI_PROGRAM_IDL as any,
      this.programId,
      this.provider
    );
  }

  private loadProgramKeypair(): Keypair {
    if (process.env.DOCI_PROGRAM_KEYPAIR) {
      const keypairData = JSON.parse(process.env.DOCI_PROGRAM_KEYPAIR);
      return Keypair.fromSecretKey(new Uint8Array(keypairData));
    }
    
    // For development, generate a deterministic keypair
    const seed = Buffer.from('doci_program_seed_fronsciers_v1', 'utf8');
    const keypair = Keypair.fromSeed(seed.slice(0, 32));
    
    console.log('DOCI Program ID:', keypair.publicKey.toString());
    return keypair;
  }

  private loadWallet(): any {
    if (process.env.SOLANA_PRIVATE_KEY) {
      const privateKeyArray = JSON.parse(process.env.SOLANA_PRIVATE_KEY);
      const keypair = Keypair.fromSecretKey(new Uint8Array(privateKeyArray));
      return {
        publicKey: keypair.publicKey,
        signTransaction: async (tx: any) => {
          tx.sign(keypair);
          return tx;
        },
        signAllTransactions: async (txs: any[]) => {
          txs.forEach(tx => tx.sign(keypair));
          return txs;
        }
      };
    }

    // Generate development wallet
    const keypair = Keypair.generate();
    console.log('Development wallet:', keypair.publicKey.toString());
    
    return {
      publicKey: keypair.publicKey,
      signTransaction: async (tx: any) => {
        tx.sign(keypair);
        return tx;
      },
      signAllTransactions: async (txs: any[]) => {
        txs.forEach(tx => tx.sign(keypair));
        return txs;
      }
    };
  }

  // Validate content hash format (32-byte hex string)
  public static validateContentHash(contentHash: string): boolean {
    const hexRegex = /^[a-fA-F0-9]{64}$/;
    return hexRegex.test(contentHash);
  }

  // Validate DOCI prefix format
  public static validatePrefix(prefix: string): boolean {
    const prefixRegex = /^10\.[A-Za-z0-9]+$/;
    return prefixRegex.test(prefix);
  }

  // Generate unique suffix for DOCI
  public static generateSuffix(): string {
    const timestamp = Date.now().toString(36);
    const random = Math.random().toString(36).substring(2, 8);
    return `${timestamp}.${random}`.toUpperCase();
  }

  // Get DOCI account address (PDA)
  public async getDociAccountAddress(fullDoci: string): Promise<[PublicKey, number]> {
    return await PublicKey.findProgramAddress(
      [
        Buffer.from('doci'),
        Buffer.from(fullDoci)
      ],
      this.programId
    );
  }

  // Register a new DOCI on-chain
  public async registerPublicationDoci(
    data: DociRegistrationData,
    authority?: PublicKey
  ): Promise<DociRegistrationResult> {
    try {
      // Validate inputs
      if (!DociProgramService.validateContentHash(data.contentHash)) {
        throw new Error('Invalid content hash format. Must be a 64-character hex string.');
      }

      if (!DociProgramService.validatePrefix(data.prefix)) {
        throw new Error('Invalid prefix format. Must start with "10." followed by alphanumeric characters.');
      }

      const fullDoci = `${data.prefix}/${data.suffix}`;
      const authorityKey = authority || this.provider.wallet.publicKey;

      // Get DOCI account address (Program Derived Address)
      const [dociAccount, bump] = await this.getDociAccountAddress(fullDoci);

      // Check if DOCI already exists
      try {
        const existingAccount = await this.program.account.dociAccount.fetch(dociAccount);
        if (existingAccount) {
          throw new Error(`DOCI ${fullDoci} already exists`);
        }
      } catch (err) {
        // Account doesn't exist, which is what we want
      }

      // Create the registration transaction
      const tx = await this.program.methods
        .registerPublicationDoci(
          data.prefix,
          data.suffix,
          data.metadataUri,
          data.contentHash,
          data.doiType
        )
        .accounts({
          doci: dociAccount,
          authority: authorityKey,
          systemProgram: SystemProgram.programId,
        })
        .rpc();

      console.log('DOCI registered successfully:', {
        fullDoci,
        dociAccount: dociAccount.toString(),
        transactionSignature: tx
      });

      return {
        dociAccount,
        transactionSignature: tx,
        fullDoci
      };

    } catch (error) {
      console.error('DOCI registration failed:', error);
      throw error;
    }
  }

  // Fetch DOCI account data
  public async getDociAccount(dociAccount: PublicKey) {
    try {
      return await this.program.account.dociAccount.fetch(dociAccount);
    } catch (error) {
      console.error('Failed to fetch DOCI account:', error);
      return null;
    }
  }

  // Search DOCIs by authority
  public async getDocisByAuthority(authority: PublicKey) {
    try {
      return await this.program.account.dociAccount.all([
        {
          memcmp: {
            offset: 8, // After discriminator
            bytes: authority.toBase58()
          }
        }
      ]);
    } catch (error) {
      console.error('Failed to fetch DOCIs by authority:', error);
      return [];
    }
  }

  // Get program info
  public getProgramInfo() {
    return {
      programId: this.programId.toString(),
      connection: this.connection.rpcEndpoint,
      commitment: this.provider.opts.commitment
    };
  }

  // Airdrop SOL for development/testing
  public async airdropSol(publicKey: PublicKey, amount: number = 1): Promise<string> {
    try {
      const signature = await this.connection.requestAirdrop(
        publicKey,
        amount * anchor.web3.LAMPORTS_PER_SOL
      );
      
      await this.connection.confirmTransaction(signature);
      return signature;
    } catch (error) {
      console.error('Airdrop failed:', error);
      throw error;
    }
  }

  // Get account balance
  public async getBalance(publicKey: PublicKey): Promise<number> {
    try {
      const balance = await this.connection.getBalance(publicKey);
      return balance / anchor.web3.LAMPORTS_PER_SOL;
    } catch (error) {
      console.error('Failed to get balance:', error);
      return 0;
    }
  }
}