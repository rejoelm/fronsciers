import { 
  users, manuscripts, reviews, daoProposals, votes, transactions, peerReviewAssignments,
  reputationHistory, reviewerExpertise, dois, communityVotes,
  userInteractions, userInterests, collaborationNetwork, recommendationFeedback, trendingTopics, feedback,
  type User, type InsertUser, type Manuscript, type InsertManuscript,
  type Review, type InsertReview, type DaoProposal, type InsertDaoProposal,
  type Vote, type InsertVote, type Transaction, type InsertTransaction,
  type PeerReviewAssignment, type InsertPeerReviewAssignment,
  type ReputationHistory, type InsertReputationHistory,
  type ReviewerExpertise, type InsertReviewerExpertise,
  type Doci, type InsertDoci, type CommunityVote, type InsertCommunityVote,
  type UserInteraction, type InsertUserInteraction, type UserInterest, type InsertUserInterest,
  type CollaborationNetwork, type InsertCollaborationNetwork,
  type RecommendationFeedback, type InsertRecommendationFeedback,
  type TrendingTopic, type InsertTrendingTopic, type Feedback, type InsertFeedback
} from "@shared/schema";
import { db } from "./db";
import { eq, and, or, desc } from "drizzle-orm";

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByWalletAddress(walletAddress: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, updates: Partial<User>): Promise<User | undefined>;

  // Manuscript operations
  getManuscript(id: number): Promise<Manuscript | undefined>;
  getManuscriptsByUser(userId: number): Promise<Manuscript[]>;
  getAllManuscripts(): Promise<Manuscript[]>;
  createManuscript(manuscript: InsertManuscript): Promise<Manuscript>;
  updateManuscript(id: number, updates: Partial<Manuscript>): Promise<Manuscript | undefined>;

  // Review operations
  getReview(id: number): Promise<Review | undefined>;
  getReviewsByManuscript(manuscriptId: number): Promise<Review[]>;
  getReviewsByReviewer(reviewerId: number): Promise<Review[]>;
  createReview(review: InsertReview): Promise<Review>;
  updateReview(id: number, updates: Partial<Review>): Promise<Review | undefined>;

  // DAO operations
  getDaoProposal(id: number): Promise<DaoProposal | undefined>;
  getAllDaoProposals(): Promise<DaoProposal[]>;
  getActiveDaoProposals(): Promise<DaoProposal[]>;
  createDaoProposal(proposal: InsertDaoProposal): Promise<DaoProposal>;
  updateDaoProposal(id: number, updates: Partial<DaoProposal>): Promise<DaoProposal | undefined>;

  // Vote operations
  getVote(proposalId: number, voterId: number): Promise<Vote | undefined>;
  getVotesByProposal(proposalId: number): Promise<Vote[]>;
  createVote(vote: InsertVote): Promise<Vote>;

  // Transaction operations
  getTransaction(id: number): Promise<Transaction | undefined>;
  getTransactionsByUser(userId: number): Promise<Transaction[]>;
  createTransaction(transaction: InsertTransaction): Promise<Transaction>;
  updateTransaction(id: number, updates: Partial<Transaction>): Promise<Transaction | undefined>;

  // Peer review assignment operations
  getPeerReviewAssignment(id: number): Promise<PeerReviewAssignment | undefined>;
  getPeerReviewAssignmentsByManuscript(manuscriptId: number): Promise<PeerReviewAssignment[]>;
  getPeerReviewAssignmentsByReviewer(reviewerId: number): Promise<PeerReviewAssignment[]>;
  createPeerReviewAssignment(assignment: InsertPeerReviewAssignment): Promise<PeerReviewAssignment>;
  updatePeerReviewAssignment(id: number, updates: Partial<PeerReviewAssignment>): Promise<PeerReviewAssignment | undefined>;

  // Additional methods for tokenomics
  getAllUsers(): Promise<User[]>;
  getAllTransactions(): Promise<Transaction[]>;

  // Academic integration methods
  getManuscriptByExternalId(externalId: string): Promise<Manuscript | undefined>;

  // Reputation tracking methods
  getReputationHistory(id: number): Promise<ReputationHistory | undefined>;
  getReputationHistoryByUser(userId: number): Promise<ReputationHistory[]>;
  createReputationHistory(history: InsertReputationHistory): Promise<ReputationHistory>;

  // Reviewer expertise methods
  getReviewerExpertise(id: number): Promise<ReviewerExpertise | undefined>;
  getReviewerExpertiseByUser(userId: number): Promise<ReviewerExpertise[]>;
  createReviewerExpertise(expertise: InsertReviewerExpertise): Promise<ReviewerExpertise>;
  updateReviewerExpertise(id: number, updates: Partial<ReviewerExpertise>): Promise<ReviewerExpertise | undefined>;

  // DOCI registry methods
  getDoci(id: number): Promise<Doci | undefined>;
  getDociBySolanaAccount(solanaAccount: string): Promise<Doci | undefined>;
  getDociByFullDoci(fullDoci: string): Promise<Doci | undefined>;
  getDocisByUser(userId: number): Promise<Doci[]>;
  getDocisByManuscript(manuscriptId: number): Promise<Doci[]>;
  createDoci(doci: InsertDoci): Promise<Doci>;
  updateDoci(id: number, updates: Partial<Doci>): Promise<Doci | undefined>;

  // Community vote methods
  getCommunityVote(identifier: string, voterId: number): Promise<CommunityVote | undefined>;
  getCommunityVotesByManuscript(manuscriptId: number): Promise<CommunityVote[]>;
  getCommunityVotesByDoci(dociId: string): Promise<CommunityVote[]>;
  createCommunityVote(vote: InsertCommunityVote): Promise<CommunityVote>;

  // Recommendation engine methods
  createUserInteraction(interaction: InsertUserInteraction): Promise<UserInteraction>;
  getUserInteractions(userId: number, limit?: number): Promise<UserInteraction[]>;
  getUserInteractionsByType(userId: number, targetType: string): Promise<UserInteraction[]>;
  
  getUserInterests(userId: number): Promise<UserInterest[]>;
  createUserInterest(interest: InsertUserInterest): Promise<UserInterest>;
  updateUserInterest(id: number, updates: Partial<UserInterest>): Promise<UserInterest | undefined>;
  
  getCollaborationNetwork(userId: number): Promise<CollaborationNetwork[]>;
  createCollaborationNetwork(collaboration: InsertCollaborationNetwork): Promise<CollaborationNetwork>;
  updateCollaborationNetwork(id: number, updates: Partial<CollaborationNetwork>): Promise<CollaborationNetwork | undefined>;
  
  createRecommendationFeedback(feedback: InsertRecommendationFeedback): Promise<RecommendationFeedback>;
  getRecommendationFeedback(userId: number): Promise<RecommendationFeedback[]>;
  
  getTrendingTopics(timeWindow?: string, limit?: number): Promise<TrendingTopic[]>;
  createTrendingTopic(topic: InsertTrendingTopic): Promise<TrendingTopic>;
  updateTrendingTopic(id: number, updates: Partial<TrendingTopic>): Promise<TrendingTopic | undefined>;

  // Feedback operations
  createFeedback(feedback: InsertFeedback): Promise<Feedback>;
  getAllFeedback(): Promise<Feedback[]>;
  getFeedbackByRating(rating: number): Promise<Feedback[]>;
  updateFeedback(id: number, updates: Partial<Feedback>): Promise<Feedback | undefined>;
}

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByWalletAddress(walletAddress: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.walletAddress, walletAddress));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }

  async updateUser(id: number, updates: Partial<User>): Promise<User | undefined> {
    const [user] = await db
      .update(users)
      .set(updates)
      .where(eq(users.id, id))
      .returning();
    return user || undefined;
  }

  // Manuscript operations
  async getManuscript(id: number): Promise<Manuscript | undefined> {
    const [manuscript] = await db.select().from(manuscripts).where(eq(manuscripts.id, id));
    return manuscript || undefined;
  }

  async getManuscriptsByUser(userId: number): Promise<Manuscript[]> {
    return await db.select().from(manuscripts).where(eq(manuscripts.userId, userId));
  }

  async getAllManuscripts(): Promise<Manuscript[]> {
    return await db.select().from(manuscripts);
  }

  async createManuscript(insertManuscript: InsertManuscript): Promise<Manuscript> {
    const [manuscript] = await db
      .insert(manuscripts)
      .values(insertManuscript)
      .returning();
    return manuscript;
  }

  async updateManuscript(id: number, updates: Partial<Manuscript>): Promise<Manuscript | undefined> {
    const [manuscript] = await db
      .update(manuscripts)
      .set(updates)
      .where(eq(manuscripts.id, id))
      .returning();
    return manuscript || undefined;
  }

  // Review operations
  async getReview(id: number): Promise<Review | undefined> {
    const [review] = await db.select().from(reviews).where(eq(reviews.id, id));
    return review || undefined;
  }

  async getReviewsByManuscript(manuscriptId: number): Promise<Review[]> {
    return await db.select().from(reviews).where(eq(reviews.manuscriptId, manuscriptId));
  }

  async getReviewsByReviewer(reviewerId: number): Promise<Review[]> {
    return await db.select().from(reviews).where(eq(reviews.reviewerId, reviewerId));
  }

  async createReview(insertReview: InsertReview): Promise<Review> {
    const [review] = await db
      .insert(reviews)
      .values(insertReview)
      .returning();
    return review;
  }

  async updateReview(id: number, updates: Partial<Review>): Promise<Review | undefined> {
    const [review] = await db
      .update(reviews)
      .set(updates)
      .where(eq(reviews.id, id))
      .returning();
    return review || undefined;
  }

  // DAO operations
  async getDaoProposal(id: number): Promise<DaoProposal | undefined> {
    const [proposal] = await db.select().from(daoProposals).where(eq(daoProposals.id, id));
    return proposal || undefined;
  }

  async getAllDaoProposals(): Promise<DaoProposal[]> {
    return await db.select().from(daoProposals);
  }

  async getActiveDaoProposals(): Promise<DaoProposal[]> {
    return await db.select().from(daoProposals).where(eq(daoProposals.status, 'active'));
  }

  async createDaoProposal(insertProposal: InsertDaoProposal): Promise<DaoProposal> {
    const [proposal] = await db
      .insert(daoProposals)
      .values(insertProposal)
      .returning();
    return proposal;
  }

  async updateDaoProposal(id: number, updates: Partial<DaoProposal>): Promise<DaoProposal | undefined> {
    const [proposal] = await db
      .update(daoProposals)
      .set(updates)
      .where(eq(daoProposals.id, id))
      .returning();
    return proposal || undefined;
  }

  // Vote operations
  async getVote(proposalId: number, voterId: number): Promise<Vote | undefined> {
    const [vote] = await db
      .select()
      .from(votes)
      .where(and(eq(votes.proposalId, proposalId), eq(votes.voterId, voterId)));
    return vote || undefined;
  }

  async getVotesByProposal(proposalId: number): Promise<Vote[]> {
    return await db.select().from(votes).where(eq(votes.proposalId, proposalId));
  }

  async createVote(insertVote: InsertVote): Promise<Vote> {
    const [vote] = await db
      .insert(votes)
      .values(insertVote)
      .returning();
    return vote;
  }

  // Transaction operations
  async getTransaction(id: number): Promise<Transaction | undefined> {
    const [transaction] = await db.select().from(transactions).where(eq(transactions.id, id));
    return transaction || undefined;
  }

  async getTransactionsByUser(userId: number): Promise<Transaction[]> {
    return await db.select().from(transactions).where(eq(transactions.userId, userId));
  }

  async createTransaction(insertTransaction: InsertTransaction): Promise<Transaction> {
    const [transaction] = await db
      .insert(transactions)
      .values(insertTransaction)
      .returning();
    return transaction;
  }

  async updateTransaction(id: number, updates: Partial<Transaction>): Promise<Transaction | undefined> {
    const [transaction] = await db
      .update(transactions)
      .set(updates)
      .where(eq(transactions.id, id))
      .returning();
    return transaction || undefined;
  }

  // Peer review assignment operations
  async getPeerReviewAssignment(id: number): Promise<PeerReviewAssignment | undefined> {
    const [assignment] = await db.select().from(peerReviewAssignments).where(eq(peerReviewAssignments.id, id));
    return assignment || undefined;
  }

  async getPeerReviewAssignmentsByManuscript(manuscriptId: number): Promise<PeerReviewAssignment[]> {
    return await db.select().from(peerReviewAssignments).where(eq(peerReviewAssignments.manuscriptId, manuscriptId));
  }

  async getPeerReviewAssignmentsByReviewer(reviewerId: number): Promise<PeerReviewAssignment[]> {
    return await db.select().from(peerReviewAssignments).where(eq(peerReviewAssignments.reviewerId, reviewerId));
  }

  async createPeerReviewAssignment(insertAssignment: InsertPeerReviewAssignment): Promise<PeerReviewAssignment> {
    const [assignment] = await db
      .insert(peerReviewAssignments)
      .values(insertAssignment)
      .returning();
    return assignment;
  }

  async updatePeerReviewAssignment(id: number, updates: Partial<PeerReviewAssignment>): Promise<PeerReviewAssignment | undefined> {
    const [assignment] = await db
      .update(peerReviewAssignments)
      .set(updates)
      .where(eq(peerReviewAssignments.id, id))
      .returning();
    return assignment || undefined;
  }

  // Additional methods for tokenomics
  async getAllUsers(): Promise<User[]> {
    return await db.select().from(users);
  }

  async getAllTransactions(): Promise<Transaction[]> {
    return await db.select().from(transactions);
  }

  // Academic integration methods
  async getManuscriptByExternalId(externalId: string): Promise<Manuscript | undefined> {
    const [manuscript] = await db.select().from(manuscripts).where(eq(manuscripts.externalId, externalId));
    return manuscript || undefined;
  }

  // Reputation tracking methods
  async getReputationHistory(id: number): Promise<ReputationHistory | undefined> {
    const [history] = await db.select().from(reputationHistory).where(eq(reputationHistory.id, id));
    return history || undefined;
  }

  async getReputationHistoryByUser(userId: number): Promise<ReputationHistory[]> {
    return await db.select().from(reputationHistory).where(eq(reputationHistory.userId, userId));
  }

  async createReputationHistory(insertHistory: InsertReputationHistory): Promise<ReputationHistory> {
    const [history] = await db.insert(reputationHistory).values(insertHistory).returning();
    return history;
  }

  // Reviewer expertise methods
  async getReviewerExpertise(id: number): Promise<ReviewerExpertise | undefined> {
    const [expertise] = await db.select().from(reviewerExpertise).where(eq(reviewerExpertise.id, id));
    return expertise || undefined;
  }

  async getReviewerExpertiseByUser(userId: number): Promise<ReviewerExpertise[]> {
    return await db.select().from(reviewerExpertise).where(eq(reviewerExpertise.userId, userId));
  }

  async createReviewerExpertise(insertExpertise: InsertReviewerExpertise): Promise<ReviewerExpertise> {
    const [expertise] = await db.insert(reviewerExpertise).values(insertExpertise).returning();
    return expertise;
  }

  async updateReviewerExpertise(id: number, updates: Partial<ReviewerExpertise>): Promise<ReviewerExpertise | undefined> {
    const [expertise] = await db
      .update(reviewerExpertise)
      .set(updates)
      .where(eq(reviewerExpertise.id, id))
      .returning();
    return expertise || undefined;
  }

  // DOCI registry methods
  async getDoci(id: number): Promise<Doci | undefined> {
    const [doci] = await db.select().from(dois).where(eq(dois.id, id));
    return doci || undefined;
  }

  async getDociBySolanaAccount(solanaAccount: string): Promise<Doci | undefined> {
    const [doci] = await db.select().from(dois).where(eq(dois.solanaAccount, solanaAccount));
    return doci || undefined;
  }

  async getDociByFullDoci(fullDoci: string): Promise<Doci | undefined> {
    const [doci] = await db.select().from(dois).where(eq(dois.fullDoci, fullDoci));
    return doci || undefined;
  }

  async getDocisByUser(userId: number): Promise<Doci[]> {
    return await db.select().from(dois).where(eq(dois.userId, userId));
  }

  async getDocisByManuscript(manuscriptId: number): Promise<Doci[]> {
    return await db.select().from(dois).where(eq(dois.manuscriptId, manuscriptId));
  }

  async createDoci(insertDoci: InsertDoci): Promise<Doci> {
    const [doci] = await db.insert(dois).values(insertDoci).returning();
    return doci;
  }

  async updateDoci(id: number, updates: Partial<Doci>): Promise<Doci | undefined> {
    const [doci] = await db
      .update(dois)
      .set(updates)
      .where(eq(dois.id, id))
      .returning();
    return doci || undefined;
  }

  // Community vote operations
  async getCommunityVote(identifier: string, voterId: number): Promise<CommunityVote | undefined> {
    const [vote] = await db
      .select()
      .from(communityVotes)
      .where(
        and(
          or(
            eq(communityVotes.dociId, identifier),
            eq(communityVotes.manuscriptId, parseInt(identifier) || 0)
          ),
          eq(communityVotes.voterId, voterId)
        )
      );
    return vote || undefined;
  }

  async getCommunityVotesByManuscript(manuscriptId: number): Promise<CommunityVote[]> {
    return await db
      .select()
      .from(communityVotes)
      .where(eq(communityVotes.manuscriptId, manuscriptId));
  }

  async getCommunityVotesByDoci(dociId: string): Promise<CommunityVote[]> {
    return await db
      .select()
      .from(communityVotes)
      .where(eq(communityVotes.dociId, dociId));
  }

  async createCommunityVote(insertVote: InsertCommunityVote): Promise<CommunityVote> {
    const [vote] = await db
      .insert(communityVotes)
      .values(insertVote)
      .returning();
    return vote;
  }

  // Recommendation engine implementations
  async createUserInteraction(insertInteraction: InsertUserInteraction): Promise<UserInteraction> {
    const [interaction] = await db
      .insert(userInteractions)
      .values(insertInteraction)
      .returning();
    return interaction;
  }

  async getUserInteractions(userId: number, limit = 100): Promise<UserInteraction[]> {
    return await db
      .select()
      .from(userInteractions)
      .where(eq(userInteractions.userId, userId))
      .orderBy(desc(userInteractions.createdAt))
      .limit(limit);
  }

  async getUserInteractionsByType(userId: number, targetType: string): Promise<UserInteraction[]> {
    return await db
      .select()
      .from(userInteractions)
      .where(and(
        eq(userInteractions.userId, userId),
        eq(userInteractions.targetType, targetType)
      ))
      .orderBy(desc(userInteractions.createdAt));
  }

  async getUserInterests(userId: number): Promise<UserInterest[]> {
    return await db
      .select()
      .from(userInterests)
      .where(eq(userInterests.userId, userId))
      .orderBy(desc(userInterests.weight));
  }

  async createUserInterest(insertInterest: InsertUserInterest): Promise<UserInterest> {
    const [interest] = await db
      .insert(userInterests)
      .values(insertInterest)
      .returning();
    return interest;
  }

  async updateUserInterest(id: number, updates: Partial<UserInterest>): Promise<UserInterest | undefined> {
    const [interest] = await db
      .update(userInterests)
      .set({ ...updates, lastUpdated: new Date() })
      .where(eq(userInterests.id, id))
      .returning();
    return interest || undefined;
  }

  async getCollaborationNetwork(userId: number): Promise<CollaborationNetwork[]> {
    return await db
      .select()
      .from(collaborationNetwork)
      .where(or(
        eq(collaborationNetwork.userId, userId),
        eq(collaborationNetwork.collaboratorId, userId)
      ))
      .orderBy(desc(collaborationNetwork.strength));
  }

  async createCollaborationNetwork(insertCollaboration: InsertCollaborationNetwork): Promise<CollaborationNetwork> {
    const [collaboration] = await db
      .insert(collaborationNetwork)
      .values(insertCollaboration)
      .returning();
    return collaboration;
  }

  async updateCollaborationNetwork(id: number, updates: Partial<CollaborationNetwork>): Promise<CollaborationNetwork | undefined> {
    const [collaboration] = await db
      .update(collaborationNetwork)
      .set({ ...updates, lastCollaboration: new Date() })
      .where(eq(collaborationNetwork.id, id))
      .returning();
    return collaboration || undefined;
  }

  async createRecommendationFeedback(insertFeedback: InsertRecommendationFeedback): Promise<RecommendationFeedback> {
    const [feedback] = await db
      .insert(recommendationFeedback)
      .values(insertFeedback)
      .returning();
    return feedback;
  }

  async getRecommendationFeedback(userId: number): Promise<RecommendationFeedback[]> {
    return await db
      .select()
      .from(recommendationFeedback)
      .where(eq(recommendationFeedback.userId, userId))
      .orderBy(desc(recommendationFeedback.createdAt));
  }

  async getTrendingTopics(timeWindow = 'weekly', limit = 50): Promise<TrendingTopic[]> {
    return await db
      .select()
      .from(trendingTopics)
      .where(eq(trendingTopics.timeWindow, timeWindow))
      .orderBy(desc(trendingTopics.score))
      .limit(limit);
  }

  async createTrendingTopic(insertTopic: InsertTrendingTopic): Promise<TrendingTopic> {
    const [topic] = await db
      .insert(trendingTopics)
      .values(insertTopic)
      .returning();
    return topic;
  }

  async updateTrendingTopic(id: number, updates: Partial<TrendingTopic>): Promise<TrendingTopic | undefined> {
    const [topic] = await db
      .update(trendingTopics)
      .set({ ...updates, calculatedAt: new Date() })
      .where(eq(trendingTopics.id, id))
      .returning();
    return topic || undefined;
  }

  // Feedback operations
  async createFeedback(feedbackData: InsertFeedback): Promise<Feedback> {
    const [newFeedback] = await db
      .insert(feedback)
      .values(feedbackData)
      .returning();
    return newFeedback;
  }

  async getAllFeedback(): Promise<Feedback[]> {
    return await db
      .select()
      .from(feedback)
      .orderBy(desc(feedback.createdAt));
  }

  async getFeedbackByRating(rating: number): Promise<Feedback[]> {
    return await db
      .select()
      .from(feedback)
      .where(eq(feedback.rating, rating))
      .orderBy(desc(feedback.createdAt));
  }

  async updateFeedback(id: number, updates: Partial<Feedback>): Promise<Feedback | undefined> {
    const [updated] = await db
      .update(feedback)
      .set(updates)
      .where(eq(feedback.id, id))
      .returning();
    return updated || undefined;
  }
}

export const storage = new DatabaseStorage();