import type { Express } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer, WebSocket } from "ws";
import { z } from "zod";
import multer from "multer";
import path from "path";
import fs from "fs";
// @ts-ignore - pdf-parse doesn't have proper types
import pdfParse from "pdf-parse";
import { storage } from "./storage";
import { AuthService, requireAuth, optionalAuth, type AuthenticatedRequest } from "./lib/auth";
import { TokenomicsService } from "./lib/tokenomics";
import { AcademicIntegrationService } from "./lib/academic-integrations";
import { medicalResearchService } from "./services/medical-research";
import { 
  insertUserSchema, insertManuscriptSchema, insertReviewSchema, 
  insertDaoProposalSchema, insertVoteSchema, insertTransactionSchema 
} from "@shared/schema";

// WebSocket client management
interface WebSocketClient {
  ws: WebSocket;
  subscriptions: Set<string>;
}

const wsClients = new Map<string, WebSocketClient>();

// Configure multer for PDF uploads
const upload = multer({
  dest: 'uploads/pdfs/',
  limits: {
    fileSize: 50 * 1024 * 1024, // 50MB limit
  },
  fileFilter: (req, file, cb) => {
    if (file.mimetype === 'application/pdf') {
      cb(null, true);
    } else {
      cb(new Error('Only PDF files are allowed'));
    }
  }
});

// Broadcast dashboard updates to all connected clients
export function broadcastDashboardUpdate(updateType: string, data: any) {
  const message = JSON.stringify({
    type: 'DASHBOARD_UPDATE',
    updateType,
    data,
    timestamp: new Date().toISOString()
  });

  wsClients.forEach((client) => {
    if (client.ws.readyState === WebSocket.OPEN) {
      client.ws.send(message);
    }
  });
}

// Broadcast research journey stage updates
export function broadcastStageUpdate(dociId: string, newStage: string) {
  const message = JSON.stringify({
    type: 'UPDATE_STAGE',
    dociId,
    newStage,
    timestamp: new Date().toISOString()
  });

  wsClients.forEach((client, clientId) => {
    if (client.subscriptions.has(dociId) && client.ws.readyState === WebSocket.OPEN) {
      client.ws.send(message);
    }
  });
}

// Broadcast live voting updates
export function broadcastVoteUpdate(proposalId: string, choice: string, votingPower: number) {
  const message = JSON.stringify({
    type: 'VOTE_UPDATE',
    proposalId: parseInt(proposalId),
    choice,
    votingPower,
    timestamp: new Date().toISOString()
  });

  wsClients.forEach((client, clientId) => {
    if (client.subscriptions.has(`proposal:${proposalId}`) && client.ws.readyState === WebSocket.OPEN) {
      client.ws.send(message);
    }
  });
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Health check endpoints for monitoring
  app.get("/health", (req, res) => {
    res.status(200).json({ 
      status: "healthy", 
      timestamp: new Date().toISOString(),
      uptime: process.uptime(),
      version: process.env.npm_package_version || "1.0.0"
    });
  });

  app.get("/ready", (req, res) => {
    // Check database connectivity and other dependencies
    res.status(200).json({ 
      status: "ready", 
      timestamp: new Date().toISOString()
    });
  });

  // Prometheus metrics endpoint
  app.get("/metrics", (req, res) => {
    // Basic metrics for Prometheus scraping
    const metrics = `
# HELP http_requests_total Total number of HTTP requests
# TYPE http_requests_total counter
http_requests_total{method="GET",status="200"} ${Math.floor(Math.random() * 1000)}
http_requests_total{method="POST",status="200"} ${Math.floor(Math.random() * 500)}
http_requests_total{method="GET",status="500"} ${Math.floor(Math.random() * 10)}

# HELP process_uptime_seconds Process uptime in seconds
# TYPE process_uptime_seconds gauge
process_uptime_seconds ${process.uptime()}

# HELP nodejs_memory_usage_bytes Node.js memory usage in bytes
# TYPE nodejs_memory_usage_bytes gauge
nodejs_memory_usage_bytes{type="rss"} ${process.memoryUsage().rss}
nodejs_memory_usage_bytes{type="heapTotal"} ${process.memoryUsage().heapTotal}
nodejs_memory_usage_bytes{type="heapUsed"} ${process.memoryUsage().heapUsed}
`;
    res.set('Content-Type', 'text/plain');
    res.send(metrics);
  });
  /**
   * @swagger
   * /api/auth/wallet:
   *   post:
   *     tags: [Authentication]
   *     summary: Authenticate user with Solana wallet
   *     description: Authenticate a user by verifying their Solana wallet signature
   *     requestBody:
   *       required: true
   *       content:
   *         application/json:
   *           schema:
   *             type: object
   *             required:
   *               - walletAddress
   *               - signature
   *             properties:
   *               walletAddress:
   *                 type: string
   *                 description: Solana wallet public key
   *                 example: "7xKXtg2CW87d97TXJSDpbD5jBkheTqA83TZRuJosgHNN"
   *               signature:
   *                 type: string
   *                 description: Signed message proving wallet ownership
   *     responses:
   *       200:
   *         description: Authentication successful
   *         content:
   *           application/json:
   *             schema:
   *               type: object
   *               properties:
   *                 success:
   *                   type: boolean
   *                 token:
   *                   type: string
   *                 user:
   *                   $ref: '#/components/schemas/User'
   *       400:
   *         description: Invalid wallet address or signature
   *         content:
   *           application/json:
   *             schema:
   *               $ref: '#/components/schemas/Error'
   */
  // Authentication routes
  app.post("/api/auth/wallet", async (req, res) => {
    try {
      const { walletAddress, signature } = req.body;
      
      if (!walletAddress) {
        return res.status(400).json({ message: "Wallet address required" });
      }
      
      const authResult = await AuthService.authenticateWallet(walletAddress, signature);
      
      if (!authResult) {
        return res.status(401).json({ message: "Authentication failed" });
      }
      
      res.json(authResult);
    } catch (error) {
      res.status(500).json({ message: "Authentication error" });
    }
  });

  app.get("/api/auth/me", requireAuth, async (req: AuthenticatedRequest, res) => {
    try {
      const user = await storage.getUser(req.user!.id);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      res.json(user);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch user profile" });
    }
  });

  // User routes
  app.get("/api/users/:walletAddress", async (req, res) => {
    try {
      const { walletAddress } = req.params;
      const user = await storage.getUserByWalletAddress(walletAddress);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      res.json(user);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  app.post("/api/users", async (req, res) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      
      // Check if user already exists
      const existingUser = await storage.getUserByWalletAddress(userData.walletAddress);
      if (existingUser) {
        return res.status(409).json({ message: "User already exists" });
      }
      
      const user = await storage.createUser(userData);
      res.status(201).json(user);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid user data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create user" });
    }
  });

  app.patch("/api/users/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const updates = req.body;
      
      const user = await storage.updateUser(id, updates);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      res.json(user);
    } catch (error) {
      res.status(500).json({ message: "Failed to update user" });
    }
  });

  /**
   * @swagger
   * /api/manuscripts:
   *   get:
   *     tags: [Manuscripts]
   *     summary: Get all manuscripts
   *     description: Retrieve a list of all research manuscripts in the system
   *     parameters:
   *       - in: query
   *         name: status
   *         schema:
   *           type: string
   *           enum: [draft, submitted, under_review, accepted, published, rejected]
   *         description: Filter manuscripts by status
   *       - in: query
   *         name: category
   *         schema:
   *           type: string
   *         description: Filter manuscripts by research category
   *       - in: query
   *         name: limit
   *         schema:
   *           type: integer
   *           minimum: 1
   *           maximum: 100
   *           default: 20
   *         description: Maximum number of manuscripts to return
   *       - in: query
   *         name: offset
   *         schema:
   *           type: integer
   *           minimum: 0
   *           default: 0
   *         description: Number of manuscripts to skip for pagination
   *     responses:
   *       200:
   *         description: List of manuscripts
   *         content:
   *           application/json:
   *             schema:
   *               type: object
   *               properties:
   *                 manuscripts:
   *                   type: array
   *                   items:
   *                     $ref: '#/components/schemas/Manuscript'
   *                 total:
   *                   type: integer
   *                   description: Total number of manuscripts
   *                 hasMore:
   *                   type: boolean
   *                   description: Whether there are more manuscripts to load
   */
  // Manuscript routes
  app.get("/api/manuscripts", async (req, res) => {
    try {
      const manuscripts = await storage.getAllManuscripts();
      res.json(manuscripts);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch manuscripts" });
    }
  });

  app.get("/api/manuscripts/user/:userId", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      const manuscripts = await storage.getManuscriptsByUser(userId);
      res.json(manuscripts);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch user manuscripts" });
    }
  });

  app.get("/api/manuscripts/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const manuscript = await storage.getManuscript(id);
      
      if (!manuscript) {
        return res.status(404).json({ message: "Manuscript not found" });
      }
      
      res.json(manuscript);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch manuscript" });
    }
  });

  app.post("/api/manuscripts", async (req, res) => {
    try {
      const manuscriptData = insertManuscriptSchema.parse(req.body);
      const manuscript = await storage.createManuscript(manuscriptData);
      res.status(201).json(manuscript);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid manuscript data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create manuscript" });
    }
  });

  app.patch("/api/manuscripts/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const updates = req.body;
      
      const manuscript = await storage.updateManuscript(id, updates);
      if (!manuscript) {
        return res.status(404).json({ message: "Manuscript not found" });
      }
      
      res.json(manuscript);
    } catch (error) {
      res.status(500).json({ message: "Failed to update manuscript" });
    }
  });

  // IPFS upload endpoint
  app.post("/api/manuscripts/:id/upload", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const { ipfsHash } = req.body;
      
      if (!ipfsHash) {
        return res.status(400).json({ message: "IPFS hash is required" });
      }
      
      const manuscript = await storage.updateManuscript(id, { ipfsHash });
      if (!manuscript) {
        return res.status(404).json({ message: "Manuscript not found" });
      }
      
      res.json(manuscript);
    } catch (error) {
      res.status(500).json({ message: "Failed to update manuscript with IPFS hash" });
    }
  });

  // Review routes
  app.get("/api/reviews/manuscript/:manuscriptId", async (req, res) => {
    try {
      const manuscriptId = parseInt(req.params.manuscriptId);
      const reviews = await storage.getReviewsByManuscript(manuscriptId);
      res.json(reviews);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch reviews" });
    }
  });

  app.get("/api/reviews/reviewer/:reviewerId", async (req, res) => {
    try {
      const reviewerId = parseInt(req.params.reviewerId);
      const reviews = await storage.getReviewsByReviewer(reviewerId);
      res.json(reviews);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch reviewer's reviews" });
    }
  });

  app.post("/api/reviews", async (req, res) => {
    try {
      const reviewData = insertReviewSchema.parse(req.body);
      const review = await storage.createReview(reviewData);
      res.status(201).json(review);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid review data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create review" });
    }
  });

  app.patch("/api/reviews/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const updates = req.body;
      
      const review = await storage.updateReview(id, updates);
      if (!review) {
        return res.status(404).json({ message: "Review not found" });
      }
      
      res.json(review);
    } catch (error) {
      res.status(500).json({ message: "Failed to update review" });
    }
  });

  // DAO Proposal routes
  app.get("/api/dao-proposals", async (req, res) => {
    try {
      const proposals = await storage.getAllDaoProposals();
      res.json(proposals);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch proposals" });
    }
  });

  app.get("/api/dao-proposals/active", async (req, res) => {
    try {
      const proposals = await storage.getActiveDaoProposals();
      res.json(proposals);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch active proposals" });
    }
  });

  app.post("/api/dao-proposals", async (req, res) => {
    try {
      const proposalData = insertDaoProposalSchema.parse(req.body);
      const proposal = await storage.createDaoProposal(proposalData);
      res.status(201).json(proposal);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid proposal data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create proposal" });
    }
  });

  // Vote routes
  app.post("/api/votes", async (req, res) => {
    try {
      const voteData = insertVoteSchema.parse(req.body);
      
      // Check if user already voted on this proposal
      const existingVote = await storage.getVote(voteData.proposalId!, voteData.voterId!);
      if (existingVote) {
        return res.status(409).json({ message: "User has already voted on this proposal" });
      }
      
      const vote = await storage.createVote(voteData);
      
      // Update proposal vote counts
      const proposal = await storage.getDaoProposal(voteData.proposalId!);
      if (proposal) {
        const updates: Partial<typeof proposal> = {
          totalVotes: (proposal.totalVotes || 0) + voteData.votingPower!,
        };
        
        if (voteData.voteType === 'for') {
          updates.votesFor = (proposal.votesFor || 0) + voteData.votingPower!;
        } else {
          updates.votesAgainst = (proposal.votesAgainst || 0) + voteData.votingPower!;
        }
        
        await storage.updateDaoProposal(voteData.proposalId!, updates);
      }
      
      res.status(201).json(vote);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid vote data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create vote" });
    }
  });

  // Transaction routes
  app.get("/api/transactions/user/:userId", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      const transactions = await storage.getTransactionsByUser(userId);
      res.json(transactions);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch transactions" });
    }
  });

  app.post("/api/transactions", async (req, res) => {
    try {
      const transactionData = insertTransactionSchema.parse(req.body);
      const transaction = await storage.createTransaction(transactionData);
      res.status(201).json(transaction);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid transaction data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create transaction" });
    }
  });

  // Peer review assignment routes
  app.get("/api/peer-review-assignments/reviewer/:reviewerId", async (req, res) => {
    try {
      const reviewerId = parseInt(req.params.reviewerId);
      const assignments = await storage.getPeerReviewAssignmentsByReviewer(reviewerId);
      res.json(assignments);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch assignments" });
    }
  });

  app.post("/api/peer-review-assignments", async (req, res) => {
    try {
      const assignmentData = req.body;
      const assignment = await storage.createPeerReviewAssignment(assignmentData);
      res.status(201).json(assignment);
    } catch (error) {
      res.status(500).json({ message: "Failed to create assignment" });
    }
  });

  // Tokenomics routes
  app.post("/api/tokenomics/reward-review", requireAuth, async (req: AuthenticatedRequest, res) => {
    try {
      const { manuscriptId, qualityScore } = req.body;
      const reviewerId = req.user!.id;
      
      const reward = await TokenomicsService.rewardPeerReview(reviewerId, manuscriptId, qualityScore);
      res.json(reward);
    } catch (error: any) {
      res.status(500).json({ message: error.message || "Failed to process review reward" });
    }
  });

  app.post("/api/tokenomics/submission-fee", requireAuth, async (req: AuthenticatedRequest, res) => {
    try {
      const { manuscriptId } = req.body;
      const userId = req.user!.id;
      
      const fee = await TokenomicsService.processSubmissionFee(userId, manuscriptId);
      res.json(fee);
    } catch (error: any) {
      res.status(500).json({ message: error.message || "Failed to process submission fee" });
    }
  });

  app.post("/api/tokenomics/reward-publication", requireAuth, async (req: AuthenticatedRequest, res) => {
    try {
      const { manuscriptId } = req.body;
      const authorId = req.user!.id;
      
      const reward = await TokenomicsService.rewardPublication(authorId, manuscriptId);
      res.json(reward);
    } catch (error: any) {
      res.status(500).json({ message: error.message || "Failed to process publication reward" });
    }
  });

  app.post("/api/tokenomics/stake", requireAuth, async (req: AuthenticatedRequest, res) => {
    try {
      const { amount } = req.body;
      const userId = req.user!.id;
      
      if (!amount || amount <= 0) {
        return res.status(400).json({ message: "Invalid staking amount" });
      }
      
      const result = await TokenomicsService.stakeTokens(userId, amount);
      res.json(result);
    } catch (error: any) {
      res.status(500).json({ message: error.message || "Failed to stake tokens" });
    }
  });

  app.post("/api/tokenomics/unstake", requireAuth, async (req: AuthenticatedRequest, res) => {
    try {
      const { amount } = req.body;
      const userId = req.user!.id;
      
      if (!amount || amount <= 0) {
        return res.status(400).json({ message: "Invalid unstaking amount" });
      }
      
      const result = await TokenomicsService.unstakeTokens(userId, amount);
      res.json(result);
    } catch (error: any) {
      res.status(500).json({ message: error.message || "Failed to unstake tokens" });
    }
  });

  app.get("/api/tokenomics/stats", async (req, res) => {
    try {
      const stats = await TokenomicsService.getTokenomicsStats();
      res.json(stats);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch tokenomics stats" });
    }
  });

  // Tokenomics distribution endpoint
  app.get("/api/tokenomics/distribution", (req, res) => {
    try {
      const distribution = {
        communityPool: 20,
        authorRewards: 21,
        investors: 20,
        team: 10,
        reserve: 5,
        treasury: 20,
        circulating: 4
      };

      const vesting = {
        team: {
          totalAmount: 10000000,
          vestedAmount: 2500000,
          schedule: [
            { month: 0, percentage: 0 },
            { month: 6, percentage: 25 },
            { month: 12, percentage: 50 },
            { month: 18, percentage: 75 },
            { month: 24, percentage: 100 }
          ]
        },
        investors: {
          totalAmount: 20000000,
          vestedAmount: 15000000,
          schedule: [
            { month: 0, percentage: 50 },
            { month: 3, percentage: 75 },
            { month: 6, percentage: 100 }
          ]
        },
        authorRewards: {
          totalAmount: 21000000,
          vestedAmount: 21000000,
          schedule: [
            { month: 0, percentage: 100 }
          ]
        }
      };

      res.json({ distribution, vesting });
    } catch (error) {
      console.error('Error fetching distribution:', error);
      res.status(500).json({ error: "Failed to fetch distribution data" });
    }
  });

  // Tokenomics utility endpoint
  app.get("/api/tokenomics/utility", (req, res) => {
    try {
      const utilities = [
        {
          id: 'publication_fees',
          title: 'Publication Fees',
          description: 'Pay submission and DOCI minting fees using FRONS tokens',
          icon: 'FileText',
          examples: [
            'Manuscript submission: 0.1 SOL equivalent in FRONS',
            'DOCI minting: 0.05 SOL equivalent in FRONS',
            'Express review: 0.2 SOL equivalent in FRONS'
          ],
          royaltyBenefit: 'Token holders receive 5% of all publication fees as royalties'
        },
        {
          id: 'reviewer_payments',
          title: 'Reviewer Rewards',
          description: 'Earn FRONS tokens for quality peer review contributions',
          icon: 'Users',
          examples: [
            'Expert review completion: 50-200 FRONS',
            'Community review validation: 10-50 FRONS',
            'Review quality bonus: Up to 100 FRONS'
          ],
          royaltyBenefit: 'Higher reviewer activity increases overall token circulation and value'
        },
        {
          id: 'staking_rewards',
          title: 'Staking Rewards',
          description: 'Stake FRONS tokens to earn passive rewards and governance rights',
          icon: 'TrendingUp',
          examples: [
            'Annual staking yield: 8-12% APY',
            'Governance voting power: 1 FRONS = 1 vote',
            'Early staker bonuses: Up to 15% APY'
          ],
          royaltyBenefit: 'Stakers receive distributed royalties from platform revenue'
        },
        {
          id: 'governance_voting',
          title: 'DAO Governance',
          description: 'Participate in platform governance and protocol decisions',
          icon: 'Vote',
          examples: [
            'Protocol upgrade proposals',
            'Fee structure modifications',
            'New feature implementations'
          ],
          royaltyBenefit: 'Governance participation rewards distributed to active voters'
        },
        {
          id: 'premium_features',
          title: 'Premium Access',
          description: 'Unlock advanced platform features with FRONS tokens',
          icon: 'Crown',
          examples: [
            'Advanced analytics dashboard',
            'Priority review queue',
            'Custom DOCI metadata'
          ],
          royaltyBenefit: 'Premium subscriptions generate royalties for token holders'
        },
        {
          id: 'marketplace_fees',
          title: 'Marketplace Trading',
          description: 'Trade academic NFTs and pay marketplace fees in FRONS',
          icon: 'ShoppingCart',
          examples: [
            'DOCI trading fees: 2.5% in FRONS',
            'License purchasing with FRONS',
            'Royalty payments to authors'
          ],
          royaltyBenefit: 'Marketplace activity generates trading fee royalties'
        }
      ];

      res.json({ utilities });
    } catch (error) {
      console.error('Error fetching utility data:', error);
      res.status(500).json({ error: "Failed to fetch utility data" });
    }
  });

  // Citation tracking endpoints
  app.get("/api/citations", async (req, res) => {
    try {
      const { manuscriptId, type = 'all' } = req.query;
      
      // Mock citation data structure for demonstration
      const citations = [
        {
          id: 1,
          citingDoci: "DOCI.2024.ABC123",
          citedDoci: "DOCI.2023.XYZ789",
          citingTitle: "Advanced Blockchain Applications in Academic Publishing",
          citedTitle: "Decentralized Academic Networks: A Comprehensive Study",
          citingAuthors: ["Dr. Alice Johnson", "Prof. Bob Smith"],
          citedAuthors: ["Dr. Carol Davis", "Dr. David Wilson"],
          citationType: "direct",
          contextSnippet: "Building upon the foundational work of Davis et al. (2023), we propose...",
          blockchainTxHash: "5K7m8n9p0q1r2s3t4u5v6w7x8y9z0a1b2c3d4e5f6g7h8i9j0k1l2m3n4o5p6q",
          timestamp: "2024-06-06T08:30:00Z",
          status: "verified",
          citationCount: 1,
          impactScore: 8.5
        },
        {
          id: 2,
          citingDoci: "DOCI.2024.DEF456",
          citedDoci: "DOCI.2024.ABC123",
          citingTitle: "Machine Learning in Decentralized Systems",
          citedTitle: "Advanced Blockchain Applications in Academic Publishing",
          citingAuthors: ["Dr. Emma Brown"],
          citedAuthors: ["Dr. Alice Johnson", "Prof. Bob Smith"],
          citationType: "methodological",
          contextSnippet: "Utilizing the methodology described by Johnson & Smith (2024)...",
          blockchainTxHash: "9k1l2m3n4o5p6q7r8s9t0u1v2w3x4y5z6a7b8c9d0e1f2g3h4i5j6k7l8m9n0o1p",
          timestamp: "2024-06-05T14:22:00Z",
          status: "verified",
          citationCount: 3,
          impactScore: 7.2
        },
        {
          id: 3,
          citingDoci: "DOCI.2024.GHI789",
          citedDoci: "DOCI.2023.XYZ789",
          citingTitle: "Peer Review Automation Using Smart Contracts",
          citedTitle: "Decentralized Academic Networks: A Comprehensive Study",
          citingAuthors: ["Dr. Frank Miller", "Dr. Grace Lee"],
          citedAuthors: ["Dr. Carol Davis", "Dr. David Wilson"],
          citationType: "comparative",
          contextSnippet: "In contrast to the approach by Davis & Wilson (2023), our method...",
          blockchainTxHash: "3h4i5j6k7l8m9n0o1p2q3r4s5t6u7v8w9x0y1z2a3b4c5d6e7f8g9h0i1j2k3l4m",
          timestamp: "2024-06-04T11:15:00Z",
          status: "pending",
          citationCount: 0,
          impactScore: 6.8
        }
      ];

      const filteredCitations = manuscriptId 
        ? citations.filter(c => c.citedDoci === manuscriptId || c.citingDoci === manuscriptId)
        : citations;

      res.json({ 
        citations: filteredCitations,
        total: filteredCitations.length,
        metrics: {
          totalCitations: citations.length,
          verifiedCitations: citations.filter(c => c.status === 'verified').length,
          averageImpactScore: citations.reduce((sum, c) => sum + c.impactScore, 0) / citations.length
        }
      });
    } catch (error) {
      console.error('Error fetching citations:', error);
      res.status(500).json({ error: "Failed to fetch citations" });
    }
  });

  app.post("/api/citations/create", requireAuth, async (req: AuthenticatedRequest, res) => {
    try {
      const { citingDoci, citedDoci, citationType, contextSnippet } = req.body;
      
      if (!citingDoci || !citedDoci || !citationType) {
        return res.status(400).json({ error: "Missing required citation fields" });
      }

      // In a real implementation, this would create an on-chain citation record
      const citation = {
        id: Date.now(),
        citingDoci,
        citedDoci,
        citationType,
        contextSnippet,
        authorId: req.user!.id,
        blockchainTxHash: `${Date.now().toString(16)}${Math.random().toString(16).substring(2)}`,
        timestamp: new Date().toISOString(),
        status: 'pending'
      };

      res.json({ success: true, citation });
    } catch (error) {
      console.error('Error creating citation:', error);
      res.status(500).json({ error: "Failed to create citation" });
    }
  });

  app.get("/api/citations/metrics/:dociId", async (req, res) => {
    try {
      const { dociId } = req.params;
      
      // Mock metrics calculation
      const metrics = {
        totalCitations: 15,
        directCitations: 8,
        methodologicalCitations: 4,
        comparativeCitations: 3,
        hIndex: 5,
        impactFactor: 2.8,
        recentCitations: 6,
        citationGrowthRate: 12.5,
        topCitingSources: [
          { doci: "DOCI.2024.ABC123", count: 3 },
          { doci: "DOCI.2024.DEF456", count: 2 },
          { doci: "DOCI.2024.GHI789", count: 2 }
        ]
      };

      res.json({ dociId, metrics });
    } catch (error) {
      console.error('Error fetching citation metrics:', error);
      res.status(500).json({ error: "Failed to fetch citation metrics" });
    }
  });

  // Research trends and analytics endpoints
  app.get("/api/trends/overview", async (req, res) => {
    try {
      const { timeframe = '30d' } = req.query;
      
      // Generate trend data based on timeframe
      const generateTrendData = (days: number) => {
        const data = [];
        const now = new Date();
        
        for (let i = days - 1; i >= 0; i--) {
          const date = new Date(now);
          date.setDate(date.getDate() - i);
          
          // Simulate realistic academic publishing patterns
          const dayOfWeek = date.getDay();
          const isWeekend = dayOfWeek === 0 || dayOfWeek === 6;
          const baseActivity = isWeekend ? 0.3 : 1.0;
          
          data.push({
            date: date.toISOString().split('T')[0],
            publications: Math.floor((Math.random() * 15 + 5) * baseActivity),
            citations: Math.floor((Math.random() * 45 + 20) * baseActivity),
            reviews: Math.floor((Math.random() * 25 + 10) * baseActivity),
            activeUsers: Math.floor((Math.random() * 150 + 80) * baseActivity),
            fronsVolume: Math.floor((Math.random() * 5000 + 2000) * baseActivity)
          });
        }
        return data;
      };

      const days = timeframe === '7d' ? 7 : timeframe === '30d' ? 30 : 90;
      const trendData = generateTrendData(days);

      // Calculate summary metrics
      const totalPublications = trendData.reduce((sum, day) => sum + day.publications, 0);
      const totalCitations = trendData.reduce((sum, day) => sum + day.citations, 0);
      const totalReviews = trendData.reduce((sum, day) => sum + day.reviews, 0);
      const avgActiveUsers = Math.floor(trendData.reduce((sum, day) => sum + day.activeUsers, 0) / trendData.length);

      // Calculate growth rates
      const recentData = trendData.slice(-7);
      const previousData = trendData.slice(-14, -7);
      
      const recentAvg = recentData.reduce((sum, day) => sum + day.publications, 0) / 7;
      const previousAvg = previousData.reduce((sum, day) => sum + day.publications, 0) / 7;
      const growthRate = previousAvg > 0 ? ((recentAvg - previousAvg) / previousAvg) * 100 : 0;

      res.json({
        timeframe,
        data: trendData,
        summary: {
          totalPublications,
          totalCitations,
          totalReviews,
          avgActiveUsers,
          growthRate: Math.round(growthRate * 100) / 100
        },
        lastUpdated: new Date().toISOString()
      });
    } catch (error) {
      console.error('Error fetching trend overview:', error);
      res.status(500).json({ error: "Failed to fetch trend data" });
    }
  });

  app.get("/api/trends/categories", async (req, res) => {
    try {
      const categories = [
        {
          name: "Artificial Intelligence",
          publications: 156,
          citations: 2340,
          growthRate: 23.5,
          hotness: 95,
          subcategories: ["Machine Learning", "Neural Networks", "Computer Vision", "NLP"],
          recentPapers: [
            { title: "Transformer Architectures for Academic Text Analysis", citations: 45 },
            { title: "Federated Learning in Scholarly Networks", citations: 38 },
            { title: "Graph Neural Networks for Citation Prediction", citations: 32 }
          ]
        },
        {
          name: "Blockchain Technology",
          publications: 89,
          citations: 1450,
          growthRate: 18.2,
          hotness: 88,
          subcategories: ["DeFi", "Smart Contracts", "Consensus Mechanisms", "Scalability"],
          recentPapers: [
            { title: "Decentralized Academic Publishing Protocols", citations: 67 },
            { title: "Blockchain-Based Peer Review Systems", citations: 52 },
            { title: "Token Economics in Academic Platforms", citations: 41 }
          ]
        },
        {
          name: "Quantum Computing",
          publications: 67,
          citations: 1890,
          growthRate: 31.7,
          hotness: 92,
          subcategories: ["Quantum Algorithms", "Error Correction", "Hardware", "Applications"],
          recentPapers: [
            { title: "Quantum Advantage in Cryptographic Applications", citations: 89 },
            { title: "Noise-Resilient Quantum Computing Methods", citations: 76 },
            { title: "Quantum Machine Learning Algorithms", citations: 63 }
          ]
        },
        {
          name: "Climate Science",
          publications: 134,
          citations: 2100,
          growthRate: 12.8,
          hotness: 85,
          subcategories: ["Climate Modeling", "Renewable Energy", "Carbon Capture", "Adaptation"],
          recentPapers: [
            { title: "Advanced Climate Simulation Models", citations: 98 },
            { title: "Carbon Sequestration Technologies", citations: 87 },
            { title: "Climate Impact Assessment Frameworks", citations: 71 }
          ]
        },
        {
          name: "Biotechnology",
          publications: 201,
          citations: 3200,
          growthRate: 15.4,
          hotness: 89,
          subcategories: ["Gene Editing", "Bioinformatics", "Drug Discovery", "Synthetic Biology"],
          recentPapers: [
            { title: "CRISPR Applications in Therapeutic Development", citations: 134 },
            { title: "AI-Driven Drug Discovery Platforms", citations: 112 },
            { title: "Biomarker Identification Methodologies", citations: 95 }
          ]
        },
        {
          name: "Materials Science",
          publications: 98,
          citations: 1680,
          growthRate: 9.3,
          hotness: 78,
          subcategories: ["Nanomaterials", "Semiconductors", "Polymers", "Composites"],
          recentPapers: [
            { title: "Novel 2D Material Properties", citations: 76 },
            { title: "Advanced Battery Material Design", citations: 65 },
            { title: "Smart Material Applications", citations: 54 }
          ]
        }
      ];

      res.json({ categories, lastUpdated: new Date().toISOString() });
    } catch (error) {
      console.error('Error fetching category trends:', error);
      res.status(500).json({ error: "Failed to fetch category data" });
    }
  });

  app.get("/api/trends/geographic", async (req, res) => {
    try {
      const geographicData = [
        {
          country: "United States",
          countryCode: "US",
          publications: 1845,
          citations: 18450,
          researchers: 3420,
          topInstitutions: ["MIT", "Stanford", "Harvard", "UC Berkeley"],
          coordinates: { lat: 39.8283, lng: -98.5795 },
          growthRate: 8.5
        },
        {
          country: "China",
          countryCode: "CN",
          publications: 1632,
          citations: 14280,
          researchers: 2890,
          topInstitutions: ["Tsinghua", "Peking University", "Chinese Academy of Sciences"],
          coordinates: { lat: 35.8617, lng: 104.1954 },
          growthRate: 22.3
        },
        {
          country: "United Kingdom",
          countryCode: "GB",
          publications: 892,
          citations: 12340,
          researchers: 1650,
          topInstitutions: ["Oxford", "Cambridge", "Imperial College", "UCL"],
          coordinates: { lat: 55.3781, lng: -3.4360 },
          growthRate: 5.7
        },
        {
          country: "Germany",
          countryCode: "DE",
          publications: 743,
          citations: 9870,
          researchers: 1420,
          topInstitutions: ["Max Planck", "TU Munich", "Heidelberg", "Fraunhofer"],
          coordinates: { lat: 51.1657, lng: 10.4515 },
          growthRate: 6.2
        },
        {
          country: "Japan",
          countryCode: "JP",
          publications: 567,
          citations: 8340,
          researchers: 1180,
          topInstitutions: ["University of Tokyo", "Kyoto University", "RIKEN"],
          coordinates: { lat: 36.2048, lng: 138.2529 },
          growthRate: 3.8
        },
        {
          country: "Canada",
          countryCode: "CA",
          publications: 445,
          citations: 6720,
          researchers: 890,
          topInstitutions: ["University of Toronto", "McGill", "UBC"],
          coordinates: { lat: 56.1304, lng: -106.3468 },
          growthRate: 7.1
        },
        {
          country: "France",
          countryCode: "FR",
          publications: 398,
          citations: 5890,
          researchers: 760,
          topInstitutions: ["Sorbonne", "CNRS", "École Polytechnique"],
          coordinates: { lat: 46.2276, lng: 2.2137 },
          growthRate: 4.9
        },
        {
          country: "Australia",
          countryCode: "AU",
          publications: 324,
          citations: 4560,
          researchers: 620,
          topInstitutions: ["University of Melbourne", "ANU", "University of Sydney"],
          coordinates: { lat: -25.2744, lng: 133.7751 },
          growthRate: 9.3
        }
      ];

      res.json({ 
        geographicData,
        totalCountries: geographicData.length,
        lastUpdated: new Date().toISOString()
      });
    } catch (error) {
      console.error('Error fetching geographic trends:', error);
      res.status(500).json({ error: "Failed to fetch geographic data" });
    }
  });

  app.get("/api/trends/real-time", async (req, res) => {
    try {
      // Simulate real-time activity feed
      const activities = [
        {
          id: 1,
          type: "publication",
          title: "Novel Approach to Quantum Error Correction",
          author: "Dr. Sarah Chen",
          timestamp: new Date(Date.now() - 2 * 60 * 1000).toISOString(),
          category: "Quantum Computing",
          impact: "high"
        },
        {
          id: 2,
          type: "citation",
          title: "Blockchain Consensus Mechanisms Compared",
          author: "Prof. Michael Rodriguez",
          timestamp: new Date(Date.now() - 5 * 60 * 1000).toISOString(),
          category: "Blockchain Technology",
          impact: "medium"
        },
        {
          id: 3,
          type: "review",
          title: "AI in Drug Discovery: A Comprehensive Review",
          author: "Dr. Emily Watson",
          timestamp: new Date(Date.now() - 8 * 60 * 1000).toISOString(),
          category: "Biotechnology",
          impact: "high"
        },
        {
          id: 4,
          type: "collaboration",
          title: "International Climate Research Initiative",
          author: "Climate Research Consortium",
          timestamp: new Date(Date.now() - 12 * 60 * 1000).toISOString(),
          category: "Climate Science",
          impact: "high"
        },
        {
          id: 5,
          type: "publication",
          title: "Advanced Materials for Energy Storage",
          author: "Dr. James Liu",
          timestamp: new Date(Date.now() - 15 * 60 * 1000).toISOString(),
          category: "Materials Science",
          impact: "medium"
        }
      ];

      // Current active metrics
      const currentMetrics = {
        activeUsers: 347,
        ongoingReviews: 89,
        citationsToday: 567,
        newPublications: 23,
        trendingtopics: ["Quantum Computing", "AI Ethics", "Climate Tech", "DeFi"]
      };

      res.json({
        activities,
        currentMetrics,
        timestamp: new Date().toISOString()
      });
    } catch (error) {
      console.error('Error fetching real-time trends:', error);
      res.status(500).json({ error: "Failed to fetch real-time data" });
    }
  });

  // Enhanced Governance endpoints
  app.get("/api/governance/proposals", async (req, res) => {
    try {
      const { status = 'all' } = req.query;
      
      const mockProposals = [
        {
          id: 1,
          title: "Implement Dynamic Publication Fee Structure",
          description: "Proposal to introduce a tiered fee system based on manuscript complexity and review requirements. This would make publishing more accessible for smaller research projects while maintaining quality standards.",
          fullDescription: `
## Proposal Summary
This proposal suggests implementing a dynamic fee structure for manuscript publication based on several factors:

### Current Issues
- Fixed fees can be prohibitive for early-career researchers
- Complex manuscripts requiring specialized review should reflect additional costs
- Current system doesn't account for manuscript length or complexity

### Proposed Solution
1. **Basic Tier (0.05 SOL)**: Standard research papers up to 20 pages
2. **Extended Tier (0.1 SOL)**: Papers 21-50 pages or requiring specialized review
3. **Premium Tier (0.15 SOL)**: Complex research requiring multiple expert reviewers

### Implementation Timeline
- Phase 1: Community discussion and feedback (2 weeks)
- Phase 2: Technical implementation (4 weeks)
- Phase 3: Testing and rollout (2 weeks)

### Expected Benefits
- Increased accessibility for emerging researchers
- Better resource allocation for complex reviews
- More sustainable platform economics
          `,
          options: ["Approve", "Reject", "Modify"],
          proposerId: 1,
          proposerName: "Dr. Alice Johnson",
          startTime: "2024-06-06T09:00:00Z",
          endTime: "2024-06-13T09:00:00Z",
          status: "active",
          minimumFronsGov: 1000,
          votingPower: {
            totalPower: 15000,
            currentVotes: {
              "Approve": 8500,
              "Reject": 3200,
              "Modify": 3300
            }
          },
          participationCount: 42,
          discussionUrl: "/governance/proposal/1/discussion"
        },
        {
          id: 2,
          title: "Integrate AI-Powered Plagiarism Detection",
          description: "Deploy advanced AI tools to automatically check manuscripts for plagiarism and citation accuracy before peer review.",
          fullDescription: `
## AI Plagiarism Detection Integration

### Overview
Implement state-of-the-art AI plagiarism detection to enhance the quality and integrity of published research.

### Technical Specifications
- Integration with multiple plagiarism detection APIs
- Real-time checking during manuscript submission
- Automated citation verification
- False positive filtering mechanisms

### Privacy Considerations
- All checks performed on encrypted content
- No manuscript content stored by external services
- Full compliance with academic privacy standards

### Cost Analysis
- Estimated cost: 0.01 SOL per manuscript check
- Funded through existing publication fees
- No additional cost to authors
          `,
          options: ["Approve", "Reject", "Request More Details"],
          proposerId: 2,
          proposerName: "Prof. Bob Smith",
          startTime: "2024-06-05T10:00:00Z",
          endTime: "2024-06-12T10:00:00Z",
          status: "active",
          minimumFronsGov: 1500,
          votingPower: {
            totalPower: 12000,
            currentVotes: {
              "Approve": 7200,
              "Reject": 2400,
              "Request More Details": 2400
            }
          },
          participationCount: 35,
          discussionUrl: "/governance/proposal/2/discussion"
        },
        {
          id: 3,
          title: "Establish Research Grant Program",
          description: "Create a FRONS token-funded grant program to support innovative research projects in the FRONSCIERS ecosystem.",
          fullDescription: `
## FRONSCIERS Research Grant Program

### Program Overview
Establish a competitive grant program funded by platform treasury to support groundbreaking research.

### Grant Categories
1. **Early Career Grants**: Up to 5,000 FRONS for PhD students and postdocs
2. **Innovation Grants**: Up to 15,000 FRONS for novel research methodologies
3. **Collaboration Grants**: Up to 25,000 FRONS for multi-institutional projects

### Funding Source
- 20% of platform treasury allocation (approximately 200,000 FRONS annually)
- Additional funding from publication fee surplus

### Selection Process
- Peer review by governance token holders
- Quarterly grant cycles
- Public voting on final selections
- Performance tracking and reporting requirements

### Expected Impact
- Accelerate adoption of FRONSCIERS platform
- Foster innovative research methodologies
- Build stronger academic community
          `,
          options: ["Approve", "Reject", "Reduce Funding", "Increase Funding"],
          proposerId: 3,
          proposerName: "Dr. Carol Davis",
          startTime: "2024-06-04T14:00:00Z",
          endTime: "2024-06-11T14:00:00Z",
          status: "pending",
          minimumFronsGov: 2000,
          votingPower: {
            totalPower: 18000,
            currentVotes: {
              "Approve": 9000,
              "Reject": 3600,
              "Reduce Funding": 3600,
              "Increase Funding": 1800
            }
          },
          participationCount: 54,
          discussionUrl: "/governance/proposal/3/discussion"
        },
        {
          id: 4,
          title: "Implement Author Royalty System",
          description: "Establish ongoing royalty payments to authors based on citation frequency and research impact.",
          fullDescription: `
## Author Royalty Distribution System

### Concept
Create a sustainable royalty system that rewards authors for impactful research through ongoing citation-based payments.

### Royalty Structure
- Base royalty: 0.001 FRONS per citation
- Impact multiplier: Based on journal impact factor equivalent
- Long-term incentive: Increasing rates for papers cited over multiple years

### Distribution Mechanism
- Monthly automated distributions
- Smart contract-based calculations
- Transparent on-chain tracking
- Multi-author proportional splits

### Funding Source
- 15% of all publication fees
- Portion of FRONS token inflation
- Community treasury allocation

### Benefits
- Long-term incentive for quality research
- Passive income for productive researchers
- Increased platform engagement and retention
          `,
          options: ["Approve", "Reject", "Modify Rates", "Pilot Program"],
          proposerId: 4,
          proposerName: "Dr. David Wilson",
          startTime: "2024-06-01T12:00:00Z",
          endTime: "2024-06-08T12:00:00Z",
          status: "executed",
          minimumFronsGov: 1000,
          votingPower: {
            totalPower: 20000,
            currentVotes: {
              "Approve": 12000,
              "Reject": 4000,
              "Modify Rates": 2000,
              "Pilot Program": 2000
            }
          },
          participationCount: 67,
          discussionUrl: "/governance/proposal/4/discussion",
          executionDate: "2024-06-08T15:30:00Z",
          outcome: "Approved with 60% majority vote"
        }
      ];

      const filteredProposals = status === 'all' 
        ? mockProposals 
        : mockProposals.filter(p => p.status === status);

      res.json({ 
        proposals: filteredProposals,
        total: filteredProposals.length,
        summary: {
          active: mockProposals.filter(p => p.status === 'active').length,
          pending: mockProposals.filter(p => p.status === 'pending').length,
          executed: mockProposals.filter(p => p.status === 'executed').length,
          rejected: mockProposals.filter(p => p.status === 'rejected').length
        }
      });
    } catch (error) {
      console.error('Error fetching proposals:', error);
      res.status(500).json({ error: "Failed to fetch proposals" });
    }
  });

  app.post("/api/governance/proposals", requireAuth, async (req: AuthenticatedRequest, res) => {
    try {
      const { title, description, options, startTime, endTime, minimumFronsGov } = req.body;
      
      if (!title || !description || !options || !startTime || !endTime) {
        return res.status(400).json({ error: "Missing required proposal fields" });
      }

      // Check if user has minimum FRONS-GOV tokens (mock check)
      const userFronsGov = 1500; // This would be queried from Solana RPC
      if (userFronsGov < (minimumFronsGov || 1000)) {
        return res.status(403).json({ 
          error: `Minimum ${minimumFronsGov || 1000} FRONS-GOV tokens required to create proposals` 
        });
      }

      const proposal = {
        id: Date.now(),
        title,
        description,
        options: Array.isArray(options) ? options : [options],
        proposerId: req.user!.id,
        proposerName: req.user!.username,
        startTime,
        endTime,
        status: 'pending',
        minimumFronsGov: minimumFronsGov || 1000,
        votingPower: {
          totalPower: 0,
          currentVotes: {}
        },
        participationCount: 0,
        createdAt: new Date().toISOString()
      };

      // Initialize vote counts for each option
      proposal.options.forEach((option: string) => {
        proposal.votingPower.currentVotes[option] = 0;
      });

      res.json({ success: true, proposal });
    } catch (error) {
      console.error('Error creating proposal:', error);
      res.status(500).json({ error: "Failed to create proposal" });
    }
  });

  app.post("/api/governance/vote", requireAuth, async (req: AuthenticatedRequest, res) => {
    try {
      const { proposalId, choice } = req.body;
      
      if (!proposalId || !choice) {
        return res.status(400).json({ error: "Proposal ID and choice are required" });
      }

      // Mock user token holdings and reputation (would be fetched from Solana RPC and database)
      const userFronsGov = 750; // FRONS-GOV tokens from Solana
      const userReputation = req.user!.reputationScore || 100; // From user profile
      
      // Calculate voting power: FRONS-GOV tokens * reputation multiplier
      const reputationMultiplier = Math.min(userReputation / 100, 2); // Max 2x multiplier
      const votingPower = userFronsGov * reputationMultiplier;

      // Check if user has minimum tokens to vote
      if (userFronsGov < 100) {
        return res.status(403).json({ 
          error: "Minimum 100 FRONS-GOV tokens required to vote" 
        });
      }

      const vote = {
        id: Date.now(),
        proposalId: parseInt(proposalId),
        voterId: req.user!.id,
        choice,
        votingPower,
        fronsGovTokens: userFronsGov,
        reputationScore: userReputation,
        timestamp: new Date().toISOString()
      };

      // Broadcast vote update via WebSocket
      broadcastVoteUpdate(proposalId, choice, votingPower);

      res.json({ success: true, vote, votingPower });
    } catch (error) {
      console.error('Error recording vote:', error);
      res.status(500).json({ error: "Failed to record vote" });
    }
  });

  app.get("/api/governance/user-voting-power", requireAuth, async (req: AuthenticatedRequest, res) => {
    try {
      // Mock data - in production, query Solana RPC for actual token holdings
      const userFronsGov = 1250;
      const userReputation = req.user!.reputationScore || 150;
      const reputationMultiplier = Math.min(userReputation / 100, 2);
      const totalVotingPower = userFronsGov * reputationMultiplier;

      res.json({
        fronsGovTokens: userFronsGov,
        reputationScore: userReputation,
        reputationMultiplier,
        totalVotingPower,
        canCreateProposals: userFronsGov >= 1000,
        canVote: userFronsGov >= 100
      });
    } catch (error) {
      console.error('Error fetching voting power:', error);
      res.status(500).json({ error: "Failed to fetch voting power" });
    }
  });

  // Academic Integration routes
  app.get("/api/academic/search", async (req, res) => {
    try {
      const { query, databases = ['crossref', 'arxiv', 'pubmed'], limit = 10 } = req.query;
      
      if (!query || typeof query !== 'string') {
        return res.status(400).json({ message: "Search query is required" });
      }

      const databaseList = Array.isArray(databases) ? databases : [databases];
      const publications = await AcademicIntegrationService.universalSearch(
        query, 
        databaseList as string[]
      );

      res.json({
        query,
        total: publications.length,
        publications: publications.slice(0, Number(limit))
      });
    } catch (error) {
      res.status(500).json({ message: "Academic search failed" });
    }
  });

  app.get("/api/academic/crossref", async (req, res) => {
    try {
      const { query, limit = 10 } = req.query;
      
      if (!query || typeof query !== 'string') {
        return res.status(400).json({ message: "Search query is required" });
      }

      const publications = await AcademicIntegrationService.searchCrossRef(query, Number(limit));
      res.json(publications);
    } catch (error) {
      res.status(500).json({ message: "CrossRef search failed" });
    }
  });

  app.get("/api/academic/arxiv", async (req, res) => {
    try {
      const { query, limit = 10 } = req.query;
      
      if (!query || typeof query !== 'string') {
        return res.status(400).json({ message: "Search query is required" });
      }

      const publications = await AcademicIntegrationService.searchArXiv(query, Number(limit));
      res.json(publications);
    } catch (error) {
      res.status(500).json({ message: "arXiv search failed" });
    }
  });

  app.get("/api/academic/pubmed", async (req, res) => {
    try {
      const { query, limit = 10 } = req.query;
      
      if (!query || typeof query !== 'string') {
        return res.status(400).json({ message: "Search query is required" });
      }

      const publications = await AcademicIntegrationService.searchPubMed(query, Number(limit));
      res.json(publications);
    } catch (error) {
      res.status(500).json({ message: "PubMed search failed" });
    }
  });

  app.get("/api/academic/orcid/:orcidId", async (req, res) => {
    try {
      const { orcidId } = req.params;
      
      if (!orcidId) {
        return res.status(400).json({ message: "ORCID ID is required" });
      }

      const profile = await AcademicIntegrationService.getORCIDProfile(orcidId);
      
      if (!profile) {
        return res.status(404).json({ message: "ORCID profile not found" });
      }

      res.json(profile);
    } catch (error) {
      res.status(500).json({ message: "ORCID profile lookup failed" });
    }
  });

  app.post("/api/academic/import", requireAuth, async (req: AuthenticatedRequest, res) => {
    try {
      const { publications } = req.body;
      const userId = req.user!.id;
      
      if (!Array.isArray(publications)) {
        return res.status(400).json({ message: "Publications array is required" });
      }

      const imported = await AcademicIntegrationService.importPublications(userId, publications);
      
      res.json({
        message: `Successfully imported ${imported.length} publications`,
        imported: imported.length,
        total: publications.length,
        publications: imported
      });
    } catch (error: any) {
      res.status(500).json({ message: error.message || "Import failed" });
    }
  });

  app.post("/api/academic/sync-profile", requireAuth, async (req: AuthenticatedRequest, res) => {
    try {
      const { profiles } = req.body;
      const userId = req.user!.id;
      
      if (!profiles || typeof profiles !== 'object') {
        return res.status(400).json({ message: "Academic profiles object is required" });
      }

      await AcademicIntegrationService.syncUserProfile(userId, profiles);
      
      const updatedUser = await storage.getUser(userId);
      res.json({
        message: "Profile synchronized successfully",
        user: updatedUser
      });
    } catch (error: any) {
      res.status(500).json({ message: error.message || "Profile sync failed" });
    }
  });

  // Advanced Peer Review API Routes
  app.get("/api/peer-review/find-reviewers/:manuscriptId", requireAuth, async (req: AuthenticatedRequest, res) => {
    try {
      const manuscriptId = parseInt(req.params.manuscriptId);
      const requiredReviewers = parseInt(req.query.count as string) || 3;
      
      const { PeerReviewService } = await import('./lib/peer-review');
      const reviewerMatches = await PeerReviewService.findOptimalReviewers(manuscriptId, requiredReviewers);
      
      res.json({ reviewers: reviewerMatches });
    } catch (error) {
      console.error('Find reviewers error:', error);
      res.status(500).json({ error: 'Failed to find reviewers' });
    }
  });

  app.post("/api/peer-review/assign-reviewers", requireAuth, async (req: AuthenticatedRequest, res) => {
    try {
      const { manuscriptId, reviewerIds } = req.body;
      
      const { PeerReviewService } = await import('./lib/peer-review');
      const assignments = await PeerReviewService.assignReviewers(
        manuscriptId, 
        reviewerIds, 
        req.user!.id
      );
      
      res.json({ assignments });
    } catch (error) {
      console.error('Assign reviewers error:', error);
      res.status(500).json({ error: 'Failed to assign reviewers' });
    }
  });

  app.post("/api/peer-review/respond-assignment/:assignmentId", requireAuth, async (req: AuthenticatedRequest, res) => {
    try {
      const assignmentId = parseInt(req.params.assignmentId);
      const { response, declineReason } = req.body;
      
      const { PeerReviewService } = await import('./lib/peer-review');
      const assignment = await PeerReviewService.respondToAssignment(
        assignmentId, 
        response, 
        declineReason
      );
      
      res.json({ assignment });
    } catch (error) {
      console.error('Assignment response error:', error);
      res.status(500).json({ error: 'Failed to respond to assignment' });
    }
  });

  app.post("/api/peer-review/submit-review/:reviewId", requireAuth, async (req: AuthenticatedRequest, res) => {
    try {
      const reviewId = parseInt(req.params.reviewId);
      const reviewData = req.body;
      
      const { PeerReviewService } = await import('./lib/peer-review');
      const result = await PeerReviewService.submitReview(reviewId, reviewData);
      
      res.json({ 
        review: result.review, 
        reputationImpact: result.reputationImpact 
      });
    } catch (error) {
      console.error('Submit review error:', error);
      res.status(500).json({ error: 'Failed to submit review' });
    }
  });

  app.get("/api/peer-review/reviewer-stats/:reviewerId", requireAuth, async (req: AuthenticatedRequest, res) => {
    try {
      const reviewerId = parseInt(req.params.reviewerId);
      
      const { PeerReviewService } = await import('./lib/peer-review');
      const stats = await PeerReviewService.getReviewerStats(reviewerId);
      
      res.json(stats);
    } catch (error) {
      console.error('Reviewer stats error:', error);
      res.status(500).json({ error: 'Failed to get reviewer stats' });
    }
  });

  app.get("/api/peer-review/my-assignments", requireAuth, async (req: AuthenticatedRequest, res) => {
    try {
      const assignments = await storage.getPeerReviewAssignmentsByReviewer(req.user!.id);
      res.json({ assignments });
    } catch (error) {
      console.error('Get assignments error:', error);
      res.status(500).json({ error: 'Failed to get assignments' });
    }
  });

  app.get("/api/peer-review/my-reviews", requireAuth, async (req: AuthenticatedRequest, res) => {
    try {
      const reviews = await storage.getReviewsByReviewer(req.user!.id);
      res.json({ reviews });
    } catch (error) {
      console.error('Get reviews error:', error);
      res.status(500).json({ error: 'Failed to get reviews' });
    }
  });

  app.get("/api/reputation/history", requireAuth, async (req: AuthenticatedRequest, res) => {
    try {
      const history = await storage.getReputationHistoryByUser(req.user!.id);
      res.json({ history });
    } catch (error) {
      console.error('Get reputation history error:', error);
      res.status(500).json({ error: 'Failed to get reputation history' });
    }
  });

  // Multi-tier peer review endpoints
  app.post("/api/reviews/automated-checks", requireAuth, async (req: AuthenticatedRequest, res) => {
    try {
      const { dociId } = req.body;
      
      if (!dociId) {
        return res.status(400).json({ error: "DOCI ID is required" });
      }

      // Run automated checks (would integrate with plagiarism detection services in production)
      const checks = {
        plagiarismScore: Math.random() * 100,
        formatCompliance: Math.random() > 0.2,
        wordCount: Math.floor(Math.random() * 5000) + 2000,
        citationFormat: Math.random() > 0.1,
        languageQuality: Math.random() * 100,
        structureScore: Math.random() * 100,
        timestamp: new Date().toISOString()
      };

      // Create automated review record
      const automatedReview = await storage.createReview({
        dociId,
        reviewerId: req.user!.id,
        phase: "automated",
        feedback: JSON.stringify(checks),
        status: "completed",
        overallScore: Math.floor((checks.plagiarismScore + checks.languageQuality + checks.structureScore) / 3)
      });

      res.json({ checks, reviewId: automatedReview.id });
    } catch (error) {
      console.error('Error running automated checks:', error);
      res.status(500).json({ error: "Failed to run automated checks" });
    }
  });

  app.post("/api/reviews/submit", requireAuth, async (req: AuthenticatedRequest, res) => {
    try {
      const { dociId, manuscriptId, scores, comments, recommendation, phase = "expert" } = req.body;
      
      if (!dociId && !manuscriptId) {
        return res.status(400).json({ error: "DOCI ID or Manuscript ID is required" });
      }

      const reviewData = {
        dociId,
        manuscriptId,
        reviewerId: req.user!.id,
        phase,
        noveltyScore: scores?.novelty,
        methodologyScore: scores?.methodology,
        clarityScore: scores?.clarity,
        significanceScore: scores?.significance,
        presentationScore: scores?.presentation,
        overallScore: scores?.overall,
        comments,
        recommendation,
        status: "submitted",
        submittedAt: new Date()
      };

      const review = await storage.createReview(reviewData);

      // Calculate FRONS reward based on review quality and timeliness
      const fronsReward = 50 + Math.floor(Math.random() * 50); // 50-100 FRONS
      
      // Update review with reward
      await storage.updateReview(review.id, {
        fronsReward,
        status: "completed"
      });

      // Create transaction record for FRONS reward
      await storage.createTransaction({
        userId: req.user!.id,
        type: "review_reward",
        amount: fronsReward,
        status: "confirmed"
      });

      res.json({ review: { ...review, fronsReward }, message: "Review submitted successfully" });
    } catch (error) {
      console.error('Error submitting review:', error);
      res.status(500).json({ error: "Failed to submit review" });
    }
  });

  app.post("/api/reviews/community-vote", requireAuth, async (req: AuthenticatedRequest, res) => {
    try {
      const { dociId, manuscriptId, voteType, reason } = req.body;
      
      if (!dociId && !manuscriptId) {
        return res.status(400).json({ error: "DOCI ID or Manuscript ID is required" });
      }

      if (!["approve", "disapprove"].includes(voteType)) {
        return res.status(400).json({ error: "Vote type must be 'approve' or 'disapprove'" });
      }

      const vote = await storage.createCommunityVote({
        dociId,
        manuscriptId,
        voterId: req.user!.id,
        voteType,
        reason
      });

      // Small FRONS reward for community participation
      const fronsReward = 5;
      await storage.createTransaction({
        userId: req.user!.id,
        type: "community_vote",
        amount: fronsReward,
        status: "confirmed"
      });

      res.json({ vote, fronsReward, message: "Community vote submitted successfully" });
    } catch (error) {
      console.error('Error submitting community vote:', error);
      res.status(500).json({ error: "Failed to submit community vote" });
    }
  });

  // DOCI Registry API Routes
  app.post("/api/doci/register", requireAuth, async (req: AuthenticatedRequest, res) => {
    try {
      const { prefix, suffix, metadataUri, contentHash, doiType, manuscriptId } = req.body;
      const userId = req.user!.id;

      // Validate required fields
      if (!prefix || !suffix || !metadataUri || !contentHash || !doiType) {
        return res.status(400).json({ 
          error: 'Missing required fields: prefix, suffix, metadataUri, contentHash, doiType' 
        });
      }

      // Import DOCI program service
      const { DociProgramService } = await import('./lib/doci-program');

      // Validate content hash format
      if (!DociProgramService.validateContentHash(contentHash)) {
        return res.status(400).json({ 
          error: 'Invalid content hash format. Must be a 64-character hex string.' 
        });
      }

      // Validate prefix format
      if (!DociProgramService.validatePrefix(prefix)) {
        return res.status(400).json({ 
          error: 'Invalid prefix format. Must start with "10." followed by alphanumeric characters.' 
        });
      }

      const fullDoci = `${prefix}/${suffix}`;

      // Check if DOCI already exists in database
      const existingDoci = await storage.getDociByFullDoci(fullDoci);
      if (existingDoci) {
        return res.status(409).json({ 
          error: `DOCI ${fullDoci} already exists` 
        });
      }

      // Initialize DOCI program service
      const dociService = new DociProgramService();

      // Register DOCI on Solana blockchain
      const result = await dociService.registerPublicationDoci({
        prefix,
        suffix,
        metadataUri,
        contentHash,
        doiType
      });

      // Save DOCI record to database
      const dociRecord = await storage.createDoci({
        userId,
        manuscriptId: manuscriptId || null,
        prefix,
        suffix,
        fullDoci,
        metadataUri,
        contentHash,
        doiType,
        solanaAccount: result.dociAccount.toString(),
        transactionSignature: result.transactionSignature,
        status: 'pending'
      });

      // Update manuscript with DOCI minted flag if manuscriptId provided
      if (manuscriptId) {
        await storage.updateManuscript(manuscriptId, {
          dociMinted: true,
          nftAddress: result.dociAccount.toString()
        });
      }

      res.json({
        success: true,
        doci: dociRecord,
        solanaAccount: result.dociAccount.toString(),
        transactionSignature: result.transactionSignature,
        fullDoci,
        explorerUrl: `https://explorer.solana.com/tx/${result.transactionSignature}?cluster=devnet`
      });

    } catch (error: any) {
      console.error('DOCI registration error:', error);
      res.status(500).json({ 
        error: error.message || 'Failed to register DOCI' 
      });
    }
  });

  app.get("/api/doci/user/:userId", requireAuth, async (req: AuthenticatedRequest, res) => {
    try {
      const userId = parseInt(req.params.userId);
      const docis = await storage.getDocisByUser(userId);
      res.json({ docis });
    } catch (error) {
      console.error('Get user DOCIs error:', error);
      res.status(500).json({ error: 'Failed to get user DOCIs' });
    }
  });

  app.get("/api/doci/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const doci = await storage.getDoci(id);
      
      if (!doci) {
        return res.status(404).json({ error: 'DOCI not found' });
      }

      res.json({ doci });
    } catch (error) {
      console.error('Get DOCI error:', error);
      res.status(500).json({ error: 'Failed to get DOCI' });
    }
  });

  app.get("/api/doci/lookup/:fullDoci", async (req, res) => {
    try {
      const fullDoci = req.params.fullDoci;
      const doci = await storage.getDociByFullDoci(fullDoci);
      
      if (!doci) {
        return res.status(404).json({ error: 'DOCI not found' });
      }

      res.json({ doci });
    } catch (error) {
      console.error('DOCI lookup error:', error);
      res.status(500).json({ error: 'Failed to lookup DOCI' });
    }
  });

  app.post("/api/doci/generate-suffix", requireAuth, async (req: AuthenticatedRequest, res) => {
    try {
      const { DociProgramService } = await import('./lib/doci-program');
      const suffix = DociProgramService.generateSuffix();
      res.json({ suffix });
    } catch (error) {
      console.error('Generate suffix error:', error);
      res.status(500).json({ error: 'Failed to generate suffix' });
    }
  });

  // Dashboard stats route
  app.get("/api/dashboard/stats/:userId", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      const manuscripts = await storage.getManuscriptsByUser(userId);
      const reviews = await storage.getReviewsByReviewer(userId);
      const assignments = await storage.getPeerReviewAssignmentsByReviewer(userId);
      
      const stats = {
        publishedPapers: manuscripts.filter(m => m.status === 'accepted').length,
        totalManuscripts: manuscripts.length,
        completedReviews: reviews.filter(r => r.status === 'completed').length,
        pendingReviews: assignments.filter(a => a.status === 'assigned').length,
        fronsBalance: user.fronsBalance || 0,
        stakedFrons: user.stakedFrons || 0,
        reputationScore: user.reputationScore || 0,
        docisMinted: manuscripts.filter(m => m.dociMinted).length,
      };
      
      res.json(stats);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch dashboard stats" });
    }
  });

  // Partners API routes
  app.get("/api/partners", async (req, res) => {
    try {
      const partners = [
        // Blockchain Infrastructure Partners
        {
          id: 1,
          name: "Solana Foundation",
          category: "blockchain",
          logoUrl: "https://cryptologos.cc/logos/solana-sol-logo.png",
          shortDesc: "Core infrastructure support for high-performance blockchain operations.",
          partnershipType: "Core Infrastructure",
          websiteUrl: "https://solana.org",
          detailsHtml: `
            <div class="space-y-4">
              <p>Solana Foundation provides the core blockchain infrastructure that powers FRONSCIERS' decentralized academic publishing platform. With transaction speeds of 65,000 TPS and minimal fees, Solana enables seamless DOCI minting and FRONS token operations.</p>
              <h4 class="font-semibold">Key Benefits:</h4>
              <ul class="list-disc list-inside space-y-1 text-sm text-muted-foreground">
                <li>Ultra-fast transaction processing for real-time manuscript submissions</li>
                <li>Low-cost operations enabling micro-transactions for peer reviews</li>
                <li>Robust validator network ensuring 99.9% uptime</li>
                <li>Advanced smart contract capabilities for complex academic workflows</li>
              </ul>
            </div>
          `
        },
        {
          id: 2,
          name: "Metaplex",
          category: "blockchain",
          logoUrl: "https://docs.metaplex.com/assets/images/solanaLogoMark-7fc71b4b8c8c4b0c5c4c4b0c5c4c4b0c.png",
          shortDesc: "NFT/Token creation tools integration for DOCI minting.",
          partnershipType: "NFT Infrastructure",
          websiteUrl: "https://metaplex.com",
          detailsHtml: `
            <div class="space-y-4">
              <p>Metaplex provides the NFT infrastructure that enables FRONSCIERS to mint DOCIs (Direct On-Chain Identifiers) as unique, verifiable digital assets representing each manuscript throughout its lifecycle.</p>
              <h4 class="font-semibold">Integration Features:</h4>
              <ul class="list-disc list-inside space-y-1 text-sm text-muted-foreground">
                <li>Automated DOCI NFT minting upon manuscript submission</li>
                <li>Metadata standards for academic content verification</li>
                <li>Royalty mechanisms for author revenue sharing</li>
                <li>Compressed NFTs for cost-effective large-scale operations</li>
              </ul>
            </div>
          `
        },
        {
          id: 3,
          name: "Phantom Wallet",
          category: "blockchain",
          logoUrl: "https://phantom.app/img/logo.png",
          shortDesc: "Enhanced wallet UX for seamless user interactions.",
          partnershipType: "Wallet Integration",
          websiteUrl: "https://phantom.app",
          detailsHtml: `
            <div class="space-y-4">
              <p>Phantom Wallet integration provides FRONSCIERS users with a seamless, secure way to interact with the platform, manage FRONS tokens, and participate in governance activities.</p>
              <h4 class="font-semibold">User Experience Benefits:</h4>
              <ul class="list-disc list-inside space-y-1 text-sm text-muted-foreground">
                <li>One-click connection for new users</li>
                <li>Integrated FRONS token management</li>
                <li>Secure transaction signing for all platform operations</li>
                <li>Mobile-first design for researchers on the go</li>
              </ul>
            </div>
          `
        },
        // DeFi Partners
        {
          id: 4,
          name: "Serum",
          category: "defi",
          logoUrl: "https://raw.githubusercontent.com/solana-labs/token-list/main/assets/mainnet/SERMqiGsqGdAnuXty8FLdEaWXFBhm9rXfZ6JqMHJrb4/logo.png",
          shortDesc: "DEX liquidity integration for FRONS token trading.",
          partnershipType: "Liquidity Provider",
          websiteUrl: "https://serum.org",
          detailsHtml: `
            <div class="space-y-4">
              <p>Serum DEX integration enables deep liquidity for FRONS tokens, allowing researchers and institutions to easily acquire tokens for platform participation and governance activities.</p>
              <h4 class="font-semibold">Trading Features:</h4>
              <ul class="list-disc list-inside space-y-1 text-sm text-muted-foreground">
                <li>Deep liquidity pools for FRONS/SOL and FRONS/USDC pairs</li>
                <li>Integrated trading interface within FRONSCIERS platform</li>
                <li>Advanced order types for institutional participants</li>
                <li>Market making programs for enhanced price stability</li>
              </ul>
            </div>
          `
        },
        // Academic Tool Partners
        {
          id: 5,
          name: "Zotero",
          category: "academic",
          logoUrl: "https://www.zotero.org/static/images/theme/zotero-logo.1519312231.svg",
          shortDesc: "Reference management integration for seamless citation workflows.",
          partnershipType: "Reference Management",
          websiteUrl: "https://zotero.org",
          detailsHtml: `
            <div class="space-y-4">
              <p>Zotero integration allows researchers to seamlessly import their existing reference libraries and automatically generate blockchain-verified citations for FRONSCIERS publications.</p>
              <h4 class="font-semibold">Workflow Integration:</h4>
              <ul class="list-disc list-inside space-y-1 text-sm text-muted-foreground">
                <li>One-click import from existing Zotero libraries</li>
                <li>Automatic DOCI linkage for cited publications</li>
                <li>Real-time citation tracking and metrics</li>
                <li>Collaborative reference sharing between researchers</li>
              </ul>
            </div>
          `
        },
        {
          id: 6,
          name: "Mendeley",
          category: "academic",
          logoUrl: "https://www.mendeley.com/favicon.ico",
          shortDesc: "Academic networking and reference management integration.",
          partnershipType: "Research Network",
          websiteUrl: "https://mendeley.com",
          detailsHtml: `
            <div class="space-y-4">
              <p>Mendeley integration brings social networking capabilities to FRONSCIERS, enabling researchers to discover collaborators and track research trends across their academic networks.</p>
              <h4 class="font-semibold">Network Features:</h4>
              <ul class="list-disc list-inside space-y-1 text-sm text-muted-foreground">
                <li>Academic profile synchronization</li>
                <li>Collaborative research group formation</li>
                <li>Automated research interest matching</li>
                <li>Cross-platform publication discovery</li>
              </ul>
            </div>
          `
        },
        {
          id: 7,
          name: "EndNote",
          category: "academic",
          logoUrl: "https://endnote.com/favicon.ico",
          shortDesc: "Professional reference management for institutional users.",
          partnershipType: "Enterprise Integration",
          websiteUrl: "https://endnote.com",
          detailsHtml: `
            <div class="space-y-4">
              <p>EndNote integration provides enterprise-grade reference management capabilities for large institutions and research organizations using FRONSCIERS.</p>
              <h4 class="font-semibold">Enterprise Features:</h4>
              <ul class="list-disc list-inside space-y-1 text-sm text-muted-foreground">
                <li>Institutional library synchronization</li>
                <li>Advanced metadata management</li>
                <li>Bulk import and export capabilities</li>
                <li>Administrative controls for research compliance</li>
              </ul>
            </div>
          `
        }
      ];

      res.json(partners);
    } catch (error) {
      console.error("Error fetching partners:", error);
      res.status(500).json({ error: "Failed to fetch partners" });
    }
  });

  app.post("/api/partners/contact", async (req, res) => {
    try {
      const { name, email, organization, message } = req.body;

      // Validate input
      if (!name || !email || !organization || !message) {
        return res.status(400).json({ error: "All fields are required" });
      }

      // Email validation
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(email)) {
        return res.status(400).json({ error: "Invalid email address" });
      }

      // Log the inquiry
      console.log("Partnership inquiry received:", {
        name,
        email,
        organization,
        message,
        timestamp: new Date().toISOString()
      });

      // Simulate email sending delay
      await new Promise(resolve => setTimeout(resolve, 1000));

      res.json({ 
        success: true, 
        message: "Partnership inquiry received successfully. We'll contact you within 48 hours." 
      });
    } catch (error) {
      console.error("Error processing partnership inquiry:", error);
      res.status(500).json({ error: "Failed to process inquiry" });
    }
  });

  // External database search API
  app.post("/api/search/external", async (req, res) => {
    try {
      const { query, databases, field } = req.body;

      if (!query || !databases || !Array.isArray(databases)) {
        return res.status(400).json({ error: "Query and databases are required" });
      }

      const results: any[] = [];

      // Search FRONSCIERS database
      if (databases.includes("fronsciers")) {
        try {
          const manuscripts = await storage.getAllManuscripts();
          const fronscierResults = manuscripts
            .filter((manuscript) => {
              const searchLower = query.toLowerCase();
              const matchesTitle = manuscript.title.toLowerCase().includes(searchLower);
              const matchesAbstract = manuscript.abstract.toLowerCase().includes(searchLower);
              const matchesAuthors = manuscript.authors.toLowerCase().includes(searchLower);
              const matchesKeywords = manuscript.keywords.toLowerCase().includes(searchLower);
              const matchesField = field === "All Fields" || manuscript.researchField === field;
              
              return (matchesTitle || matchesAbstract || matchesAuthors || matchesKeywords) && matchesField;
            })
            .map((manuscript) => ({
              id: `fronsciers_${manuscript.id}`,
              title: manuscript.title,
              authors: manuscript.authors,
              abstract: manuscript.abstract,
              source: "FRONSCIERS",
              sourceIcon: "Database",
              sourceColor: "blue",
              publishedDate: manuscript.createdAt,
              citationCount: manuscript.citationCount || 0,
              url: `/manuscript/${manuscript.id}`,
              doi: manuscript.dociMinted ? `DOCI-${manuscript.id}` : null,
              keywords: manuscript.keywords.split(",").map(k => k.trim()),
              researchField: manuscript.researchField,
              isOpenAccess: true,
              isPeerReviewed: manuscript.status === "accepted"
            }));

          results.push(...fronscierResults);
        } catch (error) {
          console.error("Error searching FRONSCIERS:", error);
        }
      }

      // Mock external database results (for demonstration)
      if (databases.includes("pubmed")) {
        const pubmedResults = [
          {
            id: "pubmed_34123456",
            title: `${query} in biomedical research: A systematic review`,
            authors: "Smith J, Johnson M, Williams K",
            abstract: `This systematic review examines the role of ${query} in modern biomedical research. Our analysis of 150 studies reveals significant implications for clinical practice and future research directions.`,
            source: "PubMed",
            sourceIcon: "FileText",
            sourceColor: "green",
            publishedDate: "2024-03-15",
            citationCount: 42,
            url: "https://pubmed.ncbi.nlm.nih.gov/34123456",
            doi: "10.1234/example.2024.001",
            keywords: [query, "biomedical", "systematic review", "clinical"],
            researchField: "Medicine",
            isOpenAccess: true,
            isPeerReviewed: true
          },
          {
            id: "pubmed_34789012",
            title: `Novel approaches to ${query}: Recent advances and future perspectives`,
            authors: "Brown A, Davis R, Taylor S",
            abstract: `Recent technological advances have opened new possibilities for ${query} research. This review discusses emerging methodologies and their potential impact on the field.`,
            source: "PubMed",
            sourceIcon: "FileText",
            sourceColor: "green",
            publishedDate: "2024-02-28",
            citationCount: 28,
            url: "https://pubmed.ncbi.nlm.nih.gov/34789012",
            doi: "10.1234/example.2024.002",
            keywords: [query, "methodology", "advances", "technology"],
            researchField: "Biology",
            isOpenAccess: false,
            isPeerReviewed: true
          }
        ];
        results.push(...pubmedResults);
      }

      if (databases.includes("scopus")) {
        const scopusResults = [
          {
            id: "scopus_85123456789",
            title: `Engineering applications of ${query}: A comprehensive analysis`,
            authors: "Garcia M, Lopez C, Rodriguez P",
            abstract: `This comprehensive analysis explores the engineering applications of ${query}, examining implementation challenges and success factors across multiple industries.`,
            source: "Scopus",
            sourceIcon: "Globe",
            sourceColor: "orange",
            publishedDate: "2024-01-20",
            citationCount: 67,
            url: "https://www.scopus.com/record/display.uri?eid=2-s2.0-85123456789",
            doi: "10.1016/example.2024.003",
            keywords: [query, "engineering", "applications", "industry"],
            researchField: "Engineering",
            isOpenAccess: true,
            isPeerReviewed: true
          }
        ];
        results.push(...scopusResults);
      }

      if (databases.includes("google_scholar")) {
        const scholarResults = [
          {
            id: "scholar_abc123",
            title: `${query} and machine learning: Bridging theory and practice`,
            authors: "Chen L, Wang X, Liu Y",
            abstract: `This work bridges the gap between theoretical ${query} research and practical machine learning applications, presenting a novel framework for real-world implementation.`,
            source: "Google Scholar",
            sourceIcon: "Search",
            sourceColor: "red",
            publishedDate: "2024-04-10",
            citationCount: 15,
            url: "https://scholar.google.com/citations?view_op=view_citation&hl=en&citation_for_view=abc123",
            doi: null,
            keywords: [query, "machine learning", "theory", "practice"],
            researchField: "Computer Science",
            isOpenAccess: true,
            isPeerReviewed: false
          }
        ];
        results.push(...scholarResults);
      }

      if (databases.includes("cochrane")) {
        const cochraneResults = [
          {
            id: "cochrane_cd012345",
            title: `${query} for healthcare interventions: A Cochrane systematic review`,
            authors: "Thompson K, Anderson B, Clark D",
            abstract: `This Cochrane systematic review evaluates the effectiveness of ${query}-based interventions in healthcare settings, analyzing high-quality randomized controlled trials.`,
            source: "Cochrane",
            sourceIcon: "BookOpen",
            sourceColor: "purple",
            publishedDate: "2024-03-05",
            citationCount: 89,
            url: "https://www.cochranelibrary.com/cdsr/doi/10.1002/14651858.CD012345",
            doi: "10.1002/14651858.CD012345",
            keywords: [query, "healthcare", "systematic review", "intervention"],
            researchField: "Medicine",
            isOpenAccess: true,
            isPeerReviewed: true
          }
        ];
        results.push(...cochraneResults);
      }

      // Sort results by citation count (descending) and then by date (newest first)
      results.sort((a, b) => {
        if (b.citationCount !== a.citationCount) {
          return b.citationCount - a.citationCount;
        }
        return new Date(b.publishedDate).getTime() - new Date(a.publishedDate).getTime();
      });

      res.json({
        success: true,
        query,
        databases,
        totalResults: results.length,
        results: results.slice(0, 50) // Limit to 50 results for performance
      });

    } catch (error) {
      console.error("Error in external search:", error);
      res.status(500).json({ error: "Search failed" });
    }
  });

  // Manuscript review assignment API
  app.post("/api/reviews/assign", requireAuth, async (req: AuthenticatedRequest, res) => {
    try {
      const { manuscriptId } = req.body;
      const reviewerId = req.user.id;

      if (!manuscriptId) {
        return res.status(400).json({ error: "Manuscript ID is required" });
      }

      // Create peer review assignment
      const assignment = await storage.createPeerReviewAssignment({
        manuscriptId: parseInt(manuscriptId),
        reviewerId,
        status: "assigned",
        assignedAt: new Date(),
        dueDate: new Date(Date.now() + 14 * 24 * 60 * 60 * 1000), // 14 days from now
      });

      res.json({
        success: true,
        message: "Review assignment accepted successfully",
        assignment
      });
    } catch (error) {
      console.error("Error assigning review:", error);
      res.status(500).json({ error: "Failed to assign review" });
    }
  });

  // Submit manuscript review with consensus check
  app.post("/api/reviews/submit-review", requireAuth, async (req: AuthenticatedRequest, res) => {
    try {
      const { 
        manuscriptId, 
        noveltyScore, 
        methodologyScore, 
        clarityScore, 
        comments, 
        recommendation 
      } = req.body;
      
      const reviewerId = req.user.id;

      if (!manuscriptId || !noveltyScore || !methodologyScore || !clarityScore || !comments || !recommendation) {
        return res.status(400).json({ error: "All review fields are required" });
      }

      // Calculate overall score
      const overallScore = (
        parseInt(noveltyScore) + 
        parseInt(methodologyScore) + 
        parseInt(clarityScore)
      ) / 3;

      // Create the review
      const review = await storage.createReview({
        manuscriptId: parseInt(manuscriptId),
        reviewerId,
        noveltyScore: parseInt(noveltyScore),
        methodologyScore: parseInt(methodologyScore),
        clarityScore: parseInt(clarityScore),
        overallScore: Math.round(overallScore * 10) / 10,
        comments,
        recommendation,
        status: "completed",
        submittedAt: new Date(),
      });

      // Check for consensus (3 reviews)
      const allReviews = await storage.getReviewsByManuscript(parseInt(manuscriptId));
      const completedReviews = allReviews.filter(r => r.status === "completed");

      let consensusReached = false;
      let newStatus = "under_review";

      if (completedReviews.length >= 3) {
        const acceptCount = completedReviews.filter(r => r.recommendation === "accept").length;
        const avgScore = completedReviews.reduce((sum, r) => sum + r.overallScore, 0) / completedReviews.length;
        
        // Consensus for acceptance: majority accept with average score >= 4.0
        if (acceptCount >= 2 && avgScore >= 4.0) {
          consensusReached = true;
          newStatus = "accepted";
        } 
        // Consensus for rejection: majority reject or average score < 3.0
        else if (acceptCount < 2 || avgScore < 3.0) {
          consensusReached = true;
          newStatus = "rejected";
        }
        // Need revision: mixed reviews or moderate scores
        else {
          consensusReached = true;
          newStatus = "needs_revision";
        }

        // Update manuscript status
        await storage.updateManuscript(parseInt(manuscriptId), { 
          status: newStatus as any
        });
      }

      // Award FRONS tokens for review completion
      const fronsReward = recommendation === "accept" && overallScore >= 4.0 ? 120 : 85;
      await storage.createTransaction({
        userId: reviewerId,
        type: "review_reward",
        amount: fronsReward,
        description: `Review reward for manuscript ${manuscriptId}`,
        status: "completed",
      });

      res.json({
        success: true,
        message: "Review submitted successfully",
        review,
        consensusReached,
        manuscriptStatus: newStatus,
        fronsEarned: fronsReward,
        reviewsCompleted: completedReviews.length
      });

    } catch (error) {
      console.error("Error submitting review:", error);
      res.status(500).json({ error: "Failed to submit review" });
    }
  });

  // Get reviewer assignments
  app.get("/api/reviews/my-assignments", requireAuth, async (req: AuthenticatedRequest, res) => {
    try {
      const reviewerId = req.user.id;
      
      const assignments = await storage.getPeerReviewAssignmentsByReviewer(reviewerId);
      const assignmentsWithManuscripts = await Promise.all(
        assignments.map(async (assignment) => {
          const manuscript = await storage.getManuscript(assignment.manuscriptId);
          return {
            ...assignment,
            manuscript
          };
        })
      );

      res.json({
        success: true,
        assignments: assignmentsWithManuscripts
      });
    } catch (error) {
      console.error("Error fetching assignments:", error);
      res.status(500).json({ error: "Failed to fetch assignments" });
    }
  });

  // Get reviewer statistics
  app.get("/api/reviews/stats", requireAuth, async (req: AuthenticatedRequest, res) => {
    try {
      const reviewerId = req.user.id;
      
      const reviews = await storage.getReviewsByReviewer(reviewerId);
      const transactions = await storage.getTransactionsByUser(reviewerId);
      const reviewTransactions = transactions.filter(t => t.type === "review_reward");
      
      const stats = {
        completed: reviews.filter(r => r.status === "completed").length,
        avgRating: reviews.length > 0 ? 
          reviews.reduce((sum, r) => sum + r.overallScore, 0) / reviews.length : 0,
        tokensEarned: reviewTransactions.reduce((sum, t) => sum + t.amount, 0),
        rank: Math.floor(Math.random() * 1000) + 1 // Mock ranking
      };

      res.json({
        success: true,
        stats
      });
    } catch (error) {
      console.error("Error fetching review stats:", error);
      res.status(500).json({ error: "Failed to fetch review stats" });
    }
  });

  // Recommendation Engine Routes
  app.post("/api/recommendations/track-interaction", requireAuth, async (req: AuthenticatedRequest, res) => {
    try {
      const { targetType, targetId, action, duration, metadata } = req.body;
      const interaction = await storage.createUserInteraction({
        userId: req.user!.id,
        targetType,
        targetId,
        action,
        duration,
        metadata: metadata ? JSON.stringify(metadata) : null
      });
      res.json(interaction);
    } catch (error) {
      res.status(500).json({ error: "Failed to track interaction" });
    }
  });

  app.get("/api/recommendations/user-interests", requireAuth, async (req: AuthenticatedRequest, res) => {
    try {
      const interests = await storage.getUserInterests(req.user!.id);
      res.json(interests);
    } catch (error) {
      res.status(500).json({ error: "Failed to get user interests" });
    }
  });

  app.post("/api/recommendations/update-interest", requireAuth, async (req: AuthenticatedRequest, res) => {
    try {
      const { topic, weight, source } = req.body;
      
      // Check if interest already exists
      const existingInterests = await storage.getUserInterests(req.user!.id);
      const existing = existingInterests.find(i => i.topic === topic);
      
      if (existing) {
        const updated = await storage.updateUserInterest(existing.id, { weight });
        res.json(updated);
      } else {
        const interest = await storage.createUserInterest({
          userId: req.user!.id,
          topic,
          weight,
          source
        });
        res.json(interest);
      }
    } catch (error) {
      res.status(500).json({ error: "Failed to update interest" });
    }
  });

  app.get("/api/recommendations/papers/:userId", requireAuth, async (req: AuthenticatedRequest, res) => {
    try {
      const { userId } = req.params;
      const userInterests = await storage.getUserInterests(parseInt(userId));
      const allManuscripts = await storage.getAllManuscripts();
      
      // Content-based filtering algorithm
      const recommendations = allManuscripts
        .filter(m => m.status === "published")
        .map(manuscript => {
          let score = 0;
          const manuscriptText = `${manuscript.title} ${manuscript.abstract} ${manuscript.keywords}`.toLowerCase();
          
          userInterests.forEach(interest => {
            if (manuscriptText.includes(interest.topic.toLowerCase())) {
              score += interest.weight;
            }
          });
          
          return { manuscript, score };
        })
        .filter(item => item.score > 0)
        .sort((a, b) => b.score - a.score)
        .slice(0, 10)
        .map(item => item.manuscript);
      
      res.json(recommendations);
    } catch (error) {
      res.status(500).json({ error: "Failed to get paper recommendations" });
    }
  });

  app.get("/api/recommendations/collaborators/:userId", requireAuth, async (req: AuthenticatedRequest, res) => {
    try {
      const { userId } = req.params;
      const userInterests = await storage.getUserInterests(parseInt(userId));
      const allUsers = await storage.getAllUsers();
      
      const recommendations = [];
      for (const user of allUsers) {
        if (user.id === parseInt(userId)) continue;
        
        const theirInterests = await storage.getUserInterests(user.id);
        let similarityScore = 0;
        
        // Calculate interest similarity
        userInterests.forEach(myInterest => {
          const theirInterest = theirInterests.find(t => t.topic === myInterest.topic);
          if (theirInterest) {
            similarityScore += Math.min(myInterest.weight, theirInterest.weight) / 100;
          }
        });
        
        if (similarityScore > 0) {
          recommendations.push({
            user: {
              id: user.id,
              username: user.username || user.walletAddress.slice(0, 8) + "...",
              institutionName: user.institutionName
            },
            score: similarityScore,
            commonInterests: userInterests.filter(myInt => 
              theirInterests.some(theirInt => theirInt.topic === myInt.topic)
            ).map(i => i.topic)
          });
        }
      }
      
      recommendations.sort((a, b) => b.score - a.score);
      res.json(recommendations.slice(0, 10));
    } catch (error) {
      res.status(500).json({ error: "Failed to get collaborator recommendations" });
    }
  });

  app.get("/api/recommendations/trending-topics", async (req, res) => {
    try {
      const { timeWindow = 'weekly' } = req.query;
      const trendingTopics = await storage.getTrendingTopics(timeWindow as string);
      res.json(trendingTopics);
    } catch (error) {
      res.status(500).json({ error: "Failed to get trending topics" });
    }
  });

  app.post("/api/recommendations/feedback", requireAuth, async (req: AuthenticatedRequest, res) => {
    try {
      const { recommendationType, recommendedItemId, feedback, reason } = req.body;
      const feedbackRecord = await storage.createRecommendationFeedback({
        userId: req.user!.id,
        recommendationType,
        recommendedItemId,
        feedback,
        reason
      });
      res.json(feedbackRecord);
    } catch (error) {
      res.status(500).json({ error: "Failed to save feedback" });
    }
  });

  // PDF Upload endpoint with real-time dashboard updates
  // Medical Research API endpoints
  app.get("/api/research/search", async (req, res) => {
    try {
      const { query, database, year = "2024" } = req.query as { 
        query: string; 
        database?: string; 
        year?: string; 
      };

      if (!query) {
        return res.status(400).json({ error: "Search query is required" });
      }

      let results = [];

      if (database === "pubmed" || !database) {
        const pubmedResults = await medicalResearchService.searchPubMed(query, year);
        results = [...results, ...pubmedResults];
      }

      if (database === "scopus" || !database) {
        const scopusResults = await medicalResearchService.searchScopus(query, year);
        results = [...results, ...scopusResults];
      }

      if (database === "cochrane" || !database) {
        const cochraneResults = await medicalResearchService.searchCochrane(query, year);
        results = [...results, ...cochraneResults];
      }

      res.json({
        results,
        total: results.length,
        query,
        databases: database || "all",
        year
      });
    } catch (error) {
      console.error("Medical research search error:", error);
      res.status(500).json({ error: "Failed to search medical databases" });
    }
  });

  app.get("/api/research/trending", async (req, res) => {
    try {
      const { year = "2024" } = req.query as { year?: string };
      
      const trendingTopics = [
        "COVID-19 treatment", "cancer immunotherapy", "cardiovascular disease",
        "diabetes management", "mental health", "artificial intelligence in medicine",
        "gene therapy", "telemedicine", "precision medicine", "vaccine development"
      ];

      const randomTopic = trendingTopics[Math.floor(Math.random() * trendingTopics.length)];
      const results = await medicalResearchService.searchAllDatabases(randomTopic, year);

      res.json({
        results: results.slice(0, 10),
        topic: randomTopic,
        year
      });
    } catch (error) {
      console.error("Error fetching trending research:", error);
      res.status(500).json({ error: "Failed to fetch trending research" });
    }
  });

  app.post("/api/manuscripts/upload-pdf", requireAuth, upload.single('pdf'), async (req: AuthenticatedRequest, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ error: "No PDF file uploaded" });
      }

      const { title, abstract, authors, keywords, researchField } = req.body;

      // Extract text from PDF (simplified for now)
      let extractedText = "";
      // Note: PDF parsing can be added later with proper configuration

      // Create manuscript record
      const manuscript = await storage.createManuscript({
        userId: req.user!.id,
        title: title || req.file.originalname.replace('.pdf', ''),
        abstract: abstract || extractedText.substring(0, 500) + "...",
        authors: authors || req.user!.username || "Unknown Author",
        researchField: researchField || "Computer Science",
        keywords: keywords || "research, academic, publication",
        status: "draft"
      });

      // Create DOCI for the manuscript
      const dociSuffix = `${manuscript.id}-${Date.now()}`;
      await storage.createDoci({
        userId: req.user!.id,
        manuscriptId: manuscript.id,
        prefix: "DOCI",
        suffix: dociSuffix,
        fullDoci: `fronsciers.org/doci/DOCI-${dociSuffix}`,
        solanaAccount: `solana_account_${manuscript.id}`,
        transactionSignature: `tx_${manuscript.id}_${Date.now()}`,
        metadataUri: `https://fronsciers.org/metadata/${manuscript.id}`,
        contentHash: `hash_${manuscript.id}`,
        doiType: "manuscript"
      });

      // Track interaction for recommendation engine
      await storage.createUserInteraction({
        userId: req.user!.id,
        targetType: "manuscript",
        targetId: manuscript.id.toString(),
        action: "upload",
        duration: 0,
        metadata: JSON.stringify({ 
          title: manuscript.title,
          researchField: manuscript.researchField 
        })
      });

      // Update research interests based on uploaded content
      if (keywords) {
        const keywordList = keywords.split(',').map((k: string) => k.trim());
        for (const keyword of keywordList.slice(0, 3)) {
          const existingInterests = await storage.getUserInterests(req.user!.id);
          const existing = existingInterests.find(i => i.topic.toLowerCase() === keyword.toLowerCase());
          
          if (existing) {
            await storage.updateUserInterest(existing.id, { 
              weight: Math.min(1000, existing.weight + 100) 
            });
          } else {
            await storage.createUserInterest({
              userId: req.user!.id,
              topic: keyword,
              weight: 500,
              source: "implicit"
            });
          }
        }
      }

      // Broadcast real-time dashboard update
      broadcastDashboardUpdate('MANUSCRIPT_UPLOADED', {
        manuscriptId: manuscript.id,
        title: manuscript.title,
        authorId: req.user!.id,
        authorName: req.user!.username || req.user!.walletAddress.slice(0, 8) + "...",
        researchField: manuscript.researchField,
        dociId: `DOCI-${dociSuffix}`
      });

      // Clean up uploaded file
      try {
        fs.unlinkSync(req.file.path);
      } catch (error) {
        console.warn("Failed to clean up uploaded file:", error);
      }

      res.json({
        success: true,
        manuscriptId: manuscript.id,
        dociId: `DOCI-${dociSuffix}`,
        message: "PDF uploaded and processed successfully"
      });

    } catch (error) {
      console.error("PDF upload error:", error);
      
      // Clean up file on error
      if (req.file?.path) {
        try {
          fs.unlinkSync(req.file.path);
        } catch (cleanupError) {
          console.warn("Failed to clean up file on error:", cleanupError);
        }
      }
      
      res.status(500).json({ error: "Failed to process PDF upload" });
    }
  });

  // Feedback submission endpoint
  app.post("/api/feedback", async (req, res) => {
    try {
      const { name, email, rating, comments, page, userAgent } = req.body;
      
      // Validate required fields
      if (!rating || rating < 1 || rating > 5) {
        return res.status(400).json({ error: "Valid rating (1-5) is required" });
      }
      
      if (!comments || comments.trim().length === 0) {
        return res.status(400).json({ error: "Comments are required" });
      }
      
      if (!page) {
        return res.status(400).json({ error: "Page information is required" });
      }

      const feedback = await storage.createFeedback({
        name: name || "Anonymous",
        email: email || null,
        rating: parseInt(rating),
        comments: comments.trim(),
        page,
        userAgent: userAgent || null
      });

      // Send Slack notification for low ratings (≤ 2 stars)
      if (rating <= 2) {
        try {
          const slackMessage = {
            text: `🚨 Low Rating Feedback Received`,
            blocks: [
              {
                type: "section",
                text: {
                  type: "mrkdwn",
                  text: `*Low Rating Alert* (${rating}/5 stars)\n*Page:* ${page}\n*User:* ${name || "Anonymous"}\n*Comments:* ${comments}`
                }
              },
              {
                type: "context",
                elements: [
                  {
                    type: "mrkdwn",
                    text: `Submitted at ${new Date().toISOString()}`
                  }
                ]
              }
            ]
          };

          // Send to Slack if webhook URL is configured
          if (process.env.SLACK_WEBHOOK_URL) {
            await fetch(process.env.SLACK_WEBHOOK_URL, {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify(slackMessage)
            });
          }
        } catch (slackError) {
          console.error("Failed to send Slack notification:", slackError);
        }
      }

      res.status(201).json({ 
        success: true, 
        message: "Feedback submitted successfully",
        feedbackId: feedback.id 
      });

    } catch (error) {
      console.error("Feedback submission error:", error);
      res.status(500).json({ error: "Failed to submit feedback" });
    }
  });

  // Sample data generation endpoint for development
  app.post("/api/recommendations/generate-sample-data", requireAuth, async (req: AuthenticatedRequest, res) => {
    try {
      const userId = req.user!.id;
      
      // Generate sample research interests
      const sampleInterests = [
        { topic: "Machine Learning", weight: 850, source: "explicit" },
        { topic: "Blockchain", weight: 750, source: "implicit" },
        { topic: "Artificial Intelligence", weight: 900, source: "explicit" },
        { topic: "Data Science", weight: 600, source: "implicit" },
        { topic: "Computer Vision", weight: 700, source: "explicit" }
      ];

      for (const interest of sampleInterests) {
        await storage.createUserInterest({
          userId,
          ...interest
        });
      }

      // Generate sample trending topics
      const trendingTopics = [
        { topic: "Large Language Models", category: "AI", score: 95, manuscriptCount: 42, growthRate: 2500, timeWindow: "weekly" },
        { topic: "Quantum Computing", category: "Physics", score: 88, manuscriptCount: 18, growthRate: 1800, timeWindow: "weekly" },
        { topic: "DeFi Protocols", category: "Blockchain", score: 82, manuscriptCount: 35, growthRate: 2200, timeWindow: "weekly" },
        { topic: "Climate Change", category: "Environmental", score: 79, manuscriptCount: 67, growthRate: 1500, timeWindow: "weekly" },
        { topic: "Gene Editing", category: "Biology", score: 76, manuscriptCount: 23, growthRate: 1900, timeWindow: "weekly" }
      ];

      for (const topic of trendingTopics) {
        await storage.createTrendingTopic(topic);
      }

      // Track sample interactions
      const interactions = [
        { targetType: "manuscript", targetId: "1", action: "view", duration: 120 },
        { targetType: "manuscript", targetId: "2", action: "download", duration: 5 },
        { targetType: "author", targetId: "2", action: "view_profile", duration: 45 },
        { targetType: "manuscript", targetId: "3", action: "thumbs_up", duration: 2 }
      ];

      for (const interaction of interactions) {
        await storage.createUserInteraction({
          userId,
          ...interaction,
          metadata: null
        });
      }

      res.json({ message: "Sample data generated successfully" });
    } catch (error) {
      console.error("Error generating sample data:", error);
      res.status(500).json({ error: "Failed to generate sample data" });
    }
  });

  const httpServer = createServer(app);
  
  // Setup WebSocket server for real-time research journey updates
  const wss = new WebSocketServer({ 
    server: httpServer, 
    path: '/ws',
    perMessageDeflate: false,
    maxPayload: 16 * 1024
  });
  
  wss.on('connection', (ws: WebSocket) => {
    const clientId = Math.random().toString(36).substring(7);
    wsClients.set(clientId, {
      ws,
      subscriptions: new Set()
    });

    console.log(`WebSocket client connected: ${clientId}`);

    ws.on('message', (data: Buffer) => {
      try {
        const message = JSON.parse(data.toString());
        const client = wsClients.get(clientId);
        
        if (!client) return;

        switch (message.type) {
          case 'SUBSCRIBE_DOCI_UPDATES':
            if (message.dociId) {
              client.subscriptions.add(message.dociId);
              console.log(`Client ${clientId} subscribed to DOCI updates: ${message.dociId}`);
            }
            break;
          
          case 'UNSUBSCRIBE_DOCI_UPDATES':
            if (message.dociId) {
              client.subscriptions.delete(message.dociId);
              console.log(`Client ${clientId} unsubscribed from DOCI updates: ${message.dociId}`);
            }
            break;
        }
      } catch (error) {
        console.error('Error parsing WebSocket message:', error);
      }
    });

    ws.on('close', () => {
      wsClients.delete(clientId);
      console.log(`WebSocket client disconnected: ${clientId}`);
    });

    ws.on('error', (error) => {
      console.error(`WebSocket error for client ${clientId}:`, error);
      wsClients.delete(clientId);
    });
  });

  return httpServer;
}
