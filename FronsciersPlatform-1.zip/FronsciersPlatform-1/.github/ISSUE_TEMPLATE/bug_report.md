---
name: Bug Report
about: Create a report to help us improve FRONSCIERS
title: '[BUG] '
labels: ['bug']
assignees: ''
---

## 🐛 Bug Description
A clear and concise description of what the bug is.

## 🔄 Steps to Reproduce
1. Navigate to '...'
2. Click on '...'
3. Enter '...'
4. See error

## ✅ Expected Behavior
A clear and concise description of what you expected to happen.

## ❌ Actual Behavior
A clear and concise description of what actually happened.

## 🖼️ Screenshots
If applicable, add screenshots to help explain your problem.

## 🌐 Environment
**Browser:**
- [ ] Chrome (version: )
- [ ] Firefox (version: )
- [ ] Safari (version: )
- [ ] Edge (version: )

**Device:**
- [ ] Desktop
- [ ] Mobile (specify device: )
- [ ] Tablet (specify device: )

**Operating System:**
- [ ] Windows (version: )
- [ ] macOS (version: )
- [ ] Linux (distribution: )
- [ ] iOS (version: )
- [ ] Android (version: )

**Screen Resolution:** (e.g., 1920x1080)

## 🔧 Additional Context
**Console Errors:**
```
Paste any console error messages here
```

**Network Errors:**
```
Paste any 4xx/5xx HTTP responses here
```

**Blockchain Context (if applicable):**
- Wallet used: (Phantom, Solflare, etc.)
- Network: (Devnet, Mainnet)
- Transaction hash: (if relevant)

## 🎯 Severity
- [ ] **Critical** - App crashes, data loss, security vulnerability
- [ ] **High** - Major feature broken, significant user impact
- [ ] **Medium** - Minor feature affected, workarounds available
- [ ] **Low** - Cosmetic issue, edge case

## 🏷️ Component
- [ ] Authentication/Wallet
- [ ] Manuscript Submission
- [ ] Peer Review System
- [ ] DOCI Registry
- [ ] Governance/DAO
- [ ] Tokenomics
- [ ] Search/Discovery
- [ ] Mobile Interface
- [ ] PWA Functionality
- [ ] API Integration

## 📋 Checklist
- [ ] I have searched existing issues to ensure this is not a duplicate
- [ ] I have provided all requested information
- [ ] I have tested this on the latest version
- [ ] I have included relevant screenshots/logs