# FRONSCIERS Deployment Guide

## Overview

This guide covers the complete CI/CD pipeline and infrastructure setup for the FRONSCIERS blockchain academic publishing platform.

## Infrastructure Components

### 1. GitHub Actions Workflows

- **`backend-ci.yml`**: Builds, tests, and pushes backend Docker images
- **`frontend-ci.yml`**: Builds frontend, runs Lighthouse PWA audits, deploys to Vercel/Netlify  
- **`deploy.yml`**: Orchestrates production deployment to Kubernetes

### 2. Infrastructure as Code

#### Terraform (`infrastructure/terraform/`)
- **AWS EKS cluster** with auto-scaling node groups
- **RDS PostgreSQL** with automated backups and monitoring
- **VPC** with public/private subnets and NAT gateways
- **AWS Secrets Manager** for secure configuration
- **CloudWatch** logging and monitoring

#### Pulumi (`infrastructure/pulumi/`)
- Alternative IaC implementation using TypeScript
- Same infrastructure components as Terraform
- Integrated with Kubernetes deployments

### 3. Monitoring Stack

- **Prometheus** for metrics collection
- **Grafana** for visualization dashboards
- **AlertManager** for incident notifications
- **Custom health checks** for Solana blockchain and IPFS

## Quick Start

### Prerequisites

1. **Docker Hub account** for container registry
2. **AWS account** with appropriate permissions
3. **Kubernetes cluster** (EKS recommended)
4. **GitHub repository** with Actions enabled

### Required Secrets

Configure these secrets in your GitHub repository:

```bash
# Docker Registry
DOCKER_USERNAME=your-dockerhub-username
DOCKER_PASSWORD=your-dockerhub-token

# Kubernetes
KUBE_CONFIG=base64-encoded-kubeconfig

# Frontend Deployment
VERCEL_TOKEN=your-vercel-token
VERCEL_ORG_ID=your-org-id
VERCEL_PROJECT_ID=your-project-id
VITE_API_URL=https://api.fronsciers.com
VITE_SOLANA_NETWORK=mainnet-beta
VITE_SOLANA_RPC_URL=your-solana-rpc-endpoint

# Application Secrets
DATABASE_URL=postgresql://user:pass@host:5432/db
SOLANA_PRIVATE_KEY=your-solana-private-key
IPFS_API_KEY=your-ipfs-service-key
ANTHROPIC_API_KEY=your-anthropic-key
PUBMED_API_KEY=your-pubmed-key
SCOPUS_API_KEY=your-scopus-key
COCHRANE_API_KEY=your-cochrane-key

# Monitoring
SLACK_WEBHOOK_URL=your-slack-webhook
```

### Infrastructure Deployment

#### Option 1: Terraform

```bash
cd infrastructure/terraform
terraform init
terraform plan -var="db_password=secure_password"
terraform apply
```

#### Option 2: Pulumi

```bash
cd infrastructure/pulumi
npm install
pulumi config set dbPassword --secret
pulumi config set solanaPrivateKey --secret
pulumi up
```

### Application Deployment

1. **Trigger deployment** by pushing to `main` branch
2. **Monitor progress** in GitHub Actions
3. **Verify deployment** at health endpoints:
   - Backend: `https://api.fronsciers.com/health`
   - Frontend: `https://fronsciers.com`

### Manual Deployment

```bash
chmod +x infrastructure/scripts/deploy.sh
./infrastructure/scripts/deploy.sh
```

## Monitoring and Alerts

### Health Endpoints

- `/health` - Basic application health
- `/ready` - Readiness for traffic
- `/metrics` - Prometheus metrics

### Key Metrics Monitored

- **Application**: Response time, error rate, throughput
- **Infrastructure**: CPU, memory, disk usage
- **Database**: Connection count, query performance
- **Blockchain**: Transaction success rate, account balance
- **IPFS**: Node connectivity, storage usage

### Alert Thresholds

- **Critical**: Service down, high error rate (>10%)
- **Warning**: High response time (>2s), resource usage (>80%)
- **Info**: Certificate expiration (30 days)

## Security Features

- **Multi-stage Docker builds** with non-root user
- **Network policies** for pod-to-pod communication
- **TLS termination** with Let's Encrypt certificates
- **Rate limiting** on API endpoints
- **Secret management** via Kubernetes secrets

## Performance Optimizations

- **Horizontal Pod Autoscaler** for traffic spikes
- **CDN integration** for static assets
- **Database connection pooling**
- **Redis caching** for API responses
- **GZIP compression** for responses

## Backup and Recovery

- **Database**: Automated daily backups with 7-day retention
- **Container images**: Versioned and stored in registry
- **Configuration**: Infrastructure as Code in Git
- **Disaster recovery**: Multi-AZ deployment

## Cost Optimization

- **Spot instances** for non-critical workloads
- **Auto-scaling** to match demand
- **Resource limits** to prevent over-provisioning
- **Monitoring dashboards** for cost tracking

## Troubleshooting

### Common Issues

1. **Pod crashes**: Check logs with `kubectl logs`
2. **DNS resolution**: Verify service names and namespaces
3. **Certificate issues**: Check cert-manager logs
4. **Database connectivity**: Verify security groups and passwords

### Useful Commands

```bash
# Check deployment status
kubectl get pods -n fronsciers-production

# View application logs
kubectl logs -f deployment/fronsciers-backend -n fronsciers-production

# Port forward for local testing
kubectl port-forward svc/fronsciers-backend-service 8080:80 -n fronsciers-production

# Scale deployment
kubectl scale deployment fronsciers-backend --replicas=5 -n fronsciers-production
```

## Support

For deployment issues:
1. Check GitHub Actions logs
2. Review Kubernetes events: `kubectl get events`
3. Monitor Grafana dashboards
4. Check Slack alerts for automated notifications

This deployment pipeline ensures reliable, scalable, and secure operation of the FRONSCIERS platform with comprehensive monitoring and automated recovery capabilities.