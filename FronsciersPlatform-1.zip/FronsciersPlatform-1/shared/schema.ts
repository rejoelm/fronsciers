import { pgTable, text, serial, integer, boolean, timestamp, jsonb, numeric } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  walletAddress: text("wallet_address").notNull().unique(),
  username: text("username"),
  email: text("email"),
  institutionName: text("institution_name"),
  researchField: text("research_field"),
  reputationScore: integer("reputation_score").default(0),
  fronsBalance: integer("frons_balance").default(0),
  stakedFrons: integer("staked_frons").default(0),
  // Advanced reputation metrics
  reviewsCompleted: integer("reviews_completed").default(0),
  avgReviewQuality: integer("avg_review_quality").default(0), // 0-100 scale
  reviewResponseTime: integer("review_response_time").default(0), // average hours
  expertiseFields: text("expertise_fields").array(),
  isVerifiedReviewer: boolean("is_verified_reviewer").default(false),
  reviewerLevel: text("reviewer_level").default("novice"), // novice, intermediate, expert, distinguished
  lastActiveAt: timestamp("last_active_at").defaultNow(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const manuscripts = pgTable("manuscripts", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  title: text("title").notNull(),
  abstract: text("abstract").notNull(),
  authors: text("authors").notNull(),
  researchField: text("research_field").notNull(),
  keywords: text("keywords").notNull(),
  ipfsHash: text("ipfs_hash"),
  status: text("status").default("draft"), // draft, submitted, under_review, accepted, rejected
  submissionDate: timestamp("submission_date"),
  dociMinted: boolean("doci_minted").default(false),
  nftAddress: text("nft_address"),
  citationCount: integer("citation_count").default(0),
  viewCount: integer("view_count").default(0),
  // External integration fields
  externalId: text("external_id"),
  externalSource: text("external_source"), // crossref, arxiv, pubmed, etc.
  doi: text("doi"),
  arxivId: text("arxiv_id"),
  pubmedId: text("pubmed_id"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const feedback = pgTable("feedback", {
  id: serial("id").primaryKey(),
  name: text("name").default("Anonymous"),
  email: text("email"),
  rating: integer("rating").notNull(), // 1-5 stars
  comments: text("comments").notNull(),
  page: text("page").notNull(),
  userAgent: text("user_agent"),
  isResolved: boolean("is_resolved").default(false),
  adminNotes: text("admin_notes"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const reviews = pgTable("reviews", {
  id: serial("id").primaryKey(),
  dociId: text("doci_id"), // Support DOCI-based reviews
  manuscriptId: integer("manuscript_id").references(() => manuscripts.id),
  reviewerId: integer("reviewer_id").references(() => users.id),
  phase: text("phase").notNull(), // automated, expert, community
  noveltyScore: integer("novelty_score"),
  methodologyScore: integer("methodology_score"),
  clarityScore: integer("clarity_score"),
  significanceScore: integer("significance_score"),
  presentationScore: integer("presentation_score"),
  overallScore: integer("overall_score"), // calculated weighted average
  comments: text("comments"),
  feedback: text("feedback"), // Structured feedback for multi-tier reviews
  recommendation: text("recommendation"), // accept, minor_revisions, major_revisions, reject
  fronsReward: integer("frons_reward").default(0),
  reputationImpact: integer("reputation_impact").default(0),
  qualityRating: integer("quality_rating"), // peer assessment of review quality
  timeToComplete: integer("time_to_complete"), // hours taken to complete
  confidenceLevel: integer("confidence_level"), // reviewer's confidence 1-5
  expertiseMatch: integer("expertise_match"), // algorithm calculated 0-100
  status: text("status").default("pending"), // pending, submitted, completed, rated
  deadline: timestamp("deadline"),
  submittedAt: timestamp("submitted_at"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const daoProposals = pgTable("dao_proposals", {
  id: serial("id").primaryKey(),
  proposerId: integer("proposer_id").references(() => users.id),
  title: text("title").notNull(),
  description: text("description").notNull(),
  category: text("category").notNull(), // governance, tokenomics, platform
  status: text("status").default("active"), // active, passed, rejected, executed
  votesFor: integer("votes_for").default(0),
  votesAgainst: integer("votes_against").default(0),
  totalVotes: integer("total_votes").default(0),
  endDate: timestamp("end_date"),
  executionDate: timestamp("execution_date"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const votes = pgTable("votes", {
  id: serial("id").primaryKey(),
  proposalId: integer("proposal_id").references(() => daoProposals.id),
  voterId: integer("voter_id").references(() => users.id),
  voteType: text("vote_type").notNull(), // for, against
  votingPower: integer("voting_power").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const communityVotes = pgTable("community_votes", {
  id: serial("id").primaryKey(),
  dociId: text("doci_id"),
  manuscriptId: integer("manuscript_id").references(() => manuscripts.id),
  voterId: integer("voter_id").references(() => users.id),
  voteType: text("vote_type").notNull(), // approve, disapprove
  reason: text("reason"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const transactions = pgTable("transactions", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  type: text("type").notNull(), // mint_doci, review_reward, submission_fee, governance_stake
  amount: integer("amount").notNull(),
  transactionHash: text("transaction_hash"),
  status: text("status").default("pending"), // pending, confirmed, failed
  createdAt: timestamp("created_at").defaultNow(),
});

export const peerReviewAssignments = pgTable("peer_review_assignments", {
  id: serial("id").primaryKey(),
  manuscriptId: integer("manuscript_id").references(() => manuscripts.id),
  reviewerId: integer("reviewer_id").references(() => users.id),
  assignedBy: integer("assigned_by").references(() => users.id), // editor/system
  matchingScore: integer("matching_score"), // algorithm calculated 0-100
  invitationSent: boolean("invitation_sent").default(false),
  responseDeadline: timestamp("response_deadline"),
  reviewDeadline: timestamp("review_deadline"),
  priority: text("priority").default("normal"), // urgent, high, normal, low
  status: text("status").default("assigned"), // assigned, accepted, declined, completed, overdue
  declineReason: text("decline_reason"),
  assignedAt: timestamp("assigned_at").defaultNow(),
  respondedAt: timestamp("responded_at"),
});

// New table for reviewer reputation history
export const reputationHistory = pgTable("reputation_history", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  action: text("action").notNull(), // review_completed, review_quality_rated, deadline_met, deadline_missed
  points: integer("points").notNull(), // can be positive or negative
  reviewId: integer("review_id").references(() => reviews.id),
  description: text("description"),
  createdAt: timestamp("created_at").defaultNow(),
});

// New table for reviewer expertise tracking
export const reviewerExpertise = pgTable("reviewer_expertise", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  researchField: text("research_field").notNull(),
  subfields: text("subfields").array(),
  expertiseLevel: integer("expertise_level").default(1), // 1-5 scale
  reviewsInField: integer("reviews_in_field").default(0),
  avgQualityInField: integer("avg_quality_in_field").default(0),
  lastReviewInField: timestamp("last_review_in_field"),
  createdAt: timestamp("created_at").defaultNow(),
});

// DOCI (Direct On-Chain Identifier) registry table
export const dois = pgTable("dois", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  manuscriptId: integer("manuscript_id").references(() => manuscripts.id),
  prefix: text("prefix").notNull().default("10.FRONS"),
  suffix: text("suffix").notNull(),
  fullDoci: text("full_doci").notNull(), // prefix/suffix
  metadataUri: text("metadata_uri").notNull(),
  contentHash: text("content_hash").notNull(), // 32-byte hex string
  doiType: text("doi_type").notNull(), // article, preprint, dataset, etc.
  solanaAccount: text("solana_account").notNull(), // on-chain account address
  transactionSignature: text("transaction_signature").notNull(),
  status: text("status").default("pending"), // pending, confirmed, failed
  mintedAt: timestamp("minted_at").defaultNow(),
  createdAt: timestamp("created_at").defaultNow(),
});

// Insert schemas
export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
});

export const insertManuscriptSchema = createInsertSchema(manuscripts).omit({
  id: true,
  createdAt: true,
  submissionDate: true,
});

export const insertReviewSchema = createInsertSchema(reviews).omit({
  id: true,
  createdAt: true,
  submittedAt: true,
});

export const insertDaoProposalSchema = createInsertSchema(daoProposals).omit({
  id: true,
  createdAt: true,
});

export const insertVoteSchema = createInsertSchema(votes).omit({
  id: true,
  createdAt: true,
});

export const insertTransactionSchema = createInsertSchema(transactions).omit({
  id: true,
  createdAt: true,
});

export const insertPeerReviewAssignmentSchema = createInsertSchema(peerReviewAssignments).omit({
  id: true,
  assignedAt: true,
});

export const insertReputationHistorySchema = createInsertSchema(reputationHistory).omit({
  id: true,
  createdAt: true,
});

export const insertReviewerExpertiseSchema = createInsertSchema(reviewerExpertise).omit({
  id: true,
  createdAt: true,
});

export const insertDociSchema = createInsertSchema(dois).omit({
  id: true,
  createdAt: true,
  mintedAt: true,
});

export const insertCommunityVoteSchema = createInsertSchema(communityVotes).omit({
  id: true,
  createdAt: true,
});

// Recommendation Engine Tables
export const userInteractions = pgTable("user_interactions", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  targetType: text("target_type").notNull(), // 'manuscript', 'author', 'topic'
  targetId: text("target_id").notNull(),
  action: text("action").notNull(), // 'view', 'download', 'cite', 'bookmark', 'share'
  duration: integer("duration"), // time spent in seconds
  metadata: text("metadata"), // JSON string for additional context
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const userInterests = pgTable("user_interests", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  topic: text("topic").notNull(),
  weight: integer("weight").notNull().default(100), // interest strength (0-1000)
  source: text("source").notNull(), // 'explicit', 'implicit', 'collaborative'
  lastUpdated: timestamp("last_updated").defaultNow().notNull(),
});

export const collaborationNetwork = pgTable("collaboration_network", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  collaboratorId: integer("collaborator_id").notNull().references(() => users.id),
  strength: integer("strength").notNull().default(100), // collaboration strength (0-1000)
  manuscriptCount: integer("manuscript_count").notNull().default(0),
  citationCount: integer("citation_count").notNull().default(0),
  lastCollaboration: timestamp("last_collaboration").defaultNow().notNull(),
});

export const recommendationFeedback = pgTable("recommendation_feedback", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  recommendationType: text("recommendation_type").notNull(), // 'paper', 'collaborator', 'topic'
  recommendedItemId: text("recommended_item_id").notNull(),
  feedback: text("feedback").notNull(), // 'like', 'dislike', 'irrelevant', 'helpful'
  reason: text("reason"), // optional feedback reason
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const trendingTopics = pgTable("trending_topics", {
  id: serial("id").primaryKey(),
  topic: text("topic").notNull(),
  category: text("category").notNull(),
  score: integer("score").notNull().default(0), // trending score (0-10000)
  manuscriptCount: integer("manuscript_count").notNull().default(0),
  growthRate: integer("growth_rate").notNull().default(0), // percentage growth * 100
  timeWindow: text("time_window").notNull(), // 'daily', 'weekly', 'monthly'
  calculatedAt: timestamp("calculated_at").defaultNow().notNull(),
});

// Insert schemas for recommendation tables
export const insertUserInteractionSchema = createInsertSchema(userInteractions).omit({
  id: true,
  createdAt: true,
});

export const insertUserInterestSchema = createInsertSchema(userInterests).omit({
  id: true,
  lastUpdated: true,
});

export const insertCollaborationNetworkSchema = createInsertSchema(collaborationNetwork).omit({
  id: true,
  lastCollaboration: true,
});

export const insertRecommendationFeedbackSchema = createInsertSchema(recommendationFeedback).omit({
  id: true,
  createdAt: true,
});

export const insertTrendingTopicSchema = createInsertSchema(trendingTopics).omit({
  id: true,
  calculatedAt: true,
});

// Types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type Manuscript = typeof manuscripts.$inferSelect;
export type InsertManuscript = z.infer<typeof insertManuscriptSchema>;
export type Review = typeof reviews.$inferSelect;
export type InsertReview = z.infer<typeof insertReviewSchema>;
export type DaoProposal = typeof daoProposals.$inferSelect;
export type InsertDaoProposal = z.infer<typeof insertDaoProposalSchema>;
export type Vote = typeof votes.$inferSelect;
export type InsertVote = z.infer<typeof insertVoteSchema>;
export type Transaction = typeof transactions.$inferSelect;
export type InsertTransaction = z.infer<typeof insertTransactionSchema>;
export type PeerReviewAssignment = typeof peerReviewAssignments.$inferSelect;
export type InsertPeerReviewAssignment = z.infer<typeof insertPeerReviewAssignmentSchema>;
export type ReputationHistory = typeof reputationHistory.$inferSelect;
export type InsertReputationHistory = z.infer<typeof insertReputationHistorySchema>;
export type ReviewerExpertise = typeof reviewerExpertise.$inferSelect;
export type InsertReviewerExpertise = z.infer<typeof insertReviewerExpertiseSchema>;
export type Doci = typeof dois.$inferSelect;
export type InsertDoci = z.infer<typeof insertDociSchema>;
export type CommunityVote = typeof communityVotes.$inferSelect;
export type InsertCommunityVote = z.infer<typeof insertCommunityVoteSchema>;
export type UserInteraction = typeof userInteractions.$inferSelect;
export type InsertUserInteraction = z.infer<typeof insertUserInteractionSchema>;
export type UserInterest = typeof userInterests.$inferSelect;
export type InsertUserInterest = z.infer<typeof insertUserInterestSchema>;
export type CollaborationNetwork = typeof collaborationNetwork.$inferSelect;
export type InsertCollaborationNetwork = z.infer<typeof insertCollaborationNetworkSchema>;
export type RecommendationFeedback = typeof recommendationFeedback.$inferSelect;
export type InsertRecommendationFeedback = z.infer<typeof insertRecommendationFeedbackSchema>;
export type TrendingTopic = typeof trendingTopics.$inferSelect;
export type InsertTrendingTopic = z.infer<typeof insertTrendingTopicSchema>;

// Feedback schema
export const insertFeedbackSchema = createInsertSchema(feedback);
export type Feedback = typeof feedback.$inferSelect;
export type InsertFeedback = z.infer<typeof insertFeedbackSchema>;
