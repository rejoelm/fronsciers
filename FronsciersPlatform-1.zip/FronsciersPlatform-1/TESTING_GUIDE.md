# FRONSCIERS Testing Environment Setup

## QA Testing Infrastructure

### Blockchain Testing (Solana Devnet)
```bash
# Environment setup for Solana testing
export SOLANA_NETWORK=devnet
export CLUSTER_URL=https://api.devnet.solana.com
```

### Required Test Wallets
- **Author Wallet**: For manuscript submission and DOCI minting
- **Reviewer Wallet**: For receiving FRONS tokens and staking
- **Admin Wallet**: For governance operations

### Critical Test Scenarios

#### 1. DOCI NFT Minting Flow
```typescript
// Test manuscript submission → DOCI generation → NFT minting
POST /api/manuscripts/submit
POST /api/doci/register
// Verify Solana transaction success
```

#### 2. Token Transfer Verification
```typescript
// Test reviewer reward distribution
POST /api/tokenomics/reward-review
// Verify SPL token balance update
```

#### 3. Staking Operations
```typescript
// Test FRONS token staking
POST /api/tokenomics/stake
POST /api/tokenomics/unstake
// Verify staking pool balance changes
```

### Real-Time Testing
The Research Journey Progress Bar updates are triggered by WebSocket events:
```javascript
ws.send(JSON.stringify({
  type: 'MANUSCRIPT_STATUS_UPDATE',
  manuscriptId: 123,
  newStatus: 'under_review'
}));
```

### Performance Benchmarks
- Page load time: < 3 seconds
- API response time: < 500ms
- Blockchain transaction confirmation: < 30 seconds
- WebSocket message delivery: < 100ms

### Mobile Testing Breakpoints
- 320px: iPhone SE, small Android devices
- 768px: iPad, Android tablets
- 1440px: Desktop displays

### PWA Installation Testing
#### Android (Chrome)
1. Navigate to application
2. Look for "Install app" prompt
3. Verify standalone mode functionality
4. Test offline capabilities

#### iOS (Safari)
1. Open in Safari browser
2. Share → Add to Home Screen
3. Verify app icon and launch
4. Test PWA features

### Security Testing Checklist
#### SQL Injection Prevention
```sql
-- Test these inputs in forms:
'; DROP TABLE users; --
' OR '1'='1
<script>alert('XSS')</script>
```

#### XSS Protection
Test script injection in:
- Review comment fields
- Manuscript title/abstract
- User profile information

### Third-Party Integration Testing
#### Academic APIs (Sandbox Mode)
- PubMed: Test paper import functionality
- Scopus: Verify citation data retrieval
- Cochrane: Test systematic review integration

#### IPFS Integration
- File upload to Pinata
- Hash generation verification
- File retrieval testing

### Accessibility Testing
- Screen reader compatibility (NVDA, JAWS)
- Keyboard navigation (Tab, Enter, Esc)
- Color contrast ratios (WCAG 2.1 AA)
- Alt text for images
- ARIA labels for interactive elements

### Performance Monitoring
- Lighthouse audit scores ≥ 90
- Core Web Vitals compliance
- Bundle size optimization
- Image compression verification

## Feedback System Implementation

The feedback form appears on every page with these capabilities:
- Star rating (1-5)
- Optional contact information
- Comment submission
- Automatic Slack notifications for ratings ≤ 2
- Database storage for admin review

### Feedback API Testing
```bash
curl -X POST http://localhost:5000/api/feedback \
  -H "Content-Type: application/json" \
  -d '{
    "rating": 2,
    "comments": "Navigation is confusing",
    "page": "/submit",
    "name": "Test User"
  }'
```

### Low Rating Alert System
Ratings of 2 stars or below trigger immediate Slack notifications to the development team for rapid response.

## Bug Reporting Workflow

### GitHub Issue Creation
1. Use provided templates in `.github/ISSUE_TEMPLATE/`
2. Include environment details
3. Provide reproduction steps
4. Add relevant screenshots
5. Classify severity appropriately

### Issue Labels
- `bug`: Defects and errors
- `enhancement`: Feature requests
- `security`: Security vulnerabilities
- `performance`: Performance issues
- `mobile`: Mobile-specific problems
- `blockchain`: Solana integration issues

### Priority Classification
- **P0**: Critical issues blocking release
- **P1**: Major functionality broken
- **P2**: Important but not blocking
- **P3**: Nice to have improvements

## Quality Gates for Release

### Pre-Production Checklist
- [ ] All P0/P1 bugs resolved
- [ ] 95%+ test case pass rate
- [ ] Accessibility compliance verified
- [ ] Performance benchmarks met
- [ ] Security scan passed
- [ ] Cross-browser compatibility confirmed
- [ ] Mobile responsiveness tested
- [ ] PWA functionality verified
- [ ] Blockchain integration tested
- [ ] Feedback system operational

### Automated Testing Pipeline
```yaml
# CI/CD quality gates
- unit_tests: 80%+ coverage
- integration_tests: All endpoints tested
- e2e_tests: Critical flows automated
- security_scan: No high/critical vulnerabilities
- lighthouse_audit: PWA/A11y/Performance ≥ 90
```

This comprehensive testing framework ensures FRONSCIERS meets production quality standards before deployment.