# GitHub Repository Creation Instructions

## Manual Repository Creation Required

Due to token permission limitations, please create the GitHub repository manually:

### Step 1: Create Repository on GitHub

1. Go to https://github.com/new
2. Repository name: `fronsciers-decoy`
3. Description: `Decoy repository for FRONSCIERS academic publishing platform with automated daily sync`
4. Set to **Private**
5. Do NOT initialize with README (we have prepared files)
6. Click "Create repository"

### Step 2: Push Decoy Content

```bash
cd original-repo-decoy
git remote add origin https://github.com/rejoelm/fronsciers-decoy.git
git branch -M main
git push -u origin main
```

### Step 3: Configure Repository Secrets

In the new repository settings:

1. Go to Settings > Secrets and variables > Actions
2. Click "New repository secret"
3. Name: `GITHUB_TOKEN`
4. Value: `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`
5. Click "Add secret"

### Step 4: Enable Actions

1. Go to the Actions tab in your repository
2. Click "I understand my workflows, enable them"
3. The daily sync workflow will be activated

### Step 5: Test the Setup

```bash
# Test demo server
cd original-repo-decoy
npm install
npm start

# Verify endpoints
curl http://localhost:3000/
curl http://localhost:3000/api/health
curl http://localhost:3000/api/demo
```

### Step 6: Configure Replit Integration

1. Import the repository to Replit from GitHub
2. Set environment variable: `GITHUB_TOKEN` with the same token value
3. The `.replit` configuration will auto-start the server

## Automated Features Active After Setup

- **Daily Sync**: Runs at midnight UTC
- **Security Filter**: Excludes sensitive files
- **Pull Requests**: Created for manual review
- **Branch Cleanup**: Automatic after 7 days
- **Demo Server**: Available on port 3000

## Repository Structure Created

```
fronsciers-decoy/
├── src/index.js                    # Demo HTTP server
├── README.md                       # Project documentation
├── package.json                    # Dependencies
├── .replit                         # Replit configuration
├── replit.nix                      # System dependencies
├── .github/workflows/sync.yml      # Daily sync automation
├── DECOY-SETUP.md                  # Complete documentation
└── GITHUB-SETUP-INSTRUCTIONS.md   # This file
```

The decoy repository system is fully prepared and will operate autonomously once the GitHub repository is created and configured.