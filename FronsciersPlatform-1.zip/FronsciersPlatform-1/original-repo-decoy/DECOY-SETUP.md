# FRONSCIERS Decoy Repository Setup Guide

## Overview

This decoy repository provides a sanitized demonstration version of the FRONSCIERS academic publishing platform. It automatically syncs safe content from the original repository while protecting sensitive information.

## Initial Setup

### 1. Update Original Repository URL

Set the environment variable for the source repository:

```bash
export ORIGINAL_REPO=https://github.com/rejoelm/fronsciers.git
```

### 2. Configure GitHub Token

The automation requires a GitHub Personal Access Token with the following permissions:

**Required Scopes:**
- `repo` - Full control of private repositories
- `workflow` - Update GitHub Action workflows
- `read:org` - Read organization membership

**Setup Instructions:**
1. Go to GitHub Settings > Developer settings > Personal access tokens
2. Generate new token (classic) with required scopes
3. Add as repository secret named `GITHUB_TOKEN`

```bash
# Via GitHub CLI (if available)
gh secret set GITHUB_TOKEN

# Via GitHub web interface
# Repository Settings > Secrets and variables > Actions > New repository secret
```

### 3. Configure Replit Environment

Add the following secrets in Replit:
- `GITHUB_TOKEN` - Your GitHub Personal Access Token
- `ORIGINAL_REPO` - Source repository URL (optional, defaults to hardcoded value)

## Daily Sync Mechanism

### How It Works

The GitHub Actions workflow (`/.github/workflows/sync.yml`) runs daily at midnight UTC and:

1. **Fetches Updates** - Pulls latest changes from original repository
2. **Selective Sync** - Merges only safe files (dependencies, documentation)
3. **Security Filter** - Excludes sensitive files (.env, secrets, keys)
4. **Pull Request** - Creates PR for manual review of changes
5. **Cleanup** - Removes old sync branches automatically

### Sync Process Details

```yaml
# Files that are synced:
✅ package.json (dependencies only)
✅ README.md (documentation updates)
✅ Public documentation files

# Files that are excluded:
❌ .env* files
❌ API keys and secrets
❌ Source code files
❌ Database configurations
❌ Private configuration files
```

### Manual Sync Trigger

You can manually trigger a sync:

```bash
# Via GitHub CLI
gh workflow run sync.yml

# Via GitHub web interface
# Actions tab > Daily Sync workflow > Run workflow
```

## Local Development

### Running the Decoy Server

```bash
# Install dependencies
npm install

# Start development server
npm run dev

# Production mode
npm start
```

### Testing the API

```bash
# Health check
curl http://localhost:3000/api/health

# Demo features
curl http://localhost:3000/api/demo

# API documentation
open http://localhost:3000/docs
```

## Replit Configuration

### Auto-pull Setup

The `.replit` configuration automatically:
- Installs Node.js dependencies
- Starts the demo server
- Configures environment for development

### Git Integration

```bash
# Set up Replit Git integration
git remote add origin https://github.com/username/fronsciers-decoy.git
git branch -M main
git push -u origin main

# Configure auto-pull from main branch
# Replit will automatically pull latest changes on each run
```

## Security Features

### Content Filtering

The sync process includes multiple security layers:

1. **File Extension Filtering** - Blocks sensitive file types
2. **Path Exclusion** - Ignores directories with sensitive content
3. **Content Scanning** - Removes environment variables and secrets
4. **Manual Review** - All changes require PR approval

### Safe Defaults

```bash
# Environment variables are sanitized
NODE_ENV=production
PORT=3000

# No database connections
# No API keys required
# No external service dependencies
```

## Maintenance

### Branch Cleanup

Old sync branches are automatically cleaned up after 7 days. Manual cleanup:

```bash
# List sync branches
git branch -r | grep sync-

# Delete specific branch
git push origin --delete sync-YYYYMMDD
```

### Monitoring Sync Status

Check the Actions tab in GitHub for:
- Daily sync execution logs
- Failed sync notifications
- PR creation status

### Troubleshooting

**Sync Failures:**
1. Check GitHub token permissions
2. Verify original repository accessibility
3. Review workflow logs for specific errors

**Replit Issues:**
1. Ensure `.replit` configuration is correct
2. Check Node.js version compatibility
3. Verify environment variables are set

## API Endpoints

The decoy server provides these demo endpoints:

| Endpoint | Description | Response |
|----------|-------------|----------|
| `GET /` | Welcome message | JSON overview |
| `GET /api/health` | Server status | Health information |
| `GET /api/demo` | Demo features | Feature list |
| `GET /docs` | Documentation | HTML docs page |

## Deployment Options

### Replit Deployment

1. Configure secrets in Replit environment
2. The server starts automatically with `npm start`
3. Access via Replit's provided URL

### External Deployment

```bash
# Environment setup
export NODE_ENV=production
export PORT=3000

# Install and start
npm install --production
npm start
```

## Support

For issues with the decoy repository:

1. Check the sync workflow logs
2. Verify GitHub token permissions
3. Review security filtering rules
4. Test local server functionality

The decoy system is designed to run autonomously once properly configured with the required secrets and permissions.