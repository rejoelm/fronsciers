# FRONSCIERS Demo Platform

A demonstration academic collaboration platform showcasing research paper submission, peer review workflows, and citation tracking capabilities.

## Features

- **Research Paper Submission**: Simple API for submitting academic manuscripts
- **Peer Review Workflow**: Basic review assignment and feedback collection
- **Citation Tracking**: Monitor paper citations and academic impact
- **Collaboration Tools**: Connect researchers and facilitate academic partnerships

## Quick Start

```bash
# Install dependencies
npm install

# Start the demo server
npm start

# Access the API
curl http://localhost:3000/api/demo
```

## API Endpoints

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/` | GET | Welcome message and API overview |
| `/api/health` | GET | Health check and server status |
| `/api/demo` | GET | Demo features and capabilities |
| `/docs` | GET | Interactive API documentation |

## Development

```bash
# Development mode with auto-reload
npm run dev

# Run tests
npm test

# Build for production
npm run build
```

## Environment Setup

```bash
# Set port (optional, defaults to 3000)
export PORT=3000

# Production mode
export NODE_ENV=production
```

## Demo Usage

This platform demonstrates core academic publishing features:

1. **Paper Submission**: Submit research papers with metadata
2. **Review Assignment**: Automatic reviewer matching based on expertise
3. **Review Process**: Structured peer review with scoring rubrics
4. **Publication Pipeline**: Streamlined publication workflow
5. **Citation Network**: Track academic citations and impact metrics

## Technology Stack

- **Backend**: Node.js with Express
- **API**: RESTful JSON endpoints
- **Documentation**: Built-in API docs
- **Deployment**: Docker-ready configuration

## License

MIT License - Educational and demonstration purposes

## Support

For questions about this demo platform, please refer to the API documentation at `/docs` or check the health status at `/api/health`.

---

*This is a demonstration version showcasing academic collaboration platform capabilities.*