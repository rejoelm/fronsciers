const express = require('express');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;

// Basic middleware
app.use(express.json());
app.use(express.static('public'));

// Root endpoint
app.get('/', (req, res) => {
  res.json({
    message: 'Hello from FRONSCIERS Decoy!',
    description: 'Academic collaboration demo platform',
    version: '1.0.0',
    endpoints: {
      '/api/health': 'Health check',
      '/api/demo': 'Demo functionality',
      '/docs': 'API documentation'
    }
  });
});

// Health check endpoint
app.get('/api/health', (req, res) => {
  res.json({
    status: 'healthy',
    timestamp: new Date().toISOString(),
    uptime: process.uptime()
  });
});

// Demo endpoint
app.get('/api/demo', (req, res) => {
  res.json({
    demo: 'Academic publishing platform features',
    features: [
      'Research paper submission',
      'Peer review workflow',
      'Citation tracking',
      'Collaboration tools'
    ],
    note: 'This is a demonstration version'
  });
});

// Documentation endpoint
app.get('/docs', (req, res) => {
  res.send(`
    <html>
      <head><title>FRONSCIERS Decoy API</title></head>
      <body>
        <h1>FRONSCIERS Demo API</h1>
        <h2>Available Endpoints:</h2>
        <ul>
          <li><code>GET /</code> - Welcome message</li>
          <li><code>GET /api/health</code> - Health check</li>
          <li><code>GET /api/demo</code> - Demo features</li>
          <li><code>GET /docs</code> - This documentation</li>
        </ul>
        <p>This is a demonstration platform for academic collaboration features.</p>
      </body>
    </html>
  `);
});

// Start server
app.listen(PORT, '0.0.0.0', () => {
  console.log(`FRONSCIERS Decoy server running on port ${PORT}`);
  console.log(`Visit http://localhost:${PORT} for API endpoints`);
});

module.exports = app;